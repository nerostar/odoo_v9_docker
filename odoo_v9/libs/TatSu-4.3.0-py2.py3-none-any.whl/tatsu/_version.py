# -*- coding: utf-8 -*-
from tatsu._config import __version__  # noqa
