﻿/**
 * Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
/* CKEDITOR.stylesSet.add('default',[]); */
CKEDITOR.stylesSet.add('appy_styles',[
  { name: 'Paragraph (page break after)', element: 'p',
    attributes : { 'style' : 'page-break-after:always' } }
]);
