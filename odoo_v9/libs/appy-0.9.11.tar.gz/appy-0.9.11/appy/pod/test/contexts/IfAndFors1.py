from appy.pod.test.contexts import Group

groups = [Group('group1'), Group('group2'), Group('toto')]
subListA = [('A1', 'A2', 'A3'), ('AA', 'AB', 'AC'), ('AX', 'AY', 'AZ')]
subListB = [('B1', 'B2'), ('BA', 'BB')]
para='P'
