xhtmlInput = '''
<div class="document">
<p>Some <strong>bold</strong> and some <em>italic</em> text.</p>
<p>A new paragraph.</p>
<p>A list with three items:</p>
<ul> 
<li>the first item</li> 
<li>another item</li> 
<li>the last item</li> 
</ul> 
<p>A last paragraph.</p>
</div>
<table border="1" cellpadding="1" cellspacing="1" style="width:500px">
	<tbody>
		<tr>
			<td>A1</td>
			<td colspan="1" rowspan="2">B12</td>
			<td>C1</td>
		</tr>
		<tr>
			<td>A2</td>
			<td>C2</td>
		</tr>
		<tr>
			<td colspan="2" rowspan="1">A3A2</td>
			<td>A3</td>
		</tr>
	</tbody>
</table>
'''
