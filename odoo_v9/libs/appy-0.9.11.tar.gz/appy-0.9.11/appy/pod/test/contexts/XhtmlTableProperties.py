xhtmlInput = '''
<table width="500px">
 <tr>
  <td>Hello pixels</td>
  <td>Table properties</td>
 </tr>
</table>
<table style="width:50%">
 <tr>
  <td>Hello percentage</td>
  <td>Table properties</td>
 </tr>
</table>
<!-- We will ignore silly width=0px -->
<table width="0px">
  <tr>
    <td style="border:1px solid #000000">
      <p>1</p>
    </td>
  </tr>
</table>
'''
