# -*- coding: utf-8 -*-
xhtmlInput='''
<table id="configabsences_cal" class="list timeline" width="90%">
      <colgroup>
       <col width="100px"/>
       <col style=""/><col style=""/><col style=""/><col style=""/><col style="background-color: #dedede"/><col style="background-color: #c0c0c0"/><col style="background-color: #c0c0c0"/><col style=""/><col style=""/><col style=""/><col style=""/><col style="background-color: #dedede"/><col style="background-color: #c0c0c0"/><col style="background-color: #c0c0c0"/><col style=""/><col style=""/><col style=""/><col style=""/><col style="background-color: #dedede"/><col style="background-color: #c0c0c0"/><col style="background-color: #c0c0c0"/><col style=""/><col style=""/><col style=""/><col style=""/><col style="background-color: #dedede"/><col style="background-color: #c0c0c0"/><col style="background-color: #c0c0c0"/><col style=""/><col style=""/><col style=""/><col style=""/><col style="background-color: #dedede"/><col style="background-color: #c0c0c0"/><col style="background-color: #c0c0c0"/><col style=""/><col style=""/><col style=""/><col style=""/><col style="background-color: #dedede"/><col style="background-color: #c0c0c0"/><col style="background-color: #c0c0c0"/>
       <col style="width: 75px"/>
      </colgroup>
      <tbody>
     <tr><th></th>
      <th colspan="6">Février 2015</th><th colspan="31">Mars 2015</th><th colspan="5"><acronym title="Avril 2015">A</acronym></th><th></th></tr>
     <tr><td></td> <td><b>L</b></td><td><b>M</b></td><td><b>M</b></td><td><b>J</b></td><td><b>V</b></td><td><b>S</b></td><td><b>D</b></td><td><b>L</b></td><td><b>M</b></td><td><b>M</b></td><td><b>J</b></td><td><b>V</b></td><td><b>S</b></td><td><b>D</b></td><td><b>L</b></td><td><b>M</b></td><td><b>M</b></td><td><b>J</b></td><td><b>V</b></td><td><b>S</b></td><td><b>D</b></td><td><b>L</b></td><td><b>M</b></td><td><b>M</b></td><td><b>J</b></td><td><b>V</b></td><td><b>S</b></td><td><b>D</b></td><td><b>L</b></td><td><b>M</b></td><td><b>M</b></td><td><b>J</b></td><td><b>V</b></td><td><b>S</b></td><td><b>D</b></td><td><b>L</b></td><td><b>M</b></td><td><b>M</b></td><td><b>J</b></td><td><b>V</b></td><td><b>S</b></td><td><b>D</b></td>
      <td></td></tr>
      <tr><td></td> <td><b>23</b></td><td><b>24</b></td><td><b>25</b></td><td><b>26</b></td><td><b>27</b></td><td><b>28</b></td><td><b>01</b></td><td><b>02</b></td><td><b>03</b></td><td><b>04</b></td><td><b>05</b></td><td><b>06</b></td><td><b>07</b></td><td><b>08</b></td><td><b>09</b></td><td><b>10</b></td><td><b>11</b></td><td><b>12</b></td><td><b>13</b></td><td><b>14</b></td><td><b>15</b></td><td><b>16</b></td><td><b>17</b></td><td><b>18</b></td><td><b>19</b></td><td><b>20</b></td><td><b>21</b></td><td><b>22</b></td><td><b>23</b></td><td><b>24</b></td><td><b>25</b></td><td><b>26</b></td><td><b>27</b></td><td><b>28</b></td><td><b>29</b></td><td><b>30</b></td><td><b>31</b></td><td><b>01</b></td><td><b>02</b></td><td><b>03</b></td><td><b>04</b></td><td><b>05</b></td>
       <td></td></tr>
        <tr>
         <td class="tlLeft"><a target="_blank" href="http://localhost:8080/config/GardesUser1350721915326376433960017169/view?page=preferences"><acronym title="Barbason Alain">Alain Barbason</acronym></a></td>
           <td style="background-color: #E5B620">z</td>
           <td style="background-color: #E5B620"></td>
           <td style="background-color: #E5B620"></td>
           <td></td>
           <td style="background-color: #E5B620"></td>
           <td style="background-color: #E5B620"></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td style="background-color: #13751F"></td>
           <td style="background-color: #13751F"></td>
           <td></td>
           <td></td>
           <td title="Congé (AM), Congrès (PM)" style="background-image: url(http://localhost:8080/ui/angled.png)"></td>
           <td></td>
           <td></td>
           <td style="background-color: #d08181"></td>
           <td style="background-color: #d08181"></td>
           <td style="background-color: #d08181"></td>
           <td style="background-color: #d08181"></td>
           <td style="background-color: #d08181"></td>
           <td style="background-color: #d08181"></td>
           <td style="background-color: #d08181"></td>
           <td style="background-color: #d08181"></td>
           <td style="background-color: #d08181"></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
          <td class="tlRight"><a target="_blank" href="http://localhost:8080/config/GardesUser1350721915326376433960017169/view?page=preferences"><acronym title="Barbason Alain">AB</acronym></a></td>
        </tr><tr>
          <td class="tlLeft"><a target="_blank" href="http://localhost:8080/config/GardesUser1350721915119231834005028903/view?page=preferences"><acronym title="Blom-Peters Lucien">LB</acronym></a></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td style="background-color: #d08181"></td>
           <td style="background-color: #d08181"></td>
           <td style="background-color: #d08181"></td>
           <td style="background-color: #d08181"></td>
           <td style="background-color: #d08181"></td>
           <td style="background-color: #d08181"></td>
           <td style="background-color: #d08181"></td>
           <td style="background-color: #d08181"></td>
           <td style="background-color: #d08181"></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td></td>
           <td class="tlRight"><a target="_blank" href="http://localhost:8080/config/GardesUser1350721915119231834005028903/view?page=preferences"><acronym title="Blom-Peters Lucien">LB</acronym></a></td>
        </tr>
      </tbody>
     <tbody id="configabsences_trs">
      <script>new AjaxData('configabsences_trs', 'absences:pxTotalRowsFromAjax', {}, 'configabsences')</script>
      <tr>
       <td class="tlLeft">
        <acronym title="Nombre de travailleurs disponibles"><b>P</b></acronym></td>
       <td>42</td><td>42</td><td>41</td><td>42</td><td>41</td><td>39</td><td>40</td><td>42</td><td>41</td><td>41</td><td>41</td><td>42</td><td>37</td><td>37</td><td>41</td><td>42</td><td>40</td><td>39</td><td>39</td><td>37</td><td>37</td><td>39</td><td>37</td><td>36</td><td>36</td><td>36</td><td>31</td><td>32</td><td>38</td><td>39</td><td>39</td><td>39</td><td>38</td><td>37</td><td>37</td><td>42</td><td>41</td><td>41</td><td>41</td><td>42</td><td>33</td><td>33</td>
       <td class="tlRight">
        <acronym title="Nombre de travailleurs disponibles"><b>P</b></acronym></td>
      </tr><tr>
       <td class="tlLeft">
        <acronym title="Nombre total de travailleurs"><b>T</b></acronym></td>
       <td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td><td>46</td>
       <td class="tlRight">
        <acronym title="Nombre total de travailleurs"><b>T</b></acronym></td>
      </tr>
     </tbody>
      <tbody> 
       
      <tr><td></td> 
       <td><b>23</b></td><td><b>24</b></td><td><b>25</b></td><td><b>26</b></td><td><b>27</b></td><td><b>28</b></td><td><b>01</b></td><td><b>02</b></td><td><b>03</b></td><td><b>04</b></td><td><b>05</b></td><td><b>06</b></td><td><b>07</b></td><td><b>08</b></td><td><b>09</b></td><td><b>10</b></td><td><b>11</b></td><td><b>12</b></td><td><b>13</b></td><td><b>14</b></td><td><b>15</b></td><td><b>16</b></td><td><b>17</b></td><td><b>18</b></td><td><b>19</b></td><td><b>20</b></td><td><b>21</b></td><td><b>22</b></td><td><b>23</b></td><td><b>24</b></td><td><b>25</b></td><td><b>26</b></td><td><b>27</b></td><td><b>28</b></td><td><b>29</b></td><td><b>30</b></td><td><b>31</b></td><td><b>01</b></td><td><b>02</b></td><td><b>03</b></td><td><b>04</b></td><td><b>05</b></td>
       <td></td></tr>
     <tr><td></td> 
      <td><b>L</b></td><td><b>M</b></td><td><b>M</b></td><td><b>J</b></td><td><b>V</b></td><td><b>S</b></td><td><b>D</b></td><td><b>L</b></td><td><b>M</b></td><td><b>M</b></td><td><b>J</b></td><td><b>V</b></td><td><b>S</b></td><td><b>D</b></td><td><b>L</b></td><td><b>M</b></td><td><b>M</b></td><td><b>J</b></td><td><b>V</b></td><td><b>S</b></td><td><b>D</b></td><td><b>L</b></td><td><b>M</b></td><td><b>M</b></td><td><b>J</b></td><td><b>V</b></td><td><b>S</b></td><td><b>D</b></td><td><b>L</b></td><td><b>M</b></td><td><b>M</b></td><td><b>J</b></td><td><b>V</b></td><td><b>S</b></td><td><b>D</b></td><td><b>L</b></td><td><b>M</b></td><td><b>M</b></td><td><b>J</b></td><td><b>V</b></td><td><b>S</b></td><td><b>D</b></td>
      <td></td></tr>
       
     <tr><th></th> 
      <th colspan="6">Février 2015</th><th colspan="31">Mars 2015</th><th colspan="5"><acronym title="Avril 2015">A</acronym></th><th></th></tr>
      </tbody>
     </table>

<p></p>
<table cellspacing="1" cellpadding="1" border="1" style="width:500px">
  <tbody>
    <tr><td style="width:20%">1</td>
            <td>Maecenas vitae ligula eu nunc ultrices consectetur a ac mi. Cras cursus risus elit. In leo tellus, vehicula nec velit id, rhoncus iaculis leo. Nullam nec dapibus urna. Morbi vulputate dictum turpis. ipsum non finibus.</td>
            <td>Maecenas vitae ligula eu nunc ultrices consectetur a ac mi. Cras cursus risus elit. In leo tellus, vehicula nec velit id, rhoncus iaculis leo. Nullam nec dapibus urna. Morbi vulputate dictum turpis. Vivamus eget consequat nisl. Nam tempus auctor ipsum at lobortis. Vesti laoreet. Cras tristique vitae ipsum non finibus.</td>
        </tr>
    <tr><td>2</td>
            <td>Maecenas vitae ligula eu nunc ultrices consectetur a ac mi. Cras cursus risus elit. In leo tellus, vehicula nec velit id, rhoncus iaculis leo. Nullam nec dapibus urna. Morbi vulputate dictum turpis. Vivamus eget consequat nisl. Nam tempus auctor ipsum at lobortis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nam semper ex vitae augue viverra, ut euismod quam laoreet. Cras tristique vitae ipsum non finibus.</td>
            <td>Maecenas vitae ligula eu nunc ultrices consectetur a ac mi. Cras curvitae ipsum non finibus.</td>
        </tr>
    <tr><td>3</td>
            <td>Maecenas vitae ligula eu nunc ultrices consectetur a ac mi. Cras cursus risus elit. In leo tellus, vehicula nec velit id, rhoncus iaculis leo. Nullam nec dapibus urna. Morbi vulputate dictum turpis. Vivamus eget consequat nisl. Nam tempus auctor ipsum at lobortis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
  </tbody>
</table>
'''
