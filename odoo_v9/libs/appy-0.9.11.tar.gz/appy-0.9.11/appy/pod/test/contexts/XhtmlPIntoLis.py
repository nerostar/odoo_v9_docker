# -*- coding: utf-8 -*-
xhtmlInput = '''
<ol>
 <li>Row 1;</li>
 <li>row 2 :
  <p>- sub-paragraph, row 1</p>
  <p>- sub-paragraph, row 2</p>
 </li>
 <li><p>row 3;</p></li>
 <li>row 4:
   <ul>
     <li>Sub list:<p>aa</p><div>bb</div><div>aa</div></li>
     <li><div>Hello</div></li>
     <li>Normal</li>
   </ul>
 </li>
</ol>
<ul>
  <li><div><p>Texte</p></div></li>
</ul>'''
