# -*- coding: utf-8 -*-
xhtmlInput = '''<table>
 <tr>
  <td>Default cell style</td>
  <td><p>This should also get the default cell style</p></td>
 </tr>
 <tr>
    <td>
      <p>First line</p>
      <p>Second line</p>
    </td>
    <td>
      <p>Text</p>
    </td>
  </tr>
  <tr>
    <td><p>Para1</p><span>Para2</span><p>Para3</p></td>
    <td><p>Para1</p><p>Para2</p><p>Para3</p></td>
  </tr>
</table>
'''
