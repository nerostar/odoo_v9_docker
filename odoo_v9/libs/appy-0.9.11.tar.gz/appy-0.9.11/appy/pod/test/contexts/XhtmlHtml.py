# -*- coding: utf-8 -*-
xhtmlInput = '''
  Manage BR <br> tags <br/><br />
  <input type="button" onclick="doSomething();">
'''
