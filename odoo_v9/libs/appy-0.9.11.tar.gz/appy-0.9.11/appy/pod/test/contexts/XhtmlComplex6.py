# -*- coding: utf-8 -*-
xhtmlInput = '''<div class="document">\n<p>Hallo?</p>\n</div>
<table cellspacing="0" cellpadding="0" style="width:100%">
  <tbody>
    <tr>
      <td>
        <div>
          <p>Text&nbsp;</p>
        </div>
      </td>
    </tr>
  </tbody>
</table>
'''
