# -*- coding: utf-8 -*-
xhtmlInput1 = '''
<p><i><p>***<em>Vu les demandes</em></p>a</i></p>
'''

xhtmlInput2 = '''
<p><br/><b>Proposition(s) / <i>Voorstel(len)</i>:</b><p>Approuver</p>
<i><p>***<em>Vu les demandes</em></p>a</i></p>
'''

xhtmlInput3 = '''
<p><br/><b>Proposition(s) / <i>Voorstel(len)</i>:</b><p>Approuver l'octroi de concessions pour sépultures</p>
<p>Montant de la Recette : 5.340 € </p>
<p>Article budgétaire : 878/161-05/61</p>
<i><p>***<em>Vu les demandes tendant à obtenir des concessions de terrain pour sépulture au cimetière communal;</em></p>
<p><em>Vu l'article 123 de la loi communale;</em></p>
<p><em>Vu la loi du 20 juillet 1971 sur les funérailles et sépultures;</em></p>
<p><em>Vu le règlement communal sur les concessions de sépulture;</em></p>
<p><em>Vu la délibération du Conseil communal en date du 26 juin 1984 renouvelée le 16 octobre 2012 par laquelle celui-ci a fait usage de la faculté de délégation prévue par l'article 6 de la loi du 20 juillet 1971;</em></p>
<p><em>DECIDE :</em></p>
<p><em><u>Article 1er</u></em><em>: Les concessions reprises au tableau ci-annexé, numérotées du n° 83 au n° 90 inclus sont accordées aux conditions des règlements communaux sur la matière.</em></p>
<p><em><u>Article 2</u></em><em>: Un titre de concession sera remis au(x) requérant(s).</em></p>
<p>***<em>Gelet op de aanvragen tot het bekomen van grondvergunningen voor begravingen op de gemeentelijke begraafplaats;</em></p>
<p><em>Gelet op artikel 123 van de gemeentewet;</em></p>
<p><em>Gelet op de wet van 20 juli 1971 op de begraafplaatsen en de lijkbezorging;</em></p>
<p><em>Gelet op het gemeentelijk reglement betreffende de grafconcessies;</em></p>
<p><em>Gelet op het besluit van de Gemeenteraad van 26 juni 1984, vernieuwd op 16 oktober 2012 waarbij deze gebruik gemaakt heeft van het overdrachtsrecht, bepaald bij artikel 6 van de wet van 20 juli 1971;</em></p>
<p><em>BESLUIT :</em></p>
<p><em><u>Artikel 1</u></em><em>: De vergunningen hernomen op de hierbijgevoegde lijst, van nr 83 tot nr 90 inbegrepen verleend tegen voorwaarden bij de gemeentereglementen inzake bepaald.</em></p>
<p><em><u>Artikel 2</u></em><em>: Een vergunningstitel zal aan de aanvrager(s) overhandigd worden.</em></p>
</i><center style="font-weight: bold">Approuvé / Goedgekeurd</center><div class="itemRef">61/B/002</div></p>
'''

xhtmlInput4 = '''
<center style="font-weight: bold">Approuvé / Goedgekeurd</center>
'''
