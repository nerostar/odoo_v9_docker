# -*- coding: utf-8 -*-
xhtmlInput = '''
<ul>
<li>Aa</li>
<li>Bb
 <ul>
  <li>Sub</li>
 </ul>
</li>
</ul>
<ol>
 <li>UN</li>
 <li>Deux<ol><li>SubDeux</li></ol></li>
 <li>Trois<ol><li>SubTrois</li></ol></li>
 <li>Quatre</li>
</ol>
<ol>
 <li>Numbered</li>
 <ol><li>Sub</li></ol>
 <li>Numbered<ol><li>Sub2</li></ol></li>
 <li>Numbered</li>
</ol>
<p>-</p>
<ol>
  <li>
    <ol>
      <li>
        <ol>
          <li><em><u>Contrôles des revenus</u></em></li>
        </ol>
      </li>
    </ol>
  </li>
</ol>
'''
