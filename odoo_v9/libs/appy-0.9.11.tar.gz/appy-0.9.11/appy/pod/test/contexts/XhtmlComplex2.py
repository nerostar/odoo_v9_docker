# -*- coding: utf-8 -*-
xhtmlInput = '''
<div><strong>Programmes FSE Convergence et Compétitivité
             régionale et emploi.</strong></div>'''

xhtmlInput2 = '''<b>Walloon entreprises, welcome !</b><br/>
<br/>
This site will allow you to get simple answers to those questions:<br/>
- am I an SME or not ?<br/>
- to which incentives may I postulate for, in Wallonia, according to my size?
<br/>The little test which you will find on this site is based on the European
Recommendation of May 6th, 2003. It was enforced on January 1st, 2005.
Most of the incentives that are available for SMEs in Wallonia are based
on the SME definition proposed by this recommandation.<br/><br/>

Incentives descriptions come from the 
<a href="http://economie.wallonie.be/" target="_blank">MIDAS</a> 
database and represent all incentives that are available on the Walloon
territory, whatever public institution is proposing it.<br/><br/>

<b>Big enterprises, do not leave !</b><br/><br/>

If this sites classifies you as a big enterprise, you will be able to consult
all incentives that are targeted to you.'''

xhtmlInput3 = '''
<div><strong>Programmes A</strong></div>
<div>Programmes B</div>
<div><strong>Programmes C</strong></div>
<ul><li>a</li><li>b</li></ul>'''
