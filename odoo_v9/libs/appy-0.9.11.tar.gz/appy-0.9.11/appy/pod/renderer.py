# Copyright (C) 2007-2018 Gaetan Delannay

# This file is part of Appy.

# Appy is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# Appy is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with Appy. If not, see <http://www.gnu.org/licenses/>.

# ------------------------------------------------------------------------------
import zipfile, shutil, xml.sax, os, os.path, re, mimetypes, time
from UserDict import UserDict
import appy.pod
from appy.pod import PodError
from appy.shared import mimeTypes, mimeTypesExts
from appy.shared.xml_parser import XmlElement
from appy.shared.zip import unzip, zip
from appy.shared.utils import FolderDeleter, executeCommand, FileWrapper
from appy.pod.pod_parser import PodParser, PodEnvironment, OdInsert
from appy.pod.converter import FILE_TYPES
from appy.pod.buffers import FileBuffer
from appy.pod.xhtml2odt import Xhtml2OdtConverter
from appy.pod.doc_importers import getUuid, \
     OdtImporter, ImageImporter, PdfImporter, ConvertImporter, PodImporter
from appy.pod.styles_manager import \
     StylesManager, TableProperties, NumberedProperties, BulletedProperties

# ------------------------------------------------------------------------------
BAD_CONTEXT = 'Context must be either a dict, a UserDict or an instance.'
RESULT_FILE_EXISTS = 'Result file "%s" exists.'
CANT_WRITE_RESULT = 'I cannot write result file "%s". %s'
CANT_WRITE_TEMP_FOLDER = 'I cannot create temp folder "%s". %s'
NO_PY_PATH = 'Extension of result file is "%s". In order to perform ' \
             'conversion from ODT to this format we need to call LibreOffice. '\
             'But the Python interpreter which runs the current script does ' \
             'not know UNO, the library that allows to connect to ' \
             'LibreOffice in server mode. If you can\'t install UNO in this ' \
             'Python interpreter, you can specify, in parameter ' \
             '"pythonWithUnoPath", the path to a UNO-enabled Python ' \
             'interpreter. One such interpreter may be found in ' \
             '<open_office_path>/program.'
PY_PATH_NOT_FILE = '"%s" is not a file. You must here specify the absolute ' \
                   'path of a Python interpreter (.../python, .../python.sh, ' \
                   '.../python.exe, .../python.bat...).'
BAD_RESULT_TYPE = 'Result "%s" has a wrong extension. Allowed extensions ' \
                  'are: "%s".'
CONVERT_ERROR = 'An error occurred during the conversion. %s'
BAD_OO_PORT = 'Bad LibreOffice port "%s". Make sure it is an integer.'
XHTML_ERROR = 'An error occurred while rendering XHTML content.'
WARNING_INCOMPLETE_OD = 'Warning: your OpenDocument file may not be complete ' \
  '(ie imported documents may not be present). This is because we could not ' \
  'connect to LibreOffice in server mode: %s'
DOC_NOT_SPECIFIED = 'Please specify a document to import, either with a ' \
                    'stream (parameter "content") or with a path (parameter ' \
                    '"at")'
DOC_FORMAT_ERROR = 'POD was unable to deduce the document format. Please ' \
                   'specify it through parameter named "format" (=odt, gif, ' \
                   'png, ...).'
DOC_WRONG_FORMAT = 'Format "%s" is not supported.'
WARNING_FINALIZE_ERROR = 'Warning: error while calling finalize function. %s'

# Default font added by pod in content.xml and styles.xml
POD_FONTS = '<style:font-face style:name="PodStarSymbol" ' \
            'svg:font-family="StarSymbol"/>'

# Default styles added by pod in content.xml and styles.xml
POD_STYLES = {}
podFolder = os.path.dirname(appy.pod.__file__)
for name in ('content', 'styles'):
    f = file('%s/%s.xmlt' % (podFolder, name))
    POD_STYLES[name] = f.read()
    f.close()

# ------------------------------------------------------------------------------
class Renderer:
    templateTypes = ('odt', 'ods') # Types of POD templates

    # ODF tags that may hold POD expressions
    allExpressionsHolders = (
      'if',      # Conditional fields
      'change',  # Track-changed text
      'input',   # Text input fields
      'db'       # Database fields
    )
    defaultExpressionsHolders = ('if', 'change', 'input')

    def __init__(self, template, context, result, pythonWithUnoPath=None,
      ooPort=2002, stylesMapping={}, html=False, forceOoCall=False,
      finalizeFunction=None, overwriteExisting=False, raiseOnError=False,
      imageResolver=None, stylesTemplate=None, optimalColumnWidths=False,
      script=None, managePageStyles=None, resolveFields=False,
      expressionsHolders=defaultExpressionsHolders):
        '''This Python Open Document Renderer (PodRenderer) loads a document
           template (p_template) which is an ODT or ODS file with some elements
           written in Python. Based on this template and some Python objects
           defined in p_context, the renderer generates an ODT file (p_result)
           that instantiates the p_template and fills it with objects from the
           p_context.

         - If p_result does not end with .odt or .ods, the Renderer will call
           LibreOffice to perform a conversion. If p_forceOoCall is True, even
           if p_result ends with .odt, LibreOffice will be called, not for
           performing a conversion, but for updating some elements like indexes
           (table of contents, etc) and sections containing links to external
           files (which is the case, for example, if you use the default
           function "document").

         - If the Python interpreter which runs the current script is not
           UNO-enabled, this script will run, in another process, a UNO-enabled
           Python interpreter (whose path is p_pythonWithUnoPath) which will
           call LibreOffice. In both cases, we will try to connect to
           LibreOffice in server mode on port p_ooPort.

         - If you plan to make "XHTML to OpenDocument" conversions (via the POD
           function "xhtml"), you may specify a "styles mapping" in
           p_stylesMapping. Moreover, if the input(s) to this function is valid
           HTML but not valid XHTML, specify p_html being True.

         - If you specify a function in p_finalizeFunction, this function will
           be called by the renderer before re-zipping the ODT/S result. This
           way, you can still perform some actions on the content of the ODT/S
           file before it is zipped and potentially converted. This function
           must accept 2 args:
            * the absolute path to the temporary folder, containing the
              un-zipped content of the ODT/S result;
            * the Renderer instance.

         - If you set p_overwriteExisting to True, the renderer will overwrite
           the result file. Else, an exception will be thrown if the result file
           already exists.

         - If p_raiseOnError is False (the default value), any error encountered
           during the generation of the result file will be dumped into it, as
           a Python traceback within a note. Else, the error will be raised.

         - p_imageResolver allows POD to retrieve images, from "img" tags within
           XHTML content. Indeed, POD may not be able (ie, may not have the
           permission to) perform a HTTP GET on those images. Currently, the
           resolver can only be a Zope application object.

         - p_stylesTemplate can be the path to a LibreOffice file (ie, a .ott
           file) whose styles will be imported within the result.

         - p_optimalColumnWidths corresponds to the homonym option to
           converter.py, excepted that values "True" or "False" must be boolean
           values. Note that the POD function "xhtml" requires this parameter to
           be "OCW_.*" to be fully operational. When optimalColumnWidths is not
           False, forceOoCall is forced to True.

         - p_script is the absolute path to a Python script containing functions
           that the converter will call in order to customize the process of
           manipulating the document via the LibreOffice UNO interface. For more
           information, see appy/pod/converter.py, option "-s". Note that when
           such p_script is specified, p_forceOoCall is forced to True.

         - If this document is a sub-document to be included in a master one, it
           has sense to set a specific value for parameter p_managePageStyles:
             "rename"  will rename all page styles with unique names. This way,
                       when imported into a master document, no name clash will
                       occur and elements tied to page styles (like headers and
                       footers) will be correctly imported for all included
                       sub-documents. The "do... pod" statement automatically
                       sets this parameter to "rename";
             <int>     will rename page styles similarly to "rename" and will
                       also restart, in the sub-document, page numbering at this
                       integer value. It will only work if page styles are
                       explicitly applied to pages in the sub-pod template. In
                       order to achieve this with LibreOffice, open your
                       template, set the cursor somewhere in the first page,
                       open the pane with page styles, and double-clic on the
                       "default style". To check if it has worked, click inside
                       the first paragraph in the page, open its properties and
                       check that a page break has been defined on it.

         - If you want to replace (some) fields with their "hard-coded" values,
           use p_resolveFields. It can be useful, for instance, if the POD
           result must be included in a master document (via statement "do ...
           from pod"), but the total number of pages must be kept as is. If
           p_resolveFields is True, all fields will be resolved, excepted
           special ones like PageNumber. Indeed, its value is different from one
           page to another, so resolving it to a single, hard-coded value has no
           sense. You can also specify "PageCount" as value for p_resolveField.
           In this case, only the field(s) containing the total number of pages
           will be resolved. Use it if it is the only field you need to resolve,
           it will be more performant. Note that when p_resolveFields is set,
           p_forceOoCall is forced to True.

           POD expressions may be defined at various places within a document
           template. Possible places are listed in static variable
           "allExpressionsHolders" hereabove. Default places are listed in
           static variable "defaultExpressionsHolders" hereabove.
        '''
        self.template = template
        self.result = result
        self.contentXml = None # Content (string) of content.xml
        self.stylesXml = None # Content (string) of styles.xml
        # Manages the styles defined into the ODT template
        self.stylesManager = None 
        self.tempFolder = None
        self.env = None
        self.pyPath = pythonWithUnoPath
        self.ooPort = ooPort
        # p_forceOoCall may be forced to True
        self.forceOoCall = forceOoCall or bool(optimalColumnWidths) or \
                           bool(script) or bool(resolveFields)
        self.finalizeFunction = finalizeFunction
        self.overwriteExisting = overwriteExisting
        self.raiseOnError = raiseOnError
        self.imageResolver = imageResolver
        self.stylesTemplate = stylesTemplate
        self.optimalColumnWidths = optimalColumnWidths
        self.script = script
        self.managePageStyles = managePageStyles
        self.resolveFields = resolveFields
        self.expressionsHolders = expressionsHolders
        # Keep trace of the original context given to the renderer
        self.originalContext = context
        # Remember potential files or images that will be included through
        # "do ... from document" statements: we will need to declare them in
        # META-INF/manifest.xml. Keys are file names as they appear within the
        # ODT file (to dump in manifest.xml); values are original paths of
        # included images (used for avoiding to create multiple copies of a file
        # which is imported several times).
        self.fileNames = {}
        self.prepareFolders()
        # Unzip template
        self.unzipFolder = os.path.join(self.tempFolder, 'unzip')
        os.mkdir(self.unzipFolder)
        info = unzip(template, self.unzipFolder, odf=True)
        self.contentXml = info['content.xml']
        self.stylesXml = info['styles.xml']
        self.stylesManager = StylesManager(self)
        # From LibreOffice 3.5, it is not possible anymore to dump errors into
        # the resulting ods as annotations. Indeed, annotations can't reside
        # anymore within paragraphs. ODS files generated with pod and containing
        # error messages in annotations cause LibreOffice 3.5 and 4.0 to crash.
        # LibreOffice >= 4.1 simply does not show the annotation.
        if info['mimetype'] == mimeTypes['ods']: self.raiseOnError = True
        # Create the parsers for content.xml and styles.xml
        nso = PodEnvironment.NS_OFFICE
        for name in ('content', 'styles'):
            styleTag = (name == 'content') and 'automatic-styles' or 'styles'
            inserts = (
              OdInsert(POD_FONTS, XmlElement('font-face-decls', nsUri=nso)),
              OdInsert(POD_STYLES[name], XmlElement(styleTag, nsUri=nso)))
            parser = self.createPodParser('%s.xml' % name, context, inserts)
            setattr(self, '%sParser' % name, parser)
        # Store the styles mapping
        self.setStylesMapping(stylesMapping)
        # Store the p_html parameter
        self.html = html
        # While working, POD may identify "dynamic styles" to insert either in
        # the "automatic-styles" section of content.xml (ie, the column styles
        # of tables generated from XHTML tables via xhtml2odt.py), or in the
        # "styles" section of styles.xml (ie, bullet styles).
        self.dynamicStyles = {'content': [], 'styles': []}

    def createPodParser(self, odtFile, context, inserts=None):
        '''Creates the parser with its environment for parsing the given
           p_odtFile (content.xml or styles.xml). p_context is given by the pod
           user, while p_inserts depends on the ODT file we must parse.'''
        # The default evaluation context
        evalContext = {}
        if hasattr(context, '__dict__'):
            evalContext.update(context.__dict__)
        elif isinstance(context, dict) or isinstance(context, UserDict):
            evalContext.update(context)
        else:
            raise PodError(BAD_CONTEXT)
        # Incorporate the default, unalterable, context
        evalContext.update({'xhtml': self.renderXhtml,
          'test': self.evalIfExpression, 'document': self.importDocument,
          'pod': self.importPod, 'TableProperties': TableProperties,
          'BulletedProperties': BulletedProperties,
          'NumberedProperties': NumberedProperties,
          'pageBreak': self.insertPageBreak,
          'columnBreak': self.insertColumnBreak,
          # Variables to use for representing pod-reserved chars
          'PIPE': '|', 'SEMICOLON': ';'})
        # Developer, forget the following line
        if '_ctx_' not in evalContext: evalContext['_ctx_'] = evalContext
        env = PodEnvironment(evalContext, inserts, self.expressionsHolders)
        fileBuffer = FileBuffer(env, os.path.join(self.tempFolder,odtFile))
        env.currentBuffer = fileBuffer
        return PodParser(env, self)

    def renderXhtml(self, s, encoding='utf-8', stylesMapping={}, keepWithNext=0,
                    keepImagesRatio=False, html=None):
        '''Method that can be used (under the name 'xhtml') into a pod template
           for converting a chunk of XHTML content (p_s) into a chunk of ODT
           content.

           For this conversion, beyond the global styles mapping defined at the
           renderer level, a specific p_stylesMapping can be given: any key in
           it overrides its homonym in the global mapping.

           If p_html is not None, it overrides renderer's homonym parameter.
        '''
        stylesMapping = self.stylesManager.checkStylesMapping(stylesMapping)
        if html == None: html = self.html
        return Xhtml2OdtConverter(s, encoding, self.stylesManager,
                 stylesMapping, keepWithNext, keepImagesRatio, self, html).run()

    def evalIfExpression(self, condition, ifTrue, ifFalse):
        '''This method implements the method 'test' which is proposed in the
           default pod context. It represents an 'if' expression (as opposed to
           the 'if' statement): depending on p_condition, expression result is
           p_ifTrue or p_ifFalse.'''
        if condition: return ifTrue
        return ifFalse

    # Supported image formats. "image" represents any format
    imageFormats = ('png', 'jpeg', 'jpg', 'gif', 'svg', 'image')
    ooFormats = ('odt',)
    convertibleFormats = FILE_TYPES.keys()

    def importDocument(self, content=None, at=None, format=None,
      anchor='as-char', wrapInPara=True, size=None, sizeUnit='cm', style=None,
      keepRatio=True, pageBreakBefore=False, pageBreakAfter=False,
      convertOptions=None):
        '''If p_at is not None, it represents a path or url allowing to find
           the document. If p_at is None, the content of the document is
           supposed to be in binary format in p_content. The document
           p_format may be: odt or any format in imageFormats.

           p_anchor, p_wrapInPara, p_size, p_sizeUnit, p_style and p_keepRatio
           are only relevant for images:
           * p_anchor defines the way the image is anchored into the document;
                      Valid values are 'page','paragraph', 'char' and 'as-char';
           * p_wrapInPara, if true, wraps the resulting 'image' tag into a 'p'
                           tag;
           * p_size, if specified, is a tuple of float or integers
                     (width, height) expressing size in p_sizeUnit (see below).
                     If not specified, size will be computed from image info;
           * p_sizeUnit is the unit for p_size elements, it can be "cm"
             (centimeters), "px" (pixels) or "pc" (percentage). Percentages, in
             p_size, must be expressed as integers from 1 to 100.
           * if p_style is given, it is a appy.shared.css.CssStyles instance,
             containing CSS attributes. If "width" and "heigth" attributes are
             found there, they will override p_size and p_sizeUnit.
           * If p_keepRatio is True, the image width/height ratio will be kept
             when p_size is specified.

           p_pageBreakBefore and p_pageBreakAfter are only relevant for
           importing external odt documents, and allows to insert a page break
           before/after the inserted document. More precisely, each of these
           parameters can have values:
           * True     insert a page break;
           * False    do no insert a page break;

           moreover, p_pageBreakAfter can have this additional parameter:
           * 'duplex' insert 2 page breaks if the sub-document has an odd number
                      of pages, 1 else (useful for duplex printing).

           If p_convertOptions are given (for images only), imagemagick will be
           called with these options to perform some transformation on the
           image. For example, if you specify
                             convertOptions="-rotate 90"

           pod will perform this command before importing the file into the
           result:
                       convert your.image -rotate 90 your.image

           You can also specify a function in convertOptions. This function will
           receive a single arg, "image", an instance of
           appy.pod.doc_importers.Image giving some characteristics of the image
           to convert, like image.width and image.height in pixels (integers).
           If your function does not return a string containing the convert
           options, no conversion will occur.
        '''
        importer = None
        # Is there someting to import ?
        if not content and not at: raise PodError(DOC_NOT_SPECIFIED)
        # Convert Zope files into Appy wrappers
        if content.__class__.__name__ in ('File', 'Image'):
            content = FileWrapper(content)
        # Guess document format
        if isinstance(content, FileWrapper):
            format = content.mimeType
        if not format:
            # It should be deduced from p_at
            if not at:
                raise PodError(DOC_FORMAT_ERROR)
            format = os.path.splitext(at)[1][1:]
        else:
            # If format is a mimeType, convert it to an extension
            if mimeTypesExts.has_key(format):
                format = mimeTypesExts[format]
        isImage = False
        isOdt = False
        if format in self.ooFormats:
            importer = OdtImporter
            self.forceOoCall = True
            isOdt = True
        elif (format in self.imageFormats) or not format:
            # If the format can't be guessed, we suppose it is an image
            importer = ImageImporter
            isImage = True
        elif format == 'pdf':
            importer = PdfImporter
        elif format in self.convertibleFormats:
            importer = ConvertImporter
        else:
            raise PodError(DOC_WRONG_FORMAT % format)
        imp = importer(content, at, format, self)
        # Initialise image-specific parameters
        if isImage:
            imp.init(anchor, wrapInPara, size, sizeUnit, style, keepRatio,
                     convertOptions)
        elif isOdt: imp.init(pageBreakBefore, pageBreakAfter)
        return imp.run()

    def getResolvedNamespaces(self):
        '''Gets a context where mainly used namespaces have been resolved'''
        env = self.stylesParser.env
        return {'text': env.ns(env.NS_TEXT), 'style': env.ns(env.NS_STYLE)}

    def importPod(self, content=None, at=None, format='odt', context=None,
          pageBreakBefore=False, pageBreakAfter=False,
          managePageStyles='rename', renamePageStyles=None,resolveFields=False):
        '''Similar to m_importDocument, but allows to import the result of
           executing the POD template specified in p_content or p_at, and
           include it in the POD result.

           Renaming page styles for the sub-pod (p_managePageStyles being
           "rename") ensures there is no name clash between page styles (and
           tied elements such as headers and footers) coming from several
           sub-pods or with styles defined at the master document level. This
           takes some processing, so you can set it to None if you are sure you
           do not need it.

           p_resolveFields has the same meaning as the homonym parameter on the
           Renderer.
        '''
        # Is there a pod template defined ?
        if not content and not at:
            raise PodError(DOC_NOT_SPECIFIED)
        # If the POD template is specified as a Zope file, convert it into a
        # Appy FileWrapper.
        if content.__class__.__name__ == 'File':
            content = FileWrapper(content)
        imp = PodImporter(content, at, format, self)
        self.forceOoCall = True
        # Define the context to use: either the current context of the current
        # POD renderer, or p_context if given.
        if context:
            ctx = context
        else:
            ctx = self.contentParser.env.context
        # Manage the deprecated parameter "renamePageStyles"
        if renamePageStyles != None:
            managePageStyles = (renamePageStyles == True) and 'rename' or None
        imp.init(ctx, pageBreakBefore, pageBreakAfter,
                 managePageStyles, resolveFields)
        return imp.run()

    def _insertBreak(self, type):
        '''Inserts a page or column break into the result'''
        return '<text:p text:style-name="pod%sBreak"></text:p>' % \
               type.capitalize()
    def insertPageBreak(self): return self._insertBreak('page')
    def insertColumnBreak(self): return self._insertBreak('column')

    def prepareFolders(self):
        # Check if I can write the result
        if not self.overwriteExisting and os.path.exists(self.result):
            raise PodError(RESULT_FILE_EXISTS % self.result)
        try:
            f = open(self.result, 'w')
            f.write('Hello')
            f.close()
        except OSError, oe:
            raise PodError(CANT_WRITE_RESULT % (self.result, oe))
        except IOError, ie:
            raise PodError(CANT_WRITE_RESULT % (self.result, ie))
        self.result = os.path.abspath(self.result)
        os.remove(self.result)
        # Create a temp folder for storing temporary files
        absResult = os.path.abspath(self.result)
        self.tempFolder = '%s.%f' % (absResult, time.time())
        try:
            os.mkdir(self.tempFolder)
        except OSError, oe:
            raise PodError(CANT_WRITE_TEMP_FOLDER % (self.result, oe))

    def patchManifest(self):
        '''Declares, in META-INF/manifest.xml, images or files included via the
           "do... from document" statements if any.'''
        if self.fileNames:
            j = os.path.join
            toInsert = ''
            for fileName in self.fileNames.iterkeys():
                if fileName.endswith('.svg'):
                    fileName = os.path.splitext(fileName)[0] + '.png'
                mimeType = mimetypes.guess_type(fileName)[0]
                toInsert += ' <manifest:file-entry manifest:media-type="%s" ' \
                            'manifest:full-path="%s"/>\n' % (mimeType, fileName)
            manifestName = j(self.unzipFolder, j('META-INF', 'manifest.xml'))
            f = file(manifestName)
            manifestContent = f.read()
            hook = '</manifest:manifest>'
            manifestContent = manifestContent.replace(hook, toInsert+hook)
            f.close()
            # Write the new manifest content
            f = file(manifestName, 'w')
            f.write(manifestContent)
            f.close()

    # Public interface
    def run(self):
        '''Renders the result'''
        try:
            # Remember which parser is running
            self.currentParser = self.contentParser
            # Create the resulting content.xml
            self.currentParser.parse(self.contentXml)
            self.currentParser = self.stylesParser
            # Create the resulting styles.xml
            self.currentParser.parse(self.stylesXml)
            # Patch META-INF/manifest.xml
            self.patchManifest()
            # Re-zip the result
            self.finalize()
        finally:
            FolderDeleter.delete(self.tempFolder)

    def getStyles(self):
        '''Returns a dict of the styles that are defined into the template.'''
        return self.stylesManager.styles

    def setStylesMapping(self, stylesMapping):
        '''Establishes a correspondence between, on one hand, CSS styles or
           XHTML tags that will be found inside XHTML content given to POD,
           and, on the other hand, ODT styles found into the template.'''
        try:
            manager = self.stylesManager
            # Initialise the styles mapping when relevant
            ocw = self.optimalColumnWidths
            if ocw: TableProperties.initStylesMapping(stylesMapping, ocw)
            manager.stylesMapping = manager.checkStylesMapping(stylesMapping)
        except PodError, po:
            self.contentParser.env.currentBuffer.content.close()
            self.stylesParser.env.currentBuffer.content.close()
            if os.path.exists(self.tempFolder):
                FolderDeleter.delete(self.tempFolder)
            raise po

    def callLibreOffice(self, resultName, resultType):
        '''Call LibreOffice in server mode to convert or update the result'''
        loOutput = ''
        try:
            if (not isinstance(self.ooPort, int)) and \
               (not isinstance(self.ooPort, long)):
                raise PodError(BAD_OO_PORT % str(self.ooPort))
            try:
                from appy.pod.converter import Converter, ConverterError
                try:
                    Converter(resultName, resultType, self.ooPort,
                              self.stylesTemplate, self.optimalColumnWidths,
                              self.script, self.resolveFields).run()
                except ConverterError, ce:
                    raise PodError(CONVERT_ERROR % str(ce))
            except ImportError:
                # I do not have UNO. So try to launch a UNO-enabled Python
                # interpreter which should be in self.pyPath.
                if not self.pyPath:
                    raise PodError(NO_PY_PATH % resultType)
                if not os.path.isfile(self.pyPath):
                    raise PodError(PY_PATH_NOT_FILE % self.pyPath)
                convScript = '%s/converter.py' % \
                            os.path.dirname(appy.pod.__file__)
                cmd = [self.pyPath, convScript, resultName, resultType,
                       '-p%d' % self.ooPort]
                if self.stylesTemplate:
                    cmd.append('-t%s' % self.stylesTemplate)
                if self.optimalColumnWidths:
                    cmd.append('-o')
                    cmd.append('%s' % str(self.optimalColumnWidths))
                if self.script:
                    cmd.append('-s')
                    cmd.append('%s' % self.script)
                if self.resolveFields:
                    cmd.append('-r')
                    cmd.append('%s' % self.resolveFields)
                out, loOutput = executeCommand(cmd)
        except PodError, pe:
            # When trying to call LO in server mode for producing ODT or ODS
            # (=forceOoCall=True), if an error occurs we have nevertheless
            # an ODT or ODS to return to the user. So we produce a warning
            # instead of raising an error.
            if (resultType in self.templateTypes) and self.forceOoCall:
                print(WARNING_INCOMPLETE_OD % str(pe))
            else:
                raise pe
        return loOutput

    def getTemplateType(self):
        '''Identifies the type of the pod template in self.template
           (ods or odt). If self.template is a string, it is a file name and we
           simply get its extension. Else, it is a binary file in a StringIO
           instance, and we seek the mime type from the first bytes.'''
        if isinstance(self.template, basestring):
            res = os.path.splitext(self.template)[1][1:]
        else:
            # A StringIO instance
            self.template.seek(0)
            firstBytes = self.template.read(90)
            firstBytes = firstBytes[firstBytes.index('mimetype')+8:]
            if firstBytes.startswith(mimeTypes['ods']):
                res = 'ods'
            else:
                res = 'odt' # We suppose this is ODT
        return res

    def finalize(self):
        '''Re-zip the result and potentially call LibreOffice if target format
           is not among self.templateTypes or if forceOoCall is True.'''
        j = os.path.join
        # If an action regarding page styles must be performed, get and modify
        # them accordingly.
        pageStyles = None
        mps = self.managePageStyles
        if mps != None:
            pageStyles = self.stylesManager.pageStyles.init(mps)
        # Patch styles.xml and content.xml
        for name in ('styles', 'content'):
            # Copy the [content|styles].xml file from the temp to the zip folder
            fn = '%s.xml' % name
            shutil.copy(j(self.tempFolder, fn), j(self.unzipFolder, fn))
            # For styles.xml, complete dynamic styles with default styles for
            # bulleted and numbered lists.
            ds = self.dynamicStyles[name]
            if name == 'styles':
                env = self.stylesParser.env
                n = {'text': env.ns(env.NS_TEXT), 'style': env.ns(env.NS_STYLE)}
                ds.insert(0,NumberedProperties().dumpStyle('podNumberedList',n))
                ds.insert(0,BulletedProperties().dumpStyle('podBulletedList',n))
            # Get the file content and inject dynamic styles into it
            fn = os.path.join(self.unzipFolder, fn)
            f = file(fn)
            content = f.read().replace('<!DYNAMIC_STYLES!>', ''.join(ds))
            # Rename the page styles
            if pageStyles:
                content = pageStyles.renameIn(name, content)
            f.close()
            # Write the updated content to the file
            f = file(fn, 'w')
            f.write(content)
            f.close()
        # Call the user-defined "finalize" function when present
        if self.finalizeFunction:
            try:
                self.finalizeFunction(self.unzipFolder, self)
            except Exception, e:
                print(WARNING_FINALIZE_ERROR % str(e))
        # Re-zip the result, first as an OpenDocument file of the same type as
        # the POD template (odt, ods...)
        resultExt = self.getTemplateType()
        resultName = os.path.join(self.tempFolder, 'result.%s' % resultExt)
        zip(resultName, self.unzipFolder, odf=True)
        resultType = os.path.splitext(self.result)[1].strip('.')
        if (resultType in self.templateTypes) and not self.forceOoCall:
            # Simply move the ODT result to the result
            os.rename(resultName, self.result)
        else:
            if resultType not in FILE_TYPES:
                raise PodError(BAD_RESULT_TYPE % (
                    self.result, FILE_TYPES.keys()))
            # Call LibreOffice to perform the conversion or document update
            output = self.callLibreOffice(resultName, resultType)
            # I (should) have the result. Move it to the correct name.
            resPrefix = os.path.splitext(resultName)[0]
            if resultType in self.templateTypes:
                # converter.py has (normally!) created a second file
                # suffixed .res.[resultType]
                finalResultName = '%s.res.%s' % (resPrefix, resultType)
                if not os.path.exists(finalResultName):
                    finalResultName = resultName
                    # In this case OO in server mode could not be called to
                    # update indexes, sections, etc.
            else:
                finalResultName = '%s.%s' % (resPrefix, resultType)
            if not os.path.exists(finalResultName):
                raise PodError(CONVERT_ERROR % output)
            os.rename(finalResultName, self.result)
# ------------------------------------------------------------------------------
