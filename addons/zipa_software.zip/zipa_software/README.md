ZIPA: Sistema de Gestión Integral de Proyectos
==============================================

Este sistema cuenta con los siguientes módulos:

- Portafolio de Proyectos
- Gestión EDT
- Visor de Obras Web
- Visor de Obras Móvil
- Tablero de Seguimiento
- Gestión Residuos de Construcción y Demolición
