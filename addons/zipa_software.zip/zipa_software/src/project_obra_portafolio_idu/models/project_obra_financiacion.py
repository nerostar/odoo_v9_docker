# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api
from openerp.exceptions import ValidationError, Warning
import json
from datetime import datetime
import logging
_logger = logging.getLogger(__name__)


class project_obra_proyecto_etapa_financiacion(models.Model):
    _name = 'project_obra.proyecto.etapa.financiacion'
    _description = 'Etapas financiacion.'
    _inherit = ['mail.thread']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=255,
        help='''Nombre de financiacion''',
        compute='_compute_name',
        store=True
    )
    centro_costo_id = fields.Many2one(
        string='Centro de Costo',
        required=True,
        comodel_name='stone_erp.centro_costo',
        ondelete='restrict',
        track_visibility='onchange',
    )
    nombre_centro_costo = fields.Char(
        string='Nombre de Centro de Costo',
        related='centro_costo_id.name',
        readonly=True,
        store=True,
        track_visibility='onchange',
    )
    etapa_id = fields.Many2one(
        string='Etapa',
        required=False,
        readonly=True,
        default=lambda self: self.env.context.get('meta_id'),
        comodel_name='project_obra.proyecto.etapa',
        ondelete='restrict',
        track_visibility='onchange',
    )

    ######################
    # metodos
    ######################

    @api.one
    @api.depends('etapa_id.name', 'centro_costo_id.name')
    def _compute_name(self):
        self.name = '{}-{}-{}_{}'.format(self.etapa_id.name, self.centro_costo_id.name, self.centro_costo_id.codigo, self.id)





class project_obra_proyecto_etapa_financiacion_externa(models.Model):
    _name = 'project_obra.proyecto.etapa.financiacion_externa'
    _description = 'Etapas financiacion externa.'
    _inherit = ['mail.thread']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=255,
        help='''Nombre del financiación externa''',
        compute='_compute_name',
        store=True
    )
    descripcion = fields.Char(
        string='descripcion',
        track_visibility='onchange',
        size=255,
        help='''Descripción de la fincnciación externa''',
    )
    fuente_id = fields.Many2one(
        string='Fuente',
        required=True,
        comodel_name='plan_anual_adquisiciones.plan.linea.fuente',
        ondelete='restrict',
        track_visibility='onchange',
    )
    nombre_fuente = fields.Char(
        string='Nombre de Fuente',
        related='fuente_id.name',
        readonly=True,
        store=True,
        track_visibility='onchange',
    )
    etapa_id = fields.Many2one(
        string='Etapa',
        required=False,
        readonly=True,
        default=lambda self: self.env.context.get('meta_id'),
        comodel_name='project_obra.proyecto.etapa',
        ondelete='restrict',
        track_visibility='onchange',
    )
    valor = fields.Float(
        string='valor',
        ondelete='restrict',
        track_visibility='onchange',
    )
    vigencia = fields.Integer(
        string='Vigencia',
        ondelete='restrict',
        track_visibility='onchange',
        default=datetime.today().year
    )


    ######################
    # metodos
    ######################

    @api.one
    @api.depends('etapa_id.name', 'fuente_id.name')
    def _compute_name(self):
        self.name = '{}-{}_{}'.format(self.etapa_id.name, self.fuente_id.name, self.id)





class project_obra_proyecto_etapa(models.Model):
    _name = 'project_obra.proyecto.etapa'
    _inherit = ['project_obra.proyecto.etapa']

    # -------------------
    # Fields
    # -------------------


    financiacion_ids = fields.One2many(
        string='Financiaciones',
        comodel_name='project_obra.proyecto.etapa.financiacion',
        inverse_name='etapa_id',
        track_visibility='onchange',
    )
    financiacion_externa_ids = fields.One2many(
        string='Financiaciones Externas',
        comodel_name='project_obra.proyecto.etapa.financiacion_externa',
        inverse_name='etapa_id',
        track_visibility='onchange',
    )

