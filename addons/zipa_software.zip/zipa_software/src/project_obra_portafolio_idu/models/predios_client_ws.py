# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2016 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from suds.client import Client

def get_indicadores_predios(id_obra, url_wsdl):
    cliente = Client(url_wsdl)
    resumen_proyecto = cliente.service.get_pre_resumen_proyecto(id_obra)
    res = {
        'rt_solicitados': resumen_proyecto['rt_solicitados'], 
        'rt_utilizados': resumen_proyecto['rt_utilizados'], 
        'predios_entregados': resumen_proyecto['predios_entregados'],
        'predios_pendientes': resumen_proyecto['predio_pendiente'],
    }
    return res

def get_predios_no_recibidos(id_obra, url_wsdl):
    cliente = Client(url_wsdl)
    res = []
    predios_no_recibidos = cliente.service.get_predios_no_recibidos(id_obra)
    for predio in predios_no_recibidos:
        diccionario_pago = {
            'registro_topografico': predio['Registro_Topografico'],
            'chip': predio['Chip'],
            'direccion_predio': predio['Direccion_Predio'],
        }
        res.append(diccionario_pago)
    return res
