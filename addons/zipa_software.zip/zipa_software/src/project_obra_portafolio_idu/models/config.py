# -*- coding: utf-8 -*-

from openerp import models, fields, api


class project_obra_portafolio_idu_config_settings(models.TransientModel):
    _name = 'project_obra_portafolio_idu.config'
    _inherit = 'res.config.settings'

    frentes_ws_url = fields.Char(
        string='URL del Servicio de Sincronización de Frentes de Obra',
        default='https://webidu.idu.gov.co/servergis/rest/services/Frentes/Publicaci%C3%B3nVistaFrentes/FeatureServer/1',
        help='URL en donde se encuentra alojado el servicio con la información de los frentes de obra.',
    )
    
    feat_layer_proyectos_visor = fields.Char(
        string='URL de Feature Service del Visor de proyectos de IDU',
        default='https://webidu.idu.gov.co/servergis1/rest/services/ProyectoGeneralIDU/ProyectosGeneralIDU/FeatureServer',
        help='Url del servicio de feature, que se muestra en el visor de proyectos.',
    )
    
    arcgis_server = fields.Char(
        string='URL de Server SIGIDU',
        default='https://webidu.idu.gov.co/servergis1',
        help='Usuario de ArcGIS Portal para acceder a recurso',
    )
    
    arcgis_portal = fields.Char(
        string='URL Portal SIGIDU',
        default='https://webidu.idu.gov.co/portalidu1',
        help='Usuario de ArcGIS Portal para acceder a recurso',
    )
    
    
    usuario_sigidu = fields.Char(
        string='Usuario SIGIDU',
        default='usuario1',
        help='Usuario de ArcGIS Portal para acceder a recurso',
    )
    
    clave_sigidu = fields.Char(
        string='Clave de SIGIDU',
        default='12345',
        help='Clave para acceder a Feature Layer de SIGIDU',
    )
    
    requiere_token = fields.Boolean(
        string='Requiere Token',
        default='False',
        help='Se usa en caso de que los servicios estén protegidos',
    )  
    


    @api.model
    def get_default_frentes_ws_url(self, fields):
        conf = self.env['ir.config_parameter']
        return {
                'frentes_ws_url': conf.get_param('project_obra_portafolio_idu.frentes'),
            }

    @api.one
    def set_frentes_ws_url(self):
        self.env['ir.config_parameter'].set_param('project_obra_portafolio_idu.frentes', self.frentes_ws_url)
        
    @api.model
    def get_feat_layer_proyectos_visor(self, fields):
        conf = self.env['ir.config_parameter']
        return {
                'feat_layer_proyectos_visor': conf.get_param('project_obra_portafolio_idu.feat_layer_proyectos_visor'),
            }
    @api.one
    def set_feat_layer_proyectos_visor(self):
        self.env['ir.config_parameter'].set_param('project_obra_portafolio_idu.feat_layer_proyectos_visor', self.feat_layer_proyectos_visor)
        
        
    @api.model
    def get_usuario_sigidu(self, fields):
        conf = self.env['ir.config_parameter']
        return {
                'usuario_sigidu': conf.get_param('project_obra_portafolio_idu.usuario_sigidu'),
            }
    @api.one
    def set_usuario_sigidu(self):
        self.env['ir.config_parameter'].set_param('project_obra_portafolio_idu.usuario_sigidu', self.usuario_sigidu)
        
    
    
    @api.model
    def get_clave_sigidu(self, fields):
        conf = self.env['ir.config_parameter']
        return {
                'clave_sigidu': conf.get_param('project_obra_portafolio_idu.clave_sigidu'),
            }
    @api.one
    def set_clave_sigidu(self):
        self.env['ir.config_parameter'].set_param('project_obra_portafolio_idu.clave_sigidu', self.clave_sigidu)    
        
    
    @api.model
    def get_arcgis_server(self, fields):
        conf = self.env['ir.config_parameter']
        return {
                'arcgis_server': conf.get_param('project_obra_portafolio_idu.arcgis_server'),
            }
    @api.one
    def set_arcgis_server(self):
        self.env['ir.config_parameter'].set_param('project_obra_portafolio_idu.arcgis_server', self.arcgis_server)
        
        
    @api.model
    def get_arcgis_portal(self, fields):
        conf = self.env['ir.config_parameter']
        return {
                'arcgis_portal': conf.get_param('project_obra_portafolio_idu.arcgis_portal'),
            }
    @api.one
    def set_arcgis_portal(self):
        self.env['ir.config_parameter'].set_param('project_obra_portafolio_idu.arcgis_portal', self.arcgis_portal)


    @api.model
    def get_requiere_token(self, fields):
        conf = self.env['ir.config_parameter']
        return {
                'requiere_token': conf.get_param('project_obra_portafolio_idu.requiere_token'),
            }
    @api.one
    def set_requiere_token(self):
        self.env['ir.config_parameter'].set_param('project_obra_portafolio_idu.requiere_token', self.requiere_token)
        
