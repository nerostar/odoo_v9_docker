# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api
from openerp.exceptions import ValidationError,AccessError


class project_project(models.Model):
    _name = 'project.project'
    _inherit = ['project.project']

    # -------------------
    # Fields
    # -------------------
    reporte_desempeno_manual_ids = fields.One2many(
        string='Reportes de Desempeño',
        required=False,
        comodel_name='project_obra.reporte_desempeno_manual',
        inverse_name='project_id',
        ondelete='restrict',
    )
    contrato_ids = fields.Many2many(
        string='Contratos',
        required=False,
        comodel_name='contrato.contrato',
        ondelete='restrict',
    )
    obra_proyecto_id = fields.Many2one(
        string='Proyecto de Obra',
        required=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
    )
    obra_etapa_tipo_id = fields.Many2one(
        string='Tipo de Etapa de Obra',
        required=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.etapa.tipo',
        ondelete='restrict',
    )

    # -------------------
    # methods
    # -------------------
    @api.multi
    def variacion_desempeno_button(self):
        view = self.env.ref('project_obra_portafolio_idu.reporte_desempeno_manual_tree')
        return {
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'project_obra.reporte_desempeno_manual',
            'context': { 'project_id': self.id },
            'domain': [('project_id', '=', self.id)],
        }


class project_task(models.Model):
    _name = 'project.task'
    _inherit = ['project.task']

    @api.one
    def _compute_usuario_actual_puede_reprogramar(self):
        super(project_task, self)._compute_usuario_actual_puede_reprogramar()
        if self.project_id and self.project_id.proyecto_tipo == 'obra_componente' and self.env.user.has_group_v8('project_obra_portafolio_idu.group_programador')[0]:
            self.usuario_actual_puede_reprogramar = True

class project_edt(models.Model):
    _name = 'project.edt'
    _inherit = ['project.edt']

    @api.one
    def _compute_usuario_actual_puede_reprogramar(self):
        super(project_edt, self)._compute_usuario_actual_puede_reprogramar()
        if self.project_id and self.project_id.proyecto_tipo == 'obra_componente' and self.env.user.has_group_v8('project_obra_portafolio_idu.group_programador')[0]:
            self.usuario_actual_puede_reprogramar = True

class project_financiacion(models.Model):
    _name = 'project.financiacion'
    _inherit = 'project.financiacion'

    # -------------------
    # Fields
    # -------------------
    fuente_financiacion_id = fields.Many2one(
        string='Fuente de financiación',
        required=True,
        track_visibility='onchange',
        comodel_name='stone_erp.fuente',
        ondelete='restrict',
    )


class project_problema(models.Model):
    _name = 'project.problema'
    _inherit = ['project.problema']

    # -------------------
    # Fields
    # -------------------
    frente_obra_id = fields.Many2one(
        string='Frente de Obra',
        required=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.frente_obra',
        ondelete='restrict',
        domain="[('proyecto_id','=',proyecto_id)]",
        default=lambda self: self._context.get('frente_obra_id', self.env['project_obra.proyecto.frente_obra'].browse()),
        readonly=True,
        states={
            'abierto': [('readonly', False)],
            'nuevo': [('readonly', False)],
            'devuelto': [('readonly', False)],
            'por_revisar': [('readonly', False)],
        }
    )

    frente_obra_ids = fields.Many2many(
        string='Frente / Componente',
        comodel_name='project_obra.proyecto.frente_obra',
        domain="[('proyecto_id','=',proyecto_id)]",
        default=lambda self: self._context.get('frente_obra_id', self.env['project_obra.proyecto.frente_obra'].browse()),
        readonly=True,
        states={
            'abierto': [('readonly', False)],
            'nuevo': [('readonly', False)],
            'en_progreso': [('readonly', False)],
            'devuelto': [('readonly', False)],
            'por_revisar': [('readonly', False)],
        }
    )

    proyecto_id = fields.Many2one(
        string='Proyecto de Obra',
        required=False,
        readonly=True,
        invisible=True,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
        default=lambda self: self._context.get('proyecto_id', self.env['project_obra.proyecto'].browse()),
    )

    # -------------------
    # methods
    # -------------------
    def search(self, cr, uid, args, offset=0, limit=None, order=None, context=None, count=False, xtra=None):
        new_args = self.adiciona_keywords_en_search(cr, uid, args, offset, limit, order, context, count, xtra)
        return super(project_problema, self).search(cr, uid, new_args, offset, limit, order, context, count)

    def adiciona_keywords_en_search(self, cr, uid, args, offset, limit, order, context, count, xtra):
        new_args = []
        for arg in args:
            if type(arg) is not tuple and type(arg) is not list:
                new_args += arg
                continue
            if len(arg) >= 3 and arg[2] == 'MIS_PROYECTOS':
                user = self.pool.get('res.users').browse(cr, uid, uid)
                proyecto_ids = user.get_proyecto_obra_asignado_ids()
                new_args += [(arg[0], arg[1], proyecto_ids)]
            else:
                new_args += [arg]
        return new_args

    @api.model
    def create(self, vals):
        if vals.get('proyecto_id'):
            proyectos_permitidos_ids = self.env.user.get_proyecto_obra_asignado_ids()
            if not vals.get('proyecto_id') in proyectos_permitidos_ids:
                raise AccessError('No puede crear novedades para este proyecto, debe ser un coordinador o especialista asociado')
        project_problema_obj = super(project_problema, self).create(vals)
        return project_problema_obj


    @api.one
    def write(self, vals):
        if (vals.get('proyecto_id') or self.proyecto_id):
            proyectos_permitidos_ids = self.env.user.get_proyecto_obra_asignado_ids()
            if not vals.get('proyecto_id') in proyectos_permitidos_ids and not self.proyecto_id.id in proyectos_permitidos_ids:
                raise AccessError('No puede editar novedades para este proyecto, debe ser un coordinador o especialista asociado')
        res = super(project_problema, self).write(vals)
        return res


class project_meta_tipo(models.Model):
    _name = 'project.meta.tipo'
    _description = 'Tipificación Meta de Proyecto'
    _inherit = ['project.meta.tipo']

    # -------------------
    # Fields
    # -------------------
    tipo_elemento_id = fields.Many2one(
        string='Tipo Elemento Infraestructura',
        required=False,
        comodel_name='infraestructura_urbana.elemento.tipo',
        ondelete='restrict',
    )

    # -------------------
    # methods
    # -------------------


class project_meta(models.Model):
    _inherit = 'project.meta'

    # -------------------
    # Fields
    # -------------------
    proyecto_plan_id = fields.Many2one(
        string='Proyecto Plan',
        required=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto_plan',
        ondelete='restrict',
        help='''Proyecto Plan Relacionado''',
    )

    meta_hacienda_id = fields.Many2one(
        string='Meta Hacienda',
        required=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto_plan.meta_hacienda',
        ondelete='restrict',
        help='''Meta de Hacienda Relacionada''',
        domain="[('proyecto_plan_id','=',proyecto_plan_id)]",
    )
    plan_desarrollo_id = fields.Many2one(
        string='Plan Desarrollo Distrital',
        comodel_name='plan_desarrollo_distrital.plan',
        related='meta_hacienda_id.plan_desarrollo_id',
        readonly=True,
        store=True,
        ondelete='restrict',
    )

    @api.onchange('project_id')
    def _onchange_project_id(self):
        proyecto = self.env['project_obra.proyecto'].browse(self.env.context.get('proyecto_id'))
        plan_ids = proyecto.proyecto_plan_ids.mapped('proyecto_plan_id.id')
        return {
            'domain': {
                'proyecto_plan_id': [('id', 'in', plan_ids),],
            }
        }

    @api.onchange('proyecto_plan_id')
    def _onchange_project_id(self):
        proyecto = self.env['project_obra.proyecto'].browse(self.env.context.get('proyecto_id'))
        plan_ids = proyecto.proyecto_plan_ids.mapped('proyecto_plan_id.id')
        if self.proyecto_plan_id.id not in plan_ids:
            self.proyecto_plan_id = False
        return {
            'domain': {
                'proyecto_plan_id': [('id', 'in', plan_ids),],
            }
        }
