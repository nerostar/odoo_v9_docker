# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api
from openerp.exceptions import ValidationError, Warning
from openerp.tools import config as odoo_config
import json
import logging
import predios_client_ws
import requests
from datetime import date, datetime, timedelta
from base64 import b64encode
from openerp.addons.base_idu.tools.arcgis_utility import arcgis_utility

_logger = logging.getLogger(__name__)



def enviar_mensaje_con_plantilla(objeto, contexto, plantilla, nombre_adj="", contenido_adj=""):
    try:
        if nombre_adj and contenido_adj:
            objeto.with_context(contexto).message_post_with_template(plantilla.id,
                notify=False,
                composition_mode='mass_mail',
                attachment_ids=[(0, 0, {'name':nombre_adj, 'datas_fname': nombre_adj, 'datas': b64encode(contenido_adj)})]
                )
        else:
            objeto.with_context(contexto).message_post_with_template(plantilla.id,
            notify=False,
            composition_mode='mass_mail'
            )
    except Exception, e:
        _logger.error('No se pudo enviar el mensaje a los destinatarios, por favor verifique que estos si tengan dirección valida, el nombre del adjunto y el contenido.')
        _logger.exception(e)





class project_obra_proyecto_plan_meta_hacienda(models.Model):
    _name = 'project_obra.proyecto_plan.meta_hacienda'
    _description = 'Relacion m2m entre Metas de Hacienda y Proyectos Plan'
    _inherit = ['mail.thread']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=255,
        help='''Nombre de la meta hacienda''',
        compute='_compute_name',
        store=True
    )
    proyecto_plan_id = fields.Many2one(
        string='Proyecto Plan',
        required=True,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto_plan',
        ondelete='restrict',
        help='''Proyecto Plan Relacionado''',
        default=lambda self: self._context.get('proyecto_plan_id', None),
    )
    plan_desarrollo_id = fields.Many2one(
        string='Plan de Desarrollo',
        required=True,
        track_visibility='onchange',
        comodel_name='plan_desarrollo_distrital.plan',
        ondelete='restrict',
        help='''Plan de desarrollo asociado''',
    )
    meta_hacienda_id = fields.Many2one(
        string='Meta Hacienda',
        required=False,
        track_visibility='onchange',
        comodel_name='plan_desarrollo_distrital.metas_hacienda',
        ondelete='restrict',
        help='''Meta hacienda''',
        domain="[('proyecto_institucional_id.programa_id.plan_id','=',plan_desarrollo_id)]",
    )

    @api.one
    @api.depends('proyecto_plan_id.name', 'plan_desarrollo_id.name', 'meta_hacienda_id.name')
    def _compute_name(self):
        self.name = '{} - {} - {}'.format(self.proyecto_plan_id.name, self.plan_desarrollo_id.name, self.meta_hacienda_id.name)

class project_obra_proyecto_plan_rel(models.Model):
    _name = 'project_obra.proyecto_proyecto_plan_rel'
    _description = 'Relacion m2m Proyectos con Proyecto Plan'
    _inherit = ['mail.thread']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=255,
        help='''Nombre de la meta hacienda''',
        compute='_compute_name',
        store=True
    )
    proyecto_plan_id = fields.Many2one(
        string='Proyecto Plan',
        required=True,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto_plan',
        ondelete='restrict',
        help='''Proyecto Plan Relacionado''',
        default=lambda self: self._context.get('proyecto_plan_id', None),
    )
    proyecto_id = fields.Many2one(
        string='Proyecto Contrato',
        required=True,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
        default=lambda self: self._context.get('proyecto_id', None),
    )
    _sql_constraints = [
        ('unique_proyecto_plan_proyecto', 'unique(proyecto_plan_id, proyecto_id)', 'Estos proyectos ya estan asociado'),
    ]

    @api.one
    def _compute_name(self):
        self.name = '{} - {}'.format(self.proyecto_plan_id.name, self.proyecto_id.name)


class project_obra_proyecto_plan(models.Model):
    _name = 'project_obra.proyecto_plan'
    _description = 'Proyectos Plan de Obra e Infraestructura'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    name = fields.Char(
        string='Nombre',
        track_visibility='onchange',
        required=True,
    )
    codigo = fields.Char(
        string='Código Plan ZIPA',
        required=False,
        track_visibility='onchange',
        size=15,
    )
    state = fields.Selection(
        string='Estado',
        selection=[
            ('draft', 'Nuevo'),
            ('open', 'En Progreso'),
            ('cancelled','Cancelado'),
            ('pending','Pendiente'),
            ('close','Cerrado'),
            ],
        track_visibility='onchange',
        required=True,
        default='draft',
    )
    proyecto_obra_ids = fields.One2many(
        string='proyecto_obra_ids',
        comodel_name='project_obra.proyecto_proyecto_plan_rel',
        inverse_name='proyecto_plan_id',
        track_visibility='onchange',
    )
    meta_hacienda_ids = fields.One2many(
        string='Metas Hacienda',
        comodel_name='project_obra.proyecto_plan.meta_hacienda',
        inverse_name='proyecto_plan_id',
        track_visibility='onchange',
    )

    poblacion = fields.Integer(
        string='Población',
        required=False,
        track_visibility='onchange',
    )
    longitud = fields.Float(
        string='Longitud en Kilometros',
        required=False,
        track_visibility='onchange',
    )
    area = fields.Float(
        string='Área en Metros Cuadrados',
        required=False,
        track_visibility='onchange',
    )
    localidad_id = fields.Many2one(
        string='Localidad',
        required=False,
        comodel_name='res.country.state.city.district',
        ondelete='restrict',
    )
    company_id = fields.Many2one(
        string='Compañía',
        required=False,
        comodel_name='res.company',
        ondelete='restrict',
        default=lambda self: self.env.user.company_id,
    )
    currency_id = fields.Many2one(
        string='Moneda',
        required=False,
        readonly=True,
        related='company_id.currency_id',
        comodel_name='res.currency',
        ondelete='restrict',
    )
    costos_estimados_factibilidad = fields.Monetary(
        string='Costos de Factibilidad',
        required=False,
        track_visibility='onchange',
    )
    costos_estimados_diseno = fields.Monetary(
        string='Costos de Diseño',
        required=False,
        track_visibility='onchange',
    )
    costos_estimados_gestion_predial = fields.Monetary(
        string='Costos de Gestión Predial',
        required=False,
        track_visibility='onchange',
    )
    costos_estimados_obra = fields.Monetary(
        string='Costos de Obra',
        required=False,
        track_visibility='onchange',
    )
    costo_estimado_total = fields.Monetary(
        string='Costo Total',
        required=False,
        track_visibility='onchange',
        compute='_compute_costo_estimado_total',
    )

    @api.model
    def create(self, vals):
        codigo_plan_zipa = self.env['ir.sequence'].next_by_code('project_obra.codigo_plan_zipa.secuencia')
        vals.update({'codigo': codigo_plan_zipa})
        proyecto_plan = super(project_obra_proyecto_plan, self).create(vals)
        return proyecto_plan

    @api.one
    @api.depends('costos_estimados_obra', 'costos_estimados_gestion_predial', 'costos_estimados_diseno', 'costos_estimados_factibilidad')
    def _compute_costo_estimado_total(self):
        self.costo_estimado_total = self.costos_estimados_obra + self.costos_estimados_gestion_predial + self.costos_estimados_diseno + self.costos_estimados_factibilidad


class project_obra_proyecto(models.Model):
    _name = 'project_obra.proyecto'
    _description = 'Proyectos de Obra e Infraestructura'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']
    _inherits = {
        'project.project': 'project_id',
    }
    _order = "sequence ASC, id DESC "

    # -------------------
    # Fields
    # -------------------
    sequence = fields.Integer(
        string='Sequencia de Ordenamiento',
        required=False,
    )
    state = fields.Selection(
        string='Estado',
        required=True,
        selection=[
            ('draft', 'Nuevo o Registrado'),
            ('open', 'En Progreso o En ejecución'),
            ('pending', 'Pendiente o Por iniciar siguiente etapa del ciclo de vida'),
            ('close', 'Cerrado o Terminado'),
        ],
        default='draft',
    )
    proyecto_plan_ids = fields.One2many(
        string='Proyectos Plan',
        required=False,
        comodel_name='project_obra.proyecto_proyecto_plan_rel',
        inverse_name='proyecto_id',
        ondelete='restrict',
        track_visibility='onchange',
    )
    eje_id = fields.Many2one(
        string='Eje Víal',
        required=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.eje',
        ondelete='restrict',
    )
    motivo_cierre = fields.Text(
        string='Motivo Aplazamiento o Cancelación',
        required=False,
        track_visibility='onchange',
        help='''Indicar el mótivo por el cual se aplaza o cancela el proyecto''',
    )
    project_id = fields.Many2one(
        string='Proyecto Odoo',
        required=True,
        readonly=True,
        track_visibility='onchange',
        comodel_name='project.project',
        ondelete='restrict',
    )
    tag_ids = fields.Many2many(
        string='Etiquetas',
        required=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.tag',
        ondelete='restrict',
    )
    codigo = fields.Char(
        string='Código ZIPA',
        required=False,
        track_visibility='onchange',
        size=15,
    )
    codigo_sigidu = fields.Char(
        string='Código SIGIDU',
        required=False,
        track_visibility='onchange',
        size=15,
    )
    codigo_valoricemos = fields.Char(
        string='Código Valoricemos',
        required=False,
        track_visibility='onchange',
        size=15,
    )
    origen_id = fields.Many2one(
        string='Origen',
        required=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.origen',
        ondelete='restrict',
    )
    etapa_ids = fields.One2many(
        string='Etapas',
        required=False,
        comodel_name='project_obra.proyecto.etapa',
        inverse_name='proyecto_id',
        ondelete='restrict',
        domain=[('parent_id', '=', False)],
    )
    photo_ids = fields.One2many(
        string='Galeria de Fotos',
        required=False,
        comodel_name='photo_gallery.photo',
        inverse_name='proyecto_obra_id',
        ondelete='restrict',
    )
    localidad_ids = fields.Many2many(
        string='Localidades',
        required=False,
        comodel_name='res.country.state.city.district',
        ondelete='restrict',
    )
    proceso_selectivo_ids = fields.One2many(
        string='Procesos Selectivos',
        required=False,
        comodel_name='proceso_selectivo.proceso',
        inverse_name='proyecto_id',
        ondelete='restrict',
    )
    frente_obra_ids = fields.One2many(
        string='Frentes de Obra',
        required=False,
        comodel_name='project_obra.proyecto.frente_obra',
        inverse_name='proyecto_id',
        ondelete='restrict',
    )
    indicador_predios_requeridos = fields.Integer(
        string='No. Predios Requeridos',
        required=False,
        track_visibility='onchange',
        help='''Conteo de todos los predios (RT's) que están asociados al proyecto''',
    )
    indicador_predios_entregados = fields.Integer(
        string='No. Predios Entregados',
        required=False,
        track_visibility='onchange',
        help='''Conteo de todos los predios (RT's) que ya fueron entregados al IDU (son los que ya tienen Acta de Entrega al IDU)''',
    )
    indicador_predios_pendientes = fields.Integer(
        string='No. Predios Pendientes',
        required=False,
        track_visibility='onchange',
        help='''Diferencia del # Predios Requeridos - # Predios Entregados''',
    )
    indicador_predios_disponibles = fields.Integer(
        string='No. Predios Disponibles',
        required=False,
        track_visibility='onchange',
        help='''Conteo de todos los predios (RT's) que están disponibles''',
    )
    indicador_predios_valor_estimado = fields.Monetary(
        string='Valor Estimado de Predios',
        required=False,
        track_visibility='onchange',
        help='''Suma del valor de todos los predios requeridos para la obra''',
    )
    indicador_predios_valor_ejecutado = fields.Monetary(
        string='Valor Ejecutado de Predios',
        required=False,
        track_visibility='onchange',
        help='''Suma del valor de compromisos (CRP)''',
    )
    indicador_predios_valor_girado = fields.Monetary(
        string='Valor Girado de Predios',
        required=False,
        track_visibility='onchange',
        help='''Suma del valor de ordenes de pago''',
    )
    visibilidad = fields.Selection(
        string='Visibilidad',
        required=False,
        track_visibility='onchange',
        help='''Público sera deplegado en el sitio web de proyectos del público, IDU solo lo desplegará en los sitios web con cuentas de usuario''',
        selection=[
            ('publico', 'Público - En Ejecución'),
            ('publico-terminado', 'Público - Terminados'),
            ('idu', 'IDU'),
            ('publico-ejecucion-y-liquidacion','Público - En Ejecución y Liquidacion'),
        ],
        default='idu',
    )
    integrante_ids = fields.One2many(
        string='Integrantes/Responsables',
        required=False,
        comodel_name='project_obra.integrante',
        inverse_name='proyecto_id',
        ondelete='restrict',
    )
    project_id = fields.Many2one(
        comodel_name="project.project",
        ondelete='restrict',
        required=True,
    )
    predios_obra_id = fields.Integer(
        string='Sistema Predios  - ID de la Obra',
        required=False,
        track_visibility='onchange',
        help='''Este ID se usa para poder consultar los datos para este proyecto en el sistema de predios''',
    )
    enlace_encuesta_otc = fields.Char(
        string='Enlace de encuesta de la OTC',
        track_visibility='onchange',
    )
    fecha_planeada_inicio = fields.Date(
        string='Fecha de Inicio Planeada',
        required=False,
        track_visibility='onchange',
        compute='_compute_fechas',
        store=True,
    )
    fecha_planeada_fin = fields.Date(
        string='Fecha de Finalización Planeada',
        required=False,
        track_visibility='onchange',
        compute='_compute_fechas',
        store=True,
    )
    
    total_empleos_directos = fields.Integer(
        string="Total empleos Directos",
        compute="_compute_empleos",
        store=False
    )
    total_empleos_indirectos = fields.Integer(
        string="Total empleos Directos",
        compute="_compute_empleos",
        store=False
    )
    total_empleos=fields.Integer(
        string ="Total empleos",
        compute="_compute_empleos",
        store=False
        )

    _sql_constraints = [
        ('unique_codigo_valoricemos', 'unique(codigo_valoricemos)', 'Este codigo_valoricemos ya está registrado'),
        ('unique_project_id', 'unique(project_id)', 'Este project_id ya está registrado'),
        ('unique_codigo_sigidu', 'unique(codigo_sigidu)', 'Este codigo_sigidu ya está registrado'),
        ('unique_codigo', 'unique(codigo)', 'Este codigo ya está registrado'),
    ]

    # -------------------
    # methods
    # -------------------
    @api.model
    def create(self, vals):
        codigo_zipa = self.env['ir.sequence'].next_by_code('project_obra.codigo_zipa.secuencia')
        vals.update({'codigo': codigo_zipa})
        proyecto = super(project_obra_proyecto, self).create(vals)
        proyecto.project_id.write({
            'obra_proyecto_id': proyecto.id,
            'usa_problemas': True,
            'proyecto_tipo': 'obra',
            'active': False,  # El registro no se elimina, solo que no es visible en el listado de project.project,
                             # por el momento no es necesario que la gente acceda a este project.project
                             # si se requiere solo se desarchiva el registro y se gestiona comun y corriente.
        })
        return proyecto
    
    @api.one
    @api.depends('etapa_ids.empleos_directos')
    def _compute_empleos(self):
        #Sumatoria de empleos directos para cada una de las etapas
        total_directos = 0
        total_indirectos = 0
        for etapa in self.etapa_ids:
            if (etapa.empleos_directos!=False and etapa.empleos_directos!=None):
                total_directos=total_directos+etapa.empleos_directos
            if (etapa.empleos_indirectos!=False and etapa.empleos_indirectos!=None):
                total_indirectos=total_indirectos+etapa.empleos_indirectos    
        total_empleos = total_directos+total_indirectos
        self.total_empleos_directos=total_directos
        self.total_empleos_indirectos=total_indirectos
        self.total_empleos = total_empleos
        
    @api.one
    @api.depends('etapa_ids.edt_raiz_id.fecha_planeada_inicio', 'etapa_ids.edt_raiz_id.fecha_planeada_fin')
    def _compute_fechas(self):
        """Las fechas de inicio y fin del proyecto serán las de la última etapa en progreso. En caso que las
        etapas estén todas cerradas o nuevas se tomarán las fechas más recientes de todas las etapas"""
        fechas_etapas_en_progreso = []
        fechas_etapas = []
        for etapa in self.etapa_ids:
            fechas_planeadas = (etapa.fecha_planeada_fin, etapa.fecha_planeada_inicio)
            if etapa.state == 'open':
                fechas_etapas_en_progreso.append(fechas_planeadas)
            fechas_etapas.append(fechas_planeadas)
        if fechas_etapas_en_progreso:
            fechas_etapas_en_progreso.sort(reverse=True)
            self.fecha_planeada_inicio = fechas_etapas_en_progreso[0][1]
            self.fecha_planeada_fin = fechas_etapas_en_progreso[0][0]
        elif fechas_etapas:
            fechas_etapas.sort(reverse=True)
            self.fecha_planeada_inicio = fechas_etapas[0][1]
            self.fecha_planeada_fin = fechas_etapas[0][0]
        else:
            self.fecha_planeada_inicio = False
            self.fecha_planeada_fin = False
        return True

    @api.multi
    def edt_arbol_view_button(self):
        return self.project_id.edt_arbol_view_button()

    @api.multi
    def etapa_view_button(self):
        return {
            'name': 'Etapas',
            'res_model': 'project_obra.proyecto.etapa',
            'domain': [('proyecto_id', '=', self.id), ('parent_id', '=', False)],
            'context': {'proyecto_id': self.id},
            'type': 'ir.actions.act_window',
            'view_mode': 'tree,form',
            'view_type': 'form',
        }

    @api.multi
    def problema_view_button(self):
        return {
            'name': 'Novedades',
            'res_model': 'project.problema',
            'domain': [('project_id', '=', self.project_id.id)],
            'context': {'project_id': self.project_id.id, 'proyecto_id': self.id},
            'type': 'ir.actions.act_window',
            'view_mode': 'tree,form',
            'view_type': 'form',
        }

    @api.one
    def actualizar_indicadores_prediales(self, wsdl_url=None):
        if not wsdl_url or type(wsdl_url) == dict:
            wsdl_url = self.env['ir.config_parameter'].get_param('predios_idu.webservice.wsdl')
        if not self.predios_obra_id:
            return False
        indicadores = predios_client_ws.get_indicadores_predios(self.predios_obra_id, wsdl_url)
        return self.write({
            'indicador_predios_entregados': indicadores['predios_entregados'],
            'indicador_predios_pendientes': indicadores['predios_pendientes'],
            'indicador_predios_requeridos': indicadores['rt_utilizados'],
        })

    @api.model
    def predios_actualizar_indicadores_prediales_cron(self):
        _logger.info('Iniciando CRON predios_actualizar_indicadores_prediales_cron')
        proyectos = self.search([
            ('state', 'in', ['open', 'pending']),
            ('predios_obra_id', '>', 0),
        ])
        wsdl_url = self.env['ir.config_parameter'].get_param('predios_idu.webservice.wsdl')
        if not wsdl_url:
            _logger.error('No esta configurado la URL del servicio web de Predios')
            return False
        for proyecto in proyectos:
            try:
                _logger.info('Proyecto {}'.format(proyecto.id))
                proyecto.actualizar_indicadores_prediales(wsdl_url)
            except Exception as e:
               _logger.error('predios_actualizar_indicadores_prediales_cron falló con: ' + str(e))
        _logger.info('Fin CRON predios_actualizar_indicadores_prediales_cron')
        return True

    def search(self, cr, uid, args, offset=0, limit=None, order=None, context=None, count=False, xtra=None):
        new_args = self.adiciona_keywords_en_search(cr, uid, args, offset, limit, order, context, count, xtra)
        return super(project_obra_proyecto, self).search(cr, uid, new_args, offset, limit, order, context, count)

    def adiciona_keywords_en_search(self, cr, uid, args, offset, limit, order, context, count, xtra):
        new_args = []
        for arg in args:
            if type(arg) is not tuple and type(arg) is not list:
                new_args += arg
                continue
            if arg[2] == 'MIS_PROYECTOS':
                user = self.pool.get('res.users').browse(cr, uid, uid)
                proyecto_ids = user.get_proyecto_obra_asignado_ids()
                new_args += [(arg[0], arg[1], proyecto_ids)]
            else:
                new_args += [arg]
        return new_args

class project_obra_proyecto_tag(models.Model):
    _name = 'project_obra.proyecto.tag'
    _description = 'Etiqueta de Proyectos de Obra'
    _inherit = ['models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        size=255,
    )

    _sql_constraints = [
        ('unique_name', 'unique(name)', 'Este name ya está registrado'),
    ]

    # -------------------
    # methods
    # -------------------

class project_obra_proyecto_eje(models.Model):
    _name = 'project_obra.proyecto.eje'
    _description = 'Eje Proyectos de Obra'
    _inherit = ['models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        size=255,
    )

    _sql_constraints = [
        ('unique_name', 'unique(name)', 'Este name ya está registrado'),
    ]

    # -------------------
    # methods
    # -------------------

class project_obra_proyecto_origen(models.Model):
    _name = 'project_obra.proyecto.origen'
    _description = 'Origen Proyectos de Obra'
    _inherit = ['models.soft_delete.mixin']
    _order = "sequence ASC, id DESC "
    # -------------------
    # Fields
    # -------------------
    sequence = fields.Integer(
    string='Sequencia de Ordenamiento',
    required=False,
    )
    name = fields.Char(
        string='Nombre',
        required=True,
        size=255,
    )
    es_visible_website = fields.Boolean(
        string="Es visible en sitio web",
        required=False,
    )

    _sql_constraints = [
        ('unique_name', 'unique(name)', 'Este name ya está registrado'),
    ]

    # -------------------
    # methods
    # -------------------

class project_obra_proyecto_etapa(models.Model):
    
    _name = 'project_obra.proyecto.etapa'
    _description = 'Etapa Proyectos de Obra e Infraestructura'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']
    _inherits = {
        'project.project': 'project_id',
    }
    _order = "sequence ASC, id DESC "

    # -------------------
    # Fields
    # -------------------
    sequence = fields.Integer(
        string='Sequencia de Ordenamiento',
        required=False,
    )
    state = fields.Selection(
        string='Estado',
        required=True,
        selection=[
            ('draft', 'Nuevo o Registrado'),
            ('open', 'En Progreso o En ejecución'),
            ('pending', 'Pendiente o Por iniciar siguiente etapa del ciclo de vida'),
            ('close', 'Cerrado o Terminado'),
        ],
        default='draft',
    )
    proyecto_id = fields.Many2one(
        string='Proyecto',
        required=True,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
        default=lambda self: self._context.get('proyecto_id', None),
    )
    project_id = fields.Many2one(
        string='Proyecto Odoo',
        required=True,
        readonly=True,
        invisible=True,
        track_visibility='onchange',
        comodel_name='project.project',
        ondelete='restrict',
    )
    tipo_id = fields.Many2one(
        string='Tipo',
        required=True,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.etapa.tipo',
        ondelete='restrict',
    )
    parent_id = fields.Many2one(
        string='Etapa Padre',
        required=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.etapa',
        ondelete='restrict',
        default=lambda self: self._context.get('parent_id', None),
    )
    child_ids = fields.One2many(
        string='Sub Etapas',
        required=False,
        comodel_name='project_obra.proyecto.etapa',
        inverse_name='parent_id',
        ondelete='restrict',
    )
    novedad_cronograma_ids = fields.One2many(
        string='Novedades en cronograma',
        required=False,
        comodel_name='project_obra.proyecto.etapa.novedad_cronograma',
        inverse_name='etapa_id',
        ondelete='restrict',
    )
    costo_contratos_sin_interventoria = fields.Monetary(
        string='Costo Contratos Sin Interventoria',
        required=False,
        compute='_compute_costo_contratos_sin_interventoria',
    )
    
    empleos_directos = fields.Integer(
         string='Empleos Directos',
         required=False,
        )
    empleos_indirectos = fields.Integer(
         string='Empleos Indirectos',
         required=False,
        )
    empleos_total = fields.Integer(
         string="Empleos Totales",
         compute="_get_total_empleos"
        )

    _sql_constraints = [
        ('unique_project_id', 'unique(project_id)', 'Este project_id ya está registrado'),
    ]

    # -------------------
    # methods
    # -------------------
    @api.onchange('empleos_directos','empleos_indirectos')
    def _get_total_empleos(self):
        for rec in self:
            empleos_directos = rec.empleos_directos
            if (empleos_directos == None):
                empleos_directos = 0
            empleos_indirectos = rec.empleos_indirectos
            if (empleos_indirectos==None):
                empleos_indirectos = 0
            rec.empleos_total=empleos_directos+empleos_indirectos

    @api.model
    def create(self, vals):

    #     estado = vals.get('state')
    #     if (estado and estado == 'open'):
    #         proyecto_id = vals.get('proyecto_id')
    #         if not proyecto_id:
    #             proyecto_id = self.env.context.get('proyecto_id', '')
    #             if proyecto_id:
    #                 etapas_abiertas = self.search(
    #                     [
    #                         ('proyecto_id','=',proyecto_id),
    #                         ('state','=','open')
    #                     ]
    #                 )
    #                 if etapas_abiertas:
    #                     raise Warning('Existe una o más etapas en progreso relacionadas a este proyecto.')

        proyecto_etapa = super(project_obra_proyecto_etapa, self).create(vals)
        vals_project = {
            'obra_proyecto_id': proyecto_etapa.proyecto_id.id,
            'obra_etapa_tipo_id': proyecto_etapa.tipo_id.id,
            'proyecto_tipo': 'obra_etapa',
            'active': False,  # El registro no se elimina, solo que no es visible en el listado de project.project,
                             # por el momento no es necesario que la gente acceda a este project.project
                             # si se requiere solo se desarchiva el registro y se gestiona comun y corriente.
        }
        if not 'edt_raiz_id' in vals:
            vals_project['edt_raiz_id'] = proyecto_etapa.proyecto_id.project_id.edt_raiz_id.id
        if not 'parent_id' in vals:
            vals_project['project_padre_id'] = proyecto_etapa.proyecto_id.project_id.id
        if 'parent_id' in vals:
            vals_project['project_padre_id'] = proyecto_etapa.parent_id.project_id.id
        proyecto_etapa.project_id.write(vals_project)
        return proyecto_etapa


    # @api.multi
    # def write(self, vals):
    #     estado = vals.get('state','')
    #     if estado == 'open':
    #         proyecto_id = vals.get('proyecto_id', '')
    #         if not proyecto_id:
    #             proyecto_id = self.env.context.get('proyecto_id', '')
    #         etapas_abiertas = self.search(
    #             [
    #                 ('proyecto_id','=',proyecto_id),
    #                 ('state','=','open')
    #             ]
    #         )
    #         if etapas_abiertas:
    #             raise Warning('Existe una o más etapas en progreso relacionadas a este proyecto.')

    #     result = super(project_obra_proyecto_etapa, self).write(vals)

    #     return result



    @api.model
    def cron_alerta_vencimiento_etapa(self):
        fecha_actual = date.today()
        fecha_limite = fecha_actual + timedelta(days=15)


        etapas = self.search([('state','=','open'),('fecha_planeada_fin','<=',fecha_limite.strftime('%Y-%m-%d'))])
        for etapa in etapas:
            fecha_fin = etapa.fecha_planeada_fin
            fecha_vencimiento = datetime.strptime(fecha_fin, '%Y-%m-%d').date()
            fecha_15 = fecha_vencimiento - timedelta(days=15)
            fecha_10 = fecha_vencimiento - timedelta(days=10)
            fecha_5 = fecha_vencimiento - timedelta(days=5)

            # si hoy es la fecha de fin planeada menos 15 o 10 o 5 dias o ya paso la fecha de fin planeada:
            if (fecha_actual >= fecha_vencimiento or fecha_actual == fecha_15 or fecha_actual == fecha_10 or fecha_actual == fecha_5):

                contratos = etapa.contrato_ids
                coordinadores = []
                jefes_area = []
                contratos_nombres = []
                correos_coordinador_tecnico = []
                correos_revisor_tecnico = []
                correos_jefes_area = []
                for contrato in contratos:
                    if not contrato.siac_tipo_contrato_id.es_interventoria:     # and contrato.estado_siac_id.id == 1
                        contratos_nombres.append(contrato.numero)
                        coordinadores.extend(self.env['contrato.coordinador_contrato'].search([('contrato_id', '=', contrato.id), ('tipo', '=', 'tecnico')]))
                        jefes_area.append(contrato.dependencia_id.manager_id.user_id)

                        correos_coordinador_tecnico = [coor.user_id.email for coor in coordinadores if (coor.user_id.email and type(coor.user_id.email) in [unicode, str])] if coordinadores else []
                        if not correos_coordinador_tecnico :
                            _logger.error('No se pudo enviar el mensaje al coordinador técnico, por favor verifique que estos si tenga dirección válida.')

                        revisores = self.env['contrato.coordinador_contrato'].search([('contrato_id', '=', contrato.id), ('tipo', '=', 'revisor')])
                        correos_revisor_tecnico = [rev.user_id.email for rev in revisores if (rev.user_id.email and type(rev.user_id.email) in [unicode, str])] if revisores else []
                        if not correos_revisor_tecnico :
                            _logger.error('No se pudo enviar el mensaje al revisor técnico, por favor verifique que estos si tenga dirección válida.')


                        correos_jefes_area = [jefe.email for jefe in jefes_area if (jefe.email and type(jefe.email) in [unicode, str]) ] if jefes_area else []
                        if not correos_jefes_area :
                            _logger.error('No se pudo enviar el mensaje a jefes de área, por favor verifique que estos si tenga dirección válida.')


                mensaje = """<h1>Alerta de vencimiento de etapa</h1>
            <b>Señor/a usuario/a:</b>
            </br>
            </br>
            </br>
            <p>La etapa: <b>{}</b>, proyecto: <b>{}</b>, asociado al contrato(s) {} tienen fecha de finalización planeada <b>{}</b>.</p>
            </br>
            </br>
            <p>Por favor adelantar las gestiones necesarias para garantizar el cumplimento de las obligaciones correspondientes o iniciar el trámite de solicitud de modificación de la fecha de finalización planeada.</p>
            </br>
            </br>
            <p><strong>Nota:</strong> Mensaje enviado automáticamente por el Sistema ZIPA - Gestión Proyectos.</p>""".format(etapa.name, etapa.proyecto_id.name, ' ,'.join(contratos_nombres), fecha_fin)


                correos = correos_coordinador_tecnico + correos_revisor_tecnico + correos_jefes_area + ['admin.zipa@idu.gov.co']
                titulo = '[IDU] Notificación de vencimiento de etapa: {}'.format(etapa.name)
                try:
                    self.env['base.correo'].enviar_correo('adminerp@idu.gov.co', correos, titulo, mensaje, [], 'html')
                except Exception as e:
                    _logger.warning('No fue posible enviar el correo de notificación vencimiento de etapas, {}'.format(e))

        return True




    @api.model
    def cron_alerta_vencimiento_amparos(self):
        SIAC_ID_LIQUIDADO = 9
        SIAC_ID_EN_EJECUCION = 10
        TIPOS_AMPARO_A_EXCLUIR=['BUEN MANEJO DEL PAGO ANTICIPADO','BUEN MANEJO DEL ANTICIPO']
        fecha_actual = date.today()
        contratos = []
        for etapa in self.search([('proyecto_id','!=','')]):
            for c in etapa.contrato_ids:
                if c.id not in contratos:
                    contratos.append(c.id)
                    if c.estado_siac_id and c.estado_siac_id.siac_id in [SIAC_ID_LIQUIDADO,SIAC_ID_EN_EJECUCION]:
                        amparos_contrato = []
                        for poliza in c.poliza_ids:
                            if poliza.amparos:
                                try:
                                    amparos_contrato.extend(json.loads(poliza.amparos))
                                except Exception as e:
                                    _logger.warning('No fue posible adicionar los amparos del contrato con id {} al cron que envía alerta de vencimiento de polizas. Error: {}'.format(c.id, e))
                        if len(amparos_contrato) > 0:
                            amparos_contrato.sort(key=lambda x:x['fecha_fin'], reverse=True)
                            amparos_contratos_agrupados = {}
                            estabilidad_calidad_obra_ya = False
                            for a in amparos_contrato:
                                if a['tipo'] not in amparos_contratos_agrupados and a['tipo'] not in TIPOS_AMPARO_A_EXCLUIR:
                                    if a['tipo'] in ['RESPONSABILIDAD CIVIL', 'CALIDAD', 'ESTABILIDAD Y CALIDAD DE LA OBRA']:
                                        if c.estado_siac_id and c.estado_siac_id.name not in ['EN EJECUCION', 'SUSPENDIDO']:
                                            continue
                                    if estabilidad_calidad_obra_ya:
                                        continue
                                    if a['tipo'] in ['ESTABILIDAD', 'CALIDAD DE LA OBRA,' 'ESTABILIDAD Y CALIDAD DE LA OBRA']:
                                        estabilidad_calidad_obra_ya = True
                                    amparos_contratos_agrupados[a['tipo']] = a
                                    fecha_fin = a['fecha_fin']
                                    fecha_vencimiento = datetime.strptime(fecha_fin, '%Y-%m-%d').date()
                                    fecha_15 = fecha_vencimiento - timedelta(days=15)
                                    fecha_10 = fecha_vencimiento - timedelta(days=10)
                                    fecha_5 = fecha_vencimiento - timedelta(days=5)

                                    # # si hoy es la fecha de fin planeada menos 15 o 10 o 5 dias o ya paso la fecha de fin planeada:
                                    if (fecha_actual >= fecha_vencimiento or fecha_actual == fecha_15 or fecha_actual == fecha_10 or fecha_actual == fecha_5):
                                        mensaje = """
                <b>Señor/a usuario/a:</b>
                </br>
                </br>
                </br>
                <p>El amparo <b>{}</b> del contrato <b>{}</b> tienen fecha de vencimiento <b>{}</b>.</p>
                </br>
                </br>
                <p>Favor realizar las gestiones para actualizar su vigencia o liquidar el contrato.</p>
                </br>
                </br>
                <p><strong>Nota:</strong> Mensaje enviado automáticamente por el Sistema ZIPA - Gestión Proyectos.</p>""".format(a['tipo'], c.numero, fecha_fin)

                                        coordinadores = []
                                        correos_coordinador_tecnico = []
                                        correos_revisor_tecnico = []
                                        correo_jefe_area = []
                                        if not c.siac_tipo_contrato_id.es_interventoria:
                                            coordinadores.extend(self.env['contrato.coordinador_contrato'].search([('contrato_id', '=', c.id), ('tipo', '=', 'tecnico')]))
                                            jefe_area = c.dependencia_id.manager_id.user_id

                                            correos_coordinador_tecnico = [coor.user_id.email for coor in coordinadores if (coor.user_id.email and type(coor.user_id.email) in [unicode, str])] if coordinadores else []

                                            if not correos_coordinador_tecnico :
                                                _logger.error('No se pudo enviar el mensaje al coordinador técnico, por favor verifique que estos si tenga dirección válida.')

                                            revisores = self.env['contrato.coordinador_contrato'].search([('contrato_id', '=', c.id), ('tipo', '=', 'revisor')])
                                            correos_revisor_tecnico = [rev.user_id.email for rev in revisores if (rev.user_id.email and type(rev.user_id.email) in [unicode, str])] if revisores else []

                                            if not correos_revisor_tecnico :
                                                _logger.error('No se pudo enviar el mensaje al revisor técnico, por favor verifique que estos si tenga dirección válida.')

                                            correo_jefe_area = [jefe_area.email] if (jefe_area.email and type(jefe_area.email) in [unicode, str]) and jefe_area else []

                                            if not correo_jefe_area :
                                                _logger.error('No se pudo enviar el mensaje a jefe de área, por favor verifique que si tenga dirección válida.')


                                        correos = correos_coordinador_tecnico + correos_revisor_tecnico + correo_jefe_area + ['admin.zipa@idu.gov.co']
                                        titulo = '[IDU] Notificación de vencimiento de Amparo a contrato {}'.format(c.numero)
                                        try:
                                            self.env['base.correo'].enviar_correo('adminerp@idu.gov.co', correos, titulo, mensaje, [], 'html')
                                        except Exception as e:
                                            _logger.warning('No fue posible enviar el correo de notificación vencimiento de amparos, {}'.format(e))
        return True



    @api.model
    def crear_informe_cero(self):
        contratos = self.search([('state','=','open')]).mapped('contrato_ids')
        #contratos = self.search([('tipo_id.name','in',['Estudios y Diseños','Construcción','Conservación','preconstruccion','factibilidad'])]).map('contrato_ids')
        contratos_en_ejecucion = contratos.filtered(lambda c: (c.estado_siac_id.name == 'EN EJECUCION' and (c.tipo_id.name != 'interventoria' and c.siac_tipo_contrato_id.siac_id != 2)))
        contratos_en_ejecucion = list(set(contratos_en_ejecucion))
        contrato_no_aplica = self.env['contrato.contrato'].search([('numero', 'like', '%NO APLICA%')])
        for contrato in contratos_en_ejecucion:
            contrato_interventoria = contrato.interventoria_ids[0] if contrato.interventoria_ids else contrato_no_aplica
            dependencia = contrato.dependencia_id.abreviatura
            informe_construccion_model = self.env['project_obra.construccion.informe_avance']
            informe_conservacion_model = self.env['project_obra.conservacion.informe_avance']
            informes_construccion = informe_construccion_model.search([('contrato_id','=',contrato.id)])
            informes_conservacion = informe_conservacion_model.search([('contrato_id','=',contrato.id)])
            if (len(informes_construccion) + len(informes_conservacion)) == 0:
                if dependencia:
                    crear_informe_wizard_model = self.env['project_obra.seguimiento.wizard.crear_informe']
                    fecha = contrato.fecha_inicio
                    datos = {
                        'user_id': 3922,        # Admin ZIPA
                        'periodo_fecha_inicio': fecha,
                        'periodo_fecha_fin': fecha,
                        'contrato_id': contrato.id,
                        'contrato_interventoria_id': contrato_interventoria.id,
                        'semana': 0,
                    }
                    print(datos)
                    inf_wizard = crear_informe_wizard_model.with_context(publicar=True).sudo().create(datos)
                    inf = inf_wizard.crear_informe()
                    print(inf)
        return True
        
    
    @api.model
    def cron_actualizar_capas_sigidu(self):
        #Traer Servicio de configuracion capa de SIGIDU
        _logger.info("Actualizando capas del sigidu")
        servicio_de_proyectos = self.env["ir.config_parameter"].get_param("project_obra_portafolio_idu.feat_layer_proyectos_visor")
        arcgis_server_url = self.env["ir.config_parameter"].get_param("integraciones.arcgis_server_url")
        arcgis_portal_url = self.env["ir.config_parameter"].get_param("integraciones.portal_server_url")
        
        _agsUtil = arcgis_utility(arcgis_server_url=arcgis_server_url, 
                              arcgis_portal_url=arcgis_portal_url)
      
        usuario_sigidu = self.env["ir.config_parameter"].get_param("integraciones.arcgis_usuario_sigidu")
        clave_sigidu = self.env["ir.config_parameter"].get_param("integraciones.arcgis_clave_sigidu")
        token = _agsUtil.getArcgisToken(usuario_sigidu, clave_sigidu)
        #Obtener la lista de proyectos
        parametros = {
            "where" :"1=1",
            "returnGeometry":"false",
            "outFields":"objectid,CODIGO_ZIPA,FOTO2,NOMBRE",
            "f":"json",
            "token":token
        }
        project_model = self.env["project_obra.proyecto"]  
        #qProyectos = arcgis_server_url+"/"+ servicio_de_proyectos+"/0/query"
        qProyectos = servicio_de_proyectos+"/query?"
        update_features = []
        try:
            result_ags = _agsUtil.call_server(qProyectos,parametros)
            if (result_ags.code==200):
                _ags_result = result_ags.read()
                ags_result = json.loads(_ags_result)
                if "features" in ags_result:
                    for _feature in ags_result["features"]:
                        attributes = _feature["attributes"]
                        oid = attributes["OBJECTID"]
                        codigo_zipa = attributes["CODIGO_ZIPA"]
                        current_state = attributes["FOTO2"]
                        current_nombre = attributes["NOMBRE"]
                        czipa = int(codigo_zipa)                    
                        proyectos = project_model.search([('codigo','=',str(czipa))])
                        for _proyecto in  proyectos:
                            state = _proyecto.state
                            if (state!=current_state or current_nombre!=_proyecto.name):
                                new_feat = {
                                    "attributes":{
                                    "OBJECTID":oid,
                                    "FOTO2":str(state),
                                    "NOMBRE":_proyecto.name
                                    }
                                }       
                                update_features.append(new_feat)
                if (len(update_features)>0):
                    qUpdate = servicio_de_proyectos+"/updateFeatures"
                    #temp_features = update_features[2:4]
                    str_features = json.dumps(update_features) 
                    parameters={"features":str_features,"f":"json","rollbackOnFailure":False,"trueCurveClient":True,"token":token}
                    update_result = _agsUtil.call_server(qUpdate,parameters)
                    message_result = _ags_result = result_ags.read()                    
                    if (update_result.code==200):
                        _logger.info("Actualizada capa de proyectos de SIGIDU")
                        _logger.info(message_result)
                    else:
                        _logger.error("Error Actualizando Capa de proyectos de SIGIDU")
                        _logger.error(message_result)
                        
        except Exception as e:
            _logger.error("No se pudo contactar servidor de SIGIDU")
            _logger.error(e)        
        return True



    @api.model
    def get_datos_desempeno_al_corte(self, fecha_ini, fecha_fin):
        """Retorna estructura de datos con desempeño registrado al corte"""
        informe_cabecera_model = self.env['project_obra.informe_cabecera']
        res = {}
        for etapa in self:
            informe_cabecera = informe_cabecera_model.search(
                [
                    ('etapa_actual_id', '=', etapa.id),
                    ('fecha', '>=', fecha_ini), ('fecha', '<=', fecha_fin),
                    # TODO: Activar filtro por estado ('state','!=','nuevo'),
                ],
                order='fecha DESC, id DESC',
                limit=1,
            )

            tipo_etapa = etapa.tipo_id.name
            if not tipo_etapa in res:
                res[tipo_etapa] = {
                    'etapas': {}, 'sum_programado': 0, 'sum_ejecutado': 0, 'sum_variacion': 0,
                    'prom_programado': 0, 'prom_ejecutado': 0, 'prom_variacion': 0,
                    'conteo_problemas': 0, 'conteo_reportes': 0, 'valor_total_contratos': 0,
                    'fecha': False, 'informe_cabecera': False,
                }

            res[tipo_etapa]['etapas'][etapa.id] = {
                'etapa': etapa, 'programado': '-', 'ejecutado': '-', 'variacion': '-',
                'ultima_variacion': '-', 'observaciones': '-', 'ultima_observacion': '',
                'fecha': '-', 'ultima_variacion_fecha': '-',
            }

            res[tipo_etapa]['conteo_problemas'] += len(etapa.project_id.problema_ids.filtered(lambda r: r.state == 'abierto'))

            if informe_cabecera and len(informe_cabecera.informe_por_contrato_ids) > 0:
                desempeno = informe_cabecera.informe_por_contrato_ids[0]
                res[tipo_etapa]['informe_cabecera'] = informe_cabecera
                programado = desempeno.programado_porcentaje_avance_fisico_acumulado
                ejecutado = desempeno.ejecutado_porcentaje_avance_fisico_acumulado
                variacion = ejecutado - programado
                res[tipo_etapa]['etapas'][etapa.id].update({
                    'etapa': etapa, 'programado': programado,
                    'ejecutado': ejecutado, 'variacion': variacion,
                    'observaciones': '', 'fecha': informe_cabecera.fecha,
                })
                res[tipo_etapa]['fecha'] = res[tipo_etapa]['fecha'] or informe_cabecera.fecha  # Asigna fecha si no esta definida
                if informe_cabecera.fecha > res[tipo_etapa]['fecha']:
                    res[tipo_etapa]['fecha'] = informe_cabecera.fecha
                res[tipo_etapa]['etapas'][etapa.id]['reporte_desempeno_id'] = False  # TODO: colocar cabecera ID y hacer pagina que despliegue este reporte
                res[tipo_etapa]['etapas'][etapa.id]['informe_cabecera_id'] = informe_cabecera.id
                costo_contratos_sin_interventoria = etapa.costo_contratos_sin_interventoria
                costo_programado = programado * costo_contratos_sin_interventoria
                costo_ejecutado = ejecutado * costo_contratos_sin_interventoria
                res[tipo_etapa]['sum_programado'] += costo_programado
                res[tipo_etapa]['sum_ejecutado'] += costo_ejecutado
                res[tipo_etapa]['sum_variacion'] += costo_ejecutado - costo_programado
                res[tipo_etapa]['valor_total_contratos'] += costo_contratos_sin_interventoria
                res[tipo_etapa]['prom_programado'] = res[tipo_etapa]['sum_programado'] / res[tipo_etapa]['valor_total_contratos'] if res[tipo_etapa]['sum_programado'] else 0.0
                res[tipo_etapa]['prom_ejecutado'] = res[tipo_etapa]['sum_ejecutado'] / res[tipo_etapa]['valor_total_contratos'] if res[tipo_etapa]['sum_ejecutado'] else 0.0
                res[tipo_etapa]['prom_variacion'] = res[tipo_etapa]['sum_variacion'] / res[tipo_etapa]['valor_total_contratos'] if res[tipo_etapa]['sum_variacion'] else 0.0

                informe_cabecera_anterior = informe_cabecera_model.search(
                    [
                        ('etapa_actual_id', '=', etapa.id),
                        ('id', '!=', informe_cabecera.id)
                        # TODO: Activar filtro por estado ('state','!=','nuevo'),
                    ],
                    order='fecha DESC, id DESC',
                    limit=1,
                )
                if informe_cabecera_anterior and len(informe_cabecera_anterior.informe_por_contrato_ids) > 0 :
                    anterior_desempeno = informe_cabecera_anterior.informe_por_contrato_ids[0]
                    res[tipo_etapa]['fecha'] = res[tipo_etapa]['fecha'] or informe_cabecera_anterior.fecha  # Asigna fecha si no esta definida
                    if informe_cabecera_anterior.fecha > res[tipo_etapa]['fecha']:
                        res[tipo_etapa]['fecha'] = informe_cabecera_anterior.fecha

                    res[tipo_etapa]['etapas'][etapa.id]['ultima_variacion'] = anterior_desempeno.ejecutado_porcentaje_avance_fisico_acumulado - anterior_desempeno.programado_porcentaje_avance_fisico_acumulado
                    res[tipo_etapa]['etapas'][etapa.id]['ultima_observacion'] = ''
                    res[tipo_etapa]['etapas'][etapa.id]['ultima_variacion_fecha'] = informe_cabecera_anterior.fecha
                    res[tipo_etapa]['etapas'][etapa.id]['anterior_reporte_desempeno_id'] = False  # TODO: colocar cabecera ID y hacer pagina que despliegue este reporte
                    res[tipo_etapa]['etapas'][etapa.id]['anterior_informe_cabecera_id'] = informe_cabecera_anterior.id
            else:
                informe_cabecera_anterior = informe_cabecera_model.search(
                    [
                        ('etapa_actual_id', '=', etapa.id),
                        # TODO: Activar filtro por estado ('state','!=','nuevo'),
                    ],
                    order='fecha DESC, id DESC',
                    limit=1,
                )
                if informe_cabecera_anterior and len(informe_cabecera_anterior.informe_por_contrato_ids) > 0 :
                    anterior_desempeno = informe_cabecera_anterior.informe_por_contrato_ids[0]
                    res[tipo_etapa]['fecha'] = res[tipo_etapa]['fecha'] or informe_cabecera_anterior.fecha  # Asigna fecha si no esta definida
                    if informe_cabecera_anterior.fecha > res[tipo_etapa]['fecha']:
                        res[tipo_etapa]['fecha'] = informe_cabecera_anterior.fecha

                    res[tipo_etapa]['etapas'][etapa.id]['ultima_variacion'] = anterior_desempeno.ejecutado_porcentaje_avance_fisico_acumulado - anterior_desempeno.programado_porcentaje_avance_fisico_acumulado
                    res[tipo_etapa]['etapas'][etapa.id]['ultima_observacion'] = ''
                    res[tipo_etapa]['etapas'][etapa.id]['ultima_variacion_fecha'] = informe_cabecera_anterior.fecha
                    res[tipo_etapa]['etapas'][etapa.id]['anterior_reporte_desempeno_id'] = False  # TODO: colocar cabecera ID y hacer pagina que despliegue este reporte
                    res[tipo_etapa]['etapas'][etapa.id]['anterior_informe_cabecera_id'] = informe_cabecera_anterior.id
        return res
    
    
    

    @api.multi
    def edt_arbol_view_button(self):
        return self.project_id.edt_arbol_view_button()

    @api.multi
    def problema_view_button(self):
        return {
            'name': 'Problemas',
            'res_model': 'project.problema',
            'domain': [('project_id', '=', self.project_id.id)],
            'context': {'project_id': self.project_id.id},
            'type': 'ir.actions.act_window',
            'view_mode': 'tree,form',
            'view_type': 'form',
        }

    @api.one
    @api.depends('contrato_ids')
    def _compute_costo_contratos_sin_interventoria(self):
        total = 0
        for contrato in self.contrato_ids:
            if not contrato.tipo_id.es_interventoria:
                total += contrato.valor_contrato
                total += contrato.valor_adiciones
                total += contrato.mayor_cantidad_obra
        self.costo_contratos_sin_interventoria = total


class project_obra_proyecto_etapa_tipo(models.Model):
    _name = 'project_obra.proyecto.etapa.tipo'
    _description = 'Tipo de Etapas de Proyectos de Obra e Infraestructura'
    _inherit = ['models.soft_delete.mixin']
    _order = "sequence ASC, id DESC "
    # -------------------
    # Fields
    # -------------------
    sequence = fields.Integer(
    string='Sequencia de Ordenamiento',
    required=False,
    )
    name = fields.Char(
        string='Nombre',
        required=True,
        size=255,
    )
    web_color = fields.Char(
    string='Color en Sitio Web',
    required=True,
    size=8,
    )
    es_visible_website = fields.Boolean(
        string="Es visible en sitio web",
        required=False,
    )

    _sql_constraints = [
        ('unique_name', 'unique(name)', 'Este name ya está registrado'),
    ]

    # -------------------
    # methods
    # -------------------

class project_obra_reporte_desempeno_manual(models.Model):
    _name = 'project_obra.reporte_desempeno_manual'
    _description = 'Reporte de Variación de Desempeño'
    _inherit = ['mail.thread', 'models.soft_delete.mixin', 'models.fields.security.mixin']

    # _write_fields_whitelist = {
        # 'project.group_project_manager': ['state', 'observaciones'],
    # }
    # _write_fields_blacklist = {
        # 'project.group_project_user': ['observaciones'],
    # }

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        size=255,
        compute='_compute_name',
    )
    state = fields.Selection(
        string='Estado',
        required=True,
        track_visibility='onchange',
        help='''Flujo de registro y revisión de avance entre SGI y OAP''',
        selection=[
            ('registrado', 'Registrado'),
            ('por_revisar', 'Por Revisar'),
            ('pre_aprobado', 'Pre Aprobado'),
            ('devuelto', 'Devuelto'),
            ('aprobado', 'Aprobado'),
        ],
        default='registrado',
    )
    project_id = fields.Many2one(
        string='Etapa',
        required=True,
        comodel_name='project.project',
        ondelete='restrict',
        default=lambda self: self._context.get('project_id', None),
        domain=[('proyecto_tipo', '=', 'obra_etapa')],
        readonly=True,
        states={
            'registrado': [('readonly', False)],
            'devuelto': [('readonly', False)],
        }
    )
    edt_id = fields.Many2one(
        string='EDT',
        required=False,
        comodel_name='project.edt',
        ondelete='restrict',
        readonly=True,
    )
    archivo_mpp = fields.Binary(
        string='Archivo MPP',
        attachment=True,
    )
    archivo_mpp_fname = fields.Char('Nombre Archivo MPP')

    estado_etapa = fields.Selection(
        string='Estado Actual de la Etapa',
        required=True,
        selection=[
            ('sin_iniciar', 'sin_iniciar'),
            ('activo', 'activo'),
            ('suspendido', 'suspendido'),
        ],
        default='activo',
        readonly=True,
        states={
            'registrado': [('readonly', False)],
            'devuelto': [('readonly', False)],
        }
    )
    fecha = fields.Date(
        string='Fecha de Corte',
        required=True,
        track_visibility='onchange',
        default=fields.Date.today,
        readonly=True,
        states={
            'registrado': [('readonly', False)],
            'devuelto': [('readonly', False)],
        }
    )
    programado = fields.Float(
        string='Porcentaje Programado',
        required=True,
        track_visibility='onchange',
        readonly=True,
        states={
            'registrado': [('readonly', False)],
            'devuelto': [('readonly', False)],
        }
    )
    ejecutado = fields.Float(
        string='Porcentaje Ejecutado',
        required=True,
        track_visibility='onchange',
        readonly=True,
        states={
            'registrado': [('readonly', False)],
            'devuelto': [('readonly', False)],
        }
    )
    variacion = fields.Float(
        string='Variación',
        required=False,
        store=True,
        compute='_compute_variacion',
    )
    descripcion = fields.Text(
        string='Descripción del avance',
        required=False,
        track_visibility='onchange',
        help='''Descripción de los avances dados por el área técnica''',
        readonly=True,
        states={
            'registrado': [('readonly', False)],
            'devuelto': [('readonly', False)],
        }
    )
    observaciones = fields.Text(
        string='Observaciones de seguimiento',
        required=False,
        track_visibility='onchange',
        help='''Observaciones acerca del avance por parte del área de seguimiento y control''',
        readonly=True,
        states={
            'registrado': [('readonly', False)],
            'devuelto': [('readonly', False)],
        }
    )

    # -------------------
    # methods
    # -------------------

    @api.one
    def _compute_name(self):
        self.name = 'Variación de Desempeño al {} para {}'.format(self.fecha, self.project_id.name)

    @api.one
    @api.depends('programado', 'ejecutado')
    def _compute_variacion(self):
        self.variacion = self.ejecutado - self.programado

    @api.one
    @api.constrains('fecha')
    def _check_fecha(self):
        if odoo_config['test_enable']:
            return True
        hoy = fields.Date.today()
        if self.fecha and self.fecha > hoy:
            raise ValidationError('La fecha de corte no puede ser mayor a la fecha de hoy')
        return True

    @api.one
    @api.constrains('programado')
    def _check_programado(self):
        if self.programado < -1 or self.programado > 100:
            raise ValidationError("El valor programado debe estar entre 0 y 100")

    @api.one
    @api.constrains('ejecutado')
    def _check_ejecutado(self):
        if self.ejecutado < -1 or self.ejecutado > 100:
            raise ValidationError("El valor ejecutado debe estar entre 0 y 100")

    @api.onchange('fecha')
    def _onchange_fecha(self):
        try:
            self._check_fecha()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.onchange('programado')
    def _onchange_programado(self):
        try:
            self._check_programado()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.onchange('ejecutado')
    def _onchange_ejecutado(self):
        try:
            self._check_ejecutado()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    # -------------------
    # Workflow methods
    # -------------------
    def wkf_aprobado(self):
        self.state = 'aprobado'

    def wkf_registrado(self):
        self.state = 'registrado'

    def wkf_devuelto(self):
        self.state = 'devuelto'

    def wkf_por_revisar(self):
        self.state = 'por_revisar'


class project_obra_proyecto_etapa_novedad_cronograma(models.Model):
    _name = 'project_obra.proyecto.etapa.novedad_cronograma'
    _description = 'Novedad en Cronograma de Etapa de Proyecto'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Asunto',
        required=True,
        size=255,
    )
    tipo = fields.Selection(
        string='Tipo',
        required=True,
        selection=[
            ('prorroga', 'prorroga'),
            ('suspension', 'suspension'),
        ],
        default='prorroga',
    )
    fecha_inicio = fields.Date(
        string='Fecha de inicio',
        required=True,
        default=fields.Date.today,
    )
    fecha_fin = fields.Date(
        string='Fecha de Fin',
        required=True,
        default=fields.Date.today,
    )
    etapa_id = fields.Many2one(
        string='Etapa',
        required=True,
        comodel_name='project_obra.proyecto.etapa',
        ondelete='restrict',
        default=lambda self: self._context.get('etapa_id', None),
    )

    # -------------------
    # methods
    # -------------------

    @api.one
    @api.constrains('fecha_inicio')
    def _check_fecha_inicio(self):
        self._check_fechas()

    @api.one
    @api.constrains('fecha_fin')
    def _check_fecha_fin(self):
        self._check_fechas()

    @api.one
    def _check_fechas(self):
        if(self.fecha_inicio and self.fecha_fin and
           self.fecha_inicio > self.fecha_fin
            ):
            raise ValidationError("Fecha de inicio no puede ser posterior a la de finalización")

    @api.onchange('fecha_inicio')
    def _onchange_fecha_inicio(self):
        try:
            self._check_fecha_inicio()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.onchange('fecha_fin')
    def _onchange_fecha_fin(self):
        try:
            self._check_fecha_fin()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

class project_obra_proyecto_frente_obra(models.Model):
    _name = 'project_obra.proyecto.frente_obra'
    _description = 'Frente de Obra de Proyectos'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']
    _order = "sequence ASC, id DESC "

    # -------------------
    # Fields
    # -------------------
    sequence = fields.Integer(
        string='Sequencia de Ordenamiento',
        required=False,
    )
    name = fields.Char(
        string='Nombre',
        required=True,
        track_visibility='onchange',
        size=255,
    )
    proyecto_id = fields.Many2one(
        string='Proyecto',
        required=True,
        readonly=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
        default=lambda self: self._context.get('proyecto_id', self.env['project_obra.proyecto'].browse()),
    )
    linea_base_linea_id = fields.Many2one(
        string='Línea de la Línea Base',
        required=False,
        comodel_name='project.linea_base.linea',
        ondelete='restrict',
    )
    programado_tmp = fields.Float(
        string='Porcentaje Programado (campo temporal)',
        required=False,
    )
    ejecutado_tmp = fields.Float(
        string='Porcentaje Ejecutado (campo temporal)',
        required=False,
    )
    variacion_tmp = fields.Float(
        string='Variación (campo temporal)',
        required=False,
    )
    codigo_sigidu = fields.Char(
        string='Código SIGIDU',
        required=False,
        track_visibility='onchange',
        size=255,
    )
    district_id = fields.Many2one(
        string='Localidad',
        required=False,
        track_visibility='onchange',
        comodel_name='res.country.state.city.district',
        ondelete='restrict',
    )
    contrato_id = fields.Many2one(
        string='Contrato',
        required=False,
        track_visibility='onchange',
        comodel_name='contrato.contrato',
        ondelete='restrict',
    )
    tipo_etapa_id = fields.Many2one(
        string='Aplica a Etapa Tipo',
        required=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.etapa.tipo',
        ondelete='restrict',
    )
    elemento_ids = fields.Many2many(
        string='Elementos',
        required=False,
        track_visibility='onchange',
        comodel_name='infraestructura_urbana.elemento',
        relation='infr_urbana_frente_elemento_rel',
        ondelete='restrict',
    )
    fecha_planeada_inicio = fields.Date(
        string='Fecha de Inicio Planeada',
        required=False,
        track_visibility='onchange',
    )
    fecha_planeada_fin = fields.Date(
        string='Fecha de Finalización Planeada',
        required=False,
        track_visibility='onchange',
    )
    peso = fields.Integer(
        required=False,
        track_visibility='onchange',
    )
    huecos_conteo = fields.Float(
        string='Conteo de huecos reportados en el Collector',
        required=False,
    )
    huecos_area = fields.Float(
        string='Area de huecos reportados en el Collector',
        required=False,
    )
    huecos_volumen = fields.Float(
        string='Volumen de huecos reportados en el Collector',
        required=False,
    )


    # -------------------
    # methods
    # -------------------
    def _calcular_ejecucion_esperada(self, fecha):
        if not self.fecha_planeada_inicio or not self.fecha_planeada_fin:
            return 0
        fecha_inicio = fields.Date.from_string(self.fecha_planeada_inicio)
        fecha_fin = fields.Date.from_string(self.fecha_planeada_fin)
        fecha = fields.Date.from_string(fecha)
        dias_a_fecha = (fecha - fecha_inicio).days
        dias_totales = (fecha_fin - fecha_inicio).days
        valor_dia = 100.0 / dias_totales
        porcentaje_esperado = valor_dia * dias_a_fecha
        if porcentaje_esperado > 100:
            porcentaje_esperado = 100
        if porcentaje_esperado < 0:
            porcentaje_esperado = 0
        return porcentaje_esperado

    @api.one
    @api.constrains('peso')
    def _check_peso(self):
        if self.peso < 0 or self.peso > 100:
            raise ValidationError("El peso debe ser un valor entre 0 y 100")

    @api.onchange('peso')
    def _onchange_peso(self):
        try:
            self._check_peso()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.model
    def sincronizar_frentes_obra(self):
        parametros_model = self.env['ir.config_parameter']
        url_ws = parametros_model.get_param('project_obra_portafolio_idu.frentes')
        consulta_contratos = "{}/query?where=1%3D1&objectIds=&time=&geometry=&geometryType=esriGeometryEnvelope&inSR=&spatialRel=esriSpatialRelIntersects&distance=&units=esriSRUnit_Foot&relationParam=&outFields=CONTRATO&returnGeometry=false&maxAllowableOffset=&geometryPrecision=&outSR=&gdbVersion=&historicMoment=&returnDistinctValues=true&returnIdsOnly=false&returnCountOnly=false&returnExtentOnly=false&orderByFields=&groupByFieldsForStatistics=&outStatistics=&returnZ=false&returnM=false&multipatchOption=&returnTrueCurves=false&sqlFormat=none&f=pjson"
        if url_ws:
            peticion = requests.get(consulta_contratos.format(url_ws))
            datos = json.loads(peticion.text)
            for dato in datos.get("features", []):
                if 'attributes' in dato and 'CONTRATO' in dato['attributes']:
                    self.sincronizar_frentes_obra_para_contrato(url_ws, dato['attributes']['CONTRATO'])
        else:
            return {
                'title': "Error de URL",
                'warning': {'message': "No se ha establecido la url del servicio de frentes."}
            }


    @api.model
    def sincronizar_frentes_obra_para_contrato(self, url_ws, contrato_numero):
        contrato_model = self.env['contrato.contrato']
        project_obra_model = self.env['project_obra.proyecto']
        consulta_sql = "{}/query?where=CONTRATO%3D'{}'+AND+CODIGO_ZIPA+IS+NOT+NULL&objectIds=&time=&geometry=&geometryType=esriGeometryEnvelope&inSR=&spatialRel=esriSpatialRelIntersects&relationParam=&outFields=TRAMOFRENTEOBRA%2CCODIGO_FRENTE%2CLOCALIDAD%2CCONTRATO%2CCODIGO_ZIPA&returnGeometry=false&maxAllowableOffset=&geometryPrecision=&outSR=&gdbVersion=&returnDistinctValues=true&returnIdsOnly=false&returnCountOnly=false&orderByFields=&groupByFieldsForStatistics=&outStatistics=&returnZ=false&returnM=false&multipatchOption=&f=pjson"
        peticion = requests.get(consulta_sql.format(url_ws, contrato_numero))
        datos = json.loads(peticion.text)
        _logger.info('Consultando frentes para {}'.format(contrato_numero))
        for dato in datos.get("features", []):
            if 'attributes' in dato:
                proyecto = None
                nombre_frente = None
                contrato = None
                cod_frente = None
                if 'CODIGO_ZIPA' in dato["attributes"]:
                    attr_codigo_zipa = dato["attributes"]["CODIGO_ZIPA"]
                    if isinstance(attr_codigo_zipa, float):
                        attr_codigo_zipa = int(attr_codigo_zipa)
                    proyecto = project_obra_model.search([('codigo', '=', attr_codigo_zipa)])
                if 'CONTRATO' in dato["attributes"]:
                    contrato = contrato_model.search([
                        ('numero', '=', dato["attributes"]["CONTRATO"]),
                        ('dependencia_id.abreviatura', '=', 'DTM'),
                    ])
                if 'TRAMOFRENTEOBRA' in dato["attributes"]:
                    nombre_frente = dato["attributes"]["TRAMOFRENTEOBRA"]
                if 'CODIGO_FRENTE' in dato["attributes"]:
                    cod_frente = dato["attributes"]["CODIGO_FRENTE"]
                frente = None
                if proyecto and nombre_frente and contrato and cod_frente:
                    _logger.info('Sincronizando frente {} de {}'.format(nombre_frente, contrato_numero))
                    frente = self.search([('codigo_sigidu', '=', cod_frente)])
                    if frente:  # Los frentes van adoptar el nombre que tienen en el sigidu, por lo cual para los que ya tienen nombre, pero que tambien estan en sigidu se les actualiza
                        frente.write({'name':nombre_frente, 'proyecto_id':proyecto.id, 'codigo_sigidu':cod_frente, 'contrato_id':contrato.id})
                    else:  # Si no existe en zipa, pero si en sigidu, se crea con el nombre y datos del sigidu
                        frente = self.create({'name':nombre_frente, 'proyecto_id':proyecto.id, 'codigo_sigidu':cod_frente, 'contrato_id':contrato.id})

class project_obra_integrante(models.Model):
    _name = 'project_obra.integrante'
    _description = 'Integrante de Proyecto de Obra'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    proyecto_id = fields.Many2one(
        string='Proyecto de Obra',
        required=True,
        readonly=True,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
        default=lambda self: self._context.get('proyecto_id', self.env['project_obra.proyecto'].browse()),
    )
    user_id = fields.Many2one(
        string='Usuario en el Sistema',
        required=True,
        track_visibility='onchange',
        comodel_name='res.users',
        ondelete='restrict',
    )
    etapa_id = fields.Many2one(
        string='Etapa',
        required=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.etapa',
        ondelete='restrict',
        help='''No seleccione nada si no se limita la participación a una etapa''',
        domain="[('proyecto_id','=',proyecto_id)]",
        default=lambda self: self._context.get('etapa_id', self.env['project_obra.proyecto.etapa'].browse()),
    )

    # -------------------
    # methods
    # -------------------
