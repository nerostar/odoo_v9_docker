# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api

class res_users(models.Model):
    _name = 'res.users'
    _inherit = 'res.users'

    @api.model
    def get_proyecto_obra_asignado_ids(self):
        self.ensure_one()
        if self.env.uid == 1 or self.has_group('project.group_project_manager'):
            return self.env['project_obra.proyecto'].search([]).ids
        # TODO: Adicionar el uso de integrantes del proyecto 
        sql = """
            SELECT
                proyecto.id as proyecto_id, etapa.id as etapa_id, contrato.numero, contrato.id
            FROM
                contrato_coordinador_contrato coordinador
                LEFT JOIN contrato_contrato contrato ON coordinador.contrato_id = contrato.id
                LEFT JOIN contrato_contrato_project_project_rel AS c_p_relacion ON c_p_relacion.contrato_contrato_id = contrato.id
                LEFT JOIN project_project AS project_etapa ON c_p_relacion.project_project_id = project_etapa.id
                LEFT JOIN project_obra_proyecto_etapa AS etapa ON etapa.project_id = project_etapa.id
                LEFT JOIN project_obra_proyecto AS proyecto ON proyecto.id = etapa.proyecto_id
                LEFT JOIN project_project AS project_proyecto ON project_proyecto.id = proyecto.project_id
            WHERE
                coordinador.user_id = %s AND proyecto.id IS NOT NULL AND coordinador.active = 't'
        """
        self.env.cr.execute(sql, (self.id,))
        proyectos = self.env.cr.fetchall()
        return [ i[0] for i in proyectos ]
