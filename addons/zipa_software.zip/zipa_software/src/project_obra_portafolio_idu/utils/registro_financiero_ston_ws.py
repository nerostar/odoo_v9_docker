'''
Created on 9/02/2017

@author: manuel
'''

from suds.client import Client


def crear_diccionaro_pagos(prefijo_contrato,num_contrato,sufijo_contrato,valor_total_contrato,urlStoneWsdl):
    urlStone = urlStoneWsdl
    clienteStone = Client(urlStone)
    lista_diccionario_pagos = []
    listPagos = clienteStone.service.get_pagos_contrato(prefijo_contrato,num_contrato,sufijo_contrato)
    valor_acumulado = 0
    for x in range(0,len(listPagos)):
        pago = listPagos[x]
        valor_acumulado = valor_acumulado + pago['pre_op_valor']
        saldo_contrato = valor_total_contrato - valor_acumulado
        porcentaje_ejec = (valor_acumulado*100)/valor_total_contrato
        diccionario_pagos = {'op_numero': pago['pre_op_numero'], 
                             'op_fecha': pago['pre_op_fecha'], 
                             'op_valor': pago['pre_op_valor'],
                             'total_pagado':valor_acumulado,
                             'saldo_contrato':saldo_contrato,
                             'porcentaje_ejecucion':porcentaje_ejec}
        lista_diccionario_pagos.append(diccionario_pagos)
    return lista_diccionario_pagos       

def crear_encabezado_contrato(numero_contrato,urlSiacWsdl):
    urlSiac = urlSiacWsdl
    clienteSiac = Client(urlSiac)
    encabezado = clienteSiac.service.get_info_contrato(numero_contrato)
    diccionario_encabezado = {'codigo_contrato':numero_contrato,
                              'valor_inicial_contrato':encabezado[0]['valor_inicial_contrato'],
                              'descripcion_objeto':encabezado[0]['objeto_contrato'],
                              'identificacion_contratista':encabezado[0]['identificacion_contratista'],
                              'nombre_contratista':encabezado[0]['nombre_contratista']}
    return diccionario_encabezado
    
def generar_informe_contrato(prefijo_contrato,num_contrato,sufijo_contrato,urlStoneWsdl,urlSiacWsdl):

    
    diccionario_encabezado = crear_encabezado_contrato(prefijo_contrato+"-"+str(num_contrato)+"-"+sufijo_contrato,urlSiacWsdl)
    lista_diccionario_pagos = crear_diccionaro_pagos(prefijo_contrato,num_contrato,sufijo_contrato,diccionario_encabezado['valor_inicial_contrato'],urlStoneWsdl)
    diccionario_pagos_total = lista_diccionario_pagos[len(lista_diccionario_pagos)-1]
    diccionario_contrato = {'encabezado_contrato': diccionario_encabezado,
                            'lista_pagos':lista_diccionario_pagos,
                            'ultimo_registro':diccionario_pagos_total}
    
    return diccionario_contrato


def impimir_lista(lista_diccionario_pagos):
    for x in range(0,len(lista_diccionario_pagos)):
        print lista_diccionario_pagos[x]

def imprimir_obj(contrato_obj):
    print '<<<<<<<<<<<------------------------------------------------encabezado------------------------------------------------>>>>>>>>>>>>'
    print contrato_obj['encabezado_contrato']
    print '<<<<<<<<<<<--------------------------------------------------pagos--------------------------------------------------->>>>>>>>>>>>'
    impimir_lista(contrato_obj['lista_pagos'])
    print '<<<<<<<<<<<--------------------------------------------------total--------------------------------------------------->>>>>>>>>>>>'
    print contrato_obj['ultimo_registro']

imprimir_obj(generar_informe_contrato('IDU',326,'2014',"http://mv07cl01:9763/services/ws_stone?wsdl","http://mv07cl01:9763/services/ws_siac?wsdl"))


#imprimir_wsdl ()
