#!/usr/bin/python
# -*- coding: utf-8 -*-
from optparse import OptionParser
import csv
import erppeek
import logging
import requests
import json

logging.basicConfig()
_logger = logging.getLogger('script')

def main():
    usage = """Script para actualizar frente de obra con información proveniente del collector que esta guardada por elemento en el SIGIDU
    usage: %prog [options]"""
    parser = OptionParser(usage)
    parser.add_option("-n", "--odoo_db_name", dest="odoo_db_name", help="Odoo database name")
    parser.add_option("-u", "--odoo_db_user", dest="odoo_db_user",help="Odoo database user", default="admin")
    parser.add_option("-p", "--odoo_db_password", dest="odoo_db_password", help="Odoo database password", default="admin")
    parser.add_option("-s", "--odoo_host", dest="odoo_host", help="Odoo server host", default="http://localhost:8069")
    parser.add_option("-f", "--ws_frente_url", dest="ws_frente_url", help="URL del servicio de frentes")
    parser.add_option("-d", "--debug", action="store_true", dest="debug", help="Display debug message", default=False)

    (options, args) = parser.parse_args()
    _logger.setLevel(0)
    if options.debug:
        _logger.setLevel(10)

    check_obligatorios = ['odoo_db_name', 'odoo_db_user', 'odoo_db_password', 'ws_frente_url']
    for i in check_obligatorios:
        if not getattr(options, i):
            parser.error('{0} es obligatorio'.format(i))
    _logger.info('Cargando datos')
    summary = generar_summary(options)
    actualizar_frentes(options, summary)
    _logger.info("Terminado")

def generar_summary(options):
    """Returna un diccionario con los valores agregados del collector por frente de obra, a partir del servicio de elementos"""
    url_ws = options.ws_frente_url
    consulta_sql = "/query?where=CONTRATO+IN+%28%27IDU-1088-2016%27%2C+%27IDU-1092-2016%27%29&text=&objectIds=&time=&geometry=&geometryType=esriGeometryEnvelope&inSR=&spatialRel=esriSpatialRelIntersects&relationParam=&outFields=CODIGO_ZIPA%2CCODIGO_FRENTE%2COBSERVACION%2CCONTRATO&returnGeometry=false&maxAllowableOffset=&geometryPrecision=&outSR=&returnIdsOnly=false&returnCountOnly=false&orderByFields=&groupByFieldsForStatistics=&outStatistics=&returnZ=false&returnM=false&gdbVersion=&returnDistinctValues=false&returnTrueCurves=false&resultOffset=&resultRecordCount=&f=pjson"
    url_ws += consulta_sql
    peticion = requests.get(url_ws)
    datos = json.loads(peticion.text)
    summary = {}
    if not 'features' in datos:
        _logger.error('No hay features para la consulta: ' + consulta_sql)
        return False
    def convertir_valor_a_float(part, key):
        value = part.replace(key,'')
        value = value.replace(',', '.')
        value = value.strip()
        if not value:
            return 0
        try:
            return float(value)
        except:
            _logger.error('value: {} no pudo ser convertido.'.format(value))
        return None

    for dato in datos["features"]:
        if not 'attributes' in dato:
            _logger.warning('No hay atributos en el resultado')
            continue
        cod_frente = None
        if 'CODIGO_FRENTE' in dato["attributes"]:
            cod_frente = dato["attributes"]["CODIGO_FRENTE"]
        observaciones = dato["attributes"].get('OBSERVACION') #"No. huecos 5;area 242,12;volumen 24,22"
        if isinstance(observaciones, basestring):
            count_huecos = 0
            area_huecos = 0
            volumen_huecos = 0
            parts = observaciones.split(';')
            for part in parts:
                if 'No. huecos ' in part:
                    count_huecos = convertir_valor_a_float(part, 'No. huecos ')
                if 'area ' in part:
                    area_huecos = convertir_valor_a_float(part, 'area ')
                if 'volumen ' in part:
                    volumen_huecos = convertir_valor_a_float(part, 'volumen ')

        current_total = summary.get(cod_frente, {'huecos_conteo': 0, 'huecos_area': 0, 'huecos_volumen': 0})
        current_total['huecos_conteo'] += count_huecos
        current_total['huecos_area'] += area_huecos
        current_total['huecos_volumen'] += volumen_huecos
        summary.update({ cod_frente: current_total })
    return summary

def actualizar_frentes(options, summary):
    odoo = conectar_odoo_openerp(options.odoo_host, options.odoo_db_name, options.odoo_db_user, options.odoo_db_password)
    frente_model = odoo.model('project_obra.proyecto.frente_obra')
    for key, vals in summary.items():
        frente = frente_model.get([('codigo_sigidu','=',key)])
        if frente:
            _logger.info('Actualizando {} con valores: {}'.format(key, vals))
            frente.write(vals)
        else:
            _logger.warning('Frente no encontrado: {}'.format(key))

def conectar_odoo_openerp(server, db_name, user, password):
    _logger.debug('Contectando a: {0} {1}'.format(server, db_name));
    client = erppeek.Client(
        server,
        db_name,
        user,
        password,
    )
    return client

if __name__ == '__main__':
    main()
