"""Este snipped se puede copiar en una consola erppeek y muestra posibles sentencias SQL a ejecutar para corregir informes de avance de obra, que tienen asignados contratos incorrectos
Solo se debe diligenciar las variables, copiar y pegar en una consola erppeek conectada al servidor, revisar las sentencias SQL propuestas y copiar y pegar la que se requiera en una consola psql
"""
#######################################################
def do_run(tipo, contrato_numero, informe_id):
    model_name = 'project_obra.{}.informe_avance'.format(tipo)
    m = model(model_name)
    informe = m.get(informe_id)
    contrato = model('contrato.contrato').get([('numero = "{}"'.format(contrato_numero))]).id
    informe_por_contrato_ids = [i.id for i in informe.cabecera_id.informe_por_contrato_ids]
    print("[INFO] Informe por Contrato: {}".format(informe_por_contrato_ids))
    print("[INFO] ID Contrato {}".format(contrato))
    print("[SQL ] UPDATE project_obra_informe_por_contrato SET contrato_interventoria_id = {} WHERE id = {};".format(contrato, informe_por_contrato_ids[0]))
    print("[SQL ] UPDATE project_obra_informe_por_contrato SET contrato_id = {} WHERE id = {};".format(contrato, informe_por_contrato_ids[0]))

######################################################
contrato_numero = 'IDU-952-2017'
informe_id = 649
tipo = 'construccion'
#tipo = 'conservacion'

do_run(tipo, contrato_numero, informe_id)