#!/usr/bin/python
# -*- coding: utf-8 -*-
from optparse import OptionParser
import csv
import erppeek
import logging

logging.basicConfig()
_logger = logging.getLogger('script')

def main():
    usage = "Script para carga de datos de proyectos de Obra en odoo desde un CSV\nusage: %prog [options]"
    parser = OptionParser(usage)
    parser.add_option("-n", "--odoo_db_name", dest="odoo_db_name", help="Odoo database name")
    parser.add_option("-u", "--odoo_db_user",dest="odoo_db_user",help="Odoo database user", default="admin")
    parser.add_option("-p", "--odoo_db_password", dest="odoo_db_password", help="Odoo database password", default="admin")
    parser.add_option("-s", "--odoo_host", dest="odoo_host", help="Odoo server host", default="http://localhost:8069")
    parser.add_option("-f", "--filename", dest="filename", help="Archivo a cargar")
    parser.add_option("-d", "--debug", action="store_true", dest="debug", help="Display debug message", default=False)

    (options, args) = parser.parse_args()
    _logger.setLevel(0)
    if options.debug:
        _logger.setLevel(10)

    check_obligatorios = ['odoo_db_name', 'odoo_db_user', 'odoo_db_password', 'filename']
    for i in check_obligatorios:
        if not getattr(options, i):
            parser.error('{0} es obligatorio'.format(i))
    importar_datos(options)

responsable_id = 1
programador_id = 1
def importar_datos(options):
    global responsable_id
    global programador_id
    odoo = conectar_odoo_openerp(options.odoo_host, options.odoo_db_name, options.odoo_db_user, options.odoo_db_password)
    proyecto_model = odoo.model('project_obra.proyecto')
    etapa_model = odoo.model('project_obra.proyecto.etapa')
    etapa_tipo_model = odoo.model('project_obra.proyecto.etapa.tipo')
    edt_model = odoo.model('project.edt')
    user_model = odoo.model('res.users')

    with open(options.filename) as csvfile:
        cnt = 1
        reader = csv.DictReader(csvfile)
        last_proyecto_name = None
        proyecto = None
        etapa = None
        last_etapa_name = None
        try:
            responsable_id = user_model.get([('login','=','pfgalleg1')])
            programador_id = user_model.get([('login','=','cjvalbue3')])
        except:
            pass

        for row in reader:
            cnt += 1
            #if row['Código ZIPA'] != '66':
                #continue
            _logger.debug('Procesando Linea {0}: {1}'.format(cnt, row))

            if last_proyecto_name != row['Nombre']:
                last_proyecto_name = row['Nombre'].strip()
                proyecto = proyecto_model.get([('codigo','=',row['Código ZIPA'])])
                if not proyecto:
                    proyecto_datos = {}
                    try:
                        proyecto_datos['codigo_valoricemos'] = int(row['Código'])
                    except ValueError:
                        if row['Código'].strip():
                            proyecto_datos['codigo_sigidu'] = row['Código']

                    proyecto_datos.update({
                        'name': last_proyecto_name,
                        'codigo': row['Código ZIPA'].strip(),
                        'origen_id': get_origen(odoo, row['Origen'].strip()).id,
                        'user_id': responsable_id,
                        'programador_id': programador_id,
                        'edt_raiz_id': edt_model.create({
                            'name': 'Proyecto: ' + last_proyecto_name,
                            'user_id': responsable_id,
                            'programador_id': programador_id,
                        })
                    })
                    proyecto = proyecto_model.create(proyecto_datos)
                else:
                    proyecto.name = last_proyecto_name
            last_etapa_name = row['Etapa'].strip()
            etapa = get_or_create_etapa(odoo, last_etapa_name, proyecto, row, parent=None)
            sub_etapa_name = row['Sub Etapa'].strip()
            if sub_etapa_name:
                sub_etapa = get_or_create_etapa(odoo, sub_etapa_name, proyecto, row, etapa)

origen_cache = {}
def get_origen(odoo, origen_name):
    origen_model = odoo.model('project_obra.proyecto.origen')
    if origen_name in origen_cache:
        return origen_cache[origen_name]
    origen = origen_model.get([('name','=',origen_name)])
    if not origen :
        origen = origen_model.create({
            'name': origen_name,
        })
    origen_cache[origen_name] = origen
    return origen

tipo_etapa_cache = {}
def get_tipo_etapa(odoo, name):
    crear_proyecto = True
    if name.strip() in ['SUSPENSIÓN','PRÓRROGA','Suspensión']:
        return  (False, False)
    if name in tipo_etapa_cache:
        return (tipo_etapa_cache[name], crear_proyecto)
    model = odoo.model('project_obra.proyecto.etapa.tipo')
    objeto = model.get([('name','=',name)])
    if not objeto:
        objeto = model.create({
            'name': name,
            'web_color': '#FFF',
        })
    tipo_etapa_cache[name] = objeto
    return (objeto, crear_proyecto)

etapa_cache = {}
etapa_estados = {
    'CERRADO': 'close',
    'EN PROGRESO': 'open',
    'EN PROCESO': 'open',
    'NUEVO': 'draft',
}
def get_or_create_etapa(odoo, name, proyecto, row, parent=None):
    cache_key = '{}-{}-{}-{}'.format(proyecto.id, name, not not parent, hash(row['Nota'].strip()))
    if cache_key in etapa_cache:
        return etapa_cache[cache_key]
    etapa_model = odoo.model('project_obra.proyecto.etapa')
    edt_model = odoo.model('project.edt')
    etapa_nombre = 'Etapa: ' + name
    if row['Nota'].strip() and not parent: # Solo a las etapas le adiciona la nota como nombre
        etapa_nombre += ' - ' + row['Nota'].strip()
    dominio = [
        ('name','=',etapa_nombre),
        ('proyecto_id','=',proyecto.id),
    ]
    global responsable_id
    global programador_id
    if parent:
        dominio.append(('parent_id','=',parent.id))
    else:
        dominio.append(('parent_id','=',False))
    etapa = etapa_model.get(dominio,
        {'active_test': False}
    )
    if not etapa:
        tipo_etapa, construir_etapa = get_tipo_etapa(odoo, name)
        if construir_etapa:
            etapa_datos = {
                'name': etapa_nombre,
                'tipo_id': tipo_etapa.id,
                'state': etapa_estados[row['Estado Etapa']],
                'proyecto_id': proyecto.id,
                'user_id': responsable_id,
                'programador_id': programador_id,
                'edt_raiz_id': {
                    'name': name,
                    'user_id': responsable_id,
                    'programador_id': programador_id,
                }
            }
            if row['Fecha Inicio']:
                etapa_datos['edt_raiz_id']['fecha_inicio'] = row['Fecha Inicio']
                etapa_datos['edt_raiz_id']['fecha_planeada_inicio'] = row['Fecha Inicio']
            if row['Fecha Fin']:
                etapa_datos['edt_raiz_id']['fecha_fin'] = row['Fecha Fin']
                etapa_datos['edt_raiz_id']['fecha_planeada_fin'] = row['Fecha Fin']

            if row['Contratos Etapa']:
                contrato_ids = get_contrato_ids(odoo, row['Contratos Etapa'])
                etapa_datos['contrato_ids'] = [(6, 0, contrato_ids)]
            if parent: # Anidar como subetapa en EDT
                etapa_datos['edt_raiz_id']['parent_id'] = parent.edt_raiz_id.id
                etapa_datos['parent_id'] = parent.id
            else: # Anidar como etapa en EDT y asociarlo al proyecto
                etapa_datos['edt_raiz_id']['parent_id'] = proyecto.edt_raiz_id.id
            etapa_datos['edt_raiz_id'] = edt_model.create(etapa_datos['edt_raiz_id'])
            etapa = etapa_model.create(etapa_datos)
        else:
            novedad_model = odoo.model('project_obra.proyecto.etapa.novedad_cronograma')
            tipo = (name == 'PRÓRROGA' and 'prorroga') or 'suspension'
            novedad = novedad_model.get([
                ('etapa_id','=',parent.id),
                ('tipo','=',tipo),
                ('fecha_inicio','=',row['Fecha Inicio']),
                ('fecha_fin','=',row['Fecha Fin']),
            ])
            if not novedad:
                novedad_nombre = name
                if row['Nota'].strip():
                    novedad_nombre = row['Nota'].strip()
                novedad_model.create({
                    'name': novedad_nombre,
                    'tipo': tipo,
                    'fecha_inicio': row['Fecha Inicio'],
                    'fecha_fin': row['Fecha Fin'],
                    'etapa_id': parent.id,
                })
            return None
    tipo_etapa, construir_etapa = get_tipo_etapa(odoo, name)
    if not construir_etapa and parent:
        novedad_model = odoo.model('project_obra.proyecto.etapa.novedad_cronograma')
        tipo = (name == 'PRÓRROGA' and 'prorroga') or 'suspension'
        novedad = novedad_model.get([
            ('etapa_id','=',parent.id),
            ('tipo','=',tipo),
            ('fecha_inicio','=',row['Fecha Inicio']),
            ('fecha_fin','=',row['Fecha Fin']),
        ])
        if not novedad:
            novedad_nombre = name
            if row['Nota'].strip():
                novedad_nombre = row['Nota'].strip()
            novedad_model.create({
                'name': novedad_nombre,
                'tipo': tipo,
                'fecha_inicio': row['Fecha Inicio'],
                'fecha_fin': row['Fecha Fin'],
                'etapa_id': parent.id,
            })
        return None

    if etapa:
        if construir_etapa:
            etapa.write({
                'tipo_id': tipo_etapa.id,
                'active': True,
                'state': etapa_estados[row['Estado Etapa']],
            })
            edt_data = {'fecha_inicio': False, 'fecha_fin': False, 'active': True}
            if row['Fecha Inicio']:
                edt_data['fecha_inicio'] = row['Fecha Inicio']
                edt_data['fecha_planeada_inicio'] = row['Fecha Inicio']
            if row['Fecha Fin']:
                edt_data['fecha_fin'] = row['Fecha Fin']
                edt_data['fecha_planeada_fin'] = row['Fecha Fin']
            etapa.edt_raiz_id.write(edt_data)
            etapa.project_id.active = True
            etapa_cache[cache_key] = etapa
            #if not not row['Observaciones'] or not not row['% ejecutado']:
                #avance_model = odoo.model('project_obra.reporte_desempeno_manual')
                #avance_model.create({
                    #'project_id' : etapa.project_id.id,
                    #'fecha': row['Fecha de corte'] or '2016-07-01',
                    #'ejecutado': row['% ejecutado'] or -1,
                    #'programado': row['% programado'] or -1,
                    #'observaciones': row['Observaciones'] or False,
                #})
    else:
        raise Exception('No hay etapa!!!!')
    return etapa

def get_contrato_ids(odoo, contratos_txt):
    contratos = contratos_txt.split(',')
    contrato_model = odoo.model('contrato.contrato')
    res = []
    for c in contratos:
        try:
            contrato = contrato_model.create({'numero': c.strip()})
            res.append(contrato.id)
        except Exception, e:
            _logger.error('Error al crear contrato: {}: {}'.format(c, e))
    return list(set(res))

def conectar_odoo_openerp(server, db_name, user, password):
    _logger.debug('Contectando a: {0} {1}'.format(server, db_name));
    client = erppeek.Client(
        server,
        db_name,
        user,
        password,
    )
    return client

if __name__ == '__main__':
    main()
