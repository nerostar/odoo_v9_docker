#!/usr/bin/python
# -*- coding: utf-8 -*-
from optparse import OptionParser
import csv
import erppeek
import logging

logging.basicConfig()
_logger = logging.getLogger('script')

def main():
    usage = """Script para generar archivo con la información de seguimiento de las obras de conservación a nivel de detalle del elemento de obra.
    Se retornan los informes publicados y que hayan sido modificados en las fechas indicadas de inicio y fin.
    usage: %prog [options]"""
    parser = OptionParser(usage)
    parser.add_option("-n", "--odoo_db_name", dest="odoo_db_name", help="Odoo database name")
    parser.add_option("-u", "--odoo_db_user", dest="odoo_db_user",help="Odoo database user", default="admin")
    parser.add_option("-p", "--odoo_db_password", dest="odoo_db_password", help="Odoo database password", default="admin")
    parser.add_option("-s", "--odoo_host", dest="odoo_host", help="Odoo server host", default="http://localhost:8069")
    parser.add_option("-i", "--inicio", dest="fecha_inicio", help="Fecha Inicio del reporte Y-m-d")
    parser.add_option("-f", "--fin", dest="fecha_final", help="Fecha Final del reporte Y-m-d")
    parser.add_option("-o", "--output", dest="output", help="Directorio donde se guarda el archivo", default="./")
    parser.add_option("-d", "--debug", action="store_true", dest="debug", help="Display debug message", default=False)

    (options, args) = parser.parse_args()
    _logger.setLevel(0)
    if options.debug:
        _logger.setLevel(10)

    check_obligatorios = ['odoo_db_name', 'odoo_db_user', 'odoo_db_password']
    for i in check_obligatorios:
        if not getattr(options, i):
            parser.error('{0} es obligatorio'.format(i))
    _logger.info('Cargando datos')
    cabecera, data = execute(options)
    fname = "{}/conservacion_avances_por_elemento_consolidado.csv".format(options.output)
    _logger.info("Adicionando datos a archivo: " + fname)
    guardar_archivo(fname, data, 'a')
    fname = "{}/conservacion_avances_por_elemento_{}_{}.csv".format(options.output, options.fecha_inicio, options.fecha_final)
    _logger.info("Adicionando datos a archivo: " + fname)
    guardar_archivo(fname, data,'w', cabecera)
    _logger.info("Terminado")

def execute(options):
    odoo = conectar_odoo_openerp(options.odoo_host, options.odoo_db_name, options.odoo_db_user, options.odoo_db_password)
    informe_model = odoo.model('project_obra.conservacion.informe_avance')
    dominio = [('state', '=', 'publicado')]
    if options.fecha_inicio:
        dominio.append(('write_date','>=','{} 00:00:00'.format(options.fecha_inicio)))
    if options.fecha_final:
        dominio.append(('write_date','<=','{} 23:59:59'.format(options.fecha_inicio)))
    informe_ids = informe_model.search(dominio)
    _logger.debug(dominio)
    _logger.debug(informe_ids)
    res = []
    for informe_id in informe_ids:
        _logger.debug('Informe ID: {}'.format(informe_id))
        informe = informe_model.get(informe_id)
        fila = (
            informe_id,
            informe.write_date,
            informe.proyecto_id.codigo,
            informe.proyecto_id.name,
            informe.periodo_fecha_inicio,
            informe.periodo_fecha_fin,
            informe.semana,
            informe.etapa_actual_id.tipo_id.name,
            informe.contrato_id.numero,
            informe.contrato_interventoria_id.numero,
            informe.user_id.name,
        )
        for avance in informe.avance_por_frente_ids:
            if avance.elemento_ids:
                observaciones = ''
                for avance_meta in avance.ciudadano_avances_por_meta_fisica_ids:
                    if avance_meta.avance:
                        observaciones += "{}: {};".format(avance_meta.meta_fisica_id.tipo_id.name, avance_meta.avance)
                datos_por_elemento = (
                    avance.frente_id.name,
                    avance.frente_id.codigo_sigidu,
                    avance.tipo_elemento_id.name,
                    avance.tipo_intervencion_id.name,
                    avance.fase_conservacion_id.name,
                    avance.estado_id.name,
                    str(avance.programado_fecha_inicio),
                    str(avance.ejecutado_fecha_inicio),
                    str(avance.programado_fecha_fin),
                    str(avance.ejecutado_fecha_fin),
                    avance.programado_porcentaje_financiero,
                    avance.ejecutado_porcentaje_financiero,
                    avance.programado_porcentaje_fisico,
                    avance.ejecutado_porcentaje_fisico,
                    observaciones,
                )
                for elemento in avance.elemento_ids:
                    res.append(fila + datos_por_elemento + (elemento.codigo_sigidu, ))
    cabecera = (
            'informe_id',   #       'informe_id',
            'informe_write_date',   #       'informe.write_date',
            'informe_proyecto_id_codigo',   #       'informe.proyecto_id.codigo',
            'informe_proyecto_id_name',     #       'informe.proyecto_id.name',
            'informe_periodo_fecha_inicio', #       'informe.periodo_fecha_inicio',
            'informe_periodo_fecha_fin',    #       'informe.periodo_fecha_fin',
            'informe_semana',       #       'informe.semana',
            'informe_etapa_actual_tipo',    #       'informe.etapa_actual_tipo_id.name',
            'informe_contrato_id_numero',   #       'informe.contrato_id.numero',
            'informe_contrato_interventoria',       #       'informe.contrato_interventoria_id.numero',
            'informe_user_id_name', #       'informe.user_id.name',
            'avance_frente_nombre',
            'avance_frente_codigo',
            'avance_tipo_elemento_id',      #       'avance.tipo_elemento_id',
            'avance_tipo_intervencion',     #       'avance.tipo_intervencion_id.name',
            'avance_fase_conservacion',     #       'avance.fase_conservacion_id.name',
            'avance_estado_id_name',        #       'avance.estado_id.name',
            'avance_pr_fecha_inicio',       #       'avance.programado_fecha_inicio',
            'avance_ej_fecha_inicio',       #       'avance.ejecutado_fecha_inicio',
            'avance_pr_fecha_fin',  #       'avance.programado_fecha_fin',
            'avance_ej_fecha_fin',  #       'avance.ejecutado_fecha_fin',
            'avance_pr_porc_financiero',    #       'avance.programado_porcentaje_financiero',
            'avance_ej_por_financiero',     #       'avance.ejecutado_porcentaje_financiero',
            'avance_pr_por_fisico', #       'avance.programado_porcentaje_fisico',
            'avance_ej_por_fisico', #       'avance.ejecutado_porcentaje_fisico',
            'observaciones',        #       'observaciones',
            'elemento',     #       'elemento'
        )
    return cabecera, res

def guardar_archivo(fname, data, mode, cabecera=False):
    f = open(fname, mode)
    try:
        writer = csv.writer(f)
        if cabecera:
            writer.writerow(cabecera)
        for row in data:
            writer.writerow(row)
    finally:
        f.close()



def conectar_odoo_openerp(server, db_name, user, password):
    _logger.debug('Contectando a: {0} {1}'.format(server, db_name));
    client = erppeek.Client(
        server,
        db_name,
        user,
        password,
    )
    return client

if __name__ == '__main__':
    main()
