#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script que permite leer datos de las columnas y hojas indicadas de un archivo de excel y los carga en los respectivos modelos de Odoo
"""

__author__="Daniel Rene"
__copyright__="IDU"
__credits__="Daniel Rene"
__license__="GPL"
__version__="0.1.3"
__maintainer__="Daniel Rene"
__email__="daniel.chaparro@idu.gov.co"
__status__="En desarrollo"

import xlrd
import base64
import logging
from unicodedata import normalize, category
from datetime import datetime
from argparse import ArgumentParser
import erppeek
import pudb

logging.basicConfig()
_logger = logging.getLogger('INFO')
modelos = {}
listas = {}

def opciones_script() :
    """
    Funcion que captura los argumentos u opciones pasadas al script
    """
    parser = ArgumentParser()
    parser.add_argument("-f", "--file", dest="filename", help="Ruta absoluta al archivo xlsx o xls", metavar="FILE")
    parser.add_argument("-n", "--db_name", dest="db_name", help="Nombre de la base de datos de Odoo")
    parser.add_argument("-u", "--db_user",dest="db_user",help="Odoo database user")
    parser.add_argument("-p", "--db_password", dest="db_password", help="Odoo database password")
    parser.add_argument("-o", "--offset", dest="offset", help="Fila inicial")
    parser.add_argument("-s", "--host", dest="host", help="Odoo server host", default="http://localhost:8069")
    return parser.parse_args()

def procesar_archivo(nombre_archivo, nombre_hoja, lista_campos):
    archivo = xlrd.open_workbook(nombre_archivo)
    hoja = archivo.sheet_by_name(nombre_hoja)
    datos = {}
    aux = {}
    if len(lista_campos) <= hoja.ncols :
        for columna in lista_campos:
            lista = []
            for fila in range(1, hoja.nrows) :
                lista.append(hoja.cell_value(rowx=fila, colx=columna))
            datos[hoja.cell_value(rowx=0, colx=columna)] = lista
    return datos

def conectar_odoo(opts):
    '''
    Funcion que hace la conexion con el servidor de Odoo.
    @return Retorna una referencia a la conexion con el servidor.
    '''
    _logger.debug('Contectando a Odoo: {0}'.format(opts.db_name));
    client = erppeek.Client(
        opts.host,
        opts.db_name,
        opts.db_user,
        opts.db_password
    )
    return client

def buscar_objeto(modelo, campo='', valor=0) :
    '''
    Funcion que busca un objeto en un modelo determinado por el valor del id de este.
    '''
    if campo and valor:
        return modelo.browse([(campo,'=',valor)], context={'active_test':False})
    else:
        return modelo.browse([], context={'active_test':False})

def crear_registro(modelo, lista_campos, lista_valores):
    ''' Funcion que carga los datos pasados 'lista_xxx_campos' en el modelo (modelo).

    Esta funcion carga los datos pasados en las listas, en el modelo especificado, por lo cual solo carga un registro, asumiendo que se le pasan todos los valores obligatorios

    Parametros:
    modelo -- Modelo en el cual se cargaran los datos
    lista_nombre_campos -- Lista con los nombre de los campos dentro del modelo en donde se cargaran los datos
    lista_valores_campos -- Lista con los valores de los campos dentro del modelo en donde se cargaran los datos

    Excepciones:
    ....

    '''
    dic_escribir = {}
    for campo, valor in zip (lista_campos, lista_valores):
        if campo and valor:
            dic_escribir[campo] = valor
    if dic_escribir:
        try:
            return modelo.create(dic_escribir)   # Si lo creo, retorna el registro
        except Exception as e:
            print e
    else:
        return None # Si no lo creo, retorna cero, el cual es un id invalido

def actualizar_datos(modelo, registro, lista_campos, lista_valores, nombre_campo_condicion='', valor_campo_condicion=0) :
    ''' Funcion que actualiza los campos (lista_campos) con los valores (lista_valores) del modelo, que cumplen con la condicion
    modelo --
    lista_campos --
    lista_valores --
    nombre_campo_condicion -- Opcional, especifica el campo por el cual se hara la condicion, si no se pone se asume que se actualizaran todos los registros
    valor_campo_condicion -- Opcional, especifica el valor por el cual se hara la condicion, si no se pone se asume que se actualizaran todos los registros
    '''

    if registro:
        dic_escribir = {}
        for campo, valor in zip (lista_campos, lista_valores):
            if campo and valor:
                dic_escribir[campo] = valor
        if dic_escribir:
            try:
                return registro.write(dic_escribir)
            except Exception as e:
                print e
        else:
            return False # Si no lo actualizo, retorna False

def visualizar_datos(datos, nombre_columnas):
    cant_datos = len(datos[nombre_columnas[0]])
    for fila in range(cant_datos):
        for col in nombre_columnas:
            print datos[col][fila]
        print "*"*80

def principal() :
    argumentos = opciones_script()

#inicializo la conexion con odoo y referencio los modelos
    odoo = conectar_odoo(argumentos)

# Cargo los modelos en el diccionario
    modelos.update({"frente_obra":odoo.model('project_obra.proyecto.frente_obra')})
    modelos.update({"contrato":odoo.model('contrato.contrato')})

# Leo las columnas desde las hojas del archivo y las almaceno en un diccionario
    datos =  procesar_archivo(argumentos.filename, "frentes", [0,1,2,3,4])
    #visualizar_datos(datos, ['id_frente', 'nombre_sigidu', 'nombre_zipa', 'cod_frente'])
    cant_datos = len(datos['id'])
    for fila in range(cant_datos):
        id_frente = datos['id'][fila] if datos['id'][fila] else 0
        frente_obra = buscar_objeto(modelos['frente_obra'], 'id', id_frente) if id_frente else 0
        contrato = datos['cod_frente'][fila].split('-')
        contrato.pop(3)
        contrato = '-'.join(contrato)
        contrato = buscar_objeto(modelos['contrato'], 'numero', contrato) if contrato else 0
        # Si el frente de obra existe, lo actualiza con los nuevos datos
        if frente_obra and frente_obra[0] and contrato:
            actualizar_datos(
                modelo = modelos["frente_obra"],
                registro = frente_obra[0],
                lista_campos = ['contrato_id', 'proyecto_id', 'name', 'codigo_sigidu'],
                lista_valores = [contrato[0].id, datos['id_proyecto'][fila], datos['nombre_sigidu'][fila], datos['cod_frente'][fila]]
                )
            print "Se actualizo el frente: {}, cod: {}".format(datos['nombre_sigidu'][fila], datos['cod_frente'][fila])
        # Si el frente de obra no existe, lo crea con los nuevos datos
        elif contrato:
            # Si No esta en los datos del xlsx, pero esta actualmente dentro de zipa, lo busca y lo actualiza
            frente_obra = buscar_objeto(modelos['frente_obra'], 'codigo_sigidu', datos['cod_frente'][fila]) if datos['cod_frente'][fila] else 0
            if frente_obra and frente_obra[0]:
                actualizar_datos(
                modelo = modelos["frente_obra"],
                registro = frente_obra[0],
                lista_campos = ['contrato_id', 'proyecto_id', 'name', 'codigo_sigidu'],
                lista_valores = [contrato[0].id, datos['id_proyecto'][fila], datos['nombre_sigidu'][fila], datos['cod_frente'][fila]]
                )
                print "Se actualizo el frente: {}, cod: {}".format(datos['nombre_sigidu'][fila], datos['cod_frente'][fila])
            else:
                crear_registro(
                    modelo = modelos["frente_obra"],
                    lista_campos = ['contrato_id', 'proyecto_id', 'name', 'codigo_sigidu'],
                    lista_valores = [contrato[0].id, datos['id_proyecto'][fila], datos['nombre_sigidu'][fila], datos['cod_frente'][fila]]
                    )
                print "Se creo el frente: {}".format(datos['nombre_sigidu'][fila])
    return 0

if __name__=='__main__':  # Si es el archvo que se esta ejecutando, es decir el principal invoque a la funcion main()
    principal()
