#!/usr/bin/python
# -*- coding: utf-8 -*-
from optparse import OptionParser
import csv
import erppeek
import logging

logging.basicConfig()
_logger = logging.getLogger('script')

def main():
    usage = """Script para generar archivo con la información de las reuniones realizadas en las actividades de gestión social de obra.
    Se retornan las reuniones aprobadas y que hayan sido modificados en las fechas indicadas de inicio y fin.
    usage: %prog [options]"""
    parser = OptionParser(usage)
    parser.add_option("-n", "--odoo_db_name", dest="odoo_db_name", help="Odoo database name")
    parser.add_option("-u", "--odoo_db_user", dest="odoo_db_user",help="Odoo database user", default="admin")
    parser.add_option("-p", "--odoo_db_password", dest="odoo_db_password", help="Odoo database password", default="admin")
    parser.add_option("-s", "--odoo_host", dest="odoo_host", help="Odoo server host", default="http://localhost:8069")
    parser.add_option("-i", "--inicio", dest="fecha_inicio", help="Fecha Inicio del reporte Y-m-d")
    parser.add_option("-f", "--fin", dest="fecha_final", help="Fecha Final del reporte Y-m-d")
    parser.add_option("-o", "--output", dest="output", help="Directorio donde se guarda el archivo", default="./")
    parser.add_option("-d", "--debug", action="store_true", dest="debug", help="Display debug message", default=False)

    (options, args) = parser.parse_args()
    _logger.setLevel(0)
    if options.debug:
        _logger.setLevel(10)

    check_obligatorios = ['odoo_db_name', 'odoo_db_user', 'odoo_db_password']
    for i in check_obligatorios:
        if not getattr(options, i):
            parser.error('{0} es obligatorio'.format(i))
    _logger.info('Cargando datos')
    cabecera, data = execute(options)
    fname = "{}/gestion_social_obra_reuniones_consolidado.csv".format(options.output)
    _logger.info("Adicionando datos a archivo: " + fname)
    guardar_archivo(fname, data, 'a')
    fname = "{}/gestion_social_obra_reuniones_{}_{}.csv".format(options.output, options.fecha_inicio, options.fecha_final)
    _logger.info("Adicionando datos a archivo: " + fname)
    guardar_archivo(fname, data,'w', cabecera)
    _logger.info("Terminado")

def execute(options):
    odoo = conectar_odoo_openerp(options.odoo_host, options.odoo_db_name, options.odoo_db_user, options.odoo_db_password)
    reunion_model = odoo.model('gestion_social_obra.reunion')
    dominio = [('state', '=', 'aprobado')]
    if options.fecha_inicio:
        dominio.append(('write_date','>=','{} 00:00:00'.format(options.fecha_inicio)))
    if options.fecha_final:
        dominio.append(('write_date','<=','{} 23:59:59'.format(options.fecha_inicio)))
    reunion_ids = reunion_model.search(dominio)
    _logger.debug(dominio)
    _logger.debug(reunion_ids)
    res = []
    for reunion_id in reunion_ids:
        _logger.debug('Reunion ID: {}'.format(reunion_id))
        reunion = reunion_model.get(reunion_id)
        fila = (
            reunion_id,
            reunion.write_date,
            reunion.contrato_id.numero,
            reunion.proyecto_id.name,
            reunion.fase.name,
            reunion.district_id.name,
            reunion.upz_id.name,
            reunion.fecha,
            reunion.tipo_id.name,
            reunion.cantidad_convocados,
            reunion.cantidad_asistentes,
        )
        res.append(fila)
    cabecera = (
        'ID',
        'Fecha Actualización Registro',
        'Contrato',
        'Proyecto',
        'Etapa',
        'Localidad',
        'UPZ',
        'Fecha de la reunión',
        'Tipo de Reunión',
        'Cantidad Convocados',
        'Cantidad Asistentes',
    )
    return cabecera, res

def guardar_archivo(fname, data, mode, cabecera=False):
    f = open(fname, mode)
    try:
        writer = csv.writer(f)
        if cabecera:
            writer.writerow(cabecera)
        for row in data:
            writer.writerow(row)
    finally:
        f.close()



def conectar_odoo_openerp(server, db_name, user, password):
    _logger.debug('Contectando a: {0} {1}'.format(server, db_name));
    client = erppeek.Client(
        server,
        db_name,
        user,
        password,
    )
    return client

if __name__ == '__main__':
    main()
