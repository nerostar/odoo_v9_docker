# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api, exceptions
from openerp.exceptions import Warning

class project_obra_registrar_linea_base_mpp(models.TransientModel):
    _name = 'project_obra.portafolio.wzrd.reg_linea_base_mpp'
    _inherit = 'project.edt.wizard.importar_mpp'
    _description = 'Wizard para Registrar Linea Base para Proyectos de Obra'

    # -------------------
    # Fields
    # -------------------
    project_id = fields.Many2one(
        required=False,
    )
    proyecto_id = fields.Many2one(
        string='Proyecto de Obra',
        required=True,
        comodel_name='project_obra.proyecto',
        default=lambda self: self._context.get('proyecto_id', self.env['project_obra.proyecto'].browse()),
    )
    linea_base_id = fields.Many2one(
        string='Línea Base',
        required=False,
        comodel_name='project.linea_base',
    )
    user_id = fields.Many2one(
        required=False,
    )
    programador_id = fields.Many2one(
        required=False,
    )
    fecha = fields.Date(
        string='Fecha de Corte',
        required=True,
        track_visibility='onchange',
        default=fields.Date.today,
    )
    descripcion = fields.Text(
        string='Descripción del avance',
        required=True,
        track_visibility='onchange',
        help='''Descripción de los avances dados por el área técnica''',
    )

    @api.multi
    def crear_linea_base(self):
        project_model = self.env['project.project']
        for form in self:
            # Buscar project.project para el proyecto seleccionado y el tipo de etapa Construcción
            form.asignar_recursos_mpp = False
            form.project_id = self.proyecto_id.project_id.id
            form.metodo = 'hojas_son_tareas'
            form.permitir_dependencias_con_paquetes_trabajo = True
            form.programador_id = self.env.uid
            linea_base = self.env['project.linea_base'].create({
                'name': 'Con corte al {}'.format(form.fecha),
                'es_snapshot': False,
                'project_id': self.proyecto_id.project_id.id,
                'descripcion': form.descripcion,
                'archivo': form.archivo,
                'archivo_nombre': form.archivo_nombre,
            })
            form.linea_base_id = linea_base.id
            res = form.importar_mpp()
            form.linea_base_id.linea_raiz_id = res['vals']['edt_raiz_id']

        return {
            'type': 'ir.actions.act_window',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'project_obra.proyecto',
            'res_id': self.proyecto_id.id,
        }

    def actualizar_padre(self, children_ids, parent_id, ctx):
        """ coloca como parent_id a todos los registros children_ids, para crear el árbol de la EDT """
        model_linea_base = self.env['project.linea_base']
        model_linea_base_linea = self.env['project.linea_base.linea']
        model_linea_base_linea.browse(children_ids).with_context(ctx).write({'parent_id': parent_id})

    def insert_edt(self, vals, form, params, ctx):
        """Crea una EDT, puesto en un metodo aparte para ser sobreescrito por clase que herede"""
        model_linea_base_linea = self.env['project.linea_base.linea']
        linea_values = {
            'name': vals['name'],
            'numero': vals['numero'],
            'linea_base_id': form.linea_base_id.id,
            'fecha_inicio': vals['fecha_inicio'],
            'fecha_fin': vals['fecha_fin'],
            'progreso': vals['progreso'],
            'costo': vals['costo'],
            'res_model': 'ninguno',
            'res_id': 0,
        }
        return model_linea_base_linea.with_context(ctx).create(linea_values)

    def insert_task(self, vals, form, params):
        self.insert_edt(vals, form, params, {})

    def crear_dependencias(self, form, archivo_csv, indice_objetos):
        """Crear las relaciones de dependencia y agregación para tareas y EDTs"""
        pass
