# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import logging

from openerp import models, fields, api
from openerp.exceptions import ValidationError

_logger = logging.getLogger(__name__)


class asignar_proyecto_plan_wizard(models.TransientModel):
    _name = 'project_obra.wizard.asignar_proyecto_plan'
    _description = 'Wizard para Asignar un proyecto_plan y mover los datos necesarios'

    # -------------------
    # Fields
    # -------------------
    proyecto_id = fields.Many2one(
        string='Proyecto Contrato',
        required=True,
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
        help='''Proyecto Contrato''',
        default=lambda self: self._context.get('proyecto_id', None),
    )

    proyecto_plan_id = fields.Many2one(
        string='Proyecto Plan',
        required=True,
        comodel_name='project_obra.proyecto_plan',
        ondelete='restrict',
        help='''Proyecto plan donde se va a asignar este proyecto''',
        default=lambda self: self._context.get('proyecto_plan_id', None),
    )

    # -------------------
    # methods
    # -------------------
    @api.multi
    def asignar(self):
        # Revisar si ya esta asociado a un proyecto plan, sino crear la asociación
        model_plan_rel = self.env['project_obra.proyecto_proyecto_plan_rel']
        found = model_plan_rel.search([
            ('proyecto_plan_id','=',self.proyecto_plan_id.id),
            ('proyecto_id','=',self.proyecto_id.id)
        ])
        if not found:
            model_plan_rel.create({
                'proyecto_id': self.proyecto_id.id,
                'proyecto_plan_id': self.proyecto_plan_id.id,
            })
        # Asignar trámites
        tramites = self.env['tramite.tramite'].search([('proyecto_id','=',self.proyecto_id.id)])
        tramites.write({ 'proyecto_plan_id': self.proyecto_plan_id.id })
