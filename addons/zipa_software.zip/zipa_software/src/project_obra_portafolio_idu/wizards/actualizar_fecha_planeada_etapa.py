# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api
from openerp.exceptions import Warning
from xlrd import open_workbook
import base64
import StringIO

class project_obra_portafolio_actualizar_fecha_planeada_etapa(models.TransientModel):
    _name = 'project_obra.wizard.actualizar_fecha_planeada_etapa'
    _description = 'Wizard para Actualizar la Fecha Planeada de una Etapa'

    def _default_fecha_fin_planeada(self):
        if self.env.context.get('edt_id'):
            edt = self.env['project.edt'].browse(self.env.context.get('edt_id'))
            return edt.fecha_planeada_fin

    def _default_fecha_inicio_planeada(self):
        if self.env.context.get('edt_id'):
            edt = self.env['project.edt'].browse(self.env.context.get('edt_id'))
            return edt.fecha_planeada_inicio

    # -------------------
    # Fields
    # -------------------
    modo = fields.Selection(
        string='Único / Masivo',
        selection=[('unico', 'Único'), ('masivo', 'Masivo')],
        required=True,
        default='unico'
    )
    edt_id = fields.Many2one(
        string='EDT',
        required=False,
        readonly=True,
        comodel_name='project.edt',
        ondelete='restrict',
        default=lambda self: self._context.get('edt_id', None),
    )

    fecha_planeada_inicio = fields.Date(
        string='Fecha Inicio Planeada',
        required=False,
        readonly=False,
        default=_default_fecha_inicio_planeada,
    )

    fecha_planeada_fin = fields.Date(
        string='Fecha Fin Planeada',
        required=False,
        readonly=False,
        default=_default_fecha_fin_planeada,
    )
    archivo = fields.Binary(
        string='archivo',
    )


    @api.multi
    def actualizar(self):
        if self.modo == 'unico':
            self.ensure_one()
            self.edt_id.write({
                'fecha_planeada_inicio': self.fecha_planeada_inicio,
                'fecha_planeada_fin': self.fecha_planeada_fin,
            })
        elif self.modo == 'masivo':
            datos = self.archivo
            try:
                inputx = StringIO.StringIO()
                inputx.write(base64.decodestring(datos))
                book = open_workbook(file_contents=inputx.getvalue())
            except TypeError as e:
                raise Warning(u'ERROR: {}'.format(e))
            sheet = book.sheets()[0]

            for i in range(sheet.nrows):
                if i > 0:
                    etapa_id = sheet.cell(i, 0).value
                    fecha_inicio = sheet.cell(i, 1).value
                    fecha_fin = sheet.cell(i, 2).value
                    etapa = self.env['project_obra.proyecto.etapa'].browse(int(etapa_id))
                    etapa.edt_raiz_id.write({
                        'fecha_planeada_inicio': fecha_inicio,
                        'fecha_planeada_fin': fecha_fin,
                    })

        return {'type': 'ir.actions.act_window_close'}
