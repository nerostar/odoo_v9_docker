{
    'name': 'Portafolio Obras',
    'version': '1.0',
    'depends': [
        'base',
        'base_idu',
        'contrato_idu',
        'model_security',
        'photo_gallery',
        'stone_erp_idu',
        'project_edt_idu',
        'project_portafolio_idu',
        'project_problemas_idu',
        'proceso_selectivo_idu',
        'infraestructura_urbana_idu',
        'plan_desarrollo_distrital',
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
        'data/data.xml',
        'security/security.xml',
        'security/ir.model.access.csv',
        'wizards/registrar_linea_base_mpp_view.xml',
        'wizards/actualizar_fecha_planeada_etapa_view.xml',
        'wizards/asignar_proyecto_plan_views.xml',
        'views/project_obra_view.xml',
        'views/project_view.xml',
        'views/proceso_selectivo_view.xml',
        'views/photo_gallery_view.xml',
        'views/project_problemas_view.xml',
        'views/config_view.xml',
        'data/project_obra.proyecto.etapa.tipo.csv',
        'workflow/reporte_desempeno_manual_workflow.xml',
        'wizards/crear_proyecto_obra_etapa_view.xml',
        'wizards/registrar_reporte_desempeno_manual_view.xml',
        'data/tareas_programadas_data.xml',
        'views/project_financiacion_view.xml',
    ],
    'test': [
        'tests/001_users.yml',
    ],
    'demo': [
        'tests/001_users.yml',
    ],
    'installable': True,
    'description': """
## Dependencias módulos Python
## Configuración adicional
    """,
}

