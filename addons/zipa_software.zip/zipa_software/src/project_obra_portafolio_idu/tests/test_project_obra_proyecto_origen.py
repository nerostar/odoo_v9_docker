# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_project_obra_proyecto_origen(common.TransactionCase):
    def test_crud_validaciones(self):
        proyecto_origen_model = self.env['project_obra.proyecto.origen']
        vals = {
            'name': "Quo dolores quis quibusdam dicta voluptatem libero.",
        }
        proyecto_origen = proyecto_origen_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()