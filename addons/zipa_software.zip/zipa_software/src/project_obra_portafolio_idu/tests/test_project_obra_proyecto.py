# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_project_obra_proyecto(common.TransactionCase):
    def test_crud_validaciones(self):
        proyecto_model = self.env['project_obra.proyecto']
        vals = {
            'name': "Minus dolores accusamus ea delectus ut porro.",
            'state': "close",
            'eje_id': self.ref('project_obra_portafolio_idu.eje_id_01'),
            'alcance': "Ut laborum aspernatur deleniti et.",
            'notas': "Quaerat architecto dolore aliquid nulla.",
            'motivo_cierre': "Id ducimus ut velit possimus.",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tag_ids': [
                (4, self.ref('project_obra_portafolio_idu.tag_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'codigo': "Vel perspiciatis et laudantium aliquam voluptas.",
            'codigo_sigidu': "Soluta esse nulla accusantium dignissimos.",
            'codigo_valoricemos': "Ad tempore eum magni sunt sapiente.",
            'origen_id': self.ref('project_obra_portafolio_idu.origen_id_01'),
            'edt_raiz_id': self.ref('project_obra_portafolio_idu.edt_raiz_id_01'),
            'progreso': 27429356.7776,
            'etapa_ids': [
                (4, self.ref('project_obra_portafolio_idu.etapa_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_planeada_inicio': "1989-12-05",
            'fecha_planeada_fin': "2011-03-15",
            'photo_ids': [
                (4, self.ref('project_obra_portafolio_idu.photo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'financiacion_ids': [
                (4, self.ref('project_obra_portafolio_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'programa_id': self.ref('project_obra_portafolio_idu.programa_id_01'),
            'portafolio_ids': [
                (4, self.ref('project_obra_portafolio_idu.portafolio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'localidad_ids': [
                (4, self.ref('project_obra_portafolio_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto = proyecto_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()