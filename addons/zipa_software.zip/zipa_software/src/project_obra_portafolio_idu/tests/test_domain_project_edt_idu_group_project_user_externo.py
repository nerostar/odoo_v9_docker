# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import AccessError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class test_security_project_edt_idu_group_project_user_externo(common.TransactionCase):
    def test_000_project_edt_idu_group_project_user_externo_search(self):
        """ project_edt_idu.group_project_user_externo Verifica reglas de dominio en operación READ """
        user_group_project_user_externo_01 = self.ref('project_obra_portafolio_idu.group_project_user_externo_user_01')
        user_group_project_user_externo_02 = self.ref('project_obra_portafolio_idu.group_project_user_externo_user_02')

        # ----------------------------
        # project_obra.proyecto
        # ----------------------------
        proyecto_model = self.env['project_obra.proyecto']
        self.assertEqual(1000, proyecto_model.sudo(user_group_project_user_externo_01).search_count([]))
        self.assertEqual(1000, proyecto_model.sudo(user_group_project_user_externo_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.tag
        # ----------------------------
        proyecto_tag_model = self.env['project_obra.proyecto.tag']
        self.assertEqual(1000, proyecto_tag_model.sudo(user_group_project_user_externo_01).search_count([]))
        self.assertEqual(1000, proyecto_tag_model.sudo(user_group_project_user_externo_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.eje
        # ----------------------------
        proyecto_eje_model = self.env['project_obra.proyecto.eje']
        self.assertEqual(1000, proyecto_eje_model.sudo(user_group_project_user_externo_01).search_count([]))
        self.assertEqual(1000, proyecto_eje_model.sudo(user_group_project_user_externo_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.origen
        # ----------------------------
        proyecto_origen_model = self.env['project_obra.proyecto.origen']
        self.assertEqual(1000, proyecto_origen_model.sudo(user_group_project_user_externo_01).search_count([]))
        self.assertEqual(1000, proyecto_origen_model.sudo(user_group_project_user_externo_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.etapa
        # ----------------------------
        proyecto_etapa_model = self.env['project_obra.proyecto.etapa']
        self.assertEqual(1000, proyecto_etapa_model.sudo(user_group_project_user_externo_01).search_count([]))
        self.assertEqual(1000, proyecto_etapa_model.sudo(user_group_project_user_externo_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.etapa.tipo
        # ----------------------------
        proyecto_etapa_tipo_model = self.env['project_obra.proyecto.etapa.tipo']
        self.assertEqual(1000, proyecto_etapa_tipo_model.sudo(user_group_project_user_externo_01).search_count([]))
        self.assertEqual(1000, proyecto_etapa_tipo_model.sudo(user_group_project_user_externo_02).search_count([]))

        # ----------------------------
        # photo_gallery.photo
        # ----------------------------
        photo_model = self.env['photo_gallery.photo']
        self.assertEqual(1000, photo_model.sudo(user_group_project_user_externo_01).search_count([]))
        self.assertEqual(1000, photo_model.sudo(user_group_project_user_externo_02).search_count([]))

        # ----------------------------
        # project_obra.reporte_desempeno_manual
        # ----------------------------
        reporte_desempeno_manual_model = self.env['project_obra.reporte_desempeno_manual']
        self.assertEqual(1000, reporte_desempeno_manual_model.sudo(user_group_project_user_externo_01).search_count([]))
        self.assertEqual(1000, reporte_desempeno_manual_model.sudo(user_group_project_user_externo_02).search_count([]))

        # ----------------------------
        # project.project
        # ----------------------------
        project_model = self.env['project.project']
        self.assertEqual(1000, project_model.sudo(user_group_project_user_externo_01).search_count([]))
        self.assertEqual(1000, project_model.sudo(user_group_project_user_externo_02).search_count([]))

    def test_010_project_edt_idu_group_project_user_externo_create(self):
        """ project_edt_idu.group_project_user_externo Verifica reglas de dominio en operación CREATE """
        user_group_project_user_externo_01 = self.ref('project_obra_portafolio_idu.group_project_user_externo_user_01')
        user_group_project_user_externo_02 = self.ref('project_obra_portafolio_idu.group_project_user_externo_user_02')

        # ----------------------------
        # project_obra.proyecto
        # ----------------------------
        proyecto_model = self.env['project_obra.proyecto']
        # Creación permitida
        vals = {
            'name': "Ut omnis at sit mollitia quisquam et odit.",
            'state': "close",
            'eje_id': self.ref('project_obra_portafolio_idu.eje_id_01'),
            'alcance': "Enim impedit voluptate saepe nisi mollitia.",
            'notas': "Mollitia rem deleniti culpa tempora possimus consequatur quo.",
            'motivo_cierre': "Sed facere corrupti et consequuntur.",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tag_ids': [
                (4, self.ref('project_obra_portafolio_idu.tag_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'codigo': "Enim sequi et non laboriosam.",
            'codigo_sigidu': "Quis maxime vero rerum eveniet est nobis exercitationem qui.",
            'codigo_valoricemos': "Est omnis qui eos minima.",
            'origen_id': self.ref('project_obra_portafolio_idu.origen_id_01'),
            'edt_raiz_id': self.ref('project_obra_portafolio_idu.edt_raiz_id_01'),
            'progreso': 68193809.5191,
            'etapa_ids': [
                (4, self.ref('project_obra_portafolio_idu.etapa_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_planeada_inicio': "2014-04-25",
            'fecha_planeada_fin': "1988-01-21",
            'photo_ids': [
                (4, self.ref('project_obra_portafolio_idu.photo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'financiacion_ids': [
                (4, self.ref('project_obra_portafolio_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'programa_id': self.ref('project_obra_portafolio_idu.programa_id_01'),
            'portafolio_ids': [
                (4, self.ref('project_obra_portafolio_idu.portafolio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'localidad_ids': [
                (4, self.ref('project_obra_portafolio_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto = proyecto_model.sudo(user_group_project_user_externo_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Ratione voluptas expedita tempora atque et dolores.",
            'state': "open",
            'eje_id': self.ref('project_obra_portafolio_idu.eje_id_01'),
            'alcance': "Odit iure esse dolores pariatur asperiores quod.",
            'notas': "Et deserunt voluptatum sapiente facere et.",
            'motivo_cierre': "Repellat eligendi omnis aliquam quidem.",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tag_ids': [
                (4, self.ref('project_obra_portafolio_idu.tag_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'codigo': "Repellat repudiandae sunt deserunt occaecati temporibus esse dicta.",
            'codigo_sigidu': "Iusto vitae quae et minus voluptas delectus et.",
            'codigo_valoricemos': "Voluptatum qui id nemo autem qui ea laborum ut.",
            'origen_id': self.ref('project_obra_portafolio_idu.origen_id_01'),
            'edt_raiz_id': self.ref('project_obra_portafolio_idu.edt_raiz_id_01'),
            'progreso': 69545814.8362,
            'etapa_ids': [
                (4, self.ref('project_obra_portafolio_idu.etapa_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_planeada_inicio': "1992-11-21",
            'fecha_planeada_fin': "1993-07-04",
            'photo_ids': [
                (4, self.ref('project_obra_portafolio_idu.photo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'financiacion_ids': [
                (4, self.ref('project_obra_portafolio_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'programa_id': self.ref('project_obra_portafolio_idu.programa_id_01'),
            'portafolio_ids': [
                (4, self.ref('project_obra_portafolio_idu.portafolio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'localidad_ids': [
                (4, self.ref('project_obra_portafolio_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            proyecto = proyecto_model.sudo(user_group_project_user_externo_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_model))

        # ----------------------------
        # project_obra.proyecto.tag
        # ----------------------------
        proyecto_tag_model = self.env['project_obra.proyecto.tag']
        # Creación permitida
        vals = {
            'name': "Voluptatem rerum repudiandae et eveniet.",
        }
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_user_externo_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Laudantium quod sit quos neque eius.",
        }
        try:
            proyecto_tag = proyecto_tag_model.sudo(user_group_project_user_externo_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_tag_model))

        # ----------------------------
        # project_obra.proyecto.eje
        # ----------------------------
        proyecto_eje_model = self.env['project_obra.proyecto.eje']
        # Creación permitida
        vals = {
            'name': "Et inventore nihil neque saepe aut.",
        }
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_user_externo_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Adipisci doloremque totam aut totam perferendis et porro molestiae.",
        }
        try:
            proyecto_eje = proyecto_eje_model.sudo(user_group_project_user_externo_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_eje_model))

        # ----------------------------
        # project_obra.proyecto.origen
        # ----------------------------
        proyecto_origen_model = self.env['project_obra.proyecto.origen']
        # Creación permitida
        vals = {
            'name': "Delectus et reprehenderit veritatis.",
        }
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_user_externo_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Distinctio quis commodi optio possimus.",
        }
        try:
            proyecto_origen = proyecto_origen_model.sudo(user_group_project_user_externo_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_origen_model))

        # ----------------------------
        # project_obra.proyecto.etapa
        # ----------------------------
        proyecto_etapa_model = self.env['project_obra.proyecto.etapa']
        # Creación permitida
        vals = {
            'name': "Omnis hic placeat esse incidunt est.",
            'contrato_ids': [
                (4, self.ref('project_obra_portafolio_idu.contrato_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'proyecto_id': self.ref('project_obra_portafolio_idu.proyecto_id_01'),
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tipo_id': self.ref('project_obra_portafolio_idu.tipo_id_01'),
            'parent_id': self.ref('project_obra_portafolio_idu.parent_id_01'),
            'child_ids': [
                (4, self.ref('project_obra_portafolio_idu.child_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'progreso': 5019298.23268,
            'fecha_planeada_inicio': "1998-03-14",
            'fecha_planeada_fin': "1975-03-23",
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'alcance': "Quo ducimus dolorum quia odio.",
            'notas': "Omnis sit quaerat debitis voluptas quo quia.",
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_user_externo_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Itaque laudantium pariatur magni at non nesciunt voluptatum.",
            'contrato_ids': [
                (4, self.ref('project_obra_portafolio_idu.contrato_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'proyecto_id': self.ref('project_obra_portafolio_idu.proyecto_id_01'),
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tipo_id': self.ref('project_obra_portafolio_idu.tipo_id_01'),
            'parent_id': self.ref('project_obra_portafolio_idu.parent_id_01'),
            'child_ids': [
                (4, self.ref('project_obra_portafolio_idu.child_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'progreso': 80890223.2504,
            'fecha_planeada_inicio': "1979-06-06",
            'fecha_planeada_fin': "1984-06-05",
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'alcance': "Maiores enim qui non autem sequi numquam possimus.",
            'notas': "Atque facilis qui deleniti.",
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_user_externo_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_etapa_model))

        # ----------------------------
        # project_obra.proyecto.etapa.tipo
        # ----------------------------
        proyecto_etapa_tipo_model = self.env['project_obra.proyecto.etapa.tipo']
        # Creación permitida
        vals = {
            'name': "Dolor harum nesciunt iusto illum fugit asperiores sit et.",
            'web_color': "Animi aperiam dolorem cupiditate aut et deserunt.",
        }
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_user_externo_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Magnam voluptatibus occaecati quaerat cupiditate optio et.",
            'web_color': "Et eligendi facere reprehenderit ipsum et aut.",
        }
        try:
            proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_user_externo_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_etapa_tipo_model))

        # ----------------------------
        # photo_gallery.photo
        # ----------------------------
        photo_model = self.env['photo_gallery.photo']
        # Creación permitida
        vals = {
            'proyecto_obra_id': self.ref('project_obra_portafolio_idu.proyecto_obra_id_01'),
            'visible_website': True,
        }
        photo = photo_model.sudo(user_group_project_user_externo_01).create(vals)

        # Creación NO permitida
        vals = {
            'proyecto_obra_id': self.ref('project_obra_portafolio_idu.proyecto_obra_id_01'),
            'visible_website': True,
        }
        try:
            photo = photo_model.sudo(user_group_project_user_externo_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(photo_model))

        # ----------------------------
        # project_obra.reporte_desempeno_manual
        # ----------------------------
        reporte_desempeno_manual_model = self.env['project_obra.reporte_desempeno_manual']
        # Creación permitida
        vals = {
            'state': "por_revisar",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'estado_etapa': "activo",
            'fecha': "2005-09-27",
            'programado': 50058093.6069,
            'ejecutado': 11213930.8539,
            'descripcion': "Maiores nam veniam exercitationem fuga voluptatum quis similique.",
            'observaciones': "Est ut rem quasi quod.",
        }
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_user_externo_01).create(vals)

        # Creación NO permitida
        vals = {
            'state': "aprobado",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'estado_etapa': "activo",
            'fecha': "1991-06-08",
            'programado': 52969963.385,
            'ejecutado': 22498464.0517,
            'descripcion': "Eum ex perferendis facilis dolorem ipsam totam.",
            'observaciones': "At atque culpa ratione laudantium vero sunt ullam.",
        }
        try:
            reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_user_externo_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(reporte_desempeno_manual_model))

        # ----------------------------
        # project.project
        # ----------------------------
        project_model = self.env['project.project']
        # Creación permitida
        vals = {
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        project = project_model.sudo(user_group_project_user_externo_01).create(vals)

        # Creación NO permitida
        vals = {
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            project = project_model.sudo(user_group_project_user_externo_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(project_model))

    def test_020_project_edt_idu_group_project_user_externo_write(self):
        """ project_edt_idu.group_project_user_externo Verifica reglas de dominio en operación WRITE """
        user_group_project_user_externo_01 = self.ref('project_obra_portafolio_idu.group_project_user_externo_user_01')
        user_group_project_user_externo_02 = self.ref('project_obra_portafolio_idu.group_project_user_externo_user_02')

        # ----------------------------
        # project_obra.proyecto
        # ----------------------------
        proyecto_model = self.env['project_obra.proyecto']
        # Actualización permitida
        vals = {
            'name': "Dignissimos voluptatem omnis sequi quidem fugiat assumenda beatae.",
            'state': "open",
            'eje_id': self.ref('project_obra_portafolio_idu.eje_id_01'),
            'alcance': "Molestias doloremque mollitia voluptate aut asperiores qui ipsum.",
            'notas': "Tempora quia eligendi et voluptatum.",
            'motivo_cierre': "Ipsum voluptatibus debitis quas et.",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tag_ids': [
                (4, self.ref('project_obra_portafolio_idu.tag_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'codigo': "Voluptatibus alias nostrum excepturi excepturi nulla dolor et.",
            'codigo_sigidu': "Exercitationem optio tenetur quasi ut eum et et.",
            'codigo_valoricemos': "Tempore doloremque qui quam reprehenderit dolorem.",
            'origen_id': self.ref('project_obra_portafolio_idu.origen_id_01'),
            'edt_raiz_id': self.ref('project_obra_portafolio_idu.edt_raiz_id_01'),
            'progreso': 55956535.2838,
            'etapa_ids': [
                (4, self.ref('project_obra_portafolio_idu.etapa_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_planeada_inicio': "1988-11-27",
            'fecha_planeada_fin': "2015-01-13",
            'photo_ids': [
                (4, self.ref('project_obra_portafolio_idu.photo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'financiacion_ids': [
                (4, self.ref('project_obra_portafolio_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'programa_id': self.ref('project_obra_portafolio_idu.programa_id_01'),
            'portafolio_ids': [
                (4, self.ref('project_obra_portafolio_idu.portafolio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'localidad_ids': [
                (4, self.ref('project_obra_portafolio_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto = proyecto_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        proyecto.sudo(user_group_project_user_externo_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Et ut qui vitae et et assumenda perferendis.",
            'state': "open",
            'eje_id': self.ref('project_obra_portafolio_idu.eje_id_01'),
            'alcance': "Et atque et ea libero aspernatur.",
            'notas': "Sit beatae distinctio dolorem quos doloribus dicta inventore.",
            'motivo_cierre': "Earum consectetur saepe quisquam et et.",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tag_ids': [
                (4, self.ref('project_obra_portafolio_idu.tag_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'codigo': "Quaerat vitae vitae ipsa omnis.",
            'codigo_sigidu': "Laborum aut qui consequatur alias quod quos quis.",
            'codigo_valoricemos': "Eveniet omnis totam velit voluptatem quibusdam tenetur.",
            'origen_id': self.ref('project_obra_portafolio_idu.origen_id_01'),
            'edt_raiz_id': self.ref('project_obra_portafolio_idu.edt_raiz_id_01'),
            'progreso': 50944961.6296,
            'etapa_ids': [
                (4, self.ref('project_obra_portafolio_idu.etapa_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_planeada_inicio': "2015-05-09",
            'fecha_planeada_fin': "1989-12-20",
            'photo_ids': [
                (4, self.ref('project_obra_portafolio_idu.photo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'financiacion_ids': [
                (4, self.ref('project_obra_portafolio_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'programa_id': self.ref('project_obra_portafolio_idu.programa_id_01'),
            'portafolio_ids': [
                (4, self.ref('project_obra_portafolio_idu.portafolio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'localidad_ids': [
                (4, self.ref('project_obra_portafolio_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto = proyecto_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            proyecto.sudo(user_group_project_user_externo_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_model))

        # ----------------------------
        # project_obra.proyecto.tag
        # ----------------------------
        proyecto_tag_model = self.env['project_obra.proyecto.tag']
        # Actualización permitida
        vals = {
            'name': "Et quia quia dolore laudantium.",
        }
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        proyecto_tag.sudo(user_group_project_user_externo_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Quia eligendi sunt debitis.",
        }
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            proyecto_tag.sudo(user_group_project_user_externo_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_tag_model))

        # ----------------------------
        # project_obra.proyecto.eje
        # ----------------------------
        proyecto_eje_model = self.env['project_obra.proyecto.eje']
        # Actualización permitida
        vals = {
            'name': "Qui beatae fugit delectus voluptatem quia pariatur debitis.",
        }
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        proyecto_eje.sudo(user_group_project_user_externo_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Numquam voluptate vel et nam.",
        }
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            proyecto_eje.sudo(user_group_project_user_externo_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_eje_model))

        # ----------------------------
        # project_obra.proyecto.origen
        # ----------------------------
        proyecto_origen_model = self.env['project_obra.proyecto.origen']
        # Actualización permitida
        vals = {
            'name': "Similique aut laboriosam delectus aspernatur est.",
        }
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        proyecto_origen.sudo(user_group_project_user_externo_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Ducimus velit qui doloremque.",
        }
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            proyecto_origen.sudo(user_group_project_user_externo_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_origen_model))

        # ----------------------------
        # project_obra.proyecto.etapa
        # ----------------------------
        proyecto_etapa_model = self.env['project_obra.proyecto.etapa']
        # Actualización permitida
        vals = {
            'name': "Esse officiis excepturi et vitae assumenda doloribus.",
            'contrato_ids': [
                (4, self.ref('project_obra_portafolio_idu.contrato_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'proyecto_id': self.ref('project_obra_portafolio_idu.proyecto_id_01'),
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tipo_id': self.ref('project_obra_portafolio_idu.tipo_id_01'),
            'parent_id': self.ref('project_obra_portafolio_idu.parent_id_01'),
            'child_ids': [
                (4, self.ref('project_obra_portafolio_idu.child_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'progreso': 10704236.109,
            'fecha_planeada_inicio': "1981-12-29",
            'fecha_planeada_fin': "1972-03-07",
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'alcance': "Amet quia id voluptatum tempore doloremque est aperiam.",
            'notas': "Qui nostrum doloremque commodi exercitationem exercitationem quis aut facilis.",
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        proyecto_etapa.sudo(user_group_project_user_externo_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Et enim aut exercitationem perspiciatis ea cupiditate nulla omnis.",
            'contrato_ids': [
                (4, self.ref('project_obra_portafolio_idu.contrato_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'proyecto_id': self.ref('project_obra_portafolio_idu.proyecto_id_01'),
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tipo_id': self.ref('project_obra_portafolio_idu.tipo_id_01'),
            'parent_id': self.ref('project_obra_portafolio_idu.parent_id_01'),
            'child_ids': [
                (4, self.ref('project_obra_portafolio_idu.child_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'progreso': 51462977.0314,
            'fecha_planeada_inicio': "2016-02-23",
            'fecha_planeada_fin': "2014-02-19",
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'alcance': "Quia quam minima recusandae.",
            'notas': "Est cupiditate enim aperiam sint dolor ea.",
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            proyecto_etapa.sudo(user_group_project_user_externo_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_etapa_model))

        # ----------------------------
        # project_obra.proyecto.etapa.tipo
        # ----------------------------
        proyecto_etapa_tipo_model = self.env['project_obra.proyecto.etapa.tipo']
        # Actualización permitida
        vals = {
            'name': "Earum maxime porro autem dicta aliquid ea.",
            'web_color': "Consequatur id occaecati voluptatem eaque.",
        }
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        proyecto_etapa_tipo.sudo(user_group_project_user_externo_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Expedita ut dolorum corrupti enim porro.",
            'web_color': "Aut quia blanditiis voluptates et.",
        }
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            proyecto_etapa_tipo.sudo(user_group_project_user_externo_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_etapa_tipo_model))

        # ----------------------------
        # photo_gallery.photo
        # ----------------------------
        photo_model = self.env['photo_gallery.photo']
        # Actualización permitida
        vals = {
            'proyecto_obra_id': self.ref('project_obra_portafolio_idu.proyecto_obra_id_01'),
            'visible_website': False,
        }
        photo = photo_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        photo.sudo(user_group_project_user_externo_01).write(vals)

        # Actualización NO permitida
        vals = {
            'proyecto_obra_id': self.ref('project_obra_portafolio_idu.proyecto_obra_id_01'),
            'visible_website': False,
        }
        photo = photo_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            photo.sudo(user_group_project_user_externo_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(photo_model))

        # ----------------------------
        # project_obra.reporte_desempeno_manual
        # ----------------------------
        reporte_desempeno_manual_model = self.env['project_obra.reporte_desempeno_manual']
        # Actualización permitida
        vals = {
            'state': "registrado",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'estado_etapa': "activo",
            'fecha': "2010-10-27",
            'programado': 66684179.1784,
            'ejecutado': 10513319.4376,
            'descripcion': "Aut laboriosam aut corrupti corrupti dolore dolore.",
            'observaciones': "Natus illum magnam suscipit.",
        }
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        reporte_desempeno_manual.sudo(user_group_project_user_externo_01).write(vals)

        # Actualización NO permitida
        vals = {
            'state': "por_revisar",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'estado_etapa': "activo",
            'fecha': "1971-11-26",
            'programado': 38368399.4361,
            'ejecutado': 43735231.5978,
            'descripcion': "Ut voluptate doloribus cupiditate unde tempora eum et tempore.",
            'observaciones': "Reprehenderit et impedit officia et.",
        }
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            reporte_desempeno_manual.sudo(user_group_project_user_externo_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(reporte_desempeno_manual_model))

        # ----------------------------
        # project.project
        # ----------------------------
        project_model = self.env['project.project']
        # Actualización permitida
        vals = {
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        project = project_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        project.sudo(user_group_project_user_externo_01).write(vals)

        # Actualización NO permitida
        vals = {
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        project = project_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            project.sudo(user_group_project_user_externo_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(project_model))

    def test_030_project_edt_idu_group_project_user_externo_unlink(self):
        """ project_edt_idu.group_project_user_externo Verifica reglas de dominio en operación UNLINK - Delete """
        user_group_project_user_externo_01 = self.ref('project_obra_portafolio_idu.group_project_user_externo_user_01')
        user_group_project_user_externo_02 = self.ref('project_obra_portafolio_idu.group_project_user_externo_user_02')

        # ----------------------------
        # project_obra.proyecto
        # ----------------------------
        proyecto_model = self.env['project_obra.proyecto']
        # Eliminación permitida
        proyecto = proyecto_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        proyecto.sudo(user_group_project_user_externo_01).unlink()

        # Eliminación NO permitida
        proyecto = proyecto_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            proyecto.sudo(user_group_project_user_externo_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_model))

        # ----------------------------
        # project_obra.proyecto.tag
        # ----------------------------
        proyecto_tag_model = self.env['project_obra.proyecto.tag']
        # Eliminación permitida
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        proyecto_tag.sudo(user_group_project_user_externo_01).unlink()

        # Eliminación NO permitida
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            proyecto_tag.sudo(user_group_project_user_externo_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_tag_model))

        # ----------------------------
        # project_obra.proyecto.eje
        # ----------------------------
        proyecto_eje_model = self.env['project_obra.proyecto.eje']
        # Eliminación permitida
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        proyecto_eje.sudo(user_group_project_user_externo_01).unlink()

        # Eliminación NO permitida
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            proyecto_eje.sudo(user_group_project_user_externo_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_eje_model))

        # ----------------------------
        # project_obra.proyecto.origen
        # ----------------------------
        proyecto_origen_model = self.env['project_obra.proyecto.origen']
        # Eliminación permitida
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        proyecto_origen.sudo(user_group_project_user_externo_01).unlink()

        # Eliminación NO permitida
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            proyecto_origen.sudo(user_group_project_user_externo_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_origen_model))

        # ----------------------------
        # project_obra.proyecto.etapa
        # ----------------------------
        proyecto_etapa_model = self.env['project_obra.proyecto.etapa']
        # Eliminación permitida
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        proyecto_etapa.sudo(user_group_project_user_externo_01).unlink()

        # Eliminación NO permitida
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            proyecto_etapa.sudo(user_group_project_user_externo_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_etapa_model))

        # ----------------------------
        # project_obra.proyecto.etapa.tipo
        # ----------------------------
        proyecto_etapa_tipo_model = self.env['project_obra.proyecto.etapa.tipo']
        # Eliminación permitida
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        proyecto_etapa_tipo.sudo(user_group_project_user_externo_01).unlink()

        # Eliminación NO permitida
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            proyecto_etapa_tipo.sudo(user_group_project_user_externo_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_etapa_tipo_model))

        # ----------------------------
        # photo_gallery.photo
        # ----------------------------
        photo_model = self.env['photo_gallery.photo']
        # Eliminación permitida
        photo = photo_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        photo.sudo(user_group_project_user_externo_01).unlink()

        # Eliminación NO permitida
        photo = photo_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            photo.sudo(user_group_project_user_externo_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(photo_model))

        # ----------------------------
        # project_obra.reporte_desempeno_manual
        # ----------------------------
        reporte_desempeno_manual_model = self.env['project_obra.reporte_desempeno_manual']
        # Eliminación permitida
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        reporte_desempeno_manual.sudo(user_group_project_user_externo_01).unlink()

        # Eliminación NO permitida
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            reporte_desempeno_manual.sudo(user_group_project_user_externo_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(reporte_desempeno_manual_model))

        # ----------------------------
        # project.project
        # ----------------------------
        project_model = self.env['project.project']
        # Eliminación permitida
        project = project_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        project.sudo(user_group_project_user_externo_01).unlink()

        # Eliminación NO permitida
        project = project_model.sudo(user_group_project_user_externo_01).search([], limit=1)
        try:
            project.sudo(user_group_project_user_externo_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(project_model))


if __name__ == '__main__':
    unittest2.main()