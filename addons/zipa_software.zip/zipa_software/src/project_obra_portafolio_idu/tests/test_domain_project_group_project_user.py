# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import AccessError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class test_security_project_group_project_user(common.TransactionCase):
    def test_000_project_group_project_user_search(self):
        """ project.group_project_user Verifica reglas de dominio en operación READ """
        user_group_project_user_01 = self.ref('project_obra_portafolio_idu.group_project_user_user_01')
        user_group_project_user_02 = self.ref('project_obra_portafolio_idu.group_project_user_user_02')

        # ----------------------------
        # project_obra.proyecto
        # ----------------------------
        proyecto_model = self.env['project_obra.proyecto']
        self.assertEqual(1000, proyecto_model.sudo(user_group_project_user_01).search_count([]))
        self.assertEqual(1000, proyecto_model.sudo(user_group_project_user_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.tag
        # ----------------------------
        proyecto_tag_model = self.env['project_obra.proyecto.tag']
        self.assertEqual(1000, proyecto_tag_model.sudo(user_group_project_user_01).search_count([]))
        self.assertEqual(1000, proyecto_tag_model.sudo(user_group_project_user_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.eje
        # ----------------------------
        proyecto_eje_model = self.env['project_obra.proyecto.eje']
        self.assertEqual(1000, proyecto_eje_model.sudo(user_group_project_user_01).search_count([]))
        self.assertEqual(1000, proyecto_eje_model.sudo(user_group_project_user_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.origen
        # ----------------------------
        proyecto_origen_model = self.env['project_obra.proyecto.origen']
        self.assertEqual(1000, proyecto_origen_model.sudo(user_group_project_user_01).search_count([]))
        self.assertEqual(1000, proyecto_origen_model.sudo(user_group_project_user_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.etapa
        # ----------------------------
        proyecto_etapa_model = self.env['project_obra.proyecto.etapa']
        self.assertEqual(1000, proyecto_etapa_model.sudo(user_group_project_user_01).search_count([]))
        self.assertEqual(1000, proyecto_etapa_model.sudo(user_group_project_user_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.etapa.tipo
        # ----------------------------
        proyecto_etapa_tipo_model = self.env['project_obra.proyecto.etapa.tipo']
        self.assertEqual(1000, proyecto_etapa_tipo_model.sudo(user_group_project_user_01).search_count([]))
        self.assertEqual(1000, proyecto_etapa_tipo_model.sudo(user_group_project_user_02).search_count([]))

        # ----------------------------
        # photo_gallery.photo
        # ----------------------------
        photo_model = self.env['photo_gallery.photo']
        self.assertEqual(1000, photo_model.sudo(user_group_project_user_01).search_count([]))
        self.assertEqual(1000, photo_model.sudo(user_group_project_user_02).search_count([]))

        # ----------------------------
        # project_obra.reporte_desempeno_manual
        # ----------------------------
        reporte_desempeno_manual_model = self.env['project_obra.reporte_desempeno_manual']
        self.assertEqual(1000, reporte_desempeno_manual_model.sudo(user_group_project_user_01).search_count([]))
        self.assertEqual(1000, reporte_desempeno_manual_model.sudo(user_group_project_user_02).search_count([]))

        # ----------------------------
        # project.project
        # ----------------------------
        project_model = self.env['project.project']
        self.assertEqual(1000, project_model.sudo(user_group_project_user_01).search_count([]))
        self.assertEqual(1000, project_model.sudo(user_group_project_user_02).search_count([]))

    def test_010_project_group_project_user_create(self):
        """ project.group_project_user Verifica reglas de dominio en operación CREATE """
        user_group_project_user_01 = self.ref('project_obra_portafolio_idu.group_project_user_user_01')
        user_group_project_user_02 = self.ref('project_obra_portafolio_idu.group_project_user_user_02')

        # ----------------------------
        # project_obra.proyecto
        # ----------------------------
        proyecto_model = self.env['project_obra.proyecto']
        # Creación permitida
        vals = {
            'name': "Voluptate deleniti est provident hic.",
            'state': "close",
            'eje_id': self.ref('project_obra_portafolio_idu.eje_id_01'),
            'alcance': "Ipsam eaque numquam excepturi dignissimos sint eaque dicta quasi.",
            'notas': "Ut fugiat ea id earum reiciendis consequatur quos.",
            'motivo_cierre': "Autem est vel mollitia.",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tag_ids': [
                (4, self.ref('project_obra_portafolio_idu.tag_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'codigo': "Ullam distinctio ipsum perspiciatis doloremque modi voluptate et.",
            'codigo_sigidu': "Ut voluptatem dignissimos voluptate reprehenderit.",
            'codigo_valoricemos': "Ducimus autem consequatur eos laboriosam eos animi iusto.",
            'origen_id': self.ref('project_obra_portafolio_idu.origen_id_01'),
            'edt_raiz_id': self.ref('project_obra_portafolio_idu.edt_raiz_id_01'),
            'progreso': 17376014.3129,
            'etapa_ids': [
                (4, self.ref('project_obra_portafolio_idu.etapa_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_planeada_inicio': "2014-08-03",
            'fecha_planeada_fin': "2014-06-18",
            'photo_ids': [
                (4, self.ref('project_obra_portafolio_idu.photo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'financiacion_ids': [
                (4, self.ref('project_obra_portafolio_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'programa_id': self.ref('project_obra_portafolio_idu.programa_id_01'),
            'portafolio_ids': [
                (4, self.ref('project_obra_portafolio_idu.portafolio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'localidad_ids': [
                (4, self.ref('project_obra_portafolio_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto = proyecto_model.sudo(user_group_project_user_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Eos doloremque est laborum omnis.",
            'state': "open",
            'eje_id': self.ref('project_obra_portafolio_idu.eje_id_01'),
            'alcance': "Voluptas quis perferendis cumque velit iure dicta doloribus.",
            'notas': "Delectus magni iusto dolorum impedit rerum quae.",
            'motivo_cierre': "Eveniet aut est consequatur eos repellendus est.",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tag_ids': [
                (4, self.ref('project_obra_portafolio_idu.tag_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'codigo': "Enim qui a consequatur consequatur quo earum tenetur.",
            'codigo_sigidu': "Debitis et beatae rerum molestias.",
            'codigo_valoricemos': "Nisi ut rem esse quibusdam.",
            'origen_id': self.ref('project_obra_portafolio_idu.origen_id_01'),
            'edt_raiz_id': self.ref('project_obra_portafolio_idu.edt_raiz_id_01'),
            'progreso': 168842.06865,
            'etapa_ids': [
                (4, self.ref('project_obra_portafolio_idu.etapa_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_planeada_inicio': "2008-02-17",
            'fecha_planeada_fin': "1982-05-07",
            'photo_ids': [
                (4, self.ref('project_obra_portafolio_idu.photo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'financiacion_ids': [
                (4, self.ref('project_obra_portafolio_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'programa_id': self.ref('project_obra_portafolio_idu.programa_id_01'),
            'portafolio_ids': [
                (4, self.ref('project_obra_portafolio_idu.portafolio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'localidad_ids': [
                (4, self.ref('project_obra_portafolio_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            proyecto = proyecto_model.sudo(user_group_project_user_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_model))

        # ----------------------------
        # project_obra.proyecto.tag
        # ----------------------------
        proyecto_tag_model = self.env['project_obra.proyecto.tag']
        # Creación permitida
        vals = {
            'name': "Nemo officiis ratione ullam et sed accusantium aut.",
        }
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_user_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Aut facilis labore non.",
        }
        try:
            proyecto_tag = proyecto_tag_model.sudo(user_group_project_user_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_tag_model))

        # ----------------------------
        # project_obra.proyecto.eje
        # ----------------------------
        proyecto_eje_model = self.env['project_obra.proyecto.eje']
        # Creación permitida
        vals = {
            'name': "Praesentium dolores dolores enim placeat enim sit porro.",
        }
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_user_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Deleniti soluta eveniet temporibus numquam sit.",
        }
        try:
            proyecto_eje = proyecto_eje_model.sudo(user_group_project_user_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_eje_model))

        # ----------------------------
        # project_obra.proyecto.origen
        # ----------------------------
        proyecto_origen_model = self.env['project_obra.proyecto.origen']
        # Creación permitida
        vals = {
            'name': "Ut omnis quis perspiciatis est ab.",
        }
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_user_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Nam voluptates cum corporis sint id aut dolores.",
        }
        try:
            proyecto_origen = proyecto_origen_model.sudo(user_group_project_user_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_origen_model))

        # ----------------------------
        # project_obra.proyecto.etapa
        # ----------------------------
        proyecto_etapa_model = self.env['project_obra.proyecto.etapa']
        # Creación permitida
        vals = {
            'name': "Est similique blanditiis laudantium qui voluptas ipsam corporis.",
            'contrato_ids': [
                (4, self.ref('project_obra_portafolio_idu.contrato_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'proyecto_id': self.ref('project_obra_portafolio_idu.proyecto_id_01'),
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tipo_id': self.ref('project_obra_portafolio_idu.tipo_id_01'),
            'parent_id': self.ref('project_obra_portafolio_idu.parent_id_01'),
            'child_ids': [
                (4, self.ref('project_obra_portafolio_idu.child_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'progreso': 7283876.73034,
            'fecha_planeada_inicio': "2015-04-12",
            'fecha_planeada_fin': "1982-10-31",
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'alcance': "Sunt harum placeat et laboriosam tempore laborum deserunt.",
            'notas': "Quia provident debitis aut aperiam ducimus in.",
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_user_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Accusantium qui ratione ad ea.",
            'contrato_ids': [
                (4, self.ref('project_obra_portafolio_idu.contrato_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'proyecto_id': self.ref('project_obra_portafolio_idu.proyecto_id_01'),
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tipo_id': self.ref('project_obra_portafolio_idu.tipo_id_01'),
            'parent_id': self.ref('project_obra_portafolio_idu.parent_id_01'),
            'child_ids': [
                (4, self.ref('project_obra_portafolio_idu.child_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'progreso': 48971209.1642,
            'fecha_planeada_inicio': "1983-11-20",
            'fecha_planeada_fin': "1974-09-26",
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'alcance': "Dignissimos qui iure necessitatibus vel.",
            'notas': "Nostrum cupiditate autem eum nihil fugiat quia temporibus corrupti.",
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_user_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_etapa_model))

        # ----------------------------
        # project_obra.proyecto.etapa.tipo
        # ----------------------------
        proyecto_etapa_tipo_model = self.env['project_obra.proyecto.etapa.tipo']
        # Creación permitida
        vals = {
            'name': "Consequatur nihil sed est ad rerum.",
            'web_color': "Non fuga illo provident non.",
        }
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_user_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Ea itaque adipisci voluptatibus ex nemo repellendus.",
            'web_color': "Numquam veritatis quod et illo.",
        }
        try:
            proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_user_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_etapa_tipo_model))

        # ----------------------------
        # photo_gallery.photo
        # ----------------------------
        photo_model = self.env['photo_gallery.photo']
        # Creación permitida
        vals = {
            'proyecto_obra_id': self.ref('project_obra_portafolio_idu.proyecto_obra_id_01'),
            'visible_website': False,
        }
        photo = photo_model.sudo(user_group_project_user_01).create(vals)

        # Creación NO permitida
        vals = {
            'proyecto_obra_id': self.ref('project_obra_portafolio_idu.proyecto_obra_id_01'),
            'visible_website': True,
        }
        try:
            photo = photo_model.sudo(user_group_project_user_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(photo_model))

        # ----------------------------
        # project_obra.reporte_desempeno_manual
        # ----------------------------
        reporte_desempeno_manual_model = self.env['project_obra.reporte_desempeno_manual']
        # Creación permitida
        vals = {
            'state': "aprobado",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'estado_etapa': "suspendido",
            'fecha': "1994-09-25",
            'programado': 94480240.1258,
            'ejecutado': 35361934.0642,
            'descripcion': "Et fugit odit voluptatibus sit.",
            'observaciones': "Aspernatur deserunt doloribus recusandae nihil voluptas necessitatibus.",
        }
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_user_01).create(vals)

        # Creación NO permitida
        vals = {
            'state': "devuelto",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'estado_etapa': "suspendido",
            'fecha': "1984-02-27",
            'programado': 99813191.8624,
            'ejecutado': 25803296.6677,
            'descripcion': "Harum voluptas et voluptatibus est.",
            'observaciones': "Ea quas nihil quo at odio voluptatem.",
        }
        try:
            reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_user_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(reporte_desempeno_manual_model))

        # ----------------------------
        # project.project
        # ----------------------------
        project_model = self.env['project.project']
        # Creación permitida
        vals = {
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        project = project_model.sudo(user_group_project_user_01).create(vals)

        # Creación NO permitida
        vals = {
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            project = project_model.sudo(user_group_project_user_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(project_model))

    def test_020_project_group_project_user_write(self):
        """ project.group_project_user Verifica reglas de dominio en operación WRITE """
        user_group_project_user_01 = self.ref('project_obra_portafolio_idu.group_project_user_user_01')
        user_group_project_user_02 = self.ref('project_obra_portafolio_idu.group_project_user_user_02')

        # ----------------------------
        # project_obra.proyecto
        # ----------------------------
        proyecto_model = self.env['project_obra.proyecto']
        # Actualización permitida
        vals = {
            'name': "Possimus quia quia molestias autem et id.",
            'state': "cancelled",
            'eje_id': self.ref('project_obra_portafolio_idu.eje_id_01'),
            'alcance': "Ea sed eligendi ipsum eveniet temporibus ut.",
            'notas': "Qui quod enim officia.",
            'motivo_cierre': "Labore eaque et quisquam eius incidunt.",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tag_ids': [
                (4, self.ref('project_obra_portafolio_idu.tag_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'codigo': "Optio quia et corrupti ad provident adipisci neque.",
            'codigo_sigidu': "Aut voluptatem error nulla dolorem non architecto.",
            'codigo_valoricemos': "Ad dolorem nostrum similique eveniet consectetur.",
            'origen_id': self.ref('project_obra_portafolio_idu.origen_id_01'),
            'edt_raiz_id': self.ref('project_obra_portafolio_idu.edt_raiz_id_01'),
            'progreso': 39874555.0321,
            'etapa_ids': [
                (4, self.ref('project_obra_portafolio_idu.etapa_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_planeada_inicio': "1981-06-28",
            'fecha_planeada_fin': "1988-04-16",
            'photo_ids': [
                (4, self.ref('project_obra_portafolio_idu.photo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'financiacion_ids': [
                (4, self.ref('project_obra_portafolio_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'programa_id': self.ref('project_obra_portafolio_idu.programa_id_01'),
            'portafolio_ids': [
                (4, self.ref('project_obra_portafolio_idu.portafolio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'localidad_ids': [
                (4, self.ref('project_obra_portafolio_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto = proyecto_model.sudo(user_group_project_user_01).search([], limit=1)
        proyecto.sudo(user_group_project_user_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Sint et itaque magni cumque velit.",
            'state': "cancelled",
            'eje_id': self.ref('project_obra_portafolio_idu.eje_id_01'),
            'alcance': "Amet nesciunt ducimus voluptas velit et.",
            'notas': "Sit nulla consequatur incidunt aut ut eligendi.",
            'motivo_cierre': "Quo ut id accusamus et vel.",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tag_ids': [
                (4, self.ref('project_obra_portafolio_idu.tag_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'codigo': "Maiores et minima dolore in dolor eum et.",
            'codigo_sigidu': "Eligendi rerum ut facilis quibusdam ipsum est non.",
            'codigo_valoricemos': "Aut porro ipsa odit rerum veniam corporis nesciunt voluptatem.",
            'origen_id': self.ref('project_obra_portafolio_idu.origen_id_01'),
            'edt_raiz_id': self.ref('project_obra_portafolio_idu.edt_raiz_id_01'),
            'progreso': 15830967.1862,
            'etapa_ids': [
                (4, self.ref('project_obra_portafolio_idu.etapa_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_planeada_inicio': "1996-02-28",
            'fecha_planeada_fin': "1972-06-10",
            'photo_ids': [
                (4, self.ref('project_obra_portafolio_idu.photo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'financiacion_ids': [
                (4, self.ref('project_obra_portafolio_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'programa_id': self.ref('project_obra_portafolio_idu.programa_id_01'),
            'portafolio_ids': [
                (4, self.ref('project_obra_portafolio_idu.portafolio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'localidad_ids': [
                (4, self.ref('project_obra_portafolio_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto = proyecto_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            proyecto.sudo(user_group_project_user_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_model))

        # ----------------------------
        # project_obra.proyecto.tag
        # ----------------------------
        proyecto_tag_model = self.env['project_obra.proyecto.tag']
        # Actualización permitida
        vals = {
            'name': "Iste eum deleniti nihil quis ullam ab.",
        }
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_user_01).search([], limit=1)
        proyecto_tag.sudo(user_group_project_user_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Iure nostrum quo quo et est occaecati id.",
        }
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            proyecto_tag.sudo(user_group_project_user_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_tag_model))

        # ----------------------------
        # project_obra.proyecto.eje
        # ----------------------------
        proyecto_eje_model = self.env['project_obra.proyecto.eje']
        # Actualización permitida
        vals = {
            'name': "Nisi delectus corporis corrupti dolores.",
        }
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_user_01).search([], limit=1)
        proyecto_eje.sudo(user_group_project_user_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Rerum repudiandae dolore sit illum corporis et qui.",
        }
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            proyecto_eje.sudo(user_group_project_user_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_eje_model))

        # ----------------------------
        # project_obra.proyecto.origen
        # ----------------------------
        proyecto_origen_model = self.env['project_obra.proyecto.origen']
        # Actualización permitida
        vals = {
            'name': "Animi aut autem fuga accusantium voluptas et.",
        }
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_user_01).search([], limit=1)
        proyecto_origen.sudo(user_group_project_user_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Voluptas quod quod officia cumque minima error ipsam.",
        }
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            proyecto_origen.sudo(user_group_project_user_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_origen_model))

        # ----------------------------
        # project_obra.proyecto.etapa
        # ----------------------------
        proyecto_etapa_model = self.env['project_obra.proyecto.etapa']
        # Actualización permitida
        vals = {
            'name': "In iure quasi sint.",
            'contrato_ids': [
                (4, self.ref('project_obra_portafolio_idu.contrato_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'proyecto_id': self.ref('project_obra_portafolio_idu.proyecto_id_01'),
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tipo_id': self.ref('project_obra_portafolio_idu.tipo_id_01'),
            'parent_id': self.ref('project_obra_portafolio_idu.parent_id_01'),
            'child_ids': [
                (4, self.ref('project_obra_portafolio_idu.child_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'progreso': 70850217.4903,
            'fecha_planeada_inicio': "1979-04-09",
            'fecha_planeada_fin': "1973-12-20",
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'alcance': "Quo ut voluptatem illum excepturi praesentium.",
            'notas': "Iusto rem vel et autem magnam tempore quasi.",
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_user_01).search([], limit=1)
        proyecto_etapa.sudo(user_group_project_user_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Quo animi repellendus quia enim corporis et vero qui.",
            'contrato_ids': [
                (4, self.ref('project_obra_portafolio_idu.contrato_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'proyecto_id': self.ref('project_obra_portafolio_idu.proyecto_id_01'),
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tipo_id': self.ref('project_obra_portafolio_idu.tipo_id_01'),
            'parent_id': self.ref('project_obra_portafolio_idu.parent_id_01'),
            'child_ids': [
                (4, self.ref('project_obra_portafolio_idu.child_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'progreso': 21112949.1327,
            'fecha_planeada_inicio': "1990-04-05",
            'fecha_planeada_fin': "2012-08-11",
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'alcance': "Molestiae repudiandae dolorem natus sed.",
            'notas': "Consequatur nesciunt placeat ea.",
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            proyecto_etapa.sudo(user_group_project_user_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_etapa_model))

        # ----------------------------
        # project_obra.proyecto.etapa.tipo
        # ----------------------------
        proyecto_etapa_tipo_model = self.env['project_obra.proyecto.etapa.tipo']
        # Actualización permitida
        vals = {
            'name': "Quia eos aut repudiandae nihil ipsa fugiat.",
            'web_color': "Labore ut ad ipsa.",
        }
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_user_01).search([], limit=1)
        proyecto_etapa_tipo.sudo(user_group_project_user_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Dolorum atque omnis autem et dolores soluta.",
            'web_color': "Eaque laboriosam placeat ex quia in quo cupiditate.",
        }
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            proyecto_etapa_tipo.sudo(user_group_project_user_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_etapa_tipo_model))

        # ----------------------------
        # photo_gallery.photo
        # ----------------------------
        photo_model = self.env['photo_gallery.photo']
        # Actualización permitida
        vals = {
            'proyecto_obra_id': self.ref('project_obra_portafolio_idu.proyecto_obra_id_01'),
            'visible_website': True,
        }
        photo = photo_model.sudo(user_group_project_user_01).search([], limit=1)
        photo.sudo(user_group_project_user_01).write(vals)

        # Actualización NO permitida
        vals = {
            'proyecto_obra_id': self.ref('project_obra_portafolio_idu.proyecto_obra_id_01'),
            'visible_website': True,
        }
        photo = photo_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            photo.sudo(user_group_project_user_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(photo_model))

        # ----------------------------
        # project_obra.reporte_desempeno_manual
        # ----------------------------
        reporte_desempeno_manual_model = self.env['project_obra.reporte_desempeno_manual']
        # Actualización permitida
        vals = {
            'state': "aprobado",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'estado_etapa': "activo",
            'fecha': "1999-02-17",
            'programado': 10332711.8503,
            'ejecutado': 12997439.8803,
            'descripcion': "Vitae consectetur reiciendis vel distinctio hic cumque.",
            'observaciones': "Odit quidem nesciunt provident delectus hic sapiente dolor et.",
        }
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_user_01).search([], limit=1)
        reporte_desempeno_manual.sudo(user_group_project_user_01).write(vals)

        # Actualización NO permitida
        vals = {
            'state': "aprobado",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'estado_etapa': "activo",
            'fecha': "2001-10-08",
            'programado': 82255685.7104,
            'ejecutado': 76791527.1549,
            'descripcion': "Et aut error reiciendis dolor voluptate id rerum aut.",
            'observaciones': "Quasi est ut blanditiis nesciunt blanditiis.",
        }
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            reporte_desempeno_manual.sudo(user_group_project_user_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(reporte_desempeno_manual_model))

        # ----------------------------
        # project.project
        # ----------------------------
        project_model = self.env['project.project']
        # Actualización permitida
        vals = {
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        project = project_model.sudo(user_group_project_user_01).search([], limit=1)
        project.sudo(user_group_project_user_01).write(vals)

        # Actualización NO permitida
        vals = {
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        project = project_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            project.sudo(user_group_project_user_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(project_model))

    def test_030_project_group_project_user_unlink(self):
        """ project.group_project_user Verifica reglas de dominio en operación UNLINK - Delete """
        user_group_project_user_01 = self.ref('project_obra_portafolio_idu.group_project_user_user_01')
        user_group_project_user_02 = self.ref('project_obra_portafolio_idu.group_project_user_user_02')

        # ----------------------------
        # project_obra.proyecto
        # ----------------------------
        proyecto_model = self.env['project_obra.proyecto']
        # Eliminación permitida
        proyecto = proyecto_model.sudo(user_group_project_user_01).search([], limit=1)
        proyecto.sudo(user_group_project_user_01).unlink()

        # Eliminación NO permitida
        proyecto = proyecto_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            proyecto.sudo(user_group_project_user_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_model))

        # ----------------------------
        # project_obra.proyecto.tag
        # ----------------------------
        proyecto_tag_model = self.env['project_obra.proyecto.tag']
        # Eliminación permitida
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_user_01).search([], limit=1)
        proyecto_tag.sudo(user_group_project_user_01).unlink()

        # Eliminación NO permitida
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            proyecto_tag.sudo(user_group_project_user_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_tag_model))

        # ----------------------------
        # project_obra.proyecto.eje
        # ----------------------------
        proyecto_eje_model = self.env['project_obra.proyecto.eje']
        # Eliminación permitida
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_user_01).search([], limit=1)
        proyecto_eje.sudo(user_group_project_user_01).unlink()

        # Eliminación NO permitida
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            proyecto_eje.sudo(user_group_project_user_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_eje_model))

        # ----------------------------
        # project_obra.proyecto.origen
        # ----------------------------
        proyecto_origen_model = self.env['project_obra.proyecto.origen']
        # Eliminación permitida
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_user_01).search([], limit=1)
        proyecto_origen.sudo(user_group_project_user_01).unlink()

        # Eliminación NO permitida
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            proyecto_origen.sudo(user_group_project_user_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_origen_model))

        # ----------------------------
        # project_obra.proyecto.etapa
        # ----------------------------
        proyecto_etapa_model = self.env['project_obra.proyecto.etapa']
        # Eliminación permitida
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_user_01).search([], limit=1)
        proyecto_etapa.sudo(user_group_project_user_01).unlink()

        # Eliminación NO permitida
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            proyecto_etapa.sudo(user_group_project_user_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_etapa_model))

        # ----------------------------
        # project_obra.proyecto.etapa.tipo
        # ----------------------------
        proyecto_etapa_tipo_model = self.env['project_obra.proyecto.etapa.tipo']
        # Eliminación permitida
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_user_01).search([], limit=1)
        proyecto_etapa_tipo.sudo(user_group_project_user_01).unlink()

        # Eliminación NO permitida
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            proyecto_etapa_tipo.sudo(user_group_project_user_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_etapa_tipo_model))

        # ----------------------------
        # photo_gallery.photo
        # ----------------------------
        photo_model = self.env['photo_gallery.photo']
        # Eliminación permitida
        photo = photo_model.sudo(user_group_project_user_01).search([], limit=1)
        photo.sudo(user_group_project_user_01).unlink()

        # Eliminación NO permitida
        photo = photo_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            photo.sudo(user_group_project_user_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(photo_model))

        # ----------------------------
        # project_obra.reporte_desempeno_manual
        # ----------------------------
        reporte_desempeno_manual_model = self.env['project_obra.reporte_desempeno_manual']
        # Eliminación permitida
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_user_01).search([], limit=1)
        reporte_desempeno_manual.sudo(user_group_project_user_01).unlink()

        # Eliminación NO permitida
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            reporte_desempeno_manual.sudo(user_group_project_user_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(reporte_desempeno_manual_model))

        # ----------------------------
        # project.project
        # ----------------------------
        project_model = self.env['project.project']
        # Eliminación permitida
        project = project_model.sudo(user_group_project_user_01).search([], limit=1)
        project.sudo(user_group_project_user_01).unlink()

        # Eliminación NO permitida
        project = project_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            project.sudo(user_group_project_user_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(project_model))


if __name__ == '__main__':
    unittest2.main()