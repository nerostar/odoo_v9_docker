# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import AccessError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class test_security_project_group_project_manager(common.TransactionCase):
    def test_000_project_group_project_manager_search(self):
        """ project.group_project_manager Verifica reglas de dominio en operación READ """
        user_group_project_manager_01 = self.ref('project_obra_portafolio_idu.group_project_manager_user_01')
        user_group_project_manager_02 = self.ref('project_obra_portafolio_idu.group_project_manager_user_02')

        # ----------------------------
        # project_obra.proyecto
        # ----------------------------
        proyecto_model = self.env['project_obra.proyecto']
        self.assertEqual(1000, proyecto_model.sudo(user_group_project_manager_01).search_count([]))
        self.assertEqual(1000, proyecto_model.sudo(user_group_project_manager_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.tag
        # ----------------------------
        proyecto_tag_model = self.env['project_obra.proyecto.tag']
        self.assertEqual(1000, proyecto_tag_model.sudo(user_group_project_manager_01).search_count([]))
        self.assertEqual(1000, proyecto_tag_model.sudo(user_group_project_manager_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.eje
        # ----------------------------
        proyecto_eje_model = self.env['project_obra.proyecto.eje']
        self.assertEqual(1000, proyecto_eje_model.sudo(user_group_project_manager_01).search_count([]))
        self.assertEqual(1000, proyecto_eje_model.sudo(user_group_project_manager_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.origen
        # ----------------------------
        proyecto_origen_model = self.env['project_obra.proyecto.origen']
        self.assertEqual(1000, proyecto_origen_model.sudo(user_group_project_manager_01).search_count([]))
        self.assertEqual(1000, proyecto_origen_model.sudo(user_group_project_manager_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.etapa
        # ----------------------------
        proyecto_etapa_model = self.env['project_obra.proyecto.etapa']
        self.assertEqual(1000, proyecto_etapa_model.sudo(user_group_project_manager_01).search_count([]))
        self.assertEqual(1000, proyecto_etapa_model.sudo(user_group_project_manager_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.etapa.tipo
        # ----------------------------
        proyecto_etapa_tipo_model = self.env['project_obra.proyecto.etapa.tipo']
        self.assertEqual(1000, proyecto_etapa_tipo_model.sudo(user_group_project_manager_01).search_count([]))
        self.assertEqual(1000, proyecto_etapa_tipo_model.sudo(user_group_project_manager_02).search_count([]))

        # ----------------------------
        # photo_gallery.photo
        # ----------------------------
        photo_model = self.env['photo_gallery.photo']
        self.assertEqual(1000, photo_model.sudo(user_group_project_manager_01).search_count([]))
        self.assertEqual(1000, photo_model.sudo(user_group_project_manager_02).search_count([]))

        # ----------------------------
        # project_obra.reporte_desempeno_manual
        # ----------------------------
        reporte_desempeno_manual_model = self.env['project_obra.reporte_desempeno_manual']
        self.assertEqual(1000, reporte_desempeno_manual_model.sudo(user_group_project_manager_01).search_count([]))
        self.assertEqual(1000, reporte_desempeno_manual_model.sudo(user_group_project_manager_02).search_count([]))

        # ----------------------------
        # project.project
        # ----------------------------
        project_model = self.env['project.project']
        self.assertEqual(1000, project_model.sudo(user_group_project_manager_01).search_count([]))
        self.assertEqual(1000, project_model.sudo(user_group_project_manager_02).search_count([]))

    def test_010_project_group_project_manager_create(self):
        """ project.group_project_manager Verifica reglas de dominio en operación CREATE """
        user_group_project_manager_01 = self.ref('project_obra_portafolio_idu.group_project_manager_user_01')
        user_group_project_manager_02 = self.ref('project_obra_portafolio_idu.group_project_manager_user_02')

        # ----------------------------
        # project_obra.proyecto
        # ----------------------------
        proyecto_model = self.env['project_obra.proyecto']
        # Creación permitida
        vals = {
            'name': "Explicabo commodi voluptatem sed dignissimos reprehenderit ut voluptatem.",
            'state': "cancelled",
            'eje_id': self.ref('project_obra_portafolio_idu.eje_id_01'),
            'alcance': "Enim architecto ipsam eveniet commodi.",
            'notas': "Odio facere quis officia voluptatem voluptatibus aut.",
            'motivo_cierre': "Fuga repudiandae sunt nulla blanditiis est.",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tag_ids': [
                (4, self.ref('project_obra_portafolio_idu.tag_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'codigo': "Dolorem eaque dicta sed soluta nostrum quis eligendi.",
            'codigo_sigidu': "Quia aperiam in voluptatem molestias deserunt quas molestias.",
            'codigo_valoricemos': "Dolor porro voluptas omnis eligendi.",
            'origen_id': self.ref('project_obra_portafolio_idu.origen_id_01'),
            'edt_raiz_id': self.ref('project_obra_portafolio_idu.edt_raiz_id_01'),
            'progreso': 18976203.7285,
            'etapa_ids': [
                (4, self.ref('project_obra_portafolio_idu.etapa_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_planeada_inicio': "2008-06-17",
            'fecha_planeada_fin': "2004-10-01",
            'photo_ids': [
                (4, self.ref('project_obra_portafolio_idu.photo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'financiacion_ids': [
                (4, self.ref('project_obra_portafolio_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'programa_id': self.ref('project_obra_portafolio_idu.programa_id_01'),
            'portafolio_ids': [
                (4, self.ref('project_obra_portafolio_idu.portafolio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'localidad_ids': [
                (4, self.ref('project_obra_portafolio_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto = proyecto_model.sudo(user_group_project_manager_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Aut natus et est id voluptatem.",
            'state': "open",
            'eje_id': self.ref('project_obra_portafolio_idu.eje_id_01'),
            'alcance': "Et debitis quia dolores nisi porro non quidem.",
            'notas': "Sunt perspiciatis ad voluptate quam repudiandae sit.",
            'motivo_cierre': "Porro ad consequuntur excepturi sapiente.",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tag_ids': [
                (4, self.ref('project_obra_portafolio_idu.tag_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'codigo': "Ratione in et saepe unde eveniet velit.",
            'codigo_sigidu': "Quis reiciendis voluptatum odio sit nulla.",
            'codigo_valoricemos': "Totam veritatis quasi illum quas.",
            'origen_id': self.ref('project_obra_portafolio_idu.origen_id_01'),
            'edt_raiz_id': self.ref('project_obra_portafolio_idu.edt_raiz_id_01'),
            'progreso': 91439762.3597,
            'etapa_ids': [
                (4, self.ref('project_obra_portafolio_idu.etapa_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_planeada_inicio': "2000-05-24",
            'fecha_planeada_fin': "2001-01-26",
            'photo_ids': [
                (4, self.ref('project_obra_portafolio_idu.photo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'financiacion_ids': [
                (4, self.ref('project_obra_portafolio_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'programa_id': self.ref('project_obra_portafolio_idu.programa_id_01'),
            'portafolio_ids': [
                (4, self.ref('project_obra_portafolio_idu.portafolio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'localidad_ids': [
                (4, self.ref('project_obra_portafolio_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            proyecto = proyecto_model.sudo(user_group_project_manager_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_model))

        # ----------------------------
        # project_obra.proyecto.tag
        # ----------------------------
        proyecto_tag_model = self.env['project_obra.proyecto.tag']
        # Creación permitida
        vals = {
            'name': "Iure cupiditate sint nam aspernatur quaerat dolorem.",
        }
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_manager_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Eos veritatis praesentium in et molestiae sit.",
        }
        try:
            proyecto_tag = proyecto_tag_model.sudo(user_group_project_manager_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_tag_model))

        # ----------------------------
        # project_obra.proyecto.eje
        # ----------------------------
        proyecto_eje_model = self.env['project_obra.proyecto.eje']
        # Creación permitida
        vals = {
            'name': "Ad excepturi aut nihil expedita nostrum.",
        }
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_manager_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Ratione est occaecati sapiente adipisci.",
        }
        try:
            proyecto_eje = proyecto_eje_model.sudo(user_group_project_manager_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_eje_model))

        # ----------------------------
        # project_obra.proyecto.origen
        # ----------------------------
        proyecto_origen_model = self.env['project_obra.proyecto.origen']
        # Creación permitida
        vals = {
            'name': "Est corrupti est veniam aut nostrum sequi.",
        }
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_manager_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Voluptatum voluptatem delectus nemo sapiente et.",
        }
        try:
            proyecto_origen = proyecto_origen_model.sudo(user_group_project_manager_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_origen_model))

        # ----------------------------
        # project_obra.proyecto.etapa
        # ----------------------------
        proyecto_etapa_model = self.env['project_obra.proyecto.etapa']
        # Creación permitida
        vals = {
            'name': "Labore vitae quis et cum dolore est nihil.",
            'contrato_ids': [
                (4, self.ref('project_obra_portafolio_idu.contrato_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'proyecto_id': self.ref('project_obra_portafolio_idu.proyecto_id_01'),
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tipo_id': self.ref('project_obra_portafolio_idu.tipo_id_01'),
            'parent_id': self.ref('project_obra_portafolio_idu.parent_id_01'),
            'child_ids': [
                (4, self.ref('project_obra_portafolio_idu.child_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'progreso': 32712484.2103,
            'fecha_planeada_inicio': "2013-02-24",
            'fecha_planeada_fin': "2002-02-06",
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'alcance': "Quam fugiat pariatur voluptatem quo ut.",
            'notas': "Minus neque amet aperiam corporis consequatur consequatur.",
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_manager_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Voluptatem non fugit aperiam magnam consectetur.",
            'contrato_ids': [
                (4, self.ref('project_obra_portafolio_idu.contrato_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'proyecto_id': self.ref('project_obra_portafolio_idu.proyecto_id_01'),
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tipo_id': self.ref('project_obra_portafolio_idu.tipo_id_01'),
            'parent_id': self.ref('project_obra_portafolio_idu.parent_id_01'),
            'child_ids': [
                (4, self.ref('project_obra_portafolio_idu.child_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'progreso': 88231341.2482,
            'fecha_planeada_inicio': "1994-05-30",
            'fecha_planeada_fin': "2006-09-23",
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'alcance': "Ex qui deserunt et vel.",
            'notas': "Perspiciatis quia aut deserunt eos.",
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_manager_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_etapa_model))

        # ----------------------------
        # project_obra.proyecto.etapa.tipo
        # ----------------------------
        proyecto_etapa_tipo_model = self.env['project_obra.proyecto.etapa.tipo']
        # Creación permitida
        vals = {
            'name': "Soluta quaerat maiores velit et.",
            'web_color': "Est iste necessitatibus vero vel aperiam vero.",
        }
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_manager_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Aut est distinctio repudiandae temporibus earum nobis veritatis.",
            'web_color': "Suscipit soluta ab reiciendis et libero sed.",
        }
        try:
            proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_manager_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_etapa_tipo_model))

        # ----------------------------
        # photo_gallery.photo
        # ----------------------------
        photo_model = self.env['photo_gallery.photo']
        # Creación permitida
        vals = {
            'proyecto_obra_id': self.ref('project_obra_portafolio_idu.proyecto_obra_id_01'),
            'visible_website': True,
        }
        photo = photo_model.sudo(user_group_project_manager_01).create(vals)

        # Creación NO permitida
        vals = {
            'proyecto_obra_id': self.ref('project_obra_portafolio_idu.proyecto_obra_id_01'),
            'visible_website': True,
        }
        try:
            photo = photo_model.sudo(user_group_project_manager_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(photo_model))

        # ----------------------------
        # project_obra.reporte_desempeno_manual
        # ----------------------------
        reporte_desempeno_manual_model = self.env['project_obra.reporte_desempeno_manual']
        # Creación permitida
        vals = {
            'state': "pre_aprobado",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'estado_etapa': "suspendido",
            'fecha': "1975-03-13",
            'programado': 74659236.7432,
            'ejecutado': 59123419.468,
            'descripcion': "Veritatis non voluptatem occaecati maiores dolorem aliquid molestiae.",
            'observaciones': "Nostrum debitis repellat eveniet occaecati.",
        }
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_manager_01).create(vals)

        # Creación NO permitida
        vals = {
            'state': "pre_aprobado",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'estado_etapa': "sin_iniciar",
            'fecha': "1988-02-24",
            'programado': 38887424.5158,
            'ejecutado': 84155468.6972,
            'descripcion': "Eos magnam optio alias et animi maiores laboriosam mollitia.",
            'observaciones': "Labore nam sit iusto doloribus et sint accusamus.",
        }
        try:
            reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_manager_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(reporte_desempeno_manual_model))

        # ----------------------------
        # project.project
        # ----------------------------
        project_model = self.env['project.project']
        # Creación permitida
        vals = {
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        project = project_model.sudo(user_group_project_manager_01).create(vals)

        # Creación NO permitida
        vals = {
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            project = project_model.sudo(user_group_project_manager_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(project_model))

    def test_020_project_group_project_manager_write(self):
        """ project.group_project_manager Verifica reglas de dominio en operación WRITE """
        user_group_project_manager_01 = self.ref('project_obra_portafolio_idu.group_project_manager_user_01')
        user_group_project_manager_02 = self.ref('project_obra_portafolio_idu.group_project_manager_user_02')

        # ----------------------------
        # project_obra.proyecto
        # ----------------------------
        proyecto_model = self.env['project_obra.proyecto']
        # Actualización permitida
        vals = {
            'name': "Necessitatibus voluptatem consectetur autem vel.",
            'state': "cancelled",
            'eje_id': self.ref('project_obra_portafolio_idu.eje_id_01'),
            'alcance': "Voluptatem ratione repellendus aut sed aliquid expedita.",
            'notas': "Qui esse officia nihil pariatur.",
            'motivo_cierre': "Numquam harum voluptas porro porro et.",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tag_ids': [
                (4, self.ref('project_obra_portafolio_idu.tag_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'codigo': "Cumque voluptas ex consectetur officia quam.",
            'codigo_sigidu': "Nisi minima illo voluptatum quis itaque ut nam.",
            'codigo_valoricemos': "Omnis vel magnam suscipit nihil id et et.",
            'origen_id': self.ref('project_obra_portafolio_idu.origen_id_01'),
            'edt_raiz_id': self.ref('project_obra_portafolio_idu.edt_raiz_id_01'),
            'progreso': 99970184.2485,
            'etapa_ids': [
                (4, self.ref('project_obra_portafolio_idu.etapa_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_planeada_inicio': "1989-04-02",
            'fecha_planeada_fin': "1994-05-26",
            'photo_ids': [
                (4, self.ref('project_obra_portafolio_idu.photo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'financiacion_ids': [
                (4, self.ref('project_obra_portafolio_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'programa_id': self.ref('project_obra_portafolio_idu.programa_id_01'),
            'portafolio_ids': [
                (4, self.ref('project_obra_portafolio_idu.portafolio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'localidad_ids': [
                (4, self.ref('project_obra_portafolio_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto = proyecto_model.sudo(user_group_project_manager_01).search([], limit=1)
        proyecto.sudo(user_group_project_manager_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Illum rerum cum qui omnis excepturi.",
            'state': "open",
            'eje_id': self.ref('project_obra_portafolio_idu.eje_id_01'),
            'alcance': "In nostrum omnis magnam.",
            'notas': "Ullam voluptate in sit est nostrum est et temporibus.",
            'motivo_cierre': "Ut ut sit eos reprehenderit nihil.",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tag_ids': [
                (4, self.ref('project_obra_portafolio_idu.tag_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'codigo': "Tempora voluptatem fugit sit repellendus adipisci est.",
            'codigo_sigidu': "Velit molestias occaecati voluptatum delectus facilis vel assumenda.",
            'codigo_valoricemos': "Sed dolorem ut autem eius provident tenetur natus.",
            'origen_id': self.ref('project_obra_portafolio_idu.origen_id_01'),
            'edt_raiz_id': self.ref('project_obra_portafolio_idu.edt_raiz_id_01'),
            'progreso': 1339677.35656,
            'etapa_ids': [
                (4, self.ref('project_obra_portafolio_idu.etapa_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_planeada_inicio': "1977-07-30",
            'fecha_planeada_fin': "1979-08-28",
            'photo_ids': [
                (4, self.ref('project_obra_portafolio_idu.photo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'financiacion_ids': [
                (4, self.ref('project_obra_portafolio_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'programa_id': self.ref('project_obra_portafolio_idu.programa_id_01'),
            'portafolio_ids': [
                (4, self.ref('project_obra_portafolio_idu.portafolio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'localidad_ids': [
                (4, self.ref('project_obra_portafolio_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto = proyecto_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            proyecto.sudo(user_group_project_manager_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_model))

        # ----------------------------
        # project_obra.proyecto.tag
        # ----------------------------
        proyecto_tag_model = self.env['project_obra.proyecto.tag']
        # Actualización permitida
        vals = {
            'name': "Cupiditate aut quae necessitatibus est ea praesentium quae est.",
        }
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_manager_01).search([], limit=1)
        proyecto_tag.sudo(user_group_project_manager_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Qui consequuntur tempore quia enim aliquid ex consectetur.",
        }
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            proyecto_tag.sudo(user_group_project_manager_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_tag_model))

        # ----------------------------
        # project_obra.proyecto.eje
        # ----------------------------
        proyecto_eje_model = self.env['project_obra.proyecto.eje']
        # Actualización permitida
        vals = {
            'name': "Provident sint veniam quos commodi.",
        }
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_manager_01).search([], limit=1)
        proyecto_eje.sudo(user_group_project_manager_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Corporis et molestiae minima.",
        }
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            proyecto_eje.sudo(user_group_project_manager_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_eje_model))

        # ----------------------------
        # project_obra.proyecto.origen
        # ----------------------------
        proyecto_origen_model = self.env['project_obra.proyecto.origen']
        # Actualización permitida
        vals = {
            'name': "Minus nobis quos explicabo ipsam id explicabo.",
        }
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_manager_01).search([], limit=1)
        proyecto_origen.sudo(user_group_project_manager_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Quia pariatur cum ullam qui aut qui.",
        }
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            proyecto_origen.sudo(user_group_project_manager_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_origen_model))

        # ----------------------------
        # project_obra.proyecto.etapa
        # ----------------------------
        proyecto_etapa_model = self.env['project_obra.proyecto.etapa']
        # Actualización permitida
        vals = {
            'name': "Iure saepe tempora est eligendi.",
            'contrato_ids': [
                (4, self.ref('project_obra_portafolio_idu.contrato_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'proyecto_id': self.ref('project_obra_portafolio_idu.proyecto_id_01'),
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tipo_id': self.ref('project_obra_portafolio_idu.tipo_id_01'),
            'parent_id': self.ref('project_obra_portafolio_idu.parent_id_01'),
            'child_ids': [
                (4, self.ref('project_obra_portafolio_idu.child_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'progreso': 48621655.1168,
            'fecha_planeada_inicio': "2006-04-10",
            'fecha_planeada_fin': "1986-11-20",
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'alcance': "Corporis maxime eos laboriosam est aut.",
            'notas': "Ex perspiciatis in ducimus fugit nihil quae omnis.",
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_manager_01).search([], limit=1)
        proyecto_etapa.sudo(user_group_project_manager_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Sit quidem ducimus corporis et perspiciatis odio officia.",
            'contrato_ids': [
                (4, self.ref('project_obra_portafolio_idu.contrato_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'proyecto_id': self.ref('project_obra_portafolio_idu.proyecto_id_01'),
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tipo_id': self.ref('project_obra_portafolio_idu.tipo_id_01'),
            'parent_id': self.ref('project_obra_portafolio_idu.parent_id_01'),
            'child_ids': [
                (4, self.ref('project_obra_portafolio_idu.child_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'progreso': 70510371.8034,
            'fecha_planeada_inicio': "1986-07-17",
            'fecha_planeada_fin': "2011-01-04",
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'alcance': "Delectus quod sed nobis assumenda.",
            'notas': "Temporibus incidunt veniam rerum laboriosam commodi rerum architecto.",
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            proyecto_etapa.sudo(user_group_project_manager_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_etapa_model))

        # ----------------------------
        # project_obra.proyecto.etapa.tipo
        # ----------------------------
        proyecto_etapa_tipo_model = self.env['project_obra.proyecto.etapa.tipo']
        # Actualización permitida
        vals = {
            'name': "Ab praesentium rem aspernatur ducimus maxime.",
            'web_color': "Blanditiis omnis itaque delectus et ullam modi cumque.",
        }
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_manager_01).search([], limit=1)
        proyecto_etapa_tipo.sudo(user_group_project_manager_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Totam voluptas est incidunt.",
            'web_color': "Architecto saepe est aperiam nihil.",
        }
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            proyecto_etapa_tipo.sudo(user_group_project_manager_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_etapa_tipo_model))

        # ----------------------------
        # photo_gallery.photo
        # ----------------------------
        photo_model = self.env['photo_gallery.photo']
        # Actualización permitida
        vals = {
            'proyecto_obra_id': self.ref('project_obra_portafolio_idu.proyecto_obra_id_01'),
            'visible_website': False,
        }
        photo = photo_model.sudo(user_group_project_manager_01).search([], limit=1)
        photo.sudo(user_group_project_manager_01).write(vals)

        # Actualización NO permitida
        vals = {
            'proyecto_obra_id': self.ref('project_obra_portafolio_idu.proyecto_obra_id_01'),
            'visible_website': True,
        }
        photo = photo_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            photo.sudo(user_group_project_manager_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(photo_model))

        # ----------------------------
        # project_obra.reporte_desempeno_manual
        # ----------------------------
        reporte_desempeno_manual_model = self.env['project_obra.reporte_desempeno_manual']
        # Actualización permitida
        vals = {
            'state': "por_revisar",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'estado_etapa': "activo",
            'fecha': "2009-09-14",
            'programado': 26667325.8775,
            'ejecutado': 71369155.3396,
            'descripcion': "Minima tempora magnam commodi itaque non.",
            'observaciones': "Quibusdam libero nulla non omnis.",
        }
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_manager_01).search([], limit=1)
        reporte_desempeno_manual.sudo(user_group_project_manager_01).write(vals)

        # Actualización NO permitida
        vals = {
            'state': "devuelto",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'estado_etapa': "suspendido",
            'fecha': "2003-07-08",
            'programado': 99701577.5773,
            'ejecutado': 73511788.7871,
            'descripcion': "Nam quam dolores consequatur voluptates deleniti optio in.",
            'observaciones': "Libero magnam et unde voluptatum.",
        }
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            reporte_desempeno_manual.sudo(user_group_project_manager_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(reporte_desempeno_manual_model))

        # ----------------------------
        # project.project
        # ----------------------------
        project_model = self.env['project.project']
        # Actualización permitida
        vals = {
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        project = project_model.sudo(user_group_project_manager_01).search([], limit=1)
        project.sudo(user_group_project_manager_01).write(vals)

        # Actualización NO permitida
        vals = {
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        project = project_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            project.sudo(user_group_project_manager_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(project_model))

    def test_030_project_group_project_manager_unlink(self):
        """ project.group_project_manager Verifica reglas de dominio en operación UNLINK - Delete """
        user_group_project_manager_01 = self.ref('project_obra_portafolio_idu.group_project_manager_user_01')
        user_group_project_manager_02 = self.ref('project_obra_portafolio_idu.group_project_manager_user_02')

        # ----------------------------
        # project_obra.proyecto
        # ----------------------------
        proyecto_model = self.env['project_obra.proyecto']
        # Eliminación permitida
        proyecto = proyecto_model.sudo(user_group_project_manager_01).search([], limit=1)
        proyecto.sudo(user_group_project_manager_01).unlink()

        # Eliminación NO permitida
        proyecto = proyecto_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            proyecto.sudo(user_group_project_manager_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_model))

        # ----------------------------
        # project_obra.proyecto.tag
        # ----------------------------
        proyecto_tag_model = self.env['project_obra.proyecto.tag']
        # Eliminación permitida
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_manager_01).search([], limit=1)
        proyecto_tag.sudo(user_group_project_manager_01).unlink()

        # Eliminación NO permitida
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            proyecto_tag.sudo(user_group_project_manager_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_tag_model))

        # ----------------------------
        # project_obra.proyecto.eje
        # ----------------------------
        proyecto_eje_model = self.env['project_obra.proyecto.eje']
        # Eliminación permitida
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_manager_01).search([], limit=1)
        proyecto_eje.sudo(user_group_project_manager_01).unlink()

        # Eliminación NO permitida
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            proyecto_eje.sudo(user_group_project_manager_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_eje_model))

        # ----------------------------
        # project_obra.proyecto.origen
        # ----------------------------
        proyecto_origen_model = self.env['project_obra.proyecto.origen']
        # Eliminación permitida
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_manager_01).search([], limit=1)
        proyecto_origen.sudo(user_group_project_manager_01).unlink()

        # Eliminación NO permitida
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            proyecto_origen.sudo(user_group_project_manager_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_origen_model))

        # ----------------------------
        # project_obra.proyecto.etapa
        # ----------------------------
        proyecto_etapa_model = self.env['project_obra.proyecto.etapa']
        # Eliminación permitida
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_manager_01).search([], limit=1)
        proyecto_etapa.sudo(user_group_project_manager_01).unlink()

        # Eliminación NO permitida
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            proyecto_etapa.sudo(user_group_project_manager_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_etapa_model))

        # ----------------------------
        # project_obra.proyecto.etapa.tipo
        # ----------------------------
        proyecto_etapa_tipo_model = self.env['project_obra.proyecto.etapa.tipo']
        # Eliminación permitida
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_manager_01).search([], limit=1)
        proyecto_etapa_tipo.sudo(user_group_project_manager_01).unlink()

        # Eliminación NO permitida
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            proyecto_etapa_tipo.sudo(user_group_project_manager_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_etapa_tipo_model))

        # ----------------------------
        # photo_gallery.photo
        # ----------------------------
        photo_model = self.env['photo_gallery.photo']
        # Eliminación permitida
        photo = photo_model.sudo(user_group_project_manager_01).search([], limit=1)
        photo.sudo(user_group_project_manager_01).unlink()

        # Eliminación NO permitida
        photo = photo_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            photo.sudo(user_group_project_manager_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(photo_model))

        # ----------------------------
        # project_obra.reporte_desempeno_manual
        # ----------------------------
        reporte_desempeno_manual_model = self.env['project_obra.reporte_desempeno_manual']
        # Eliminación permitida
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_manager_01).search([], limit=1)
        reporte_desempeno_manual.sudo(user_group_project_manager_01).unlink()

        # Eliminación NO permitida
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            reporte_desempeno_manual.sudo(user_group_project_manager_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(reporte_desempeno_manual_model))

        # ----------------------------
        # project.project
        # ----------------------------
        project_model = self.env['project.project']
        # Eliminación permitida
        project = project_model.sudo(user_group_project_manager_01).search([], limit=1)
        project.sudo(user_group_project_manager_01).unlink()

        # Eliminación NO permitida
        project = project_model.sudo(user_group_project_manager_01).search([], limit=1)
        try:
            project.sudo(user_group_project_manager_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(project_model))


if __name__ == '__main__':
    unittest2.main()