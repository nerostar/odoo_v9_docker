# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_project_obra_proyecto_eje(common.TransactionCase):
    def test_crud_validaciones(self):
        proyecto_eje_model = self.env['project_obra.proyecto.eje']
        vals = {
            'name': "Tempora aut et itaque quaerat qui rem.",
        }
        proyecto_eje = proyecto_eje_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()