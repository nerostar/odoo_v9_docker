# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_project_obra_proyecto_etapa_registro_avance(common.TransactionCase):
    def test_crud_validaciones(self):
        proyecto_etapa_registro_avance_model = self.env['project_obra.proyecto.etapa.registro_avance']
        vals = {
            'state': "registrado",
            'etapa_id': self.ref('project_obra_portafolio_idu.etapa_id_01'),
            'estado_etapa': "sin_iniciar",
            'fecha': "2012-07-31",
            'programado': 20550859.0461,
            'ejecutado': 95381648.3241,
            'descripcion': "Accusantium voluptatem aperiam error quae non.",
            'observaciones': "Laborum dolores illum debitis aspernatur excepturi.",
        }
        proyecto_etapa_registro_avance = proyecto_etapa_registro_avance_model.create(vals)

        # Campos computados
        self.assertEqual(proyecto_etapa_registro_avance.name, 'Valor Esperado')
        self.assertEqual(proyecto_etapa_registro_avance.variacion, 'Valor Esperado')
        self.assertEqual(proyecto_etapa_registro_avance.adjunto, 'Valor Esperado')

        # Campos con api.constrain
        vals_update = {
            'fecha': 'Valor a usarse para romper la validación',
        }
        try:
            proyecto_etapa_registro_avance.write(vals_update)
        except ValidationError, e:
            pass
        else:
            self.fail('No se generó exception de validación para "fecha"')
        vals_update = {
            'programado': 'Valor a usarse para romper la validación',
        }
        try:
            proyecto_etapa_registro_avance.write(vals_update)
        except ValidationError, e:
            pass
        else:
            self.fail('No se generó exception de validación para "programado"')
        vals_update = {
            'ejecutado': 'Valor a usarse para romper la validación',
        }
        try:
            proyecto_etapa_registro_avance.write(vals_update)
        except ValidationError, e:
            pass
        else:
            self.fail('No se generó exception de validación para "ejecutado"')


if __name__ == '__main__':
    unittest2.main()