# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_project_obra_proyecto_etapa(common.TransactionCase):
    def test_crud_validaciones(self):
        proyecto_etapa_model = self.env['project_obra.proyecto.etapa']
        vals = {
            'name': "Ipsam dolor nihil quam dolorem.",
            'contrato_ids': [
                (4, self.ref('project_obra_portafolio_idu.contrato_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'proyecto_id': self.ref('project_obra_portafolio_idu.proyecto_id_01'),
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tipo_id': self.ref('project_obra_portafolio_idu.tipo_id_01'),
            'parent_id': self.ref('project_obra_portafolio_idu.parent_id_01'),
            'child_ids': [
                (4, self.ref('project_obra_portafolio_idu.child_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'progreso': 21172354.2944,
            'fecha_planeada_inicio': "2008-08-19",
            'fecha_planeada_fin': "2010-09-14",
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'alcance': "Maiores sed quia iste odio eos.",
            'notas': "Sit eos natus aliquid architecto velit ratione eaque.",
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto_etapa = proyecto_etapa_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()