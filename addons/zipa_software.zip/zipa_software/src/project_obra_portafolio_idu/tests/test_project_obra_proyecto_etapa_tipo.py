# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_project_obra_proyecto_etapa_tipo(common.TransactionCase):
    def test_crud_validaciones(self):
        proyecto_etapa_tipo_model = self.env['project_obra.proyecto.etapa.tipo']
        vals = {
            'name': "Autem eum laudantium dolor ut praesentium.",
            'web_color': "Quisquam et minus iste quis et in assumenda.",
        }
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()