# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import AccessError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class test_security_project_portafolio_idu_group_project_dependencia_admin(common.TransactionCase):
    def test_000_project_portafolio_idu_group_project_dependencia_admin_search(self):
        """ project_portafolio_idu.group_project_dependencia_admin Verifica reglas de dominio en operación READ """
        user_group_project_dependencia_admin_01 = self.ref('project_obra_portafolio_idu.group_project_dependencia_admin_user_01')
        user_group_project_dependencia_admin_02 = self.ref('project_obra_portafolio_idu.group_project_dependencia_admin_user_02')

        # ----------------------------
        # project_obra.proyecto
        # ----------------------------
        proyecto_model = self.env['project_obra.proyecto']
        self.assertEqual(1000, proyecto_model.sudo(user_group_project_dependencia_admin_01).search_count([]))
        self.assertEqual(1000, proyecto_model.sudo(user_group_project_dependencia_admin_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.tag
        # ----------------------------
        proyecto_tag_model = self.env['project_obra.proyecto.tag']
        self.assertEqual(1000, proyecto_tag_model.sudo(user_group_project_dependencia_admin_01).search_count([]))
        self.assertEqual(1000, proyecto_tag_model.sudo(user_group_project_dependencia_admin_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.eje
        # ----------------------------
        proyecto_eje_model = self.env['project_obra.proyecto.eje']
        self.assertEqual(1000, proyecto_eje_model.sudo(user_group_project_dependencia_admin_01).search_count([]))
        self.assertEqual(1000, proyecto_eje_model.sudo(user_group_project_dependencia_admin_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.origen
        # ----------------------------
        proyecto_origen_model = self.env['project_obra.proyecto.origen']
        self.assertEqual(1000, proyecto_origen_model.sudo(user_group_project_dependencia_admin_01).search_count([]))
        self.assertEqual(1000, proyecto_origen_model.sudo(user_group_project_dependencia_admin_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.etapa
        # ----------------------------
        proyecto_etapa_model = self.env['project_obra.proyecto.etapa']
        self.assertEqual(1000, proyecto_etapa_model.sudo(user_group_project_dependencia_admin_01).search_count([]))
        self.assertEqual(1000, proyecto_etapa_model.sudo(user_group_project_dependencia_admin_02).search_count([]))

        # ----------------------------
        # project_obra.proyecto.etapa.tipo
        # ----------------------------
        proyecto_etapa_tipo_model = self.env['project_obra.proyecto.etapa.tipo']
        self.assertEqual(1000, proyecto_etapa_tipo_model.sudo(user_group_project_dependencia_admin_01).search_count([]))
        self.assertEqual(1000, proyecto_etapa_tipo_model.sudo(user_group_project_dependencia_admin_02).search_count([]))

        # ----------------------------
        # photo_gallery.photo
        # ----------------------------
        photo_model = self.env['photo_gallery.photo']
        self.assertEqual(1000, photo_model.sudo(user_group_project_dependencia_admin_01).search_count([]))
        self.assertEqual(1000, photo_model.sudo(user_group_project_dependencia_admin_02).search_count([]))

        # ----------------------------
        # project_obra.reporte_desempeno_manual
        # ----------------------------
        reporte_desempeno_manual_model = self.env['project_obra.reporte_desempeno_manual']
        self.assertEqual(1000, reporte_desempeno_manual_model.sudo(user_group_project_dependencia_admin_01).search_count([]))
        self.assertEqual(1000, reporte_desempeno_manual_model.sudo(user_group_project_dependencia_admin_02).search_count([]))

        # ----------------------------
        # project.project
        # ----------------------------
        project_model = self.env['project.project']
        self.assertEqual(1000, project_model.sudo(user_group_project_dependencia_admin_01).search_count([]))
        self.assertEqual(1000, project_model.sudo(user_group_project_dependencia_admin_02).search_count([]))

    def test_010_project_portafolio_idu_group_project_dependencia_admin_create(self):
        """ project_portafolio_idu.group_project_dependencia_admin Verifica reglas de dominio en operación CREATE """
        user_group_project_dependencia_admin_01 = self.ref('project_obra_portafolio_idu.group_project_dependencia_admin_user_01')
        user_group_project_dependencia_admin_02 = self.ref('project_obra_portafolio_idu.group_project_dependencia_admin_user_02')

        # ----------------------------
        # project_obra.proyecto
        # ----------------------------
        proyecto_model = self.env['project_obra.proyecto']
        # Creación permitida
        vals = {
            'name': "Non expedita consequatur velit sed aperiam autem.",
            'state': "open",
            'eje_id': self.ref('project_obra_portafolio_idu.eje_id_01'),
            'alcance': "Molestias qui voluptatem praesentium.",
            'notas': "Eos sapiente saepe itaque non eum.",
            'motivo_cierre': "Perspiciatis voluptatem velit ratione ut.",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tag_ids': [
                (4, self.ref('project_obra_portafolio_idu.tag_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'codigo': "Nemo nulla laboriosam rerum illum saepe.",
            'codigo_sigidu': "Quae illum reiciendis beatae sint.",
            'codigo_valoricemos': "Assumenda tenetur qui est.",
            'origen_id': self.ref('project_obra_portafolio_idu.origen_id_01'),
            'edt_raiz_id': self.ref('project_obra_portafolio_idu.edt_raiz_id_01'),
            'progreso': 79156362.8535,
            'etapa_ids': [
                (4, self.ref('project_obra_portafolio_idu.etapa_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_planeada_inicio': "1982-04-12",
            'fecha_planeada_fin': "1991-02-10",
            'photo_ids': [
                (4, self.ref('project_obra_portafolio_idu.photo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'financiacion_ids': [
                (4, self.ref('project_obra_portafolio_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'programa_id': self.ref('project_obra_portafolio_idu.programa_id_01'),
            'portafolio_ids': [
                (4, self.ref('project_obra_portafolio_idu.portafolio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'localidad_ids': [
                (4, self.ref('project_obra_portafolio_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto = proyecto_model.sudo(user_group_project_dependencia_admin_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Aperiam dolore est ea aut aut ea.",
            'state': "open",
            'eje_id': self.ref('project_obra_portafolio_idu.eje_id_01'),
            'alcance': "Placeat et sequi assumenda omnis.",
            'notas': "Culpa fuga et deleniti aut totam.",
            'motivo_cierre': "Voluptatum in et qui ut.",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tag_ids': [
                (4, self.ref('project_obra_portafolio_idu.tag_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'codigo': "Deserunt sunt quia dolores sit.",
            'codigo_sigidu': "Nihil quia dolor officia ipsum culpa asperiores quibusdam.",
            'codigo_valoricemos': "Distinctio at deserunt vero a quaerat ea.",
            'origen_id': self.ref('project_obra_portafolio_idu.origen_id_01'),
            'edt_raiz_id': self.ref('project_obra_portafolio_idu.edt_raiz_id_01'),
            'progreso': 32786189.7298,
            'etapa_ids': [
                (4, self.ref('project_obra_portafolio_idu.etapa_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_planeada_inicio': "1999-01-22",
            'fecha_planeada_fin': "1980-07-10",
            'photo_ids': [
                (4, self.ref('project_obra_portafolio_idu.photo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'financiacion_ids': [
                (4, self.ref('project_obra_portafolio_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'programa_id': self.ref('project_obra_portafolio_idu.programa_id_01'),
            'portafolio_ids': [
                (4, self.ref('project_obra_portafolio_idu.portafolio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'localidad_ids': [
                (4, self.ref('project_obra_portafolio_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            proyecto = proyecto_model.sudo(user_group_project_dependencia_admin_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_model))

        # ----------------------------
        # project_obra.proyecto.tag
        # ----------------------------
        proyecto_tag_model = self.env['project_obra.proyecto.tag']
        # Creación permitida
        vals = {
            'name': "Et voluptatem eveniet pariatur voluptatum fuga iusto.",
        }
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_dependencia_admin_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Iste quod expedita eligendi dolores.",
        }
        try:
            proyecto_tag = proyecto_tag_model.sudo(user_group_project_dependencia_admin_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_tag_model))

        # ----------------------------
        # project_obra.proyecto.eje
        # ----------------------------
        proyecto_eje_model = self.env['project_obra.proyecto.eje']
        # Creación permitida
        vals = {
            'name': "Assumenda ut voluptatibus officiis non sit.",
        }
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_dependencia_admin_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Corrupti nam quam sunt vero quas et sit.",
        }
        try:
            proyecto_eje = proyecto_eje_model.sudo(user_group_project_dependencia_admin_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_eje_model))

        # ----------------------------
        # project_obra.proyecto.origen
        # ----------------------------
        proyecto_origen_model = self.env['project_obra.proyecto.origen']
        # Creación permitida
        vals = {
            'name': "Ut assumenda nisi sunt commodi consequuntur delectus explicabo magni.",
        }
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_dependencia_admin_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Non unde quas laboriosam.",
        }
        try:
            proyecto_origen = proyecto_origen_model.sudo(user_group_project_dependencia_admin_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_origen_model))

        # ----------------------------
        # project_obra.proyecto.etapa
        # ----------------------------
        proyecto_etapa_model = self.env['project_obra.proyecto.etapa']
        # Creación permitida
        vals = {
            'name': "Voluptas veniam fugit maxime dicta et et.",
            'contrato_ids': [
                (4, self.ref('project_obra_portafolio_idu.contrato_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'proyecto_id': self.ref('project_obra_portafolio_idu.proyecto_id_01'),
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tipo_id': self.ref('project_obra_portafolio_idu.tipo_id_01'),
            'parent_id': self.ref('project_obra_portafolio_idu.parent_id_01'),
            'child_ids': [
                (4, self.ref('project_obra_portafolio_idu.child_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'progreso': 99697758.7365,
            'fecha_planeada_inicio': "1998-12-05",
            'fecha_planeada_fin': "1975-06-28",
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'alcance': "Eveniet repellat enim laboriosam dolores ab accusantium quia.",
            'notas': "Soluta quae a beatae aliquid aperiam.",
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_dependencia_admin_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Fugit eum eius asperiores.",
            'contrato_ids': [
                (4, self.ref('project_obra_portafolio_idu.contrato_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'proyecto_id': self.ref('project_obra_portafolio_idu.proyecto_id_01'),
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tipo_id': self.ref('project_obra_portafolio_idu.tipo_id_01'),
            'parent_id': self.ref('project_obra_portafolio_idu.parent_id_01'),
            'child_ids': [
                (4, self.ref('project_obra_portafolio_idu.child_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'progreso': 34255901.366,
            'fecha_planeada_inicio': "1996-04-13",
            'fecha_planeada_fin': "2001-04-12",
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'alcance': "Voluptatem repellat occaecati pariatur veniam consectetur rerum et.",
            'notas': "Sit sed officia sit.",
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_dependencia_admin_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_etapa_model))

        # ----------------------------
        # project_obra.proyecto.etapa.tipo
        # ----------------------------
        proyecto_etapa_tipo_model = self.env['project_obra.proyecto.etapa.tipo']
        # Creación permitida
        vals = {
            'name': "Enim qui numquam sit repellat molestiae esse laboriosam quis.",
            'web_color': "Rerum quas excepturi omnis magnam expedita sed.",
        }
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_dependencia_admin_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Vel enim neque quae iste porro quis dolorem accusantium.",
            'web_color': "Odit nam vel quo enim corrupti error.",
        }
        try:
            proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_dependencia_admin_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(proyecto_etapa_tipo_model))

        # ----------------------------
        # photo_gallery.photo
        # ----------------------------
        photo_model = self.env['photo_gallery.photo']
        # Creación permitida
        vals = {
            'proyecto_obra_id': self.ref('project_obra_portafolio_idu.proyecto_obra_id_01'),
            'visible_website': True,
        }
        photo = photo_model.sudo(user_group_project_dependencia_admin_01).create(vals)

        # Creación NO permitida
        vals = {
            'proyecto_obra_id': self.ref('project_obra_portafolio_idu.proyecto_obra_id_01'),
            'visible_website': False,
        }
        try:
            photo = photo_model.sudo(user_group_project_dependencia_admin_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(photo_model))

        # ----------------------------
        # project_obra.reporte_desempeno_manual
        # ----------------------------
        reporte_desempeno_manual_model = self.env['project_obra.reporte_desempeno_manual']
        # Creación permitida
        vals = {
            'state': "registrado",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'estado_etapa': "activo",
            'fecha': "1986-01-25",
            'programado': 61439403.8635,
            'ejecutado': 18936765.3016,
            'descripcion': "Et aut eos quis provident velit debitis laudantium.",
            'observaciones': "Quae porro minima non.",
        }
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_dependencia_admin_01).create(vals)

        # Creación NO permitida
        vals = {
            'state': "pre_aprobado",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'estado_etapa': "sin_iniciar",
            'fecha': "2012-12-22",
            'programado': 60493604.0586,
            'ejecutado': 69620094.9003,
            'descripcion': "Nemo harum occaecati et harum est voluptas exercitationem.",
            'observaciones': "Rerum esse sed ut error qui.",
        }
        try:
            reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_dependencia_admin_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(reporte_desempeno_manual_model))

        # ----------------------------
        # project.project
        # ----------------------------
        project_model = self.env['project.project']
        # Creación permitida
        vals = {
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        project = project_model.sudo(user_group_project_dependencia_admin_01).create(vals)

        # Creación NO permitida
        vals = {
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            project = project_model.sudo(user_group_project_dependencia_admin_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(project_model))

    def test_020_project_portafolio_idu_group_project_dependencia_admin_write(self):
        """ project_portafolio_idu.group_project_dependencia_admin Verifica reglas de dominio en operación WRITE """
        user_group_project_dependencia_admin_01 = self.ref('project_obra_portafolio_idu.group_project_dependencia_admin_user_01')
        user_group_project_dependencia_admin_02 = self.ref('project_obra_portafolio_idu.group_project_dependencia_admin_user_02')

        # ----------------------------
        # project_obra.proyecto
        # ----------------------------
        proyecto_model = self.env['project_obra.proyecto']
        # Actualización permitida
        vals = {
            'name': "Harum nihil aut consequatur harum id.",
            'state': "close",
            'eje_id': self.ref('project_obra_portafolio_idu.eje_id_01'),
            'alcance': "Similique et soluta et aliquam praesentium ratione totam.",
            'notas': "Et sint omnis aut vero ea aperiam voluptatem.",
            'motivo_cierre': "Quae sit esse est omnis non aperiam.",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tag_ids': [
                (4, self.ref('project_obra_portafolio_idu.tag_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'codigo': "Modi quia deleniti sed omnis molestiae ut.",
            'codigo_sigidu': "Consequatur dicta voluptates voluptates distinctio similique accusamus.",
            'codigo_valoricemos': "Ut et pariatur vel et.",
            'origen_id': self.ref('project_obra_portafolio_idu.origen_id_01'),
            'edt_raiz_id': self.ref('project_obra_portafolio_idu.edt_raiz_id_01'),
            'progreso': 33911493.2103,
            'etapa_ids': [
                (4, self.ref('project_obra_portafolio_idu.etapa_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_planeada_inicio': "1970-07-17",
            'fecha_planeada_fin': "1981-05-13",
            'photo_ids': [
                (4, self.ref('project_obra_portafolio_idu.photo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'financiacion_ids': [
                (4, self.ref('project_obra_portafolio_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'programa_id': self.ref('project_obra_portafolio_idu.programa_id_01'),
            'portafolio_ids': [
                (4, self.ref('project_obra_portafolio_idu.portafolio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'localidad_ids': [
                (4, self.ref('project_obra_portafolio_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto = proyecto_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        proyecto.sudo(user_group_project_dependencia_admin_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Odio quasi vero ut laudantium.",
            'state': "close",
            'eje_id': self.ref('project_obra_portafolio_idu.eje_id_01'),
            'alcance': "Eos saepe voluptas nihil ducimus.",
            'notas': "Nihil mollitia ipsa repellendus facilis illum placeat impedit.",
            'motivo_cierre': "Ea nulla rerum eum odio qui.",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tag_ids': [
                (4, self.ref('project_obra_portafolio_idu.tag_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'codigo': "Magnam tempore omnis amet officia dolores nemo.",
            'codigo_sigidu': "Est perferendis sunt quas eius.",
            'codigo_valoricemos': "Qui in et est molestiae occaecati itaque.",
            'origen_id': self.ref('project_obra_portafolio_idu.origen_id_01'),
            'edt_raiz_id': self.ref('project_obra_portafolio_idu.edt_raiz_id_01'),
            'progreso': 53258954.5042,
            'etapa_ids': [
                (4, self.ref('project_obra_portafolio_idu.etapa_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_planeada_inicio': "2013-02-06",
            'fecha_planeada_fin': "1975-01-16",
            'photo_ids': [
                (4, self.ref('project_obra_portafolio_idu.photo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'financiacion_ids': [
                (4, self.ref('project_obra_portafolio_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'programa_id': self.ref('project_obra_portafolio_idu.programa_id_01'),
            'portafolio_ids': [
                (4, self.ref('project_obra_portafolio_idu.portafolio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'localidad_ids': [
                (4, self.ref('project_obra_portafolio_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto = proyecto_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            proyecto.sudo(user_group_project_dependencia_admin_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_model))

        # ----------------------------
        # project_obra.proyecto.tag
        # ----------------------------
        proyecto_tag_model = self.env['project_obra.proyecto.tag']
        # Actualización permitida
        vals = {
            'name': "Similique laboriosam nisi qui quia iusto beatae.",
        }
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        proyecto_tag.sudo(user_group_project_dependencia_admin_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Provident possimus sequi eum illo.",
        }
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            proyecto_tag.sudo(user_group_project_dependencia_admin_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_tag_model))

        # ----------------------------
        # project_obra.proyecto.eje
        # ----------------------------
        proyecto_eje_model = self.env['project_obra.proyecto.eje']
        # Actualización permitida
        vals = {
            'name': "Incidunt vel numquam ut.",
        }
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        proyecto_eje.sudo(user_group_project_dependencia_admin_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Eos ullam atque veniam illo nihil sint ratione tempore.",
        }
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            proyecto_eje.sudo(user_group_project_dependencia_admin_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_eje_model))

        # ----------------------------
        # project_obra.proyecto.origen
        # ----------------------------
        proyecto_origen_model = self.env['project_obra.proyecto.origen']
        # Actualización permitida
        vals = {
            'name': "Quia distinctio ea quia ratione consequatur.",
        }
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        proyecto_origen.sudo(user_group_project_dependencia_admin_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Et et illo beatae natus omnis doloribus.",
        }
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            proyecto_origen.sudo(user_group_project_dependencia_admin_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_origen_model))

        # ----------------------------
        # project_obra.proyecto.etapa
        # ----------------------------
        proyecto_etapa_model = self.env['project_obra.proyecto.etapa']
        # Actualización permitida
        vals = {
            'name': "Ut qui temporibus nemo soluta iste id a iure.",
            'contrato_ids': [
                (4, self.ref('project_obra_portafolio_idu.contrato_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'proyecto_id': self.ref('project_obra_portafolio_idu.proyecto_id_01'),
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tipo_id': self.ref('project_obra_portafolio_idu.tipo_id_01'),
            'parent_id': self.ref('project_obra_portafolio_idu.parent_id_01'),
            'child_ids': [
                (4, self.ref('project_obra_portafolio_idu.child_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'progreso': 94176431.8693,
            'fecha_planeada_inicio': "1991-06-28",
            'fecha_planeada_fin': "1985-04-30",
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'alcance': "Eum eum nisi delectus ipsum aut quia cumque.",
            'notas': "Qui consectetur deserunt hic doloribus molestiae eos aliquid voluptas.",
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        proyecto_etapa.sudo(user_group_project_dependencia_admin_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Quibusdam modi voluptatem laudantium ut.",
            'contrato_ids': [
                (4, self.ref('project_obra_portafolio_idu.contrato_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'proyecto_id': self.ref('project_obra_portafolio_idu.proyecto_id_01'),
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'tipo_id': self.ref('project_obra_portafolio_idu.tipo_id_01'),
            'parent_id': self.ref('project_obra_portafolio_idu.parent_id_01'),
            'child_ids': [
                (4, self.ref('project_obra_portafolio_idu.child_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'meta_ids': [
                (4, self.ref('project_obra_portafolio_idu.meta_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('project_obra_portafolio_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'reporte_desempeno_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'progreso': 91985074.8975,
            'fecha_planeada_inicio': "1990-12-29",
            'fecha_planeada_fin': "1974-05-17",
            'user_id': self.ref('project_obra_portafolio_idu.user_id_01'),
            'programador_id': self.ref('project_obra_portafolio_idu.programador_id_01'),
            'alcance': "Ut ut ab molestiae laudantium.",
            'notas': "Reiciendis officiis cumque expedita reprehenderit quod.",
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            proyecto_etapa.sudo(user_group_project_dependencia_admin_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_etapa_model))

        # ----------------------------
        # project_obra.proyecto.etapa.tipo
        # ----------------------------
        proyecto_etapa_tipo_model = self.env['project_obra.proyecto.etapa.tipo']
        # Actualización permitida
        vals = {
            'name': "Earum velit aspernatur odit omnis quae et consequatur.",
            'web_color': "Occaecati atque soluta sed sunt reiciendis qui.",
        }
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        proyecto_etapa_tipo.sudo(user_group_project_dependencia_admin_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Dolores vel ad laudantium reiciendis.",
            'web_color': "Pariatur aut laudantium qui voluptatibus autem.",
        }
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            proyecto_etapa_tipo.sudo(user_group_project_dependencia_admin_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(proyecto_etapa_tipo_model))

        # ----------------------------
        # photo_gallery.photo
        # ----------------------------
        photo_model = self.env['photo_gallery.photo']
        # Actualización permitida
        vals = {
            'proyecto_obra_id': self.ref('project_obra_portafolio_idu.proyecto_obra_id_01'),
            'visible_website': False,
        }
        photo = photo_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        photo.sudo(user_group_project_dependencia_admin_01).write(vals)

        # Actualización NO permitida
        vals = {
            'proyecto_obra_id': self.ref('project_obra_portafolio_idu.proyecto_obra_id_01'),
            'visible_website': False,
        }
        photo = photo_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            photo.sudo(user_group_project_dependencia_admin_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(photo_model))

        # ----------------------------
        # project_obra.reporte_desempeno_manual
        # ----------------------------
        reporte_desempeno_manual_model = self.env['project_obra.reporte_desempeno_manual']
        # Actualización permitida
        vals = {
            'state': "aprobado",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'estado_etapa': "suspendido",
            'fecha': "2004-01-16",
            'programado': 62822982.6628,
            'ejecutado': 60437103.413,
            'descripcion': "Et qui laborum est fugiat.",
            'observaciones': "Tempore dolore dolore quos ut voluptas qui provident voluptatem.",
        }
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        reporte_desempeno_manual.sudo(user_group_project_dependencia_admin_01).write(vals)

        # Actualización NO permitida
        vals = {
            'state': "aprobado",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'estado_etapa': "sin_iniciar",
            'fecha': "2007-01-10",
            'programado': 23782561.3717,
            'ejecutado': 22047098.3656,
            'descripcion': "Velit delectus officia laboriosam ducimus aperiam ea.",
            'observaciones': "Delectus dolor omnis nostrum assumenda voluptatibus.",
        }
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            reporte_desempeno_manual.sudo(user_group_project_dependencia_admin_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(reporte_desempeno_manual_model))

        # ----------------------------
        # project.project
        # ----------------------------
        project_model = self.env['project.project']
        # Actualización permitida
        vals = {
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        project = project_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        project.sudo(user_group_project_dependencia_admin_01).write(vals)

        # Actualización NO permitida
        vals = {
            'reporte_desempeno_manual_ids': [
                (4, self.ref('project_obra_portafolio_idu.reporte_desempeno_manual_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        project = project_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            project.sudo(user_group_project_dependencia_admin_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(project_model))

    def test_030_project_portafolio_idu_group_project_dependencia_admin_unlink(self):
        """ project_portafolio_idu.group_project_dependencia_admin Verifica reglas de dominio en operación UNLINK - Delete """
        user_group_project_dependencia_admin_01 = self.ref('project_obra_portafolio_idu.group_project_dependencia_admin_user_01')
        user_group_project_dependencia_admin_02 = self.ref('project_obra_portafolio_idu.group_project_dependencia_admin_user_02')

        # ----------------------------
        # project_obra.proyecto
        # ----------------------------
        proyecto_model = self.env['project_obra.proyecto']
        # Eliminación permitida
        proyecto = proyecto_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        proyecto.sudo(user_group_project_dependencia_admin_01).unlink()

        # Eliminación NO permitida
        proyecto = proyecto_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            proyecto.sudo(user_group_project_dependencia_admin_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_model))

        # ----------------------------
        # project_obra.proyecto.tag
        # ----------------------------
        proyecto_tag_model = self.env['project_obra.proyecto.tag']
        # Eliminación permitida
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        proyecto_tag.sudo(user_group_project_dependencia_admin_01).unlink()

        # Eliminación NO permitida
        proyecto_tag = proyecto_tag_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            proyecto_tag.sudo(user_group_project_dependencia_admin_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_tag_model))

        # ----------------------------
        # project_obra.proyecto.eje
        # ----------------------------
        proyecto_eje_model = self.env['project_obra.proyecto.eje']
        # Eliminación permitida
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        proyecto_eje.sudo(user_group_project_dependencia_admin_01).unlink()

        # Eliminación NO permitida
        proyecto_eje = proyecto_eje_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            proyecto_eje.sudo(user_group_project_dependencia_admin_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_eje_model))

        # ----------------------------
        # project_obra.proyecto.origen
        # ----------------------------
        proyecto_origen_model = self.env['project_obra.proyecto.origen']
        # Eliminación permitida
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        proyecto_origen.sudo(user_group_project_dependencia_admin_01).unlink()

        # Eliminación NO permitida
        proyecto_origen = proyecto_origen_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            proyecto_origen.sudo(user_group_project_dependencia_admin_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_origen_model))

        # ----------------------------
        # project_obra.proyecto.etapa
        # ----------------------------
        proyecto_etapa_model = self.env['project_obra.proyecto.etapa']
        # Eliminación permitida
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        proyecto_etapa.sudo(user_group_project_dependencia_admin_01).unlink()

        # Eliminación NO permitida
        proyecto_etapa = proyecto_etapa_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            proyecto_etapa.sudo(user_group_project_dependencia_admin_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_etapa_model))

        # ----------------------------
        # project_obra.proyecto.etapa.tipo
        # ----------------------------
        proyecto_etapa_tipo_model = self.env['project_obra.proyecto.etapa.tipo']
        # Eliminación permitida
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        proyecto_etapa_tipo.sudo(user_group_project_dependencia_admin_01).unlink()

        # Eliminación NO permitida
        proyecto_etapa_tipo = proyecto_etapa_tipo_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            proyecto_etapa_tipo.sudo(user_group_project_dependencia_admin_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(proyecto_etapa_tipo_model))

        # ----------------------------
        # photo_gallery.photo
        # ----------------------------
        photo_model = self.env['photo_gallery.photo']
        # Eliminación permitida
        photo = photo_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        photo.sudo(user_group_project_dependencia_admin_01).unlink()

        # Eliminación NO permitida
        photo = photo_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            photo.sudo(user_group_project_dependencia_admin_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(photo_model))

        # ----------------------------
        # project_obra.reporte_desempeno_manual
        # ----------------------------
        reporte_desempeno_manual_model = self.env['project_obra.reporte_desempeno_manual']
        # Eliminación permitida
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        reporte_desempeno_manual.sudo(user_group_project_dependencia_admin_01).unlink()

        # Eliminación NO permitida
        reporte_desempeno_manual = reporte_desempeno_manual_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            reporte_desempeno_manual.sudo(user_group_project_dependencia_admin_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(reporte_desempeno_manual_model))

        # ----------------------------
        # project.project
        # ----------------------------
        project_model = self.env['project.project']
        # Eliminación permitida
        project = project_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        project.sudo(user_group_project_dependencia_admin_01).unlink()

        # Eliminación NO permitida
        project = project_model.sudo(user_group_project_dependencia_admin_01).search([], limit=1)
        try:
            project.sudo(user_group_project_dependencia_admin_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(project_model))


if __name__ == '__main__':
    unittest2.main()