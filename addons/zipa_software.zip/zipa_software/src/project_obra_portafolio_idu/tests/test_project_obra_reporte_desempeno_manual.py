# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_project_obra_reporte_desempeno_manual(common.TransactionCase):
    def test_crud_validaciones(self):
        reporte_desempeno_manual_model = self.env['project_obra.reporte_desempeno_manual']
        vals = {
            'state': "pre_aprobado",
            'project_id': self.ref('project_obra_portafolio_idu.project_id_01'),
            'estado_etapa': "suspendido",
            'fecha': "1992-03-26",
            'programado': 66474631.3738,
            'ejecutado': 81587633.4171,
            'descripcion': "Mollitia et et et quia occaecati quo.",
            'observaciones': "Eveniet cum et omnis.",
        }
        reporte_desempeno_manual = reporte_desempeno_manual_model.create(vals)

        # Campos computados
        self.assertEqual(reporte_desempeno_manual.name, 'Valor Esperado')
        self.assertEqual(reporte_desempeno_manual.variacion, 'Valor Esperado')
        self.assertEqual(reporte_desempeno_manual.adjunto, 'Valor Esperado')

        # Campos con api.constrain
        vals_update = {
            'fecha': 'Valor a usarse para romper la validación',
        }
        try:
            reporte_desempeno_manual.write(vals_update)
        except ValidationError, e:
            pass
        else:
            self.fail('No se generó exception de validación para "fecha"')
        vals_update = {
            'programado': 'Valor a usarse para romper la validación',
        }
        try:
            reporte_desempeno_manual.write(vals_update)
        except ValidationError, e:
            pass
        else:
            self.fail('No se generó exception de validación para "programado"')
        vals_update = {
            'ejecutado': 'Valor a usarse para romper la validación',
        }
        try:
            reporte_desempeno_manual.write(vals_update)
        except ValidationError, e:
            pass
        else:
            self.fail('No se generó exception de validación para "ejecutado"')


if __name__ == '__main__':
    unittest2.main()