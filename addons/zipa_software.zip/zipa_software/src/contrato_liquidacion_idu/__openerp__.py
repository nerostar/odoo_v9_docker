{
    'name': 'ZIPA: Contrato de Liquidacion IDU',
    'version': '1.0',
    'depends': [
        'base',
        'base_idu',
        'model_security',
        'project_obra_portafolio_idu',
        'project_obra_seguimiento_idu',
    ],
    'author': "IDU I+D+I",
    'category': 'IDU',
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'wizards/agregar_actividad_view.xml',
        'wizards/wizard_agregar_nueva_gestion.xml',
        'views/contrato_liquidacion_view.xml',
        'views/project_view.xml',
        'views/contrato_view.xml',
        'workflow/actividad_workflow.xml',
    ],
    'test': [],
    'installable': True,
    'description': """
## Dependencias módulos Python
## Configuración adicional
    """,
}