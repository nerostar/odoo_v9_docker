# -*- coding: utf-8 -*-
from openerp import models, fields, api
from openerp.exceptions import ValidationError, Warning

class wizard_agregar_actividad(models.TransientModel):
    _name = 'wizard.agregar_actividad'

    producto_id = fields.Many2one(
        string='Producto / Empresa',
        required=True,
        comodel_name='liquidacion.producto',
        ondelete='restrict',
        help='''Nombre del Producto o la Empresa''',
        store=True,
    )
    pendiente_ids = fields.Many2many(
        string='Pendientes',
        required=True,
        comodel_name='liquidacion.pendiente',
        ondelete='restrict',
        help='''Pendientes relacionados''',
        domain="[('producto_id','=',producto_id)]",
    )

    @api.multi
    def agregar_actividad(self):
        es_tecnico = self.env.user.has_group('project_obra_seguimiento_idu.tecnico')
        es_administrador = self.env.user.has_group('project.group_project_manager')
        if es_tecnico or es_administrador:
            contrato_id = self.env.context.get('active_id', False)
            liquidacion_actividad_model = self.env['liquidacion.actividad']
            for pendiente in self.pendiente_ids:
                actividades = liquidacion_actividad_model.search([
                    ('contrato_id','=',contrato_id),
                    ('producto_id','=',pendiente.producto_id.id),
                    ('pendiente_id','=',pendiente.id),
                    ('name','=',False)
                    ])
                if len(actividades) == 0:
                    liquidacion_actividad_model.create({
                        'contrato_id': contrato_id,
                        'producto_id': self.producto_id.id,
                        'pendiente_id': pendiente.id,
                    })
            return {'type': 'ir.actions.act_window_close'}
        else:
            raise ValidationError("Usted no esta autorizado para crear este registro")