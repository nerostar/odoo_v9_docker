# -*- coding: utf-8 -*-
from openerp.addons.web import http
from openerp.addons.web.http import request
from openerp import models, fields, api, exceptions

class zipa_agregar_nueva_gestion(models.TransientModel):
    """Wizard to add new gestion"""
    _name = 'zipa.agregar_nueva_gestion.wizard'
    _description = 'Crear nueva gestión en actividad de contrato liquidacion'

    gestion = fields.Text(
        string='Gestión',
        required=True,
        help='''Nueva gestión de la actividad''',
    )

    @api.multi
    def guardar_gestion(self,vals):
        actividad_model = self.env["liquidacion.actividad"]
        actividad_id = vals['actividad_id']
        actividad = actividad_model.browse(actividad_id)
        actividad.gestion = self.gestion