# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api

class project_problema(models.Model):
    _name = 'project.problema'
    _inherit = 'project.problema'

    def _default_es_proyecto_terminado(self):
        return self.env.context.get('filtrar_problema_tipo_liquidacion',False)

    def _domain_producto_ids(self):
        producto_ids = []
        if 'active_id' in self.env.context:
            contrato_id = self.env.context['active_id']
            contrato_model = self.env['contrato.contrato']
            contrato = contrato_model.search([('id','=',contrato_id)])
            actividades = contrato.actividad_ids
            for actividad in actividades:
                producto_ids.append(actividad.producto_id.id)
            if producto_ids:
                producto_ids = reduce(lambda l, x: l if x in l else l+[x], producto_ids, [])
        return [('id', '=', producto_ids)]

    es_proyecto_terminado = fields.Boolean(
        string='Es proyecto terminado',
        compute='_compute_es_proyecto_terminado',
        default=_default_es_proyecto_terminado,
        store=True,
    )

    producto_ids = fields.Many2many(
        string='Producto',
        track_visibility='onchange',
        comodel_name='liquidacion.producto',
        ondelete='restrict',
        help='''Productos relacionadoS''',
        domain=_domain_producto_ids,
    )

    def search(self, cr, uid, args, offset=0, limit=None, order=None, context=None, count=False):
        if context.get('filtrar_problema_tipo_liquidacion',False):
            args += [('es_proyecto_terminado', '=', True)]
        else:
            args += [('es_proyecto_terminado', '=', False)]
        return super(project_problema, self).search(cr, uid, args, offset, limit, order, context, count)

    @api.one
    def _compute_es_proyecto_terminado(self):
        if self.env.context.get('filtrar_problema_tipo_liquidacion', False) and self.state == 'nuevo':
            self.es_proyecto_terminado = True