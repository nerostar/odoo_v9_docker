# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api

class contrato_contrato(models.Model):
    _name = 'contrato.contrato'
    _inherit = 'contrato.contrato'

    actividad_ids = fields.One2many(
        string='Actividades',
        comodel_name='liquidacion.actividad',
        inverse_name='contrato_id',
    )

    def search(self, cr, uid, args, offset=0, limit=None, order=None, context=None, count=False):
        user = self.pool.get('res.users').browse(cr, uid, uid)
        if context and context.get('filtrar_contrato_liquidacion',False):
            es_tecnico = user.has_group('project_obra_seguimiento_idu.tecnico')
            es_administrador = user.has_group('project.group_project_manager')
            es_analista = user.has_group('contrato_liquidacion_idu.analista')
            es_abogado = user.has_group('contrato_liquidacion_idu.abogado')
            if es_tecnico or es_administrador or es_analista or es_abogado:
                proyecto_model = self.pool.get('project_obra.proyecto')
                proyecto_ids = proyecto_model.search(cr, uid, [('visibilidad','in',['publico-terminado','publico-ejecucion-y-liquidacion'])])
                proyectos = proyecto_model.browse(cr, uid,proyecto_ids)
                contratos = []
                for proyecto in proyectos:
                    for etapa in proyecto.etapa_ids:
                        try:
                            if len(etapa.contrato_ids)>0:
                                contratos += etapa.contrato_ids.ids
                        except:
                            pass
                if isinstance(args,list):
                    args += [('id','in',contratos)]
                if (es_tecnico or es_abogado) and not es_administrador:
                    args += [['coordinador_ids.user_id', 'in', [uid]]]
        return super(contrato_contrato, self).search(cr, uid, args, offset, limit, order, context, count)

    @api.multi
    def problema_liquidacion_view_button(self):
        proyecto_model = self.env['project_obra.proyecto']
        contrato_id = self.id
        proyecto = proyecto_model.search([('etapa_ids.contrato_ids','=',contrato_id)])
        project = proyecto.project_id
        return {
            'name': 'Novedades',
            'res_model': 'project.problema',
            'domain': [('project_id', '=', project.id)],
            'context': {'project_id': project.id, 'proyecto_id': proyecto.id, 'filtrar_problema_tipo_liquidacion':True},
            'type': 'ir.actions.act_window',
            'view_mode': 'tree,form',
            'view_type': 'form',
        }