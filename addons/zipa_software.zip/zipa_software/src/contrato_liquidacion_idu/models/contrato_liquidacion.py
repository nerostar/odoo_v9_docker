# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api
from openerp.exceptions import ValidationError

ACTIVIDADES_ESTADOS = [
            ('por_iniciar', 'Por Iniciar'),
            ('en_ejecucion', 'En Ejecución'),
            ('suspendido', 'Suspendido'),
            ('aprobado', 'Aprobado'),
            ('terminado', 'Terminado'),
        ]

class liquidacion_producto(models.Model):
    _name = 'liquidacion.producto'
    _description = 'Empresas / Productos'
    _inherit = ['mail.thread']
    _order = 'name'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        track_visibility='onchange',
        size=255,
        help='''Nombre del Producto o la Empresa''',
    )
    pendiente_ids = fields.One2many(
        string='Pendientes',
        required=False,
        track_visibility='onchange',
        comodel_name='liquidacion.pendiente',
        inverse_name='producto_id',
        ondelete='restrict',
        help='''Pendientes relacionados''',
    )

    _sql_constraints = [
        ('unique_name', 'unique(name)', 'Este name ya está registrado'),
    ]

    # -------------------
    # methods
    # -------------------

class liquidacion_pendiente(models.Model):
    _name = 'liquidacion.pendiente'
    _description = 'Pendientes'
    _inherit = ['mail.thread']
    _order = 'name DESC'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        track_visibility='onchange',
        size=255,
        help='''Nombre del pendiente''',
    )
    producto_id = fields.Many2one(
        string='Producto Empresa',
        required=True,
        track_visibility='onchange',
        comodel_name='liquidacion.producto',
        ondelete='restrict',
        help='''Producto relacionado''',
    )
    # -------------------
    # methods
    # -------------------

class liquidacion_actividad(models.Model):
    _name = 'liquidacion.actividad'
    _description = 'Actividades'
    _inherit = ['mail.thread']
    _order = 'sequence, producto_id, pendiente_id DESC'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=255,
        help='''Nombre de la Actividad''',
    )
    contrato_id = fields.Many2one(
        string='Contrato',
        required=True,
        track_visibility='onchange',
        comodel_name='contrato.contrato',
        ondelete='restrict',
        help='''Contrato relacionado''',
    )
    producto_id = fields.Many2one(
        string='Producto / Empresa',
        required=True,
        track_visibility='onchange',
        comodel_name='liquidacion.producto',
        ondelete='restrict',
        help='''Nombre del Producto o la Empresa''',
        store=True,
    )
    pendiente_id = fields.Many2one(
        string='Pendiente',
        required=True,
        track_visibility='onchange',
        comodel_name='liquidacion.pendiente',
        ondelete='restrict',
        help='''Pendiente relacionado''',
        domain="[('producto_id','=',producto_id)]",
    )
    porcentaje_progreso = fields.Integer(
        string='Porcentaje de progreso',
        required=False,
        track_visibility='onchange',
        help='''Porcentaje''',
    )
    fecha_fin_planeada = fields.Date(
        string='Fecha de cumplimiento prevista',
        required=False,
        track_visibility='onchange',
        help='''Fecha de respuesta''',
    )
    state = fields.Selection(
        string='Estado',
        required=True,
        track_visibility='onchange',
        help='''Estados de la solicitud''',
        selection= ACTIVIDADES_ESTADOS,
        default='por_iniciar',
    )
    es_responsable_contratista = fields.Boolean(
        string='Es responsable Contratista',
        required=False,
        track_visibility='onchange',
        help='''El responsable de la gestión es Contratista''',
    )
    es_responsable_interventor = fields.Boolean(
        string='Es responsable Interventor',
        required=False,
        track_visibility='onchange',
        help='''El responsable de la gestión es Interventor''',
    )
    es_responsable_idu = fields.Boolean(
        string='Es responsable IDU',
        required=False,
        track_visibility='onchange',
        help='''El responsable de la gestión es IDU''',
    )
    es_responsable_externo = fields.Boolean(
        string='Es responsable Externo',
        required=False,
        track_visibility='onchange',
        help='''El responsable de la gestión es Externo''',
    )
    gestion = fields.Text(
        string='Gestión',
        required=False,
        track_visibility='onchange',
        help='''Última gestión de la actividad''',
    )
    sequence = fields.Integer(
        string='Orden',
        required=False,
    )

    # -------------------
    # methods
    # -------------------
    @api.multi
    def agregar_nueva_gestion(self):
        view = self.env.ref('contrato_liquidacion_idu.zipa_wizard_agregar_nueva_gestion_form')
        return {
            'name':'Agregar nueva gestión',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'zipa.agregar_nueva_gestion.wizard',
            'context': { 'actividad_id': self.id },
            'view_id': view.id,
            'target': 'new',
            'views': [(view.id, 'form'),
                    (False, 'form')],
        }
    # -------------------
    # Workflow methods
    # -------------------
    def wkf_en_ejecucion(self):
        self.state = 'en_ejecucion'

    def wkf_por_iniciar(self):
        self.state = 'por_iniciar'

    def wkf_suspendido(self):
        self.state = 'suspendido'

    def wkf_aprobado(self):
        self.state = 'aprobado'

    def wkf_terminado(self):
        self.state = 'terminado'