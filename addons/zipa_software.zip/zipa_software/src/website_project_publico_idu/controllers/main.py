# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from datetime import datetime, date
from operator import itemgetter
from random import choice
import json
import re
import werkzeug.exceptions

from openerp.addons.base_idu.tools.utilitarios import obtener_etiqueta_lista_select
from openerp.addons.contrato_idu.models.contrato import TIPO_INTEGRANTE, TIPO_INTEGRANTE_LABELS
from openerp.addons.contrato_liquidacion_idu.models.contrato_liquidacion import ACTIVIDADES_ESTADOS
from openerp.addons.project_problemas_idu.models.project import PROBLEMA_ESTADOS, PROBLEMA_ESTADOS_LABELS
from openerp.addons.tramites_idu.models.tramite import TRAMITE_STATES
from openerp.addons.project_obra_seguimiento_idu.models.project_obra import APROBACION_INTERVENTORIA_OPCIONES, NO_OBJECION_IDU_OPCIONES,APROBACION_INTERVENTORIA_LABELS, NO_OBJECION_IDU_LABELS
from openerp.addons.web import http
from openerp.addons.web.http import request
from openerp.addons.website.models.website import slug

class dict_dot_access(dict):
    """Extension to make dict attributes be accesible with dot notation
    """

    def __getattr__(self, attr):
        try:
            return self.__getitem__(attr)
        except KeyError:
            pass


placeholders = [
    'obra_1.jpg',
    'obra_2.jpg',
    'obra_3.jpg',
    'obra_4.jpg',
    'obra_5.jpg',
    'obra_6.jpg',
    'obra_7.jpg',
]

def url_imagen_proyecto(proyecto):
    if len(proyecto.photo_ids):
        photo_ids = proyecto.photo_ids.mapped('id')
        return '/web/image/photo_gallery.photo/{0}/photo/323x242'.format(choice(photo_ids), slug(proyecto))
    else:
        return '/website_project_publico_idu/static/src/images/{}'.format(choice(placeholders))


def url_imagen_contrato(contrato):
    if contrato.url_imagen:
        return contrato.url_imagen
    else:
        return '/website_project_publico_idu/static/src/images/{}'.format(choice(placeholders))



def get_coordinadores_order(coordinadores):
    integrantes_list = []
    for coordinador in coordinadores:
        orden = 4
        if coordinador.active and coordinador.tipo != 'revisor':
            if coordinador.tipo_integrante == 'tecnico':
                orden = 1
            elif coordinador.tipo_integrante in ['apoyo', 'ambiental', 'social', 'arqueologo']:
                orden = 2
            elif coordinador.tipo_integrante == 'especialista':
                orden = 3
            integrantes_list.append({
                'nombre': coordinador.user_id.name,
                'cargo': TIPO_INTEGRANTE_LABELS[coordinador.tipo_integrante],
                'orden' : orden,
            })
    integrantes_list = sorted(integrantes_list, key=lambda integrante: integrante['orden'])
    return integrantes_list


class controller(http.Controller):
    mapping_estado = {
        'ejecucion': {
            'title': 'en Ejecución',
            'breadcrumb': 'En Ejecución',
            'visibilidad': ['publico','publico-ejecucion-y-liquidacion'],
            'filtro_etapas_actuales': ['open'],
            'filtro_state_proyectos': ['open', 'pending','close'],
        },
        'en_ejecucion': {
            'title': 'en Ejecución',
            'breadcrumb': 'En Ejecución',
            'visibilidad': ['publico','publico-ejecucion-y-liquidacion'],
            'filtro_etapas_actuales': ['open'],
            'filtro_state_contratos': ['en_ejecucion'],
        },
        'terminado': {
            'title': 'Terminados y/o en Liquidación',
            'breadcrumb': 'Terminados',
            'visibilidad': ['publico-terminado','publico-ejecucion-y-liquidacion'],
            'filtro_etapas_actuales': ['close'],
            'filtro_state_proyectos': ['close','open'],
        },
    }


    ###########################################################################################
    # PROYECTOS
    ###########################################################################################

    @http.route('/zipa/proyectos_obra', type='http', auth="user", website=True)
    def proyectos_obra_index_redirect(self, **kwargs):
        return request.redirect('/zipa/proyectos_obra/ejecucion')

    @http.route('/zipa/proyectos_obra/<any(ejecucion, terminado):estado>', type='http', auth="user", website=True)
    def proyectos_obra_index(self, estado='ejecucion', **kwargs):
        datos = {
            'title': 'Seguimiento a Proyectos',
            'additional_title': self.mapping_estado[estado]['title'],
            'additional_title_breadcrumb': self.mapping_estado[estado]['breadcrumb'],
            'filtro_estado': estado,
        }
        proyecto_model = request.env['project_obra.proyecto']
        etapa_model = request.env['project_obra.proyecto.etapa.tipo']
        origen_model = request.env['project_obra.proyecto.origen']
        datos['proyectos'] = proyecto_model.search([
            ('state', 'in', self.mapping_estado[estado]['filtro_state_proyectos']),
            ('visibilidad', 'in', self.mapping_estado[estado]['visibilidad']),
        ])
        etapas_list = etapa_model.search([('es_visible_website', '=', True)]).mapped('name')
        origenes_list = origen_model.search([('es_visible_website', '=', True)]).mapped('name')
        datos['url_imagen_proyecto'] = url_imagen_proyecto
        res = []
        for position, p in enumerate(datos['proyectos']):
            if estado == 'terminado':
                etapas_actuales = p.etapa_ids.filtered(lambda r: r.state == 'close' and len(r.contrato_ids)>0)
                if etapas_actuales:
                    etapas_actuales = sorted(etapas_actuales, key=itemgetter('fecha_planeada_fin'), reverse=True)[0]
            else:
                etapas_actuales = p.etapa_ids.filtered(lambda r: r.state == 'open')
            etapa_actual = []
            contratos = []
            contrato_obra = ''
            estado_contrato = ''
            primer_contrato = False
            primero = True
            for etapa in etapas_actuales:
                etapa_actual.append({
                    'name': etapa.tipo_id.name,
                    'fecha_inicio': etapa.fecha_planeada_inicio,
                    'fecha_fin': etapa.fecha_planeada_fin,
                })
                for contrato in etapa.contrato_ids:
                    if primero:
                        primer_contrato = contrato
                        primero = False
                    contratos.append(contrato.numero)
                    if contrato.siac_tipo_contrato_id.name == 'Contrato de Obra':
                        contrato_obra = contrato.numero
                        estado_contrato = contrato.estado_siac_id.name
                        continue
            contratos = list(set(contratos))
            if (not contrato_obra) and contratos:
                 contrato_obra = primer_contrato.numero
                 estado_contrato = primer_contrato.estado_siac_id.name
            res.append({
                "name": p.name,
                "contratos": ' '.join(contratos).lower(),
                "origen": p.origen_id.name,
                "alcance": p.alcance or "*** No se ha definido el alcance para el proyecto ***",
                "etapa_actual": etapa_actual,
                "slug": slug(p),
                'url_imagen': url_imagen_proyecto(p),
                'even': int(position % 2 == 1),
                'contrato': contrato_obra,
                'estado_contrato': estado_contrato,
                'filtro_estado' : estado,
            })
        datos['proyectos_json'] = json.dumps(res)
        datos['etapas_json'] = json.dumps(etapas_list)
        datos['origenes_json'] = json.dumps(origenes_list)
        datos['nombre_etapas'] = etapas_list
        datos['nombre_origenes'] = origenes_list
        return request.website.render(
            "website_project_publico_idu.proyectos_obra_index",
            datos,
        )

    @http.route([
        '/zipa/proyectos_obra/<model("project_obra.proyecto"):proyecto>',
        '/zipa/proyectos_obra/<any(ejecucion, terminado):estado>/<model("project_obra.proyecto"):proyecto>'
        ], type='http', auth="user", website=True)
    def proyectos_obra_show(self, estado='ejecucion', proyecto=None, **kwargs):
        if proyecto.visibilidad not in ['publico', 'publico-terminado','publico-ejecucion-y-liquidacion']:
            return werkzeug.exceptions.NotFound('Proyecto no encontrado')
        problemas_estados = ['nuevo', 'cerrado']
        hay_videos = False
        for photo in proyecto.photo_ids:
            if photo.url:
                hay_videos = True
        ultimo_informe = kwargs.get('ultimo_informe')
        datos = {
            'title': proyecto.name,
            'additional_title': 'Resumen Ejecutivo',
            'proyecto': proyecto,
            'problemas_estados': problemas_estados,
            'problemas_estados_labels': PROBLEMA_ESTADOS_LABELS,
            'es_usuario_externo': request.env.user.has_group('base.group_public'),
            'hay_videos': hay_videos,
            'additional_title_breadcrumb': self.mapping_estado[estado]['breadcrumb'],
            'filtro_estado': estado,
            'ultimo_informe': ultimo_informe,
            'APROBACION_INTERVENTORIA_LABELS': APROBACION_INTERVENTORIA_LABELS,
            'NO_OBJECION_IDU_LABELS': NO_OBJECION_IDU_LABELS,
        }
        datos.update(self.get_detalle_proyecto(proyecto, problemas_estados, estado, ultimo_informe))
        return request.website.render(
            "website_project_publico_idu.proyectos_obra_show",
            datos,
        )

    @http.route(['/zipa/visor_proyectos/get_avance_de_proyectos_en_seguimiento'], type='http', auth="public", methods=['get'])
    def get_avance_de_proyectos_en_seguimiento(self, **kwargs):
        res = []
        for estado in self.mapping_estado.keys():
            proyectos = request.env['project_obra.proyecto'].sudo().search([
                ('state', 'in', self.mapping_estado[estado]['filtro_state_proyectos']),
                ('visibilidad', '=', self.mapping_estado[estado]['visibilidad']),
            ])
            contrato_interventoria = False
            for proyecto in proyectos:
                detalle_proyecto = self.get_detalle_proyecto(proyecto, [], estado)
                contratos = {}
                etapa_names = []
                for etapa in detalle_proyecto['etapas_abiertas']:
                    etapa_names.append(etapa.name)
                    for contrato in etapa.contrato_ids:
                        contratos[contrato.numero] = contrato
                        if contrato.siac_tipo_contrato_id.es_interventoria:
                            contrato_interventoria = contrato.numero

                datos_proyecto = {
                    'proyecto_nombre': proyecto.name,
                    'proyecto_codigo_zipa': proyecto.codigo,
                    'marco_legal_origen': proyecto.origen_id.name,
                    'fuente_financiacion': ';'.join(['{} ()'.format(f.fuente_financiacion_id.name, f.name) for f in proyecto.financiacion_ids]),
                    'etapas': ','.join(list(set(etapa_names))),
                }

                def extraer_datos_contrato(contrato, tipo):
                    datos_contrato = {
                        tipo + '_contrato': contrato.numero,
                        tipo + '_fecha_suscripcion_contrato': contrato.fecha_suscripcion,
                        tipo + '_fecha_fin_planeada_contrato': contrato.fecha_fin_planeada,
                        tipo + '_fecha_fin_proyectada_contrato': contrato.fecha_fin_proyectada,
                        tipo + '_fecha_inicio_contrato': contrato.fecha_inicio,  # Legalización
                        tipo + '_fecha_fin_real_contrato': contrato.fecha_finalizacion,
                        tipo + '_valor_inicial_contrato': contrato.valor_contrato,
                        tipo + '_valor_final_contrato': contrato.valor_contrato + contrato.valor_adiciones + contrato.mayor_cantidad_obra,
                    }
                    return datos_contrato

                for numero, contrato in contratos.items():
                    tipo = 'obra'
                    if numero == contrato_interventoria:
                        tipo = 'interventoria'
                    datos_proyecto.update(extraer_datos_contrato(contrato, tipo))
                datos_proyecto['avances'] = detalle_proyecto['estados_actuales']
                res.append(datos_proyecto)

        return json.dumps(res, ensure_ascii=False)

    @http.route(['/zipa/visor_proyectos/get_proyectos_en_seguimiento'], type='http', auth="public", methods=['get'])
    def get_proyectos_en_seguimiento(self, **kwargs):
        res = []
        headers = []  # Guarda el listado de cabeceras requerido en el CSV
        for estado in self.mapping_estado.keys():
            proyectos = request.env['project_obra.proyecto'].sudo().search([
                ('state', 'in', self.mapping_estado[estado]['filtro_state_proyectos']),
                ('visibilidad', '=', self.mapping_estado[estado]['visibilidad']),
            ])
            contrato_interventoria = False
            for proyecto in proyectos:
                contratos = {}
                etapas = proyecto.etapa_ids.filtered(lambda r: r.parent_id.id == False and r.state in self.mapping_estado[estado]['filtro_etapas_actuales'])
                for etapa in etapas:
                    for contrato in etapa.contrato_ids:
                        contratos[contrato.numero] = contrato

                datos_proyecto = {
                    'proyecto_nombre': proyecto.name,
                    'proyecto_codigo_zipa': proyecto.codigo,
                }

                datos_proyecto['contratos'] = []
                for numero, contrato in contratos.items():
                    datos_proyecto['contratos'].append({
                        'numero': contrato.numero,
                        'tipo': contrato.siac_tipo_contrato_id.name,
                        'Estado': contrato.state,
                        'informacion_pagos': contrato.get_pagos()['resumen']
                    })

                res.append(datos_proyecto)
        return json.dumps(res, ensure_ascii=False).encode('utf8')




    ###########################################################################################
    # CONTRATOS
    ###########################################################################################

    @http.route('/zipa/contratos_obra', type='http', auth="user", website=True)
    def contratos_obra_index_redirect(self, **kwargs):
        return request.redirect('/zipa/contratos_obra/en_ejecucion')

    @http.route('/zipa/contratos_obra/<any(en_ejecucion, terminado):estado>', type='http', auth="user", website=True)
    def contratos_obra_index(self, **kwargs):      # estado='en_ejecucion',
        datos = {
            'title': 'Seguimiento a Contratos',
            'additional_title': 'con etapas relacionadas',          # self.mapping_estado[estado]['title'],
            'additional_title_breadcrumb': 'CONTRATOS',           # self.mapping_estado[estado]['breadcrumb'],
            # 'filtro_estado': 'con etapas relacionadas',      # estado,
        }
        # contrato_model = request.env['contrato.contrato']
        tipo_etapa_model = request.env['project_obra.proyecto.etapa.tipo']
        etapa_model = request.env['project_obra.proyecto.etapa']
        origen_model = request.env['project_obra.proyecto.origen']

        # Traer todos los contratos que estén relacionados a una etapa
        etapas = etapa_model.search([('contrato_ids','!=',False)])
        contratos = etapas.mapped('contrato_ids')    # mapped de odoo devuelve la lista de los registros relacionados sin duplicados
        # estados_list = contratos.mapped('state')
        datos['contratos'] = contratos
        etapas_list = tipo_etapa_model.search([]).mapped('name')        #('es_visible_website', '=', True)
        origenes_list = origen_model.search([('es_visible_website', '=', True)]).mapped('name')
        datos['url_imagen_contrato'] = url_imagen_contrato
        res = []
        for position, c in enumerate(datos['contratos']):
            if c.id == 7672:
                print 'por aca...'
            # if estado == 'terminado':
            #     etapas_actuales = etapa_model.search([('state','=','close'),('contrato_ids','=', c.id)])
            #     # etapas_actuales = p.etapa_ids.filtered(lambda r: r.state == 'close' and len(r.contrato_ids)>0)
            #     if etapas_actuales:
            #         etapas_actuales = sorted(etapas_actuales, key=itemgetter('fecha_planeada_fin'), reverse=True)[0]
            # else:
            #     etapas_actuales = etapa_model.search([('state','!=','close'),('contrato_ids','=', c.id)])
            #     # etapas_actuales = p.etapa_ids.filtered(lambda r: r.state == 'open')
            etapas_asociadas = etapa_model.search([('contrato_ids','=', c.id)])
            if etapas_asociadas:
                etapas_asociadas = sorted(etapas_asociadas, key=itemgetter('fecha_planeada_fin'), reverse=True)
            etapas_asociadas_datos = []
            contratos_etapa = []
            contrato_obra = ''
            # estado_contrato = ''
            primer_contrato = False
            primero = True
            etapas_nombres = ''
            etapas_nombres = ' - '.join([e.tipo_id.name for e in etapas_asociadas])
            for etapa in etapas_asociadas:
                etapas_asociadas_datos.append({
                    'name': etapa.tipo_id.name,
                    'fecha_inicio': etapa.fecha_planeada_inicio,
                    'fecha_fin': etapa.fecha_planeada_fin,
                })
                for contrato in etapa.contrato_ids:
                    if primero:
                        primer_contrato = contrato
                        primero = False
                    contratos_etapa.append(contrato.numero)
                    if contrato.siac_tipo_contrato_id.name == 'Contrato de Obra':
                        contrato_obra = contrato.numero
                        # estado_contrato = contrato.estado_siac_id.name
                        continue
            # contratos = list(set(contratos))
            if (not contrato_obra) and contratos_etapa:
                 contrato_obra = primer_contrato.numero
                 # estado_contrato = primer_contrato.estado_siac_id.name
            res.append({
                "name": c.numero,
                "contratos": ' '.join(contratos_etapa).lower(),
                "origen": '-',
                "alcance": c.objeto or "*** No hay obeto de contrato ***",
                "etapa_actual": etapas_asociadas_datos,
                "etapas_nombres": etapas_nombres,
                "slug": slug(c),
                'url_imagen': url_imagen_contrato(c),     #'/website_project_publico_idu/static/src/images/obra_1.jpg',
                'even': int(position % 2 == 1),
                'contrato': contrato_obra,
                'estado_contrato': c.estado_siac_id.name,     #.state,     # estado_contrato,
                'descripcion': c.descripcion,
                # 'filtro_estado' : 'con etapas relacionadas',       # estado,
            })
        # estados_list = ['borrador', 'en_ejecucion', 'suspendido', 'terminado']
        estados_list = contratos.mapped('estado_siac_id.name')
        datos['contratos_json'] = json.dumps(res)
        datos['etapas_json'] = json.dumps(etapas_list)
        datos['origenes_json'] = json.dumps(origenes_list)
        datos['estados_json'] = json.dumps(estados_list)
        datos['nombre_etapas'] = etapas_list
        datos['nombre_origenes'] = origenes_list
        return request.website.render(
            "website_project_publico_idu.contratos_obra_index",
            datos,
        )

    @http.route([
        '/zipa/contratos_obra/<model("contrato.contrato"):contrato>',
        # '/zipa/contratos_obra/<any(en_ejecucion, terminado):estado>/<model("contrato.contrato"):contrato>'
        ], type='http', auth="user", website=True)
    def contratos_obra_show(self, contrato=None, **kwargs):     # estado='en_ejecucion',
        # if contrato.state not in ['en_ejecucion']:
        #     return werkzeug.exceptions.NotFound('Contrato no encontrado')
        problemas_estados = ['nuevo', 'cerrado']
        hay_videos = False
        # for photo in contrato.photo_ids:
        #     if photo.url:
        #         hay_videos = True
        ultimo_informe = kwargs.get('ultimo_informe')
        datos = {
            'title': contrato.numero,
            'additional_title': 'Resumen Ejecutivo',
            'contrato': contrato,
            'problemas_estados': problemas_estados,
            'problemas_estados_labels': PROBLEMA_ESTADOS_LABELS,
            'es_usuario_externo': request.env.user.has_group('base.group_public'),
            'hay_videos': hay_videos,
            'additional_title_breadcrumb': 'CONTRATOS',      # self.mapping_estado[estado]['breadcrumb'],
            # 'filtro_estado': estado,
            'ultimo_informe': ultimo_informe,
            'APROBACION_INTERVENTORIA_LABELS': APROBACION_INTERVENTORIA_LABELS,
            'NO_OBJECION_IDU_LABELS': NO_OBJECION_IDU_LABELS,
        }
        datos.update(self.get_detalle_contrato(contrato, problemas_estados, ultimo_informe))
        return request.website.render(
            "website_project_publico_idu.contratos_obra_show",
            datos,
        )
#################################################################################################################




    def get_informacion_tramites_proyecto(self, proyecto_id):
        tramite_model = request.env['tramite.tramite'].sudo()
        tramite_ids = tramite_model.search([('proyecto_id', '=', proyecto_id)])
        tramites = {'titulos':('Id', 'Trámite / Producto', 'Etapa del Proyecto', 'Fecha Estimada de Aprobación', 'Estado del Trámite', 'Descripción')}
        tramites['datos'] = []
        for tramite in tramite_ids:
            tramites['datos'].append((tramite.id, tramite.tipo_id.name, tramite.etapa_id.name, datetime.strptime(tramite.fecha_estimada, '%Y-%m-%d').strftime('%d/%m/%Y'), obtener_etiqueta_lista_select(TRAMITE_STATES, tramite.state), tramite.descripcion))
        return tramites

    def get_etapas_abiertas_agrupadas(self, etapas_abiertas):
        contratos = []
        etapas_abiertas_agrupadas = []
        etapas_name = []
        contador_etapas = 0
        for etapa_abierta in etapas_abiertas:
            contrato = etapa_abierta.contrato_ids.ids
            if len(contrato) > 0:
                if contrato in contratos:
                    etapas_name[contador_etapas - 1] = etapas_name[contador_etapas - 1] + ', ' + etapa_abierta.name.replace('Etapa: ', '')
                else:
                    etapas_name.append(etapa_abierta.name.replace('Etapa: ', ''))
                    etapas_abiertas_agrupadas.append(etapa_abierta)
                    contratos.append(contrato)
                    contador_etapas += 1
        return {
            'etapas_abiertas_agrupadas': etapas_abiertas_agrupadas,
            'etapas_name': etapas_name,
            }

    def get_info_contratos_etapas_names(self, etapas):
        contratos = etapas.mapped('contrato_ids')
        lista_contratos = []
        for contrato in contratos:
            etapas = request.env['project_obra.proyecto.etapa'].search([('contrato_ids','=',contrato.id)])
            contrato.etapas_names = ' - '.join([e.tipo_id.name for e in etapas])
            lista_contratos.append(contrato)

        return lista_contratos


    def get_datos_gestion_rcd_magcr(self, contrato_id):
        control_model = request.env['aprovechamiento_material.control'].sudo()
        controles = control_model.search([('contrato_id', '=', contrato_id), ('informe_ids.state', '=', 'terminado')])
        control = controles[0] if controles else None
        datos = {}
        if control:
            informes = control.informe_ids.filtered(lambda i: i.state == 'terminado')
            if informes:
                ultimo_informe = informes.sorted(key=lambda i: i.num_informe, reverse=True)[0] if informes else None
                if ultimo_informe:
                    datos['p_ofertado_rcd'] = control.p_orfertado_rcd
                    datos['p_ofertado_magcr'] = control.p_orfertado_magcr
                    datos['vol_total_rcd_acumulado'] = ultimo_informe.vol_total_rcd_acumulado
                    datos['vol_acumulado_rcd'] = ultimo_informe.vol_acumulado_rcd
                    datos['p_cumplimiento_fecha_rcd'] = ultimo_informe.p_cumplimiento_fecha_rcd
                    datos['vol_total_asfalto_instalado'] = ultimo_informe.vol_total_asfalto_instalado
                    datos['vol_certificado_acumulado_magcr'] = ultimo_informe.vol_certificado_acumulado_magcr
                    datos['p_cumplimiento_fecha_magcr'] = ultimo_informe.p_cumplimiento_fecha_magcr
                    datos['informes'] = []
                    for informe in informes :
                        datos['informes'].append({
                            'fecha_fin' : informe.fecha_fin,
                            'num_informe':informe.num_informe,
                            'vol_total_rcd_acumulado':informe.vol_total_rcd_acumulado,
                            'vol_acumulado_rcd':informe.vol_acumulado_rcd,
                            'vol_dif_generado_acumulado':informe.vol_total_rcd_acumulado - informe.vol_acumulado_rcd,
                            'p_cumplimiento_fecha_rcd':informe.p_cumplimiento_fecha_rcd,
                            'vol_total_asfalto_instalado':informe.vol_total_asfalto_instalado,
                            'vol_certificado_acumulado_magcr':informe.vol_certificado_acumulado_magcr,
                            'p_cumplimiento_fecha_magcr':informe.p_cumplimiento_fecha_magcr,
                            })
        return datos

    def generar_valores_linea(self, lista_datos, x, y, nombre_linea, color=None):
        grafica = {}
        if lista_datos :
            grafica['values'] = []
            for dato in lista_datos:
                if x in dato and y in dato:
                    grafica['values'].append(
                        {'x':dato[x],
                         'y':dato[y],
                        })
            grafica['key'] = nombre_linea,
            if color:
                grafica['color'] = color
        return grafica

    def get_datos_grafica_rcd_magcr(self, datos):
        datos_grafica = []
        if datos and 'informes' in datos:
            datos_grafica.append(self.generar_valores_linea(datos['informes'], 'fecha_fin', 'vol_total_rcd_acumulado', 'Volumen de RCD Generado'))
            datos_grafica.append(self.generar_valores_linea(datos['informes'], 'fecha_fin', 'vol_acumulado_rcd', 'Volumen de RCD Aprovechado'))
            datos_grafica.append(self.generar_valores_linea(datos['informes'], 'fecha_fin', 'vol_dif_generado_acumulado', 'Volumen de RCD Disposición Final'))
            datos_grafica.append(self.generar_valores_linea(datos['informes'], 'fecha_fin', 'vol_certificado_acumulado_magcr', 'Volumen Certificado Acumulado MAGCR'))
        return json.dumps(datos_grafica)

    def get_detalle_proyecto(self, proyecto, problemas_estados, estado, ultimo_informe=None):
        datos = {}
        punto_idu_model = request.env['pqrs.punto_atencion_ciudadano'].sudo()
        fecha_ini = request.env['ir.config_parameter'].sudo().get_param('project.tablero.fecha_corte_ini')
        fecha_fin = request.env['ir.config_parameter'].sudo().get_param('project.tablero.fecha_corte_fin')
        datos['etapas_abiertas'] = proyecto.etapa_ids.filtered(lambda r: r.parent_id.id == False and r.state in self.mapping_estado[estado]['filtro_etapas_actuales'])
        datos['contrato'] = False
        if datos['etapas_abiertas'] and datos['etapas_abiertas'][0].contrato_ids:
            #Si el contrato a seleccionar es de tipo Convenio Interadministrativo se selecciona el siguiente
            if datos['etapas_abiertas'][0].contrato_ids[0].siac_tipo_contrato_id.name == "Convenio Interadministrativo" and len(datos['etapas_abiertas'][0].contrato_ids) > 1:
                datos['contrato'] = datos['etapas_abiertas'][0].contrato_ids[1]
            else:
                datos['contrato'] = datos['etapas_abiertas'][0].contrato_ids[0]
            datos['valor_total_contrato'] = datos['etapas_abiertas'][0].contrato_ids[0].valor_total

        etapas_abiertas_agrupadas_y_etapas_name = self.get_etapas_abiertas_agrupadas(datos['etapas_abiertas'])
        datos['etapas_abiertas_agrupadas'] = etapas_abiertas_agrupadas_y_etapas_name['etapas_abiertas_agrupadas']
        datos['etapas_name'] = etapas_abiertas_agrupadas_y_etapas_name['etapas_name']

        datos['informacion_financiera'] = {}
        datos['informacion_anticipos'] = {}
        anticipo = ''
        datos['puntos_idu'] = punto_idu_model.browse()
        datos['puntos_idu_json'] = "[]"
        for e in datos['etapas_abiertas']:
            if len(e.contrato_ids):
                numero_contrato_obra = e.contrato_ids[0].numero
                puntos_idu = punto_idu_model.search([('contrato_id.numero', '=', numero_contrato_obra)])
                datos['puntos_idu'] = puntos_idu
                puntos_idu_list = []
                for punto_idu in puntos_idu:
                    puntos_idu_list.append(punto_idu.id)
                    datos['puntos_idu_json'] = json.dumps(puntos_idu_list)
            for c in e.contrato_ids:
                datos['informacion_financiera'][c.numero] = c.get_pagos()
                datos['informacion_anticipos'][c.numero] = 0.0
                if c.pagos_stone_json:
                    pagos_dic = json.loads(c.pagos_stone_json)
                    resumen = pagos_dic['resumen']
                    if resumen and 'anticipo' in resumen:
                        anticipo = resumen['anticipo']
                        datos['informacion_anticipos'][c.numero] = float(anticipo) if anticipo else 0.0
        datos['informacion_financiera_json'] = json.dumps(datos['informacion_financiera'])
        datos['variaciones'] = datos['etapas_abiertas'].get_datos_desempeno_al_corte(fecha_ini, fecha_fin)
        informes_avance_informacion = []
        estados_actuales = []
        informe_cabecera_anterior = False
        datos['informe_cabecera'] = False
        informe_avance_sgdu_primero = False
        informes_cabecera_mixtos = []
        datos['fecha_actualizacion'] = ''
        model_informe_avance_construccion = request.env['project_obra.construccion.informe_avance'].sudo()
        model_informe_avance_conservacion = request.env['project_obra.conservacion.informe_avance'].sudo()
        informes_avance_construccion = []
        informes_avance_conservacion = []
        if datos['contrato']:
            informes_avance_construccion = model_informe_avance_construccion.search([('contrato_id','=',datos['contrato'].id),('state','=','publicado'),('etapa_actual_id.state','=','open')], order = 'periodo_fecha_inicio desc')
            informes_avance_conservacion = model_informe_avance_conservacion.search([('contrato_id','=',datos['contrato'].id),('state','=','publicado'),('etapa_actual_id.state','=','open')], order = 'periodo_fecha_inicio desc')
        estados_actuales = []
        informe = False
        informes = []
        informe_anterior = False
        if len(informes_avance_construccion)>0:
            informes = informes_avance_construccion
            informe = informes_avance_construccion[0]
            if len(informes_avance_construccion)>1:
                informe_anterior = informes_avance_construccion[0]
        elif len(informes_avance_conservacion)>0:
            informes = informes_avance_conservacion
            informe = informes_avance_conservacion[0]
            if len(informes_avance_conservacion)>1:
                informe_anterior = informes_avance_conservacion[0]

        if informe_anterior:
            informe_cabecera_anterior = informe_anterior.cabecera_id
            datos['descripcion_estado_general_proyecto'] = informe_anterior.descripcion_estado_general_proyecto 
        if informe:
            datos['informe_cabecera'] = informe.cabecera_id

        for etapa in datos['etapas_abiertas']:
            fecha_inicio_string = ''
            fecha_fin_string = ''
            if informe and informe.contrato_id and informe.contrato_id.fecha_inicio:
                fecha_inicio_datetime = datetime.strptime(informe.contrato_id.fecha_inicio, '%Y-%m-%d')
                fecha_inicio_string = fecha_inicio_datetime.strftime('%d/%m/%Y')
            if informe and informe.contrato_id and informe.contrato_id.fecha_fin_proyectada:
                fecha_fin_datetime = datetime.strptime(informe.contrato_id.fecha_fin_proyectada, '%Y-%m-%d')
                fecha_fin_string = fecha_fin_datetime.strftime('%d/%m/%Y')
            if informe and informe.etapa_actual_id and (etapa.id == informe.etapa_actual_id.id) or informe and len(datos['etapas_abiertas'])==1:
                programado = informe.programado_porcentaje_avance_fisico_acumulado
                ejecutado = informe.ejecutado_porcentaje_avance_fisico_acumulado
                variacion = ejecutado - programado
                programado = ("%.2f" % programado)
                ejecutado = ("%.2f" % ejecutado)
                ultima_variacion = ''
                if informe_anterior:
                    ultima_variacion = informe_anterior.ejecutado_porcentaje_avance_fisico_acumulado - informe_anterior.programado_porcentaje_avance_fisico_acumulado
                estados_actuales.append({
                    'etapa': etapa.name,
                    'fecha_inicio': fecha_inicio_string,
                    'fecha_fin': fecha_fin_string,
                    'programado': programado,
                    'ejecutado': ejecutado,
                    'variacion' : variacion,
                    'ultima_variacion' : ultima_variacion,
                })

        informes_cabecera_mixtos = []

        for informe in informes:
            programado = informe.programado_porcentaje_avance_fisico_acumulado
            ejecutado = informe.ejecutado_porcentaje_avance_fisico_acumulado

            informes_avance_informacion.append({
                'id' : informe.id,
                'fecha' : informe.cabecera_id.fecha,
                'programado' : programado,
                'ejecutado' : ejecutado
            })

            if len(informe.cabecera_id.informe_etapa_ids):
                    informes_cabecera_mixtos.append(self.get_informes_etapa_mixtos(informe.cabecera_id))

            if datos['fecha_actualizacion'] == '':
                datos['fecha_actualizacion'] = informe.cabecera_id.periodo_fecha_fin
            elif informe.cabecera_id.periodo_fecha_fin > datos['fecha_actualizacion']:
                datos['fecha_actualizacion'] = informe.cabecera_id.periodo_fecha_fin

        informes_etapa = []
        datos['informe_por_frentes'] = []
        datos['informe_conservacion'] = False
        datos['resumen_cronograma'] = False

        if datos['informe_cabecera']:

            informes_etapa = self.get_informe_etapa(datos['informe_cabecera'].informe_etapa_ids, informe_cabecera_anterior)
            if (len(datos['informe_cabecera'].informe_mpp_ids) > 0) and (len(datos['informe_cabecera'].informe_mpp_ids.linea_frente_ids) > 0):
                datos['informe_por_frentes'] = datos['informe_cabecera'].informe_mpp_ids.linea_frente_ids
            else:
                # Buscar informe conservacion relacionado a la cabecera id
                informe_conservacion = request.env['project_obra.conservacion.informe_avance'].sudo().search([('cabecera_id', '=', datos['informe_cabecera'].id), ('state', '=', 'publicado')], order='fecha ASC')
                if informe_conservacion:
                    datos['informe_por_frentes'] = []  # establece list ya que se asignó arriba como recordlist .informe_mpp_ids.linea_frente_ids
                    # crear objeto para entregar los datos para que sean usables por el template
                    datos['informe_conservacion'] = True
                    datos['informe_por_frentes'] = self.get_informe_por_frentes(informe_conservacion.avance_por_frente_ids)
                elif informe_avance_sgdu_primero:
                    datos['resumen_cronograma'] = self.get_resumen_cronograma(informe_avance_sgdu_primero.avance_por_componente_ids)
        datos['estados_actuales_mixtos'] = informes_etapa
        datos['estados_actuales'] = estados_actuales
        datos['informes_cabecera_mixtos_json'] = json.dumps(informes_cabecera_mixtos)
        informes_avance_informacion.sort(key=lambda x: x['fecha'], reverse=True)
        datos['informes_avance_informacion_json'] = json.dumps(informes_avance_informacion)

        if estado == 'terminado' and not ultimo_informe:
            datos['consolidado_problemas_por_tipo_vs_estado'] = proyecto.project_id.get_consolidado_problemas_por_tipo_vs_estado(estados=problemas_estados, liquidacion=True)
        else:
            datos['consolidado_problemas_por_tipo_vs_estado'] = proyecto.project_id.get_consolidado_problemas_por_tipo_vs_estado(estados=problemas_estados)
        if ((proyecto.indicador_predios_requeridos or proyecto.indicador_predios_entregados or proyecto.indicador_predios_disponibles) or
            (proyecto.indicador_predios_valor_estimado or proyecto.indicador_predios_valor_ejecutado or proyecto.indicador_predios_valor_girado)
        ):
            hay_datos_predios = True
        else:
            hay_datos_predios = False
        datos['informe_predial'] = hay_datos_predios
        # Datos de detalles de predios del proyecto
        informe_model = request.env['project_obra.predios.informe_avance'].sudo()
        detalle_informe_predio_model = request.env['project_obra.predios.informe_avance.detalle_predio'].sudo()
        # ultimo informe
        informe_id = informe_model.search([])
        if informe_id: informe_id = informe_id[-1].id
        detalles_predios_requeridos = detalle_informe_predio_model.search([('project_obra_predios_informe_avance_id', '=', informe_id), ('proyecto_id', '=', proyecto.id)]) if informe_id else []
        detalles_predios_entregados = detalle_informe_predio_model.search([('project_obra_predios_informe_avance_id', '=', informe_id), ('proyecto_id', '=', proyecto.id), ('categoria_id.name', '=', 'ENTREGADO AL CONTRATISTA')]) if informe_id else []
        detalles_predios_pendientes = detalle_informe_predio_model.search([('project_obra_predios_informe_avance_id', '=', informe_id), ('proyecto_id', '=', proyecto.id), ('categoria_id.name', '=', 'PENDIENTE')]) if informe_id else []
        detalles_predios_disponibles = detalle_informe_predio_model.search([('project_obra_predios_informe_avance_id', '=', informe_id), ('proyecto_id', '=', proyecto.id), ('categoria_id.name', '=', 'DISPONIBLE')]) if informe_id else []
        datos['detalles_predios_requeridos'] = detalles_predios_requeridos
        datos['detalles_predios_disponibles'] = detalles_predios_disponibles
        datos['detalles_predios_entregados'] = detalles_predios_entregados
        datos['detalles_predios_pendientes'] = detalles_predios_pendientes
        # Datos de integrantes del proyecto
        datos['integrantes'] = False
        gestiones = False
        datos['actividades'] = []
        datos['contrato_obra'] = False
        if len(datos['etapas_abiertas']) and len(datos['etapas_abiertas'][0].contrato_ids) > 0:
            datos['contrato_obra'] = datos['etapas_abiertas'][0].contrato_ids[0].id
            if estado == 'terminado' and not ultimo_informe:
                datos['actividades'] = self.get_actividades(datos['contrato_obra'])
                gestiones = self.get_ultima_fecha_gestion(datos['contrato_obra'])[0]
                if len(gestiones):
                    datos['fecha_actualizacion'] = self.get_ultima_fecha_gestion(datos['contrato_obra'])[0][0].mail_message_id.create_date
            datos['integrantes'] = get_coordinadores_order(datos['etapas_abiertas'][0].contrato_ids[0].coordinador_ids)
            datos['ids_integrantes'] = datos['etapas_abiertas'][0].contrato_ids[0].coordinador_ids
        # Formato fecha de actualización proyecto
        if datos['fecha_actualizacion']:
            if estado == 'terminado' and not ultimo_informe and gestiones:
                fecha_object = datetime.strptime(datos['fecha_actualizacion'], '%Y-%m-%d %H:%M:%S')
            else:
                fecha_object = datetime.strptime(datos['fecha_actualizacion'], '%Y-%m-%d')
            datos['fecha_actualizacion'] = fecha_object.strftime('%d/%m/%Y')
        datos['tramites'] = self.get_informacion_tramites_proyecto(proyecto.id)
        # Informacion Modulo Aprovechamiento de Materiales y RCD
        datos['gestion_rcd_magcr_tabla'] = self.get_datos_gestion_rcd_magcr(datos['contrato_obra'] if 'contrato_obra' in datos else 0)
        datos['gestion_rcd_magcr_grafica'] = self.get_datos_grafica_rcd_magcr(datos['gestion_rcd_magcr_tabla'])
        datos['enlace_encuesta_otc'] = proyecto.enlace_encuesta_otc
        datos['imagenes_avance'] = self.get_imagenes_avance(datos['contrato_obra'])
        return datos



    def get_detalle_contrato(self, contrato, problemas_estados, ultimo_informe=None):
        datos = {}
        punto_idu_model = request.env['pqrs.punto_atencion_ciudadano'].sudo()
        fecha_ini = request.env['ir.config_parameter'].sudo().get_param('project.tablero.fecha_corte_ini')
        fecha_fin = request.env['ir.config_parameter'].sudo().get_param('project.tablero.fecha_corte_fin')
        # datos['etapas_abiertas'] = proyecto.etapa_ids.filtered(lambda r: r.parent_id.id == False and r.state in self.mapping_estado[estado]['filtro_etapas_actuales'])
        datos['etapas_abiertas'] = request.env['project_obra.proyecto.etapa'].search([('contrato_ids','=',contrato.id)])


        # if datos['etapas_abiertas'] and datos['etapas_abiertas'][0].contrato_ids:
        #     datos['contrato'] = datos['etapas_abiertas'][0].contrato_ids[0]
        #     datos['valor_total_contrato'] = datos['etapas_abiertas'][0].contrato_ids[0].valor_total
        datos['contrato'] = contrato
        datos['valor_total_contrato'] = contrato.valor_total

        etapas_abiertas_agrupadas_y_etapas_name = self.get_etapas_abiertas_agrupadas(datos['etapas_abiertas'])
        datos['info_contratos_etapas_name'] = self.get_info_contratos_etapas_names(datos['etapas_abiertas'])
        datos['etapas_abiertas_agrupadas'] = etapas_abiertas_agrupadas_y_etapas_name['etapas_abiertas_agrupadas']
        datos['etapas_name'] = etapas_abiertas_agrupadas_y_etapas_name['etapas_name']

        datos['informacion_financiera'] = {}
        datos['informacion_anticipos'] = {}
        anticipo = ''
        datos['puntos_idu'] = punto_idu_model.browse()
        datos['puntos_idu_json'] = "[]"
        for e in datos['etapas_abiertas']:
            if len(e.contrato_ids):
                numero_contrato_obra = e.contrato_ids[0].numero
                puntos_idu = punto_idu_model.search([('contrato_id.numero', '=', numero_contrato_obra)])
                datos['puntos_idu'] = puntos_idu
                puntos_idu_list = []
                for punto_idu in puntos_idu:
                    puntos_idu_list.append(punto_idu.id)
                    datos['puntos_idu_json'] = json.dumps(puntos_idu_list)
            for c in e.contrato_ids:
                datos['informacion_financiera'][c.numero] = c.get_pagos()
                datos['informacion_anticipos'][c.numero] = 0.0
                if c.pagos_stone_json:
                    pagos_dic = json.loads(c.pagos_stone_json)
                    resumen = pagos_dic['resumen']
                    if resumen and 'anticipo' in resumen:
                        anticipo = resumen['anticipo']
                        datos['informacion_anticipos'][c.numero] = float(anticipo) if anticipo else 0.0
        datos['informacion_financiera_json'] = json.dumps(datos['informacion_financiera'])
        datos['variaciones'] = datos['etapas_abiertas'].get_datos_desempeno_al_corte(fecha_ini, fecha_fin)
        informes_avance_informacion = []
        estados_actuales = []
        informe_cabecera_anterior = False
        datos['informe_cabecera'] = False
        informe_avance_sgdu_primero = False
        informes_cabecera_mixtos = []
        datos['fecha_actualizacion'] = ''
        model_informe_avance_construccion = request.env['project_obra.construccion.informe_avance'].sudo()
        model_informe_avance_conservacion = request.env['project_obra.conservacion.informe_avance'].sudo()
        informes_avance_construccion = []
        informes_avance_conservacion = []
        if datos['contrato']:
            informes_avance_construccion = model_informe_avance_construccion.search([('contrato_id','=',datos['contrato'].id),('state','=','publicado'),('etapa_actual_id.state','=','open')])
            informes_avance_conservacion = model_informe_avance_conservacion.search([('contrato_id','=',datos['contrato'].id),('state','=','publicado'),('etapa_actual_id.state','=','open')])
        estados_actuales = []
        informe = False
        informes = []
        informe_anterior = False
        if len(informes_avance_construccion)>0:
            informes = informes_avance_construccion
            informe = informes_avance_construccion[0]
            if len(informes_avance_construccion)>1:
                informe_anterior = informes_avance_construccion[0]
        elif len(informes_avance_conservacion)>0:
            informes = informes_avance_conservacion
            informe = informes_avance_conservacion[0]
            if len(informes_avance_conservacion)>1:
                informe_anterior = informes_avance_conservacion[0]

        if informe_anterior:
            informe_cabecera_anterior = informe_anterior.cabecera_id
        if informe:
            datos['informe_cabecera'] = informe.cabecera_id

        for etapa in datos['etapas_abiertas']:
            fecha_inicio_string = ''
            fecha_fin_string = ''
            if informe and informe.contrato_id and informe.contrato_id.fecha_inicio:
                fecha_inicio_datetime = datetime.strptime(informe.contrato_id.fecha_inicio, '%Y-%m-%d')
                fecha_inicio_string = fecha_inicio_datetime.strftime('%d/%m/%Y')
            if informe and informe.contrato_id and informe.contrato_id.fecha_fin_proyectada:
                fecha_fin_datetime = datetime.strptime(informe.contrato_id.fecha_fin_proyectada, '%Y-%m-%d')
                fecha_fin_string = fecha_fin_datetime.strftime('%d/%m/%Y')
            if informe and informe.etapa_actual_id and (etapa.id == informe.etapa_actual_id.id) or informe and len(datos['etapas_abiertas'])==1:
                programado = informe.programado_porcentaje_avance_fisico_acumulado
                ejecutado = informe.ejecutado_porcentaje_avance_fisico_acumulado
                variacion = ejecutado - programado
                programado = ("%.2f" % programado)
                ejecutado = ("%.2f" % ejecutado)
                ultima_variacion = ''
                if informe_anterior:
                    ultima_variacion = informe_anterior.ejecutado_porcentaje_avance_fisico_acumulado - informe_anterior.programado_porcentaje_avance_fisico_acumulado
                estados_actuales.append({
                    'etapa': etapa.name,
                    'fecha_inicio': fecha_inicio_string,
                    'fecha_fin': fecha_fin_string,
                    'programado': programado,
                    'ejecutado': ejecutado,
                    'variacion' : variacion,
                    'ultima_variacion' : ultima_variacion,
                })

        informes_cabecera_mixtos = []

        for informe in informes:
            programado = informe.programado_porcentaje_avance_fisico_acumulado
            ejecutado = informe.ejecutado_porcentaje_avance_fisico_acumulado

            informes_avance_informacion.append({
                'id' : informe.id,
                'fecha' : informe.cabecera_id.fecha,
                'programado' : programado,
                'ejecutado' : ejecutado
            })

            if len(informe.cabecera_id.informe_etapa_ids):
                    informes_cabecera_mixtos.append(self.get_informes_etapa_mixtos(informe.cabecera_id))

            if datos['fecha_actualizacion'] == '':
                datos['fecha_actualizacion'] = informe.cabecera_id.periodo_fecha_fin
            elif informe.cabecera_id.periodo_fecha_fin > datos['fecha_actualizacion']:
                datos['fecha_actualizacion'] = informe.cabecera_id.periodo_fecha_fin

        informes_etapa = []
        datos['informe_por_frentes'] = []
        datos['informe_conservacion'] = False
        datos['resumen_cronograma'] = False

        if datos['informe_cabecera']:

            informes_etapa = self.get_informe_etapa(datos['informe_cabecera'].informe_etapa_ids, informe_cabecera_anterior)
            if (len(datos['informe_cabecera'].informe_mpp_ids) > 0) and (len(datos['informe_cabecera'].informe_mpp_ids.linea_frente_ids) > 0):
                datos['informe_por_frentes'] = datos['informe_cabecera'].informe_mpp_ids.linea_frente_ids
            else:
                # Buscar informe conservacion relacionado a la cabecera id
                informe_conservacion = request.env['project_obra.conservacion.informe_avance'].sudo().search([('cabecera_id', '=', datos['informe_cabecera'].id), ('state', '=', 'publicado')], order='fecha ASC')
                if informe_conservacion:
                    datos['informe_por_frentes'] = []  # establece list ya que se asignó arriba como recordlist .informe_mpp_ids.linea_frente_ids
                    # crear objeto para entregar los datos para que sean usables por el template
                    datos['informe_conservacion'] = True
                    datos['informe_por_frentes'] = self.get_informe_por_frentes(informe_conservacion.avance_por_frente_ids)
                elif informe_avance_sgdu_primero:
                    datos['resumen_cronograma'] = self.get_resumen_cronograma(informe_avance_sgdu_primero.avance_por_componente_ids)
        datos['estados_actuales_mixtos'] = informes_etapa
        datos['estados_actuales'] = estados_actuales
        datos['informes_cabecera_mixtos_json'] = json.dumps(informes_cabecera_mixtos)
        informes_avance_informacion.sort(key=lambda x: x['fecha'], reverse=True)
        datos['informes_avance_informacion_json'] = json.dumps(informes_avance_informacion)

        # if estado == 'terminado' and not ultimo_informe:
        #     datos['consolidado_problemas_por_tipo_vs_estado'] = proyecto.project_id.get_consolidado_problemas_por_tipo_vs_estado(estados=problemas_estados, liquidacion=True)
        # else:
        #     datos['consolidado_problemas_por_tipo_vs_estado'] = proyecto.project_id.get_consolidado_problemas_por_tipo_vs_estado(estados=problemas_estados)
        # if ((proyecto.indicador_predios_requeridos or proyecto.indicador_predios_entregados or proyecto.indicador_predios_disponibles) or
        #     (proyecto.indicador_predios_valor_estimado or proyecto.indicador_predios_valor_ejecutado or proyecto.indicador_predios_valor_girado)
        # ):
        #     hay_datos_predios = True
        # else:
        #     hay_datos_predios = False
        hay_datos_predios = False
        datos['informe_predial'] = hay_datos_predios
        # Datos de detalles de predios del proyecto
        informe_model = request.env['project_obra.predios.informe_avance'].sudo()
        # detalle_informe_predio_model = request.env['project_obra.predios.informe_avance.detalle_predio'].sudo()
        # ultimo informe
        informe_id = informe_model.search([])
        if informe_id: informe_id = informe_id[-1].id
        # detalles_predios_requeridos = detalle_informe_predio_model.search([('project_obra_predios_informe_avance_id', '=', informe_id), ('proyecto_id', '=', proyecto.id)]) if informe_id else []
        # detalles_predios_entregados = detalle_informe_predio_model.search([('project_obra_predios_informe_avance_id', '=', informe_id), ('proyecto_id', '=', proyecto.id), ('categoria_id.name', '=', 'ENTREGADO AL CONTRATISTA')]) if informe_id else []
        # detalles_predios_pendientes = detalle_informe_predio_model.search([('project_obra_predios_informe_avance_id', '=', informe_id), ('proyecto_id', '=', proyecto.id), ('categoria_id.name', '=', 'PENDIENTE')]) if informe_id else []
        # detalles_predios_disponibles = detalle_informe_predio_model.search([('project_obra_predios_informe_avance_id', '=', informe_id), ('proyecto_id', '=', proyecto.id), ('categoria_id.name', '=', 'DISPONIBLE')]) if informe_id else []
        # datos['detalles_predios_requeridos'] = detalles_predios_requeridos
        # datos['detalles_predios_disponibles'] = detalles_predios_disponibles
        # datos['detalles_predios_entregados'] = detalles_predios_entregados
        # datos['detalles_predios_pendientes'] = detalles_predios_pendientes
        # Datos de integrantes del proyecto
        datos['integrantes'] = False
        gestiones = False
        datos['actividades'] = []
        datos['contrato_obra'] = False
        if len(datos['etapas_abiertas']) and len(datos['etapas_abiertas'][0].contrato_ids) > 0:
            datos['contrato_obra'] = datos['etapas_abiertas'][0].contrato_ids[0].id
            if not ultimo_informe:
                datos['actividades'] = self.get_actividades(datos['contrato_obra'])
                gestiones = self.get_ultima_fecha_gestion(datos['contrato_obra'])[0]
                if len(gestiones):
                    datos['fecha_actualizacion'] = self.get_ultima_fecha_gestion(datos['contrato_obra'])[0][0].mail_message_id.create_date
            datos['integrantes'] = get_coordinadores_order(datos['etapas_abiertas'][0].contrato_ids[0].coordinador_ids)
            datos['ids_integrantes'] = datos['etapas_abiertas'][0].contrato_ids[0].coordinador_ids
        # Formato fecha de actualización proyecto
        if datos['fecha_actualizacion']:
            if not ultimo_informe and gestiones:
                fecha_object = datetime.strptime(datos['fecha_actualizacion'], '%Y-%m-%d %H:%M:%S')
            else:
                fecha_object = datetime.strptime(datos['fecha_actualizacion'], '%Y-%m-%d')
            datos['fecha_actualizacion'] = fecha_object.strftime('%d/%m/%Y')
        datos['tramites'] = []    #self.get_informacion_tramites_proyecto(proyecto.id)
        # Informacion Modulo Aprovechamiento de Materiales y RCD
        datos['gestion_rcd_magcr_tabla'] = self.get_datos_gestion_rcd_magcr(datos['contrato_obra'] if 'contrato_obra' in datos else 0)
        datos['gestion_rcd_magcr_grafica'] = self.get_datos_grafica_rcd_magcr(datos['gestion_rcd_magcr_tabla'])
        datos['enlace_encuesta_otc'] = ''    #proyecto.enlace_encuesta_otc
        datos['imagenes_avance'] = self.get_imagenes_avance(datos['contrato_obra'])
        return datos




    def get_informes_etapa_mixtos(self, informe_cabecera_etapa):
        informes_etapas = []
        for informe_etapa in informe_cabecera_etapa.informe_etapa_ids:
            informes_etapas.append({
                'id': informe_etapa.id,
                'name': informe_etapa.etapa_actual_id.name,
                'fecha': informe_cabecera_etapa.fecha,
                'programado' : informe_etapa.programado_porcentaje_avance_fisico_acumulado,
                'ejecutado' : informe_etapa.ejecutado_porcentaje_avance_fisico_acumulado,
            })
        return informes_etapas

    def get_informe_etapa(self, informe_etapa_ids, informe_cabecera_anterior):
        informes_etapa = []
        if not informe_cabecera_anterior:
            return []
        for informe_etapa in informe_etapa_ids:
            variacion = informe_etapa.ejecutado_porcentaje_avance_fisico_acumulado - informe_etapa.programado_porcentaje_avance_fisico_acumulado
            ultima_variacion = ''
            if informe_cabecera_anterior:
                for informe_etapa_anterior in informe_cabecera_anterior.informe_etapa_ids:
                    if informe_etapa.etapa_actual_id.name == informe_etapa_anterior.etapa_actual_id.name:
                        ultima_variacion = informe_etapa_anterior.ejecutado_porcentaje_avance_fisico_acumulado - informe_etapa_anterior.programado_porcentaje_avance_fisico_acumulado
            informes_etapa.append({
                'etapa': informe_etapa.etapa_actual_id.name,
                'fecha_inicio': informe_etapa.etapa_actual_id.edt_raiz_id.fecha_planeada_inicio and datetime.strptime(informe_etapa.etapa_actual_id.edt_raiz_id.fecha_planeada_inicio, '%Y-%m-%d').strftime('%d/%m/%Y'),
                'fecha_fin': informe_etapa.etapa_actual_id.edt_raiz_id.fecha_planeada_fin and datetime.strptime(informe_etapa.etapa_actual_id.edt_raiz_id.fecha_planeada_fin, '%Y-%m-%d').strftime('%d/%m/%Y'),
                'programado': informe_etapa.programado_porcentaje_avance_fisico_acumulado,
                'ejecutado': informe_etapa.ejecutado_porcentaje_avance_fisico_acumulado,
                'variacion': variacion,
                'ultima_variacion': ultima_variacion,
            })
        return informes_etapa

    def get_informe_por_frentes(self, avance_por_frente_ids):
        informe_por_frentes = []
        for avance_frente in avance_por_frente_ids:
            aprobacion_interventoria = ''
            no_objecion_idu = ''
            if hasattr(avance_frente, 'aprobacion_interventoria'):
                aprobacion_interventoria = APROBACION_INTERVENTORIA_LABELS[avance_frente.aprobacion_interventoria]
            if hasattr(avance_frente, 'no_objecion_idu'):
                no_objecion_idu = NO_OBJECION_IDU_LABELS[avance_frente.no_objecion_idu]
            tmp = dict_dot_access({
                'porcentaje_programado': avance_frente.programado_porcentaje_fisico,
                'porcentaje_ejecutado': avance_frente.ejecutado_porcentaje_fisico,
                'porcentaje_variacion': avance_frente.ejecutado_porcentaje_fisico - avance_frente.programado_porcentaje_fisico,
                'aprobacion_interventoria' : aprobacion_interventoria,
                'no_objecion_idu' : no_objecion_idu,
                'frente_id': avance_frente.frente_id,
                'tipo_elemento_name': avance_frente.tipo_elemento_id.name,
                'id': avance_frente.id,
            })
            informe_por_frentes.append(tmp)
        return informe_por_frentes

    def get_resumen_cronograma(self, avance_por_componente_ids):
        resumen_cronograma = []
        novedades_model = request.env['project.problema'].sudo()
        for componente in avance_por_componente_ids:
            id_frente = componente.componente_id.id
            novedades = novedades_model.search([('frente_obra_ids', 'in', id_frente)])
            resumen_cronograma.append({
                'id' : id_frente,
                'name' : componente.componente_id.name,
                'programado' : componente.programado_porcentaje_fisico,
                'ejecutado' : componente.ejecutado_porcentaje_fisico,
                'variacion' : componente.ejecutado_porcentaje_fisico - componente.programado_porcentaje_fisico,
                'aprobacion_interventoria' : APROBACION_INTERVENTORIA_LABELS[componente.aprobacion_interventoria],
                'no_objecion_idu' : NO_OBJECION_IDU_LABELS[componente.no_objecion_idu],
                'novedades' : len(novedades)
            })
        return resumen_cronograma

    def get_actividades(self, contrato):
        actividad_list = []
        query = """
            SELECT
                contrato.numero AS "contrato"
                ,producto.id AS "producto_id"
                ,producto.name AS "producto"
                ,pendiente.name AS "pendiente"
                ,COUNT(CASE WHEN actividad.name <> '' THEN actividad.id END) AS "actividades"
                ,SUM(actividad.sequence) as orden
            FROM
                liquidacion_actividad AS actividad
            LEFT JOIN
                liquidacion_producto AS producto ON producto.id = actividad.producto_id
            LEFT JOIN
                liquidacion_pendiente AS pendiente ON pendiente.id = actividad.pendiente_id
            LEFT JOIN
                contrato_contrato AS contrato ON contrato.id = actividad.contrato_id
            WHERE
                actividad.contrato_id = {}
            GROUP BY
                contrato
                ,producto.id
                ,producto
                ,pendiente
            ORDER BY
                orden
                ,producto
                ,pendiente
        """.format(contrato)
        request.env.cr.execute(query)
        datos_completos = request.env.cr.fetchall()
        for dato_completo in datos_completos:
            actividad_list.append({
                    'contrato' : dato_completo[0],
                    'producto_id' : dato_completo[1],
                    'producto' : dato_completo[2],
                    'pendiente' : dato_completo[3],
                    'actividades': dato_completo[4],
                })
        return actividad_list

    def get_ultima_fecha_gestion(self, contrato_id, producto_id=False):
        actividades_model = request.env['liquidacion.actividad']
        dominio = [('contrato_id', '=', contrato_id)]
        if producto_id:
            dominio.append(('producto_id', '=', producto_id))
        actividades = actividades_model.search(dominio)
        model_mail = request.env['mail.tracking.value']
        gestiones = model_mail.search([
            ('field', '=', 'gestion'),
            ('mail_message_id.model', '=', 'liquidacion.actividad'),
            ('mail_message_id.res_id', 'in', actividades.ids),
        ], order='mail_message_id ASC')
        # ])
        return gestiones, actividades

    def get_imagenes_avance(self, contrato_id):
        model_informe_avance_construccion = request.env['project_obra.construccion.informe_avance'].sudo()
        model_informe_avance_conservacion = request.env['project_obra.conservacion.informe_avance'].sudo()
        model_informe_avance_conservacion_detalle_frente = request.env['project_obra.conservacion.informe_avance.detalle_frente'].sudo()
        informe_avance_construccion = model_informe_avance_construccion.search([('contrato_id','=',contrato_id),('state','=','publicado'),('etapa_actual_id.state','=','open')])
        informe_avance_conservacion = model_informe_avance_conservacion.search([('contrato_id','=',contrato_id),('state','=','publicado'),('etapa_actual_id.state','=','open')])
        imagenes = False
        if len(informe_avance_construccion)>0:
            imagenes = informe_avance_construccion[0].photo_ids
        elif len(informe_avance_conservacion)>0:
            informe_avance_conservacion_detalles_frente = model_informe_avance_conservacion_detalle_frente.search([('informe_id','=',informe_avance_conservacion[0].id)])
            informe_avance_conservacion_detalles_frente_id = []
            for informe_avance_conservacion_detalle_frente in informe_avance_conservacion_detalles_frente:
                informe_avance_conservacion_detalles_frente_id.append(informe_avance_conservacion_detalle_frente.id)
            photo_model = request.env['photo_gallery.photo']
            imagenes = photo_model.search([('proyecto_obra_avance_dtm_frente_id','in',informe_avance_conservacion_detalles_frente_id)])
        return imagenes

    def get_estados_actuales(self,contrato_id,etapas_actuales):
        model_informe_avance_construccion = request.env['project_obra.construccion.informe_avance'].sudo()
        model_informe_avance_conservacion = request.env['project_obra.conservacion.informe_avance'].sudo()
        informes_avance_construccion = model_informe_avance_construccion.search([('contrato_id','=',contrato_id),('state','=','publicado'),('etapa_actual_id.state','=','open')])
        informes_avance_conservacion = model_informe_avance_conservacion.search([('contrato_id','=',contrato_id),('state','=','publicado'),('etapa_actual_id.state','=','open')])
        estados_actuales = []
        informe = False
        informe_anterior = False
        if len(informes_avance_construccion)>0:
            informe = informes_avance_construccion[0]
            if len(informes_avance_construccion)>1:
                informe_anterior = informes_avance_construccion[0]
        elif len(informes_avance_conservacion)>0:
            informe = informes_avance_conservacion[0]
            if len(informes_avance_conservacion)>1:
                informe_anterior = informes_avance_conservacion[0]
        else:
            return False
        for etapa in etapas_actuales:
            fecha_inicio_string = ''
            fecha_fin_string = ''
            if informe.contrato_id.fecha_inicio:
                fecha_inicio_datetime = datetime.strptime(informe.contrato_id.fecha_inicio, '%Y-%m-%d')
                fecha_inicio_string = fecha_inicio_datetime.strftime('%d/%m/%Y')
            if informe.contrato_id.fecha_fin_proyectada:
                fecha_fin_datetime = datetime.strptime(informe.contrato_id.fecha_fin_proyectada, '%Y-%m-%d')
                fecha_fin_string = fecha_fin_datetime.strftime('%d/%m/%Y')
            if (etapa.id == informe.etapa_actual_id.id) or len(etapas_actuales)==1:
                programado = informe.programado_porcentaje_avance_fisico_acumulado
                ejecutado = informe.ejecutado_porcentaje_avance_fisico_acumulado
                variacion = ejecutado - programado
                programado = ("%.2f" % programado)
                ejecutado = ("%.2f" % ejecutado)
                if informe_anterior:
                    ultima_variacion = informe_anterior.ejecutado_porcentaje_avance_fisico_acumulado - informe_anterior.programado_porcentaje_avance_fisico_acumulado
                estados_actuales.append({
                    'etapa': etapa.name,
                    'fecha_inicio': fecha_inicio_string,
                    'fecha_fin': fecha_fin_string,
                    'programado': programado,
                    'ejecutado': ejecutado,
                    'variacion' : variacion,
                    'ultima_variacion' : ultima_variacion,
                })
            else:
                estados_actuales.append({
                    'etapa': etapa.name,
                    'fecha_inicio': fecha_inicio_string,
                    'fecha_fin': fecha_fin_string,
                    'programado': 0,
                    'ejecutado': 0,
                    'variacion' : 0,
                    'ultima_variacion' : '',
                })
        return estados_actuales

    @http.route(['/zipa/proyectos_obra/contrato_info/<model("project_obra.proyecto"):proyecto>'], type='http', auth="user", website=True)
    def proyectos_obra_contrato_info(self, proyecto, **kwargs):
        datos = {}
        estado = 'open'
        if proyecto.visibilidad == 'publico-terminado':
            estado = 'close'
        datos['etapas_abiertas'] = proyecto.etapa_ids.filtered(lambda r: r.parent_id.id == False and r.state == estado)
        contratos = [e.contrato_ids for e in datos['etapas_abiertas']]
        etapas_abiertas_agrupadas_y_etapas_name = self.get_etapas_abiertas_agrupadas(datos['etapas_abiertas'])
        datos['etapas_abiertas_agrupadas'] = etapas_abiertas_agrupadas_y_etapas_name['etapas_abiertas_agrupadas']
        datos['etapas_name'] = etapas_abiertas_agrupadas_y_etapas_name['etapas_name']

        if (len(contratos)>0) and contratos[0]:
            contrato=contratos[0]
            contrato_obra = contratos[0][0]
            contrato_interventoria = None
            if (len(contrato)==2):
                contrato_interventoria = contratos[0][1]
            sujeto_contractual = contrato_obra.sujeto_contractual_id
            # Sujeto contractual
            datos['sujetos_contractuales'] = [sujeto_contractual]
            # Adiciones y prorrogas
            adiciones = contrato_obra.adicion_ids
            datos['adiciones_contratos'] = [adiciones]
            # Mayores cantidades de obra
            mayores_cantidades = contrato_obra.mayores_cantidades_ids
            datos['mayores_cantidades'] = [mayores_cantidades]
            # Suspensiones
            suspensiones = contrato_obra.suspension_ids            
            datos['suspensiones'] = [suspensiones]
            
            # Procesos Sancinatorios - Multas
            multas = contrato_obra.multas_ids
            datos['multas_contrato'] = [multas]
            # Polizas
            polizas = contrato_obra.poliza_ids
            datos['polizas'] = [polizas]
            # CRPs
            crps = contrato_obra.crp_ids
            datos['crps'] = [crps]
            
            if contrato_interventoria!=None:
                # Sujeto contractual
                sujeto_contractual_interventoria = contrato_interventoria.sujeto_contractual_id
                datos['sujetos_contractuales'].append(sujeto_contractual_interventoria)
                # Adiciones y prorrogas
                adiciones_interventoria = contrato_interventoria.adicion_ids
                datos['adiciones_contratos'].append(adiciones_interventoria)
                # Mayores cantidades de obra
                mayores_cantidades_interventoria = contrato_interventoria.mayores_cantidades_ids
                datos['mayores_cantidades'].append(mayores_cantidades_interventoria)
                # Suspensiones
                suspensiones_interventoria = contrato_interventoria.suspension_ids
                datos['suspensiones'].append(suspensiones_interventoria)
                # Procesos Sancinatorios - Multas
                multas_interventoria = contrato_interventoria.multas_ids
                datos['multas_contrato'].append(multas_interventoria)
                # Polizas
                polizas_interventoria = contrato_interventoria.poliza_ids
                datos['polizas'].append(polizas_interventoria)
                # CRPs
                crps_interventoria = contrato_interventoria.crp_ids
                datos['crps'].append(crps_interventoria)

        return request.website.render(
            "website_project_tablero_idu.project_obra_contrato_info",
            datos
        )

    @http.route(['/zipa/proyectos_obra/contrato_info/polizas/json/<model("contrato.contrato"):contrato>'], type='http', auth="public", website=False, methods=['GET'])
    def genera_json_polizas(self, contrato, **kwargs):
        """
        data = {
            "data": [
                {
                    "tomador": "Tomador preuba",                #poliza
                    "tipo_poliza": "Tipo Poliza...",            #poliza
                    "numero": "1212121212",                     #poliza
                    "aseguradora": "Aseguradoa de prueba...",   #poliza
                    "fecha_expedicion": "2017-10-11",           #poliza
                    "fecha_aprobacion": "2017-10-11",           #poliza
                    "tipo_amparo":"Tipo Amparo prueba...",      #amparo
                    "fecha_inicio":"2017-10-11",                #amparo
                    "fecha_final":"2017-10-11",                 #amparo
                    "valor_inicial":"10000000000000"            #amparo
                },
            ]
        }
        """
        data_list = []
        for poliza in contrato.poliza_ids:
            amparos = json.loads(poliza.amparos)
            poliza_dicc = {
                'tomador': poliza.contrato_id.contratista_id.name,
                'tipo_poliza': poliza.tipo_poliza_id.name,
                'numero': poliza.name,
                'aseguradora': poliza.aseguradora,
                'fecha_expedicion':poliza.fecha_expedicion,
                'fecha_aprobacion': poliza.fecha_aprobacion,
                'amparos': amparos
            }
            data_list.append(poliza_dicc)

        data_json = json.dumps({'data':data_list })
        return data_json

    @http.route(['/zipa/proyectos_obra/pqrs_servicio/<int:pac_id>'], type='http', auth="public", methods=['get'])
    def get_datos(self, pac_id):
        values = {}
        query = """SELECT
                pac."name" AS punto_atencion
                ,criterio."name" AS criterio
                ,SUM (CASE WHEN pqrs.state = 'cerrado' THEN 1 ELSE 0 END) AS cerrado
                ,SUM (CASE WHEN pqrs.state = 'devuelto' THEN 1 ELSE 0 END) AS devuelto
                ,SUM (CASE WHEN pqrs.state = 'en_progreso' THEN 1 ELSE 0 END) AS en_progreso
                ,SUM (CASE WHEN pqrs.state = 'por_revisar' THEN 1 ELSE 0 END) AS por_revisar
                ,COUNT (pqrs.state)
                ,pac.id AS id
            FROM
                pqrs_pqrs AS pqrs
            LEFT JOIN
                pqrs_punto_atencion_ciudadano AS pac ON pqrs.pac_id = pac.id
            LEFT JOIN
                pqrs_criterio AS criterio ON pqrs.criterio_id = criterio.id
            WHERE
                pac_id IN ({}) AND
                pqrs.active = 't'
            GROUP BY
                punto_atencion
                ,criterio
                ,pac.id""".format(pac_id or 0)
        request.env.cr.execute(query)
        datos_completos = request.env.cr.fetchall()
        pqrs_list = []
        total_cerrado = 0
        total_devuelto = 0
        total_en_progreso = 0
        total_por_revisar = 0
        total = 0
        temporal = 0
        for dato_completo in datos_completos:
            nombre = dato_completo[0]
            if dato_completo[7] == temporal:
                nombre = ""
            temporal = dato_completo[7]
            pqrs_list.append({
                "id": dato_completo[7],
                "nombre": nombre,
                "criterio": dato_completo[1],
                "cerrado": dato_completo[2],
                "devuelto": dato_completo[3],
                "en_progreso": dato_completo[4],
                "por_revisar": dato_completo[5],
                "total": dato_completo[6],
            })
            total_cerrado += dato_completo[2]
            total_devuelto += dato_completo[3]
            total_en_progreso += dato_completo[4]
            total_por_revisar += dato_completo[5]
            total += dato_completo[6]
        pqrs_list.append({
            "nombre": 'Total',
            "criterio": '',
            "cerrado": total_cerrado,
            "devuelto":total_devuelto,
            "en_progreso":total_en_progreso,
            "por_revisar":total_por_revisar,
            "total":total,
        })
        values['pqrs'] = pqrs_list
        return json.dumps(values)

    @http.route(['/zipa/proyectos_obra/frente_componente/<model("project_obra.conservacion.informe_avance.detalle_frente"):frente>/<dia>/<mes>/<anio>/<integrantes>/<model("contrato.contrato"):contrato>'], type='http', auth="user", website=True)
    def proyectos_obra_frente_componente(self, frente=None, dia=False, mes=False, anio=False, integrantes=False, contrato=False, **kwargs):
        integrantes_list = re.findall(r'\d+', integrantes)
        integrantes_model = request.env['contrato.coordinador_contrato']
        integrantes = integrantes_model.search([('id', 'in', integrantes_list)])
        datos = {
            'frente': frente,
            'fecha_actualizacion': '{}/{}/{}'.format(str(dia).zfill(2), str(mes).zfill(2), anio),
            'integrantes': get_coordinadores_order(integrantes),
            'contrato':contrato,
        }
        return request.website.render(
            "website_project_tablero_idu.frente_componente",
            datos,
        )

    @http.route(['/zipa/proyectos_obra/tramite/<model("tramite.tramite"):tramite>'], type='http', auth="user", website=True)
    def proyectos_obra_tramite(self, tramite=None, **kwargs):
        radicados_list = []
        novedades_list = []
        for radicado in tramite.radicado_ids:
            fecha_radicado = False
            fecha_radicado_externo = False
            if radicado.fecha_rad_idu:
                fecha_radicado = datetime.strptime(radicado.fecha_rad_idu, '%Y-%m-%d').strftime('%d/%m/%Y')
            if radicado.fecha_rad_ext:
                fecha_radicado_externo = datetime.strptime(radicado.fecha_rad_ext, '%Y-%m-%d').strftime('%d/%m/%Y')
            radicados_list.append({
                'asunto': radicado.asunto_id.name,
                'radicado_idu': radicado.rad_idu,
                'fecha_radicado': fecha_radicado,
                'radicado_externo': radicado.rad_externo,
                'fecha_radicado_externo': fecha_radicado_externo,
                'observaciones': radicado.observaciones,
            })
        for novedad in tramite.novedad_ids:
            create_date = False
            if novedad.create_date:
                create_date = datetime.strptime(novedad.create_date, '%Y-%m-%d %H:%M:%S').strftime('%d/%m/%Y')
            novedades_list.append({
                'descripcion': novedad.descripcion,
                'create_uid_name': novedad.create_uid.name,
                'create_date': create_date,
            })
        datos = {
            'tramite': tramite,
            'fecha_estimada': tramite.fecha_estimada and datetime.strptime(tramite.fecha_estimada, '%Y-%m-%d').strftime('%d/%m/%Y'),
            'radicados': radicados_list,
            'novedades': novedades_list,
            'fecha_aprobacion': tramite.fecha_aprobacion and datetime.strptime(tramite.fecha_aprobacion, '%Y-%m-%d').strftime('%d/%m/%Y'),
        }
        return request.website.render(
            "website_project_tablero_idu.tramite",
            datos,
        )

    @http.route(['/zipa/proyectos_obra/actividades/<int:producto_id>/<int:contrato_id>/<int:proyecto_id>'], type='http', auth="user", website=True)
    def proyectos_obra_terminados_actividades(self, producto_id=False, contrato_id=False, proyecto_id=False, **kwargs):
        proyecto_model = request.env['project_obra.proyecto']
        gestiones_y_actividades = self.get_ultima_fecha_gestion(contrato_id, producto_id)
        gestiones = gestiones_y_actividades[0]
        actividades = gestiones_y_actividades[1]
        proyecto = proyecto_model.search([('id', '=', proyecto_id)])
        datos = {
            'actividades': actividades,
            'gestiones': gestiones,
            'ACTIVIDADES_ESTADOS': ACTIVIDADES_ESTADOS,
            'proyecto':proyecto,
        }
        return request.website.render(
            "website_project_tablero_idu.actividades",
            datos,
        )

    @http.route(['/zipa/proyectos_obra/reuniones_servicio/<int:proyecto_id>'], type='http', auth="public", methods=['get'])
    def get_datos_reunion(self, proyecto_id):
        values = {}
        query = """SELECT
            pac.name punto_idu,
            district.name as localidad,
            SUM (CASE WHEN reunion_tipo.id = 5 THEN 1 ELSE 0 END) AS comite_idu,
            SUM (CASE WHEN reunion_tipo.id = 5 THEN reunion.cantidad_asistentes ELSE 0 END) AS comite_asistentes,
            SUM (CASE WHEN reunion_tipo.id = 5 THEN reunion.cantidad_convocados ELSE 0 END) AS comite_convocados,
            SUM (CASE WHEN reunion_tipo.id = 3 THEN 1 ELSE 0 END) AS en_comunidad,
            SUM (CASE WHEN reunion_tipo.id = 3 THEN reunion.cantidad_asistentes ELSE 0 END) AS comunidad_asistentes,
            SUM (CASE WHEN reunion_tipo.id = 3 THEN reunion.cantidad_convocados ELSE 0 END) AS comunidad_convocados,
            SUM (CASE WHEN reunion_tipo.id = 1 THEN 1 ELSE 0 END) AS reunion_inicio,
            SUM (CASE WHEN reunion_tipo.id = 1 THEN reunion.cantidad_asistentes ELSE 0 END) AS reunion_inicio_asistentes,
            SUM (CASE WHEN reunion_tipo.id = 1 THEN reunion.cantidad_convocados ELSE 0 END) AS reunion__inicio_convocados,
            SUM (CASE WHEN reunion_tipo.id = 6 THEN 1 ELSE 0 END) AS reunion_extraordinaria,
            SUM (CASE WHEN reunion_tipo.id = 6 THEN reunion.cantidad_asistentes ELSE 0 END) AS reunion_extraordinaria_asistentes,
            SUM (CASE WHEN reunion_tipo.id = 6 THEN reunion.cantidad_convocados ELSE 0 END) AS reunion_extraordinaria_convocados,
            SUM (CASE WHEN
                (reunion_tipo.id = 5) OR --Comité IDU
                (reunion_tipo.id = 3) OR --En Cominidad
                (reunion_tipo.id = 1) OR --Reunión de Inicio
                (reunion_tipo.id = 6) --Reunión Extraordinaria
                THEN 1 ELSE 0 END) as cantidad,
            SUM (CASE WHEN
                (reunion_tipo.id = 5) OR --Comité IDU
                (reunion_tipo.id = 3) OR --En Cominidad
                (reunion_tipo.id = 1) OR --Reunión de Inicio
                (reunion_tipo.id = 6) --Reunión Extraordinaria
                THEN reunion.cantidad_asistentes ELSE 0 END) as total_asistentes,
            SUM (CASE WHEN
                (reunion_tipo.id = 5) OR --Comité IDU
                (reunion_tipo.id = 3) OR --En Cominidad
                (reunion_tipo.id = 1) OR --Reunión de Inicio
                (reunion_tipo.id = 6) --Reunión Extraordinaria
                THEN reunion.cantidad_convocados ELSE 0 END) as total_convocados
        from gestion_social_obra_reunion as reunion
        left join pqrs_punto_atencion_ciudadano pac on reunion.pac_id = pac.id
        left join res_country_state_city_upz upz on reunion.upz_id = upz.id
        left join res_country_state_city_district district on upz.district_id = district.id
        left join gestion_social_obra_reunion_tipo reunion_tipo on reunion.tipo_id = reunion_tipo.id
        WHERE
            proyecto_id = {}
            AND reunion.active = true
        group by punto_idu, localidad""".format(proyecto_id)
        request.env.cr.execute(query)
        datos_completos = request.env.cr.fetchall()
        reunion_list = []
        dato_list = ['Cantidad de Reuniones', 'Cantidad de Asistentes', 'Cantidad de Convocados']
        temporal_punto_idu = ''
        for dato_completo in datos_completos:
            punto_idu = dato_completo[0]
            for i in [0, 1, 2]:
                if punto_idu == temporal_punto_idu:
                    punto_idu = ''
                temporal_punto_idu = dato_completo[0]
                localidad = ''
                if i == 0:
                    localidad = dato_completo[1]
                reunion_list.append({
                    'punto_idu': punto_idu,
                    'localidad': localidad,
                    'dato': dato_list[0 + i],
                    'comite_idu': dato_completo[2 + i],
                    'en_comunidad': dato_completo[5 + i],
                    'reunion_inicio': dato_completo[8 + i],
                    'reunion_extraordinaria': dato_completo[11 + i],
                    'total': dato_completo[14 + i]
                })
        values['reuniones'] = reunion_list
        return json.dumps(values)

    @http.route(['/zipa/proyectos_obra/empleos_servicio/<int:proyecto_id>'], type='http', auth="public", methods=['get'])
    def get_datos_empleos(self, proyecto_id):
        values = {}
        query = """
            SELECT
                pac.name,
                localidad.name,
                SUM(CASE WHEN empleo.perfil = 'calificado' THEN 1 ELSE 0 END) AS calificado,
                SUM(CASE WHEN empleo.perfil = 'no_calificado' THEN 1 ELSE 0 END) AS no_calificado
            FROM
                gestion_social_obra_empleo_generado AS empleo
            LEFT JOIN
                pqrs_punto_atencion_ciudadano AS pac ON pac.id = empleo.pac_id
            LEFT JOIN
                res_country_state_city_district AS localidad ON localidad.id = empleo.district_id
            WHERE
                proyecto_id = {}
            GROUP BY
                pac.name, localidad.name
            ORDER BY
                pac.name, localidad.name
        """.format(proyecto_id)
        request.env.cr.execute(query)
        datos_completos = request.env.cr.fetchall()
        empleo_list = []
        temporal_punto_idu = ''
        for dato_completo in datos_completos:
            punto_idu = dato_completo[0]
            if punto_idu == temporal_punto_idu:
                punto_idu = ''
            temporal_punto_idu = dato_completo[0]
            empleo_list.append({
                'punto_idu': punto_idu,
                'localidad': dato_completo[1],
                'calificado': dato_completo[2],
                'no_calificado': dato_completo[3]
            })
        values['empleos'] = empleo_list
        return json.dumps(values)
