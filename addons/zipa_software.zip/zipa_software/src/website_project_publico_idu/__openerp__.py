{
    'name': 'Website público de seguimiento a proyectos',
    'version': '1.0',
    'depends': [
        'base',
        'website',
        'website_base_idu',
        'website_dhtmlxgantt',
        'project_edt_idu',
        'project_portafolio_idu',
        'project_obra_portafolio_idu',
        'website_project_idu',
        'website_project_tablero_idu',
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
        'views/main_templates.xml',
    ],
    'installable': True,
    'description': """
Sitio Web de acceso público para ver la información de los proyectos del IDU, orientado a ser accesible a todo tipo de público
    """,
}

