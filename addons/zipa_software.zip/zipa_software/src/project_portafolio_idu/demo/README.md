Contiene archivos de carga de datos para demostración y pruebas.
