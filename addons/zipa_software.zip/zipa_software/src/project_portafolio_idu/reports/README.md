Contiene el código para la generación de reportes.

- Wizards
- Plantillas
- Clases Generadoras

