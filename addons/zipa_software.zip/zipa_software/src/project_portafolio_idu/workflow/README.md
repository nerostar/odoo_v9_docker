Contiene los archivos de definición de workflows para los modelos del módulo
