Contiene los modelos y vistas para la definición de wizards.
