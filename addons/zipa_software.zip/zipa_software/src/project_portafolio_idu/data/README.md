Contiene archivos de carga de datos inicial de configuración y/o de demostración.
