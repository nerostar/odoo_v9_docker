{
    'name': 'Seguimiento a Conservación',
    'version': '1.0',
    'depends': [
        'base',
        'infraestructura_urbana_idu',
        'model_security',
        'project_obra_portafolio_idu',
        'project_obra_seguimiento_idu',
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/project_obra_view.xml',
        'views/photo_gallery_view.xml',
        'workflow/conservacion_informe_avance_workflow.xml',
        'wizards/wizard_reporte_consolidado_view.xml',
        'wizards/wizard_reporte_informe_conservacion.xml',
    ],
    'test': [
    ],
    'demo': [
    ],
    'installable': True,
    'description': """
## Dependencias módulos Python
## Configuración adicional
    """,
}
