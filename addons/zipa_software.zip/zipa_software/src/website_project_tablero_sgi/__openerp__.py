{
    'name': 'Website público de tablero de control SGI',
    'version': '1.0',
    'depends': [
        'base',
        'website',
        'website_base_idu',
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
        'views/main_templates.xml',
    ],
    'installable': True,
    'description': """
Sitio Web de acceso público para el tablero de control para la Subdirección General de Infraestructura
    """,
}