#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script que permite modificar las relaciones de los campos con el modelo res.partener, para que apunten a urbanizadores.terceros en los respectivos modelos de Odoo
"""

__author__ = "Daniel Rene"
__copyright__ = "IDU"
__credits__ = "I+D+i IDU"
__license__ = "GPL"
__version__ = "0.1.0"
__maintainer__ = "Daniel Rene"
__email__ = "daniel.chaparro@idu.gov.co"
__status__ = "En desarrollo"

import logging
from unicodedata import normalize, category
from argparse import ArgumentParser
import erppeek
from openerp import fields

logging.basicConfig()
_logger = logging.getLogger('INFO')
modelos = {}
listas = {}

def opciones_script() :
    """
    Funcion que captura los argumentos u opciones pasadas al script
    """
    parser = ArgumentParser()
    parser.add_argument("-m", "--modulo_base", dest="modulo_base", help="Modulo base a partir del cual se hara el recorrido de los modulos subsecuentes.")
    parser.add_argument("-l", "--lista_modelos",dest="modelos",help="Lista de modulos a procesar")
    parser.add_argument("-n", "--db_name", dest="db_name", help="Nombre de la base de datos de Odoo")
    parser.add_argument("-u", "--db_user",dest="db_user",help="Odoo database user")
    parser.add_argument("-p", "--db_password", dest="db_password", help="Odoo database password")
    parser.add_argument("-s", "--host", dest="host", help="Odoo server host", default="http://localhost:8069")
    return parser.parse_args()

def conectar_odoo(opts):
    '''
    Funcion que hace la conexion con el servidor de Odoo.
    @return Retorna una referencia a la conexion con el servidor.
    '''
    _logger.debug('Contectando a Odoo: {0}'.format(opts.db_name));
    client = erppeek.Client(
        opts.host,
        opts.db_name,
        opts.db_user,
        opts.db_password
    )
    return client

def principal() :
    argumentos = opciones_script()

#inicializo la conexion con odoo y referencio los modelos
    odoo = conectar_odoo(argumentos)

    modelo_terceros = odoo.model('urbanizadores.tercero')
    modelo_partner = odoo.model('res.partner')

    if argumentos.modelos :
        modelos = eval(argumentos.modelos)

        for modelo,lista_campos in modelos.iteritems() :
            try:
                modelo = odoo.model(modelo)
            except Exception as e:
                print "Verifique el nombre del modelo: {}, ya que no se encontro.".format(modelo)
                exit()

            registros_modelo = modelo.browse([]) # Leo todos los registros del modelo, para poder acceder a cada campo
            for registro in registros_modelo:
                for campo in lista_campos:

                    id_res_partner = getattr(registro, campo).id if getattr(registro, campo) else 0
                    registro_partner = modelo_partner.browse(id_res_partner) if id_res_partner else 0

                    if registro_partner :
                        #~ pu.db
                        #~ tercero_registros = modelo_terceros.browse([('identificacion_numero','=',registro_partner.identificacion_numero)])
                        #~ tercero_registro = tercero_registros[0] if tercero_registros else 0

                        #~ if not tercero_registro:
                        nuevo_tercero = {
                            'nombres':registro_partner.name,
                            'apellidos':registro_partner.apellidos,
                            'identificacion_numero':registro_partner.identificacion_numero,
                            'tipo_persona':registro_partner.tipo_persona,
                            'id_portal_idu':registro_partner.id_portal_idu,
                            'email':registro_partner.email,
                            'phone':registro_partner.phone,
                            'mobile':registro_partner.mobile,
                            'notas':registro_partner.comment,
                            'function':registro_partner.function,
                            'lang':registro_partner.lang,
                            'direccion':registro_partner.street,
                        }
                        registro_nuevo_tercero = modelo_terceros.create(nuevo_tercero)
                        if not registro_nuevo_tercero :
                            print "No se pudo crear el tercero, a partir de la informacion del res.partner: {}".format(id_res_partner)
                            break
                        # Asumiendo que el nuevo campo relacional se llama igual que el anterior, pero con el prefijo tercero_
                        try:
                            registro.write({"tercero_{}".format(campo):registro_nuevo_tercero.id})
                        except Exception as e:
                            print "No se encontro el campo: {}".format("tercero_{}".format(campo))
    else:
        print "Se deben indicar la lista de modulos a procesar -l '{'mod1':['campo1', 'campo2'],'mod2':['campo1']}'"
        exit(0)

    return 0

if __name__=='__main__':  # Si es el archivo que se esta ejecutando, es decir el principal invoque a la funcion main()
    principal()
