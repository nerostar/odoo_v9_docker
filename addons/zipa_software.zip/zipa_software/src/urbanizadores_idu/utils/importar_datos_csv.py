# -*- coding: utf-8 -*-

import csv
import sys
import xlrd
import base64
import logging
from unicodedata import normalize, category
from datetime import datetime
from argparse import ArgumentParser
import erppeek
import re

logging.basicConfig()
_logger = logging.getLogger('INFO')
modelos = {}
listas = {}

def correo_valido(dir_correo):
	if re.match(r"^[^@]+@[^@]+\.[^@]+$", dir_correo):
		return True
	else:
		return False

def telefono_valido(telefono):
	if re.match('^\d{7}$', telefono):
		return True
	else:
		return False

def fecha_valida(fecha):
	if re.match('\d{2}-\d{2}-\d{4}$', fecha):
		return True
	else:
		return False

def normalizar_real(v):
	numero = 0
	try:
		if '.' in v:
			v = v.replace('.','')
		if ',' in v:
			v = v.replace(',','.')
		numero = float(v)
	except Exception as e:
		print "Se recibio un numero no valido: " + str(e)
	return numero

def correo_idu_valido(dir_correo):
	if re.match("^.*idu\.gov\.co$", dir_correo):
		return True
	else:
		return False

def celular_valido(telefono):
	if re.match('^\d{10}$', telefono):
		return True
	else:
		return False

def cambiar_nombre_clave(dic, nom1, nom2):
	aux = ''
	encontrado = False
	for k,v in dic.iteritems():
		if k == nom1:
			aux = dic[k]
			encontrado = True
	if encontrado:
		del(dic[nom1])
		dic[nom2] = aux
	return dic

def buscar_registro(modelo, id, valor) :
    return modelo.browse([(id,'=',valor)])

def grabar_lista_datos(lista, modelo, restriccion = 'True'):
	registro = None
	for dic in lista :
		if dic and eval(restriccion) :
			print "Se va a escribir en la BD: " + str(dic)
			registro = modelo.create(dic)
		else:
			print "No se va a escribir en la BD: " + str(dic)
	return registro

def grabar_lista_datos2(lista, modelo, restriccion = {}):
	registro = None
	lista_campos_unicos = []
	lista_campos_no_vacios = []
	condicion = ""
	para_escribir = False

	if 'campos_no_repetidos' in restriccion:
		lista_campos_unicos = restriccion['campos_no_repetidos']
	if 'campos_no_vacios' in restriccion:
		lista_campos_no_vacios = restriccion['campos_no_vacios']
	if 'condicion_libre' in restriccion:
		condicion = restriccion['condicion_libre']

	for dic in lista :
		if dic:
			for campo in lista_campos_unicos:
				if dic.has_key(campo) and dic[campo] and not buscar_registro(modelo, campo, dic[campo]):
					para_escribir = True
				else:
					para_escribir = False
					break
			for campo in lista_campos_no_vacios:
				if dic.has_key(campo) and dic[campo]:
					para_escribir = True
				else:
					para_escribir = False
					break
			if condicion and eval(condicion):
				para_escribir = True

			if para_escribir:
				print "Se va a escribir en la BD: " + str(dic)
				registro = modelo.create(dic,{'no_check': True})
			else:
				print "No se va a escribir en la BD: " + str(dic)
	return registro

def agregar_producto(dic):
	lista_eliminar = []
	modelo_componente = modelos["componente"]
	modelo_producto = modelos["producto"]
	modelo_tipo_etapa = modelos["tipo_etapa"]
	modelo_tipo_producto = modelos["tipo_producto"]
	modelo_etapa = modelos["etapa"]
	modelo_proyectos = modelos["proyectos"]
	lista_etapa = listas["etapa"]
	lista_tipo_producto = listas["tipo_producto"]
	lista_proyectos = listas["proyectos"]
	campos_procesar = ['state', 'subtipo_id/id', 'etapa_id/id', 'fecha_terminacion']
	componente_id = 0
	etapa_id = 0
	subtipo_id = 0

	for k,v in dic.iteritems():
		if not dic[k]:
			lista_eliminar.append(k)
		elif k in campos_procesar:
			if k == "subtipo_id/id":
				id, componente, tipo_etapa, producto = v.split('|')
				if '-' in producto:
					pass
				if id:
					#tipo_id = buscar_lista(lista_tipo_producto, 'id', id, 'tipo_id')
					subtipo_id = buscar_lista(lista_tipo_producto, 'id', id, 'subtipo_id')
					if subtipo_id == 136:
					componente_id = buscar_lista(lista_tipo_producto, 'id', id, 'componente_id')
					dic[k] = subtipo_id
			elif k == "etapa_id/id":
				estado_id = buscar_lista(lista_etapa, 'id', v, 'estado_id')
				tipo_id = buscar_lista(lista_etapa, 'id', v, 'tipo_id')
				proyecto_id = buscar_lista(lista_etapa, 'id', v, 'proyecto_id')
				#proyecto_id = traer_relaciones(buscar_lista(lista_proyectos, 'id', v, 'name'),modelo_proyectos,"name","id")
				etapa_id = modelo_etapa.browse([('tipo_id','=',tipo_id), ('estado_id','=',estado_id), ('proyecto_id','=', proyecto_id)])
				if etapa_id:
					etapa_id = etapa_id[0].id
				dic[k] = etapa_id
			elif k == "state":
				v = v.lower()
				if not v in ['pendiente', 'entregado', 'devuelto', 'aceptado']:
					lista_eliminar.append('state')
			elif k == "fecha_terminacion":
				if not fecha_valida(v):
					lista_eliminar.append("fecha_terminacion")

	dic.update({'etapa_id':etapa_id, 'proyecto_id':proyecto_id, 'componente_id':componente_id, 'tipo_id':tipo_id})

	for k in lista_eliminar:
		del(dic[k])

	if dic.has_key("subtipo_id/id"):
		cambiar_nombre_clave(dic, 'subtipo_id/id', 'subtipo_id')
	cambiar_nombre_clave(dic, 'etapa_id/id', 'etapa_id')

	return dic

def agregar_tipo_producto(dic):

	modelo_componente = modelos["componente"]
	modelo_tipo_etapa = modelos["tipo_etapa"]
	modelo_tipo_producto = modelos["tipo_producto"]
	lista_etapa = listas["etapa"]

	componente_id = 0
	etapa_id = 0
	dic_respuesta = {}
	tiene_subtipo = False

	for k,v in dic.iteritems():
		if k == "Código":
			id, componente, tipo_etapa, producto = v.split('|')
			if '-' in producto:
				tipo, sub_tipo = producto.split('-')
				tipo = tipo.strip(' ')
				sub_tipo = sub_tipo.strip(' ')
				if tipo:
					if sub_tipo:
						tiene_subtipo = True
			else:
				tipo = producto
	if componente:
		componente_id = traer_relaciones(componente, modelo_componente, "name", "id")
		if not componente_id :
			componente_id = grabar_lista_datos([{'name':componente}], modelo_componente, "not modelo.browse([('name', '=','" + componente + "')])")
			if componente_id and isinstance(componente_id, erppeek.Record):
				componente_id = componente_id.id
	if tipo_etapa:
		tipo_etapa_id = traer_relaciones(tipo_etapa, modelo_tipo_etapa, "name", "id")
		if not tipo_etapa_id:
			condicion = "not modelo.browse([('name', '=','" + tipo_etapa + "')])"
			condicion = {'condicion_libre':condicion}
			tipo_etapa_id = grabar_lista_datos2([{'name':tipo_etapa}], modelo_tipo_etapa, condicion)
			if tipo_etapa_id:
				tipo_etapa_id = tipo_etapa_id.id
	# Existe el tipo producto?
	id_padre = traer_relaciones(tipo, modelo_tipo_producto, "name", "id")
	# Si no existe el tipo producto, creelo
	if not id_padre:

		condicion = "dic['name'] and dic['etapa_id'] and dic['componente_id'] and not modelo.browse([('name', '=','" + tipo + "'), ('etapa_id', '='," + str(tipo_etapa_id) + "), ('componente_id', '='," + str(componente_id) + ")])"
		condicion = {'condicion_libre':condicion}
		id_padre = grabar_lista_datos2([{'name':tipo, 'etapa_id':tipo_etapa_id, 'componente_id':componente_id}], modelo_tipo_producto, condicion)
		if id_padre:
			id_padre = id_padre.id
	if tiene_subtipo:
		# Busque el subtipo-producto
		id_sub_tipo = modelo_tipo_producto.browse([('name', '=',sub_tipo), ('etapa_id', '=',tipo_etapa_id), ('componente_id', '=',componente_id)])
		if id_sub_tipo:
			id_sub_tipo = id_sub_tipo[0].id
		else:
			# No existe ese subtipo, por lo cual se debe crear
			condicion = "not modelo.browse([('name', '=','" + tipo + "'), ('etapa_id', '='," + str(tipo_etapa_id) + "), ('componente_id', '='," + str(componente_id) + "), ('parent_id', '='," + str(id_padre) + ")])"
			condicion = {'condicion_libre':condicion}
			id_sub_tipo = grabar_lista_datos2([{'name':sub_tipo, 'etapa_id':tipo_etapa_id, 'componente_id':componente_id, 'parent_id':id_padre}], modelo_tipo_producto, condicion)

			if id_sub_tipo:
				id_sub_tipo = id_sub_tipo.id
	else:
		id_sub_tipo = 0
	dic_respuesta = {"id":id, "componente_id":componente_id,"tipo_id":id_padre, "subtipo_id":id_sub_tipo}

	return dic_respuesta

def agregar_tramo_cesion(dic):
	lista_eliminar = []
	modelo_tramo_cesion = modelos["tramo_cesion"]
	lista_proyectos = listas["proyectos"]
	modelo_proyectos = modelos["proyectos"]
	area_cesion_m2 = 0
	cesion_id = 0
	proyecto_id = 0
	dic_respuesta = {}

	for k,v in dic.iteritems():
		if dic[k] == "":
			lista_eliminar.append(k)
		else:
			if k == "proyecto_id":
				proyecto_id = traer_relaciones(buscar_lista(lista_proyectos, 'id', v, 'name'), modelo_proyectos, "name", "id")
				dic[k] = proyecto_id
			elif k == "area_cesion_m2":
					area_cesion_m2 = normalizar_real(v)
					dic[k] = area_cesion_m2
			elif k == "id" and not "id" in lista_eliminar:
				lista_eliminar.append('id')

	for k in lista_eliminar:
		del(dic[k])

	if proyecto_id:
		condicion = "not modelo.browse([('name', '=', dic['name']), ('proyecto_id','=', dic['proyecto_id'])])"
		condicion = {'condicion_libre':condicion}
		cesion_id = grabar_lista_datos2([dic], modelo_tramo_cesion, condicion)
		if cesion_id:
			cesion_id = cesion_id.id
		else:
			cesion_id = traer_relaciones(v, modelo_tramo_cesion, "name", "id")
	if cesion_id:
		dic_respuesta = {"name":"Elemento Provisional", "area_m2":area_cesion_m2, "cesion_id":cesion_id}

	return dic_respuesta

def agregar_etapa(dic):
	lista_eliminar = []
	modelo_tipo_etapa = modelos["tipo_etapa"]
	modelo_estado_etapa = modelos["estado_etapa"]
	modelo_proyectos = modelos["proyectos"]
	lista_proyectos = listas["proyectos"]

	for k,v in dic.iteritems():
		if not dic[k]:
			lista_eliminar.append(k)
		else:
			if k == "estado_id/id":
				id_estado, tipo_etapa, estado_etapa = v.split('|')
				id_tipo = traer_relaciones(tipo_etapa, modelo_tipo_etapa, "name", "id")
				if not id_tipo:
					id_tipo = grabar_lista_datos([{'name':tipo_etapa}], modelo_tipo_etapa)
					id_estado_tipo = grabar_lista_datos({"tipo_id":id_tipo, "name":estado_etapa}, modelo_estado_etapa)
				else:
					id_estado_tipo = modelo_estado_etapa.browse([("tipo_id", "=", id_tipo), ("name","=",estado_etapa)])
				if id_estado_tipo:
					id_estado_tipo = id_estado_tipo[0].id
				elif id_tipo:
					id_estado_tipo = grabar_lista_datos([{'name':estado_etapa, 'tipo_id':id_tipo}], modelo_estado_etapa)
					if id_estado_tipo:
						id_estado_tipo = id_estado_tipo.id
				dic[k] = id_estado_tipo

			elif k == "proyecto_id/id":
				dic[k] = traer_relaciones(buscar_lista(lista_proyectos, 'id', "{}".format(v), 'name'), modelo_proyectos, "name", "id")

	dic.update({'tipo_id':id_tipo})

	for k in lista_eliminar:
		del(dic[k])

	cambiar_nombre_clave(dic, 'estado_id/id', 'estado_id')
	cambiar_nombre_clave(dic, 'proyecto_id/id', 'proyecto_id')

	return dic

def agregar_resoluciones_urbanismo(dic):
	lista_eliminar = []
	lista_proyectos = listas["proyectos"]
	modelo_proyectos = modelos["proyectos"]

	for k,v in dic.iteritems():
		if not dic[k]:
			lista_eliminar.append(k)
		elif k == "fecha_expedicion" and not fecha_valida(dic[k]):
				lista_eliminar.append('fecha_expedicion')
		elif k == "fecha_vencimiento" and not fecha_valida(dic[k]):
				lista_eliminar.append('fecha_vencimiento')
		elif k == "proyecto_id/id":
			dic[k] = traer_relaciones(buscar_lista(lista_proyectos, 'id', v, 'name'), modelo_proyectos, "name", "id")

	lista_eliminar.append('id')

	for k in lista_eliminar:
		del(dic[k])

	if dic.has_key('proyecto_id/id'):
		cambiar_nombre_clave(dic, 'proyecto_id/id', 'proyecto_id')

#	if not dic.has_key('name'):	# Si no tiene el campo 'name' no lo puedo guadar
#			dic = {}

	return dic

def agregar_proyecto(dic):
	lista_eliminar = []
	lista_terceros = listas["terceros"]
	modelo_usuarios = modelos["usuarios"]
	modelo_terceros = modelos["terceros"]
	modelo_localidad = modelos["localidad"]
	campos_procesar = ('user_apoyo_id/id','user_id/id', 'urbanizadora_id/id', 'constructora_id/id', 'localidad', 'area_cesion_m2', 'alcance_proceso')
	for k,v in dic.iteritems():
		if not dic[k]:
			lista_eliminar.append(k)
		elif k in campos_procesar:
			if k == "user_apoyo_id/id":
				dic[k] = traer_relaciones(v, modelo_usuarios, "email", "id")
			elif k == "user_id/id":
				dic[k] = traer_relaciones(v, modelo_usuarios, "email", "id")
			elif k == "urbanizadora_id/id":
				dic[k] = traer_relaciones(buscar_lista(lista_terceros, 'id', v, 'name'), modelo_terceros, "name", "id")
			elif k == "constructora_id/id":
				dic[k] = traer_relaciones(buscar_lista(lista_terceros, 'id', v, 'name'), modelo_terceros, "name", "id")
			elif k == "localidad":
				dic[k] = traer_relaciones(v, modelo_localidad, "name", "id")
			elif k == "area_cesion_m2":
				dic[k] = normalizar_real(v)
			elif k == "alcance_proceso":
				if v.lower() in ['total', 'parcial']:
					dic[k] = v.lower()
				else:
					if dic.has_key('alcance_proceso') and not 'alcance_proceso' in lista_eliminar:
						lista_eliminar.append('alcance_proceso')

	for k in lista_eliminar:
		del(dic[k])

	cambiar_nombre_clave(dic, 'user_id/id', 'user_id')
	cambiar_nombre_clave(dic, 'user_apoyo_id/id', 'user_apoyo_id')
	cambiar_nombre_clave(dic, 'urbanizadora_id/id', 'urbanizadora_id')
	cambiar_nombre_clave(dic, 'constructora_id/id', 'constructora_id')
	cambiar_nombre_clave(dic, 'urbanizadora_id/id', 'urbanizadora_id')
	cambiar_nombre_clave(dic, 'localidad', 'localidad_id')
	return dic

def agregar_terceros(dic):
	lista_eliminar = []
	nombres = None
	for k,v in dic.iteritems():
		if not dic[k]:
			lista_eliminar.append(k)
		elif k == 'representante_legal' and not 'representante_legal' in lista_eliminar:
			lista_eliminar.append('representante_legal')
			if v:
				nombres = "Representante Legal: "+ v
		elif k == 'email' and not correo_valido(dic["email"]) and not 'email' in lista_eliminar:
			lista_eliminar.append('email')
		elif k == 'phone' and not telefono_valido(dic["phone"]) and not 'phone' in lista_eliminar:
			lista_eliminar.append('phone')
		elif k == 'mobile' and not celular_valido(dic["mobile"]) and not 'mobile' in lista_eliminar:
			lista_eliminar.append('mobile')

	if len(dic) > len(lista_eliminar)+1:
		if nombres:
			dic.update({'nombres':nombres})
	else:
		if not 'id' in lista_eliminar:
			lista_eliminar.append('id')
	for k in lista_eliminar:
		del(dic[k])
	return dic

def leer_csv_tipo_producto(nombre_archivo):
	f = open(nombre_archivo, 'rt')
	lista = []
	try:
		reader = csv.DictReader(f)
		for row in reader:
			dic = agregar_tipo_producto(row)
			lista.append(dic)
			print dic
	finally:
		f.close()
	return lista

def leer_csv_producto(nombre_archivo):
	f = open(nombre_archivo, 'rt')
	lista = []
	try:
		reader = csv.DictReader(f)
		for row in reader:
			dic = agregar_producto(row)
			lista.append(dic)
			print dic
	finally:
		f.close()
	return lista

def leer_csv_tramo_cesion(nombre_archivo):
	f = open(nombre_archivo, 'rt')
	lista = []
	try:
		reader = csv.DictReader(f)
		for row in reader:
			dic = agregar_tramo_cesion(row)
			lista.append(dic)
	finally:
		f.close()
	return lista

def leer_csv_etapas(nombre_archivo):
	f = open(nombre_archivo, 'rt')
	lista = []
	try:
		reader = csv.DictReader(f)
		for row in reader:
			dic = agregar_etapa(row)
			lista.append(dic)
	finally:
		f.close()

	return lista

def leer_csv_resoluciones_urbanismo(nombre_archivo):
	f = open(nombre_archivo, 'rt')
	lista = []
	try:
		reader = csv.DictReader(f)
		for row in reader:
			dic = agregar_resoluciones_urbanismo(row)
			lista.append(dic)
	finally:
		f.close()
	return lista

def leer_csv_proyecto(nombre_archivo):
	f = open(nombre_archivo, 'rt')
	lista = []
	try:
		reader = csv.DictReader(f)
		for row in reader:
			dic = agregar_proyecto(row)
			lista.append(dic)
	finally:
		f.close()

	return lista

def leer_csv_terceros(nombre_archivo):
	f = open(nombre_archivo, 'rt')
	lista = []
	modelo = modelos["terceros"]
	try:
		reader = csv.DictReader(f)
		for row in reader:
			dic = agregar_terceros(row)
			lista.append(dic)
	finally:
		f.close()
	return lista

def traer_relaciones(valor, modelo2, campo1, campo2) :
	''' Funcion que busca por el valor del campo1 en el modelo y trae de vuelta el valor del campo2 que se le pida, si no lo encuentra retorna 0'''
	respuesta = 0
	obj =  buscar_registro(modelo2, campo1, valor)
	if obj :
		obj = obj[0]
		respuesta = getattr(obj, campo2)
	return respuesta

def opciones_script() :
	"""
	Funcion que captura los argumentos u opciones pasadas al script
	"""
	parser = ArgumentParser()
	parser.add_argument("-fee", "--file_estados_etapa", dest="estados_etapa", help="Ruta absoluta al archivo csv estados etapa", metavar="FILE")
	parser.add_argument("-fe", "--file_etapas", dest="etapas", help="Ruta absoluta al archivo csv etapas", metavar="FILE")
	parser.add_argument("-fl", "--file_localidades", dest="localidades", help="Ruta absoluta al archivo csv localidades", metavar="FILE")
	parser.add_argument("-fpd", "--file_productos", dest="productos", help="Ruta absoluta al archivo csv productos", metavar="FILE")
	parser.add_argument("-fpy", "--file_proyectos", dest="proyectos", help="Ruta absoluta al archivo csv proyectos", metavar="FILE")
	parser.add_argument("-fru", "--file_resolucion_urbanismo", dest="resolucion_urbanismo", help="Ruta absoluta al archivo csv resolucion urbanismo", metavar="FILE")
	parser.add_argument("-ft", "--file_terceros", dest="terceros", help="Ruta absoluta al archivo csv terceros", metavar="FILE")
	parser.add_argument("-ftp", "--file_tipo_producto", dest="tipo_producto", help="Ruta absoluta al archivo csv tipo producto", metavar="FILE")
	parser.add_argument("-ftc", "--file_tramos_cesion", dest="tramos_cesion", help="Ruta absoluta al archivo csv tramos cesion", metavar="FILE")
	parser.add_argument("-n", "--db_name", dest="db_name", help="Nombre de la base de datos de Odoo")
	parser.add_argument("-u", "--db_user",dest="db_user",help="Odoo database user")
	parser.add_argument("-p", "--db_password", dest="db_password", help="Odoo database password")
	parser.add_argument("-o", "--offset", dest="offset", help="Fila inicial")
	parser.add_argument("-s", "--host", dest="host", help="Odoo server host", default="http://localhost:8069")
	return parser.parse_args()

def buscar_lista(lista, campo1, valor, campo2):
	respuesta = 0
	for dic in lista:
		if dic.has_key(campo1) and dic[campo1] == valor :
			if dic.has_key(campo2):
				respuesta = dic[campo2]
	return respuesta

def conectar_odoo(opts):
    _logger.debug('Contectando a Odoo: {0}'.format(opts.db_name));
    client = erppeek.Client(
        opts.host,
        opts.db_name,
        opts.db_user,
        opts.db_password
    )
    return client

def principal() :
	argumentos = opciones_script()

	#inicializo la conexion con odoo y referencio los modelos
	odoo = conectar_odoo(argumentos)

	modelo_proyectos = odoo.model('urbanizadores.proyecto')
	modelos.update({"proyectos":modelo_proyectos})
	modelo_terceros = odoo.model('res.partner')
	modelos.update({"terceros":modelo_terceros})
	modelo_usuarios = odoo.model('res.users')
	modelos.update({"usuarios":modelo_usuarios})
	modelo_res_urb = odoo.model('urbanizadores.proyecto.resolucion_urbanismo')
	modelos.update({"res_urb":modelo_res_urb})
	modelo_localidad = odoo.model('res.country.state.city.district')
	modelos.update({"localidad":modelo_localidad})
	modelo_estado_etapa = odoo.model('urbanizadores.proyecto.etapa.estado')
	modelos.update({"estado_etapa":modelo_estado_etapa})
	modelo_etapa = odoo.model('urbanizadores.proyecto.etapa')
	modelos.update({"etapa":modelo_etapa})
	modelo_producto = odoo.model('urbanizadores.proyecto.producto')
	modelos.update({"producto":modelo_producto})
	modelo_componente = odoo.model('urbanizadores.proyecto.componente')
	modelos.update({"componente":modelo_componente})
	modelo_tipo_etapa = odoo.model('urbanizadores.proyecto.etapa.tipo')
	modelos.update({"tipo_etapa":modelo_tipo_etapa})
	modelo_tramo_cesion = odoo.model('urbanizadores.proyecto.cesion')
	modelos.update({"tramo_cesion":modelo_tramo_cesion})
	modelo_elemento = odoo.model('urbanizadores.proyecto.elemento')
	modelos.update({"elemento":modelo_elemento})
	modelo_tipo_producto = odoo.model('urbanizadores.proyecto.producto.tipo')
	modelos.update({"tipo_producto":modelo_tipo_producto})

	lista_terceros = leer_csv_terceros(argumentos.terceros)
	listas.update({"terceros":lista_terceros})
	lista_proyectos = leer_csv_proyecto(argumentos.proyectos)
	listas.update({"proyectos":lista_proyectos})
	lista_res_urb = leer_csv_resoluciones_urbanismo(argumentos.resolucion_urbanismo)
	listas.update({"res_urb":lista_res_urb})
	lista_etapa = leer_csv_etapas(argumentos.etapas)
	listas.update({"etapa":lista_etapa})
	lista_tramo_cesion = leer_csv_tramo_cesion(argumentos.tramos_cesion)
	listas.update({"tramo_cesion":lista_tramo_cesion})
	lista_tipo_producto = leer_csv_tipo_producto(argumentos.tipo_producto)
	listas.update({"tipo_producto":lista_tipo_producto})
	lista_producto = leer_csv_producto(argumentos.productos)
	listas.update({"productos":lista_producto})

	condicion = {'campos_no_repetidos':['mobile', 'email', 'name']}
	grabar_lista_datos2(lista_terceros, modelo_terceros, condicion)
	condicion = {'campos_no_repetidos':['name', 'direccion']}
	grabar_lista_datos2(lista_proyectos, modelo_proyectos, condicion)
	condicion = {'campos_no_repetidos':['name', 'proyecto_id']}
	grabar_lista_datos2(lista_res_urb, modelo_res_urb, condicion)
#	condicion = "dic.has_key('name') and dic.has_key('estado_id') and dic.has_key('tipo_id') and not modelo.browse([('name', '=',dic['name']), ('estado_id', '=', dic['estado_id'] ), ('tipo_id', '=',dic['tipo_id'])])"
#	condicion = {'condicion_libre':condicion}
	condicion = {'campos_no_vacios':['estado_id', 'tipo_id', 'proyecto_id']}
	grabar_lista_datos2(lista_etapa, modelo_etapa, condicion)
	condicion = {'campos_no_vacios':['name', 'cesion_id']}
#	condicion = "not modelo.browse([('name', '=', dic['name']), ('cesion_id','=', dic['cesion_id']), ('area_m2','=', dic['area_m2'])])"
	grabar_lista_datos2(lista_tramo_cesion, modelo_elemento, condicion)
	condicion = {'campos_no_vacios':['tipo_id', 'subtipo_id', 'componente_id', 'etapa_id']}
#	condicion = "dic.has_key('subtipo_id') and dic.has_key('componente_id') and dic.has_key('tipo_id') and not modelo.browse([('subtipo_id', '=',dic['subtipo_id']), ('componente_id', '=', dic['componente_id'] ), ('tipo_id', '=',dic['tipo_id'])])"
#	condicion = {'condicion_libre':condicion}
	grabar_lista_datos2(lista_producto, modelo_producto, condicion)

if __name__=='__main__':  # Si es el archivo que se esta ejecutando, es decir el principal invoque a la funcion principal()
    principal()
