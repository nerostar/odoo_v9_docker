#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script que permite leer datos de las columnas y hojas indicadas de un archivo de excel y los carga en los respectivos modelos de Odoo
"""

__author__="Daniel Rene"
__copyright__="IDU"
__credits__="Daniel Rene"
__license__="GPL"
__version__="0.1.2"
__maintainer__="Daniel Rene"
__email__="daniel.chaparro@idu.gov.co"
__status__="En desarrollo"

import xlrd
import base64
import logging
from unicodedata import normalize, category
from datetime import datetime
from argparse import ArgumentParser
import erppeek

logging.basicConfig()
_logger = logging.getLogger('INFO')
modelos = {}
listas = {}

def opciones_script() :
	"""
	Funcion que captura los argumentos u opciones pasadas al script
	"""
	parser = ArgumentParser()
	parser.add_argument("-f", "--file", dest="filename", help="Ruta absoluta al archivo xlsx o xls", metavar="FILE")
	parser.add_argument("-n", "--db_name", dest="db_name", help="Nombre de la base de datos de Odoo")
	parser.add_argument("-u", "--db_user",dest="db_user",help="Odoo database user")
	parser.add_argument("-p", "--db_password", dest="db_password", help="Odoo database password")
	parser.add_argument("-o", "--offset", dest="offset", help="Fila inicial")
	parser.add_argument("-s", "--host", dest="host", help="Odoo server host", default="http://localhost:8069")
	return parser.parse_args()

def procesar_archivo(nombre_archivo, nombre_hoja, lista_campos):
	archivo = xlrd.open_workbook(nombre_archivo)
	hoja = archivo.sheet_by_name(nombre_hoja)
	datos = {}
	aux = {}
	if len(lista_campos) <= hoja.ncols :
		for columna in lista_campos:
			lista = []
			for fila in range(1, hoja.nrows) :
				lista.append(hoja.cell_value(rowx=fila, colx=columna))
			datos[hoja.cell_value(rowx=0, colx=columna)] = lista
	return datos

def conectar_odoo(opts):
	'''
	Funcion que hace la conexion con el servidor de Odoo.
	@return Retorna una referencia a la conexion con el servidor.
	'''
	_logger.debug('Contectando a Odoo: {0}'.format(opts.db_name));
	client = erppeek.Client(
		opts.host,
		opts.db_name,
		opts.db_user,
		opts.db_password
	)
	return client

def buscar_objeto(modelo, campo, valor) :
	'''
	Funcion que busca un objeto en un modelo determinado por el valor del id de este.
	'''
	if campo and valor:
		return modelo.browse([(campo,'=',valor)], context={'active_test':False})
	else:
		return modelo.browse([], context={'active_test':False})

def componer_dic(pos, lista_columnas, lista_nombre_campos_modelo_origen, lista_nombre_campos_modelo_destino, lista_convertir_valores, datos) :
	''' Funcion que crea el diccionario con los datos a insertar en la BD

	Parametros:
	modelo -- Modelo en el cual se cargaran los datos
	lista_campos -- Lista con los nombre de los campos dentro del modelo en donde se cargaran los datos
	datos -- Lista con los datos a cargar en el campo seleccionado
	'''
	cont = 0
	cadena = "{ "
	for columna in lista_columnas:
		valor = datos[columna][pos]
		if lista_convertir_valores[cont]:
			id = buscar_objeto(modelos[columna], lista_nombre_campos_modelo_origen[cont], valor)
			if id:
				cadena += "'{}':'{}',".format(lista_nombre_campos_modelo_destino[cont], id.id[0])
		else:
			if valor:
				cadena += "'{}':'{}',".format(lista_nombre_campos_modelo_destino[cont], valor)
		cont += 1
	cadena += " }"
	if ''.join(cadena.split()) == '{}':
		cadena = ''
	return cadena

def cargar_datos(modelo, lista_columnas, columna_id, campo_id, lista_nombre_campos_modelo_origen, lista_nombre_campos_modelo_destino, lista_convertir_valores, datos):
	'''	Funcion que carga los datos de la lista (datos), referenciada por el campo (id), en el modelo (modelo).

	Esta funcion carga los datos contenidos en un diccionario, cuya clave es el titulo de la columna y cuyo valor es la lista con los datos de dicha columna,
	el id .......

	Parametros:
	modelo -- Modelo en el cual se cargaran los datos
	lista_campos -- Lista con los nombre de los campos dentro del modelo en donde se cargaran los datos
	datos -- Diccionario con el nombre del campo como llave y la lista de valores como valor.

	Excepciones:
	....

	'''
	cant_datos = len(datos[columna_id])
	for pos in range(cant_datos) :
		valor = datos[columna_id][pos]
		if buscar_objeto(modelo, campo_id, valor): # Si el id ya existe, no grabara ese registro
			print "Este registro: {}, ya esta en la BD y no se cargará".format(valor)
			continue
		cadena = componer_dic(pos, lista_columnas, lista_nombre_campos_modelo_origen, lista_nombre_campos_modelo_destino, lista_convertir_valores, datos)
		if cadena:
			modelo.create(eval(cadena))

def crear_registro(modelo, id_registro, lista_nombre_campos, lista_valores_campos):
	'''	Funcion que carga los datos pasados 'lista_xxx_campos' en el modelo (modelo).

	Esta funcion carga los datos pasados en las listas, en el modelo especificado, por lo cual solo carga un registro.

	Parametros:
	modelo -- Modelo en el cual se cargaran los datos
	lista_nombre_campos -- Lista con los nombre de los campos dentro del modelo en donde se cargaran los datos
	lista_valores_campos -- Lista con los valores de los campos dentro del modelo en donde se cargaran los datos

	Excepciones:
	....

	'''
	pos = lista_nombre_campos.index(id_registro)
	id = buscar_objeto(modelo, id_registro, lista_valores_campos[pos])
	if not id:
		cant_datos = len(lista_nombre_campos)
		if len(lista_valores_campos) == cant_datos:
			cadena = "{ "
			for cont in range(cant_datos):
				cadena += "'{}':'{}',".format(lista_nombre_campos[cont], lista_valores_campos[cont])
			cadena += " }"
			if ''.join(cadena.split()) != '{}':
				return modelo.create(eval(cadena)).id
	return id.id[0]

def borrar_datos(modelo, campo=0, valor=0) :
	id_borrar = buscar_objeto(modelo, campo, valor)
	if id_borrar:
		return id_borrar.unlink({'force_unlink': 1})
	return False

def actualizar_datos(modelo, lista_campos, lista_valores, nombre_campo_condicion=0, valor_campo_condicion=0) :
	''' Funcion que actualiza los campos (lista_campos) con los valores (lista_valores) del modelo, que cumplen con la condicion
	modelo --
	lista_campos --
	lista_valores --
	nombre_campo_condicion -- Opcional, especifica el campo por el cual se hara la condicion, si no se pone se asume que se actualizaran todos los registros
	valor_campo_condicion -- Opcional, especifica el valor por el cual se hara la condicion, si no se pone se asume que se actualizaran todos los registros
	'''
	registro = buscar_objeto(modelo, nombre_campo_condicion, valor_campo_condicion)
	if registro:
		cont = 0
		cadena = "{ "
		for campo in lista_campos:
			valor = lista_valores[cont]
			if valor:
				cadena += "'{}':'{}',".format(campo, valor)
			cont += 1
		cadena += " }"
		if ''.join(cadena.split()) != '{}':
			return registro.write(eval(cadena))
	return False

def principal() :
	argumentos = opciones_script()

#inicializo la conexion con odoo y referencio los modelos
	odoo = conectar_odoo(argumentos)

# Cargo los modelos en el diccionario
	modelos.update({"subtipo_producto":odoo.model('urbanizadores.proyecto.producto.subtipo')})
	modelos.update({"componente":odoo.model('urbanizadores.proyecto.componente')})
	modelos.update({"tipo_etapa":odoo.model('urbanizadores.proyecto.etapa.tipo')})
	modelos.update({"tipo_producto":odoo.model('urbanizadores.proyecto.producto.tipo')})
	modelos.update({"producto":odoo.model('urbanizadores.proyecto.producto')})
	modelos.update({"etapa":odoo.model('urbanizadores.proyecto.etapa')})

# Leo las columnas desde las hojas del archivo y las almaceno en un diccionario
	datos =  procesar_archivo(argumentos.filename, "Productos - Subproductos", [0,1,2,3])

# Creo el subproducto por 'por_clasificar' para poder referenciarlo en los productos.
	id_subtipo_producto = crear_registro(
		modelo = modelos["subtipo_producto"],
		id_registro = 'name',
		lista_nombre_campos = ['name'],
		lista_valores_campos = ['por_clasificar'],
		)

# Creo el componente por 'por_clasificar' para poder referenciarlo en los productos.
	id_componente = crear_registro(
		modelo = modelos["componente"],
		id_registro = 'name',
		lista_nombre_campos = ['name'],
		lista_valores_campos = ['por_clasificar'],
		)

# NOSE VA A USAR. Creo el tipo etapa por 'por_clasificar' para poder referenciarlo en los productos.
	#id_tipo_etapa = crear_registro(
		#modelo = modelos["tipo_etapa"],
		#id_registro = 'name',
		#lista_nombre_campos = ['name'],
		#lista_valores_campos = ['por_clasificar'],
		#)

# Creo el tipo_producto por 'por_clasificar' para poder referenciarlo en los productos. Por defecto y para no crear un tipo_etapa 'por_clasificar' referencio id_tipo_etapa a 1
	etapa_id = buscar_objeto(modelos['tipo_etapa'], 0, 0)
	if etapa_id:
		etapa_id = etapa_id.id[0]
	id_tipo_producto = crear_registro(
		modelo = modelos["tipo_producto"],
		id_registro = 'name',
		lista_nombre_campos = ['name', 'etapa_id', 'componente_id'],
		lista_valores_campos = ['por_clasificar', etapa_id, id_componente],
		)

# Activo todos los componentes ocultos, ya que algunos de esos los voy a usar, los que no voy a usar, los elimino
	actualizar_datos(
			modelo = modelos["componente"],
			lista_campos = ['active'],
			lista_valores = [True]
			)

###### Compara los componentes que estan en la BD y de esos componentes que no estan en el archivo, les quita la referencia y los elimina
	lista_bd = buscar_objeto(modelos['componente'], 0, 0)
	lista_archivo = datos['componente']
	lista_archivo.append('por_clasificar')
	lista_eliminar = []
	for componente in lista_bd:
		if not componente.name in lista_archivo:
			lista_eliminar.append(componente.id)
	for componente in lista_eliminar:
		actualizar_datos(
			modelo = modelos["producto"],
			lista_campos = ['componente_id', 'tipo_id', 'subtipo_id'],
			lista_valores = [id_componente,id_tipo_producto,id_subtipo_producto],
			nombre_campo_condicion = 'componente_id',
			valor_campo_condicion = componente
			)
	odoo.unlink('urbanizadores.proyecto.componente', lista_eliminar, {'force_unlink': 1})

# NO SE USA. quitar la referencia a esos dos componentes que no estan en el xlsx
	#componente = buscar_objeto(modelos["componente"], 'name', 'Geometría y Tránsito')
	#if componente:
		#actualizar_datos(
			#modelo = modelos["producto"],
			#lista_campos = ['componente_id', 'tipo_id', 'subtipo_id'],
			#lista_valores = [id_componente,id_tipo_producto,id_subtipo_producto],
			#nombre_campo_condicion = 'componente_id',
			#valor_campo_condicion = componente.id[0]
			#)
	#componente = buscar_objeto(modelos["componente"], 'name', 'Constancia de Entrega')
	#if componente:
		#actualizar_datos(
			#modelo = modelos["producto"],
			#lista_campos = ['componente_id', 'tipo_id', 'subtipo_id'],
			#lista_valores = [id_componente,id_tipo_producto,id_subtipo_producto],
			#nombre_campo_condicion = 'componente_id',
			#valor_campo_condicion = componente.id[0]
			#)

# Actualizo las referencias a tipo_id y subtipo_id a todos los Productos, el componente se conserva.
	actualizar_datos(
			modelo = modelos["producto"],
			lista_campos = ['tipo_id', 'subtipo_id'],
			lista_valores = [id_tipo_producto, id_subtipo_producto]
			)

# Actualizo las referencias y elimino cada uno de los registros de los tipo Producto, lo demas se conserva
	#actualizar_datos(
			#modelo = modelos["tipo_producto"],
			#lista_campos = ['parent_id', 'componente_id'],
			#lista_valores = [
				#buscar_objeto(modelos["tipo_producto"], 'name', 'por_clasificar').id[0],
				#buscar_objeto(modelos["componente"], 'name', 'por_clasificar').id[0],
				#]
			#)
# Actualizo las referencias y las elimino uno a uno de los registros de los tipo Producto, lo demas se conserva
	lista_bd = buscar_objeto(modelos['tipo_producto'], 0, 0)
	for registro in lista_bd:
		registro.write({'componente_id':buscar_objeto(modelos["componente"], 'name', 'por_clasificar').id[0]}) #deprotno simplemente usar id_componente
		if registro.name != 'por_clasificar':
			registro.unlink({'force_unlink': 1})

# Elimino todos los subtipo_producto excepto 'por_clasificar', verificar que no existan productos relacionados, revisar los productos inactivos
	lista_bd = buscar_objeto(modelos['subtipo_producto'], 0, 0)
	lista_archivo = ['por_clasificar']
	lista_eliminar = []
	for tipo in lista_bd:
		if not tipo.name in lista_archivo and tipo.active:
			lista_eliminar.append(tipo.id)
	odoo.unlink('urbanizadores.proyecto.producto.subtipo', lista_eliminar, {'force_unlink': 1})

# Elimino todos los tipo_producto excepto 'por_clasificar', verificar que no existan productos relacionados, revisar los productos inactivos
	#lista_bd = buscar_objeto(modelos['tipo_producto'], 0, 0)
	#lista_archivo = ['por_clasificar']
	#lista_eliminar = []
	#for tipo in lista_bd:
		#if not tipo.name in lista_archivo and tipo.active:
			#lista_eliminar.append(tipo.id)
	#odoo.unlink('urbanizadores.proyecto.producto.tipo', lista_eliminar, {'force_unlink': 1})

# Cargo los nuevos subtipo producto
	cargar_datos(
		modelo = modelos["subtipo_producto"],
		lista_columnas = ['subtipo_producto'], # Asumo que el nombre de las columnas es el mismo nombre de las llaves de los modelos
		columna_id = 'subtipo_producto',
		campo_id = 'name',
		lista_nombre_campos_modelo_destino = ['name'],
		lista_nombre_campos_modelo_origen = ['name'],
		lista_convertir_valores = [0],
		datos = datos
		)

# Cargo los nuevos componentes
	cargar_datos(
		modelo = modelos["componente"],
		lista_columnas = ['componente'], # Asumo que el nombre de las columnas es el mismo nombre de las llaves de los modelos
		columna_id = 'componente',
		campo_id = 'name',
		lista_nombre_campos_modelo_destino = ['name'],
		lista_nombre_campos_modelo_origen = ['name'],
		lista_convertir_valores = [0],
		datos = datos
		)

# Cargo los nuevos tipo producto, se quito el parent y deben ser diferentes (name, componente_id, etapa_id)
	#cargar_datos(
		#modelo = modelos["tipo_producto"],
		#lista_columnas = ['tipo_producto', 'componente', 'tipo_etapa'], # Asumo que el nombre de las columnas es el mismo nombre de las llaves de los modelos
		#columna_id = 'tipo_producto',
		#campo_id = 'name',
		#lista_nombre_campos_modelo_destino = ['name', 'componente_id', 'etapa_id'],
		#lista_nombre_campos_modelo_origen = ['name', 'name', 'name'],
		#lista_convertir_valores = [0,1,1],
		#datos = datos
		#)
# Cargo los nuevos tipo producto, deben ser diferentes (name, componente_id, etapa_id)
	cant_datos = len(datos['tipo_producto'])
	for pos in range(cant_datos) :
		nombre = datos['tipo_producto'][pos]
		componente = datos['componente'][pos]
		etapa = datos['tipo_etapa'][pos]
		#subtipo = buscar_objeto(modelos["subtipo_producto"], 'name', subtipo).id[0]
		if modelos["tipo_producto"].browse([('name','=',nombre), ('componente_id', '=', componente), ('etapa_id', '=', etapa)]):
			print "Este registro: ({},{},{}), , ya esta en la BD y no se cargará".format(nombre, componente, etapa)
			continue
		cadena = componer_dic(
			pos,
			['tipo_producto', 'componente', 'tipo_etapa'],
			['name', 'name', 'name'],
			['name', 'componente_id', 'etapa_id'],
			[0,1,1],
			datos
			)
		if cadena:
			modelos["tipo_producto"].create(eval(cadena))

# NO SE VA USAR. Borro los tipo producto que no esten en el xlsx, nose va hacer solo se van a eliminar todos los datos y despues meter todos los datos del xlsx
	#lista_bd = buscar_objeto(modelos['tipo_producto'], 0, 0)
	#lista_archivo = datos['tipo_producto']
	#lista_archivo.append('por_clasificar')
	#lista_eliminar = []
	#for tipo in lista_bd:
		#if not tipo.name in lista_archivo:
			#lista_eliminar.append(tipo.id)
	#odoo.unlink('urbanizadores.proyecto.producto.tipo', lista_eliminar, {'force_unlink': 1})

if __name__=='__main__':  # Si es el archvo que se esta ejecutando, es decir el principal invoque a la funcion main()
    principal()
