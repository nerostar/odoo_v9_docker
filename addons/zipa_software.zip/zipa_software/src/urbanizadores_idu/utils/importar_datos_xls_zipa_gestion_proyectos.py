#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Script que permite leer datos de las columnas y hojas indicadas de un archivo de excel y los carga en los respectivos modulos de Odoo
"""

__author__="Daniel Rene"
__copyright__="IDU"
__credits__="Daniel Rene"
__license__="GPL"
__version__="0.1.2"
__maintainer__="Daniel Rene"
__email__="daniel.chaparro@idu.gov.co"
__status__="En desarrollo"

import xlrd
import base64
import logging
from unicodedata import normalize, category
from datetime import datetime
from argparse import ArgumentParser
import erppeek

logging.basicConfig()
_logger = logging.getLogger('INFO')

def normaliza(cadena) :
    u = u'{}'.format(cadena.lower())
    vocmap = {ord(c): ord(t) for c, t in zip(u"áéíóúñ", u"aeioun")}
    res = u.translate(vocmap)
    return " ".join(res.split())

def opciones_script() :
	"""
	Funcion que captura los argumentos u opciones pasadas al script
	"""
	parser = ArgumentParser()
	parser.add_argument("-f", "--file", dest="filename", help="Ruta absoluta al archivo xlsx o xls", metavar="FILE")
	parser.add_argument("-n", "--db_name", dest="db_name", help="Nombre de la base de datos de Odoo")
	parser.add_argument("-u", "--db_user",dest="db_user",help="Odoo database user")
	parser.add_argument("-p", "--db_password", dest="db_password", help="Odoo database password")
	parser.add_argument("-o", "--offset", dest="offset", help="Fila inicial")
	parser.add_argument("-s", "--host", dest="host", help="Odoo server host", default="http://localhost:8069")
	return parser.parse_args()
		
def procesar_archivo(nombre_archivo, nombre_hoja, lista_campos):
	archivo = xlrd.open_workbook(nombre_archivo)	
	hoja = archivo.sheet_by_name(nombre_hoja)
	datos = {}
	aux = {}
	if len(lista_campos) <= hoja.ncols :
		for columna in lista_campos:
			lista = []	
			for fila in range(1, hoja.nrows) :		
				lista.append(hoja.cell_value(rowx=fila, colx=columna))			
			aux = {hoja.cell_value(rowx=0, colx=columna): lista}
			datos.update(aux)
	return datos
		
def conectar_odoo(opts):
    _logger.debug('Contectando a Odoo: {0}'.format(opts.db_name));
    client = erppeek.Client(
        opts.host,
        opts.db_name,
        opts.db_user,
        opts.db_password
    )
    return client
    
def buscar_objeto(modelo, id, valor) :   
    return modelo.browse([(id,'=',valor)])
   
def funcion(nombre, parametro):
	return nombre(parametro)
  
def aplicar_opciones(llave, valor, opciones) :
	if opciones and "conversion" in opciones:
		cantidad = len(opciones["conversion"])
		for i in range(cantidad) :
			campo = opciones["conversion"][i][0]
			tipo = opciones["conversion"][i][1]
			if llave == campo :
				try:
					#valor = funcion(tipo, valor)
					valor = int(float(valor))
				except Exception as e:
					print "No es posible convertir el dato ingresado" + str(e)
	if opciones and "union" in opciones :
		cantidad = len(opciones["union"])
		print cantidad
		for i in range(cantidad) :
			campo1 = opciones["union"][i][0]
			modelo2 = opciones["union"][i][1]
			campo2 = opciones["union"][i][2]
			id2 = opciones["union"][i][3]
			if llave == campo1 :
				obj =  buscar_objeto(modelo2, campo2, valor)
				if obj :
					obj = obj[0]
					valor = getattr(obj, id2)
	return valor
	
  
def componer_dic(pos, llaves, datos, verificar_id, opciones, id = None) :	
	
	cadena = "{ "
	for llave in llaves :
		if datos[llave][pos] :	
			if verificar_id :	# Solo guarda los campos no nulos.
				cadena += "'" + str(llave) + "'" + " : " + "'" + str(aplicar_opciones(llave, datos[llave][pos], opciones)) + "'" + ", "					
			elif id and llave != id : # No guarda el id, deja que lo genere automaticamente la BD.
				cadena += "'" + str(llave) + "'" + " : " + "'" + str(aplicar_opciones(llave, datos[llave][pos], opciones)) + "'" + ", "
	cadena += " }"
	return cadena
	 
def cargar_datos(modelo, id, datos, verificar_id=False, opciones=None) :
	llaves = list(datos.keys())				
	cant_datos = len(datos[id])	
		
	for pos in range(cant_datos) :
		if verificar_id :
			if datos[id][pos] and buscar_objeto(modelo, id, int(datos[id][pos])):#modelo.search([(id,'=',int(datos[id][pos]))]): Si el campo id no es nulo y si no existe (es nuevo)
				print "el usuario {} existe, por lo tanto no se creara.".format(datos["name"][pos])
			else :				
				cadena = componer_dic(pos, llaves, datos, verificar_id, opciones)			
		else :			
			cadena = componer_dic(pos, llaves, datos, verificar_id, opciones, id)
		print cadena
		#modelo.create(eval(cadena))
				
def principal() :
	argumentos = opciones_script()
	#inicializo la conexion con odoo y referencio los modelos
	odoo = conectar_odoo(argumentos)
	modelo_urb_pro = odoo.model('urbanizadores.proyecto')
	modelo_terceros = odoo.model('res.partner')		
	modelo_res_urb = odoo.model('urbanizadores.proyecto.resolucion_urbanismo')
	
	# Leo los datos desde las hojas del archivo
	lista_terceros = procesar_archivo(argumentos.filename, "Terceros", [0,1,2,3,4,5])
	lista_proyectos = procesar_archivo(argumentos.filename, "Proyectos", [valor for valor in range(21)])
	lista_resoluciones_urb = procesar_archivo(argumentos.filename, "Resoluciones de Urbanismo", [valor for valor in range(6)])
	lista_etapas = procesar_archivo(argumentos.filename, "Etapas", [valor for valor in range(6)])
	lista_productos = procesar_archivo(argumentos.filename, "Productos", [valor for valor in range(6)])
	lista_tipo_producto = procesar_archivo(argumentos.filename, "Tipo de Producto", [0])
	lista_estado_etapa = procesar_archivo(argumentos.filename, "Estados de Etapa", [0])
	lista_localidades = procesar_archivo(argumentos.filename, "Localidades", [0])
	lista_tramo_cesion = procesar_archivo(argumentos.filename, "Tramos de Cesion", [valor for valor in range(5)])
	# Cargo los datos en odoo
	#cargar_datos(modelo_terceros, 'id', lista_terceros, False, {"conversion":[("phone","int"), ("id","int")]})	
	#cargar_datos(modelo_terceros, 'id', lista_proyectos, False, {"conversion":[("phone","int"), ("id","int")], "union":[("name", modelo_terceros, "name", 'id')]} )
	#print aplicar_opciones("name", "CONSTRUCTORA CAPITAL S.A.S.", {"union":[("name", modelo_terceros, "name", 'id')]})
	cargar_datos(modelo_res_urb, 'id', lista_resoluciones_urb, False)
	
if __name__=='__main__':  # Si es el archvo que se esta ejecutando, es decir el principal invoque a la funcion main()
    principal()
