# -*- coding: utf-8 -*-

from dateutil.parser import parse

from openerp import models, fields, api, exceptions
from openerp.addons.base_idu.tools import reportes
from openerp.addons.base_idu.tools.utilitarios import obtener_etiqueta_lista_select, localizar_fecha, lista_campo_modelo
from openerp.addons.urbanizadores_idu.models.urbanizadores import VISITA_STATES
from openerp.exceptions import Warning, ValidationError
import pytz


class urbanizadores_wizard_reporte_visitas(models.TransientModel):
    _name = 'urbanizadores.wizard.reporte_visitas'

    # -------------------
    # Fields
    # -------------------
    archivo_encuesta = fields.Binary('Archivo', readonly=True, filters="xls")
    nombre_archivo_encuesta = fields.Char('Nombre del Archivo', size=255)
    proyecto_id = fields.Many2one(
        string='Proyecto',
        comodel_name='urbanizadores.proyecto',
        ondelete='restrict',
        help='Proyecto de Urbanismo a Cargo de Terceros',
        required=True,
    )

    # -------------------
    # methods
    # -------------------
    def seccion_visita(self, proyecto):
        visitas = self.env['urbanizadores.proyecto.visita'].search([('proyecto_id', '=', proyecto.id)])
        all_visitas = []
        conta = 0
        for visita in visitas:
            nombres = ''
            for especialista in visita.user_ids:
                nombres += "{},".format(especialista.name)
            visita_dic = {
                'tipo': visita.tipo_id.name or 'Sin Información',
                'asunto': visita.name or 'Sin Información',
                'especialista': nombres or 'Sin Información',
                'observaciones': visita.observacion_visita or 'Sin Información',
                'fecha_inicio': localizar_fecha(self, visita.fecha_inicio, retornar_str=True) or 'Sin Información',
                'fecha_fin': localizar_fecha(self, visita.fecha_fin, retornar_str=True) or 'Sin Información',
                'estado': obtener_etiqueta_lista_select(VISITA_STATES, visita.state) or 'Sin Información',
            }
            fotos_visita = []

            for i in visita.observacion_ids:
                obs_especialista = i.user_id.name
                for foto in i.photo_ids:
                    if 'photo' in foto and foto.photo:
                        conta += 1
                        data_fotos_dic = {
                            'obs_especialista': obs_especialista,
#                             'resumen': foto.name or 'Sin Información',
                            'ruta_archivo': reportes.crear_archivo(foto.photo, conta)
                        }
                        fotos_visita.append(data_fotos_dic)
            visita_dic['fotos'] = fotos_visita
            all_visitas.append(visita_dic)
        return all_visitas

    @api.multi
    def crear_reporte_visitas(self):
        proyecto = {}
        # construir diccionario
        proyecto['nombre'] = self.proyecto_id.name or 'Sin Información'
        proyecto['direccion'] = self.proyecto_id.direccion or 'Sin Información'
        proyecto['localidad'] = self.proyecto_id.localidad_id.name or 'Sin Información'
        proyecto['expediente'] = self.proyecto_id.numero_expediente_orfeo or 'Sin Información'
        proyecto['fecha_inicio'] = localizar_fecha(self, self.proyecto_id.fecha_inicio_proceso if self.proyecto_id else None, retornar_str=True) or 'Sin Información'
        proyecto['etapa'] = self.proyecto_id.etapa_id.name or 'Sin Información'
        proyecto['estado_etapa'] = self.proyecto_id.etapa_id.estado_id.name or 'Sin Información'
        proyecto['tipo_etapa'] = self.proyecto_id.etapa_id.estado_id.name or 'Sin Información'
        proyecto['resolucion'] = self.proyecto_id.resolucion_urbanismo_id.name or 'Sin Información'
        proyecto['fecha_resolucion'] = (self.proyecto_id.resolucion_urbanismo_id.fecha_expedicion or 'Sin Información') + ' - ' + (self.proyecto_id.resolucion_urbanismo_id.fecha_vencimiento or 'Sin Información')
        proyecto['no_plano_urbanismo'] = self.proyecto_id.resolucion_urbanismo_id.numero_plano_urbanismo or 'Sin Información'
        proyecto['area_cesion'] = self.proyecto_id.area_cesion_m2 or 'Sin Información'
        proyecto['urbanizador'] = self.proyecto_id.tercero_urbanizadora_id.name or 'Sin Información'
        proyecto['constructor'] = self.proyecto_id.tercero_constructora_id.name or 'Sin Información'
        proyecto['constructor_celular'] = self.proyecto_id.tercero_constructora_id.mobile or 'Sin Información'
        proyecto['constructor_direccion'] = self.proyecto_id.tercero_constructora_id.direccion or 'Sin Información'
        proyecto['constructor_correo'] = self.proyecto_id.tercero_constructora_id.email or 'Sin Información'
        proyecto['constructor_tel_fijo'] = self.proyecto_id.tercero_constructora_id.phone or 'Sin Información'

        # sección registro fotografico de visita
        proyecto['visitas'] = self.seccion_visita(self.proyecto_id)
        # crear reporte
        documento = reportes.crear_reporte(
            self,
            proyecto,
            'VISITAS',
            'pdf',
            'plantilla_visitas.odt',
            'urbanizadores_ruta_plantillas'
        )
        # eliminar imagenes
        reportes.limpiar_carpeta('/tmp/img_reporte')
        # nombre del reporte para campos de odoo
        self.archivo_encuesta = documento[0]
        self.nombre_archivo_encuesta = documento[1]
        # buscamos el wizar de descarga
        view_ids = self.env['ir.ui.view'].search([('model', '=', 'urbanizadores.wizard.reporte_visitas'),
                                                  ('name', '=', 'urbanizadores_wizard_reporte_visitas_download')])
        ids = self.id
        return {
                'view_type':'form',
                'view_mode':'form',
                'res_model':'urbanizadores.wizard.reporte_visitas',
                'target':'new',
                'type':'ir.actions.act_window',
                'view_id':view_ids.id,
                'res_id': ids
        }
