# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_urbanizadores_proyecto_accion(common.TransactionCase):
    def test_crud_validaciones(self):
        proyecto_accion_model = self.env['urbanizadores.proyecto.accion']
        vals = {
            'name': "Id sit voluptas odit non hic consequuntur ut.",
            'descripcion': "Odio ut voluptatum eos animi repellat in cum.",
        }
        proyecto_accion = proyecto_accion_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()