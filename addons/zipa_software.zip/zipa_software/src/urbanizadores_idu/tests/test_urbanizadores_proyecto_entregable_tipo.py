# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_urbanizadores_proyecto_entregable_tipo(common.TransactionCase):
    def test_crud_validaciones(self):
        proyecto_entregable_tipo_model = self.env['urbanizadores.proyecto.entregable.tipo']
        vals = {
            'name': "Voluptates excepturi sed ipsum sit beatae.",
            'etapa_id': self.ref('urbanizadores_idu.etapa_id_01'),
        }
        proyecto_entregable_tipo = proyecto_entregable_tipo_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()