# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_urbanizadores_proyecto(common.TransactionCase):
    def test_crud_validaciones(self):
        proyecto_model = self.env['urbanizadores.proyecto']
        vals = {
            'name': "Quaerat perspiciatis beatae ipsam vel dicta est autem.",
            'state': "terminado",
            'numero_resolucion_urbanismo': "Voluptas et molestiae adipisci qui.",
            'urbanizadora_id': self.ref('urbanizadores_idu.urbanizadora_id_01'),
            'constructora_id': self.ref('urbanizadores_idu.constructora_id_01'),
            'direccion': "Odio voluptatem officiis qui voluptatem et.",
            'localidad_id': self.ref('urbanizadores_idu.localidad_id_01'),
            'descripcion': "Quas qui odit et eligendi.",
            'area_cesion_m2': 13303002,
            'numero_expediente_orfeo': "Occaecati vero molestiae ipsa unde deserunt.",
            'en_accion_popular': True,
            'con_seguimiento': False,
            'etapa_id': self.ref('urbanizadores_idu.etapa_id_01'),
            'siguiente_accion_id': self.ref('urbanizadores_idu.siguiente_accion_id_01'),
            'numero_oficio_aceptacion': "Cupiditate perferendis minus illum dolorum.",
            'fecha_firma_acta': "1987-10-11",
            'reunion_ids': [
                (4, self.ref('urbanizadores_idu.reunion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'entregable_ids': [
                (4, self.ref('urbanizadores_idu.entregable_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        proyecto = proyecto_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()