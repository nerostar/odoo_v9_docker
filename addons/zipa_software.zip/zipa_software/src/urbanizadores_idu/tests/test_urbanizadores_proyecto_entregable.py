# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_urbanizadores_proyecto_entregable(common.TransactionCase):
    def test_crud_validaciones(self):
        proyecto_entregable_model = self.env['urbanizadores.proyecto.entregable']
        vals = {
            'name': "Eligendi a autem fugiat et dolor et.",
            'proyecto_id': self.ref('urbanizadores_idu.proyecto_id_01'),
            'tipo_id': self.ref('urbanizadores_idu.tipo_id_01'),
            'state': "entregado",
            'fecha_terminacion': "2012-03-20",
            'numero_oficio_aprobacion': "Harum dolore qui quis.",
        }
        proyecto_entregable = proyecto_entregable_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()