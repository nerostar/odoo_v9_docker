# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_urbanizadores_reunion(common.TransactionCase):
    def test_disponibilidad(self):
        proyecto_model = self.env['urbanizadores.proyecto']
        vals = {
            'name': "Proyecto de Prueba",
            'numero_resolucion_urbanismo': "Voluptas et molestiae adipisci qui.",
            'direccion': "Odio voluptatem officiis qui voluptatem et.",
        }
        proyecto = proyecto_model.create(vals)

        reunion_model = self.env['urbanizadores.reunion']
        vals = {
            'proyecto_id': proyecto.id,
            'fecha_hora_inicio': "2016-10-06 07:00:00",
            'fecha_hora_fin': "2016-10-06 08:00:00",
            'contacto_id': self.ref('base.partner_root'),
        }
        reunion_model.create(vals)
        vals = {
            'proyecto_id': proyecto.id,
            'fecha_hora_inicio': "2016-10-06 08:00:00",
            'fecha_hora_fin': "2016-10-06 09:00:00",
            'contacto_id': self.ref('base.partner_root'),
        }
        reunion_model.create(vals)
        vals = {
            'proyecto_id': proyecto.id,
            'fecha_hora_inicio': "2016-10-06 13:00:00",
            'fecha_hora_fin': "2016-10-06 13:59:00",
            'contacto_id': self.ref('base.partner_root'),
        }
        reunion_model.create(vals)
        vals = {
            'proyecto_id': proyecto.id,
            'fecha_hora_inicio': "2016-10-06 14:00:00",
            'fecha_hora_fin': "2016-10-06 14:30:00",
            'contacto_id': self.ref('base.partner_root'),
        }
        reunion_model.create(vals)
        # Sin conflicto
        found = reunion_model.buscar_reuniones_en_conflicto('2016-10-06 10:00:00', '2016-10-06 11:00:00')
        self.assertEqual(len(found), 0)
        # con conflicto propuesta dentro de los tiempos de una existente
        found = reunion_model.buscar_reuniones_en_conflicto('2016-10-06 07:10:00', '2016-10-06 07:20:00')
        self.assertEqual(len(found), 1)
        # con conflicto propuesta igual a una existente
        found = reunion_model.buscar_reuniones_en_conflicto('2016-10-06 13:00:00', '2016-10-06 13:59:00')
        self.assertEqual(len(found), 1)
        # con conflicto propuesta inicia en una reunion existente y termina en otra existente
        found = reunion_model.buscar_reuniones_en_conflicto('2016-10-06 07:10:00', '2016-10-06 08:20:00')
        self.assertEqual(len(found), 2)
        # con conflicto propuesta inicia antes de una reunion existente y termina despues de una existente
        found = reunion_model.buscar_reuniones_en_conflicto('2016-10-06 12:00:00', '2016-10-06 15:00:00')
        self.assertEqual(len(found), 2)
        # con conflicto inicia en una existente y termina en bloque libre
        found = reunion_model.buscar_reuniones_en_conflicto('2016-10-06 08:30:00', '2016-10-06 11:00:00')
        self.assertEqual(len(found), 1)
        # con conflicto inicia en bloque libre y termina en reunion existente
        found = reunion_model.buscar_reuniones_en_conflicto('2016-10-06 11:00:00', '2016-10-06 14:10:00')
        self.assertEqual(len(found), 2)

if __name__ == '__main__':
    unittest2.main()