# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from datetime import datetime, timedelta
from openerp import models, fields, api
from openerp.addons.base_idu.tools.archivos import generar_evento_calendario, generar_archivo_excel
from openerp.addons.base_idu.tools.mail import enviar_nota, enviar_mensaje_con_plantilla
from openerp.addons.base_idu.tools.utilitarios import url_vista_boton, localizar_fecha, lista_campo_modelo, obtener_etiqueta_lista_select, numeros_a_letras, generar_codigo_qr
from openerp.addons.base_idu.tools.validaciones import validar_fecha, validar_correo_electronico, validar_formato
from openerp.exceptions import ValidationError, Warning
from pychart import coord
from workalendar.america import Colombia
from openerp.addons.base_idu.tools.reportes import Reporte

import logging
import openerp.addons.binary_field_as_attachment as binary_field
import workdays  # sudo pip install workdays
import base64

# INFO Estados en los que el proyecto urbanismo se considera terminado y no permite modificaciones
PROYECTO_ESTADOS_TERMINADO = [
                            'finalizado',
                            'archivado',
                            ]
VISITA_STATES = [
            ('programada', 'Programada'),
            ('aceptada', 'Aceptada'),
            ('realizada', 'Realizada'),
            ('cancelada', 'Cancelada'),
            ]
PRODUCTO_STATES = [
            ('sin_iniciar', 'Sin Iniciar'),
            ('entregado', 'En Proceso'),
            ('devuelto', 'Devuelto con Observaciones'),
            ('aceptado_condicionado', 'Aceptación Condicionada'),
            ('aceptado', 'Aceptado'),
            ('centro_documentacion', 'Enviado a Centro de Documentación')
            ]
TIPO_TRAMITE_STATE = [
            ('normal', 'Normal'),
            ('validacion', 'Validación'),
            ('mixto', 'Mixto'),
            ]
PROYECTO_STATES = [
            ('previo', 'Previo'),
            ('en_proceso', 'En Ejecución'),
            ('suspendido', 'Suspendido'),
            ('finalizado', 'Terminado'),
            ('archivado', 'Archivado'),
        ]
LISTA_TIPOS_REUNION = [
            ('mesa_trabajo', 'Mesas de Trabajo'),
            ('mesa_trabajo_instrumentos', 'Mesas de Trabajo (Instrumentos de Planeación y Movilidad)'),
        ]
LISTA_TIPOS_VISITA = [
            ('visita_inspeccion_final', 'Visitas de Inspección Final'),
            ('visita_topografica', 'Visitas Topográficas'),
            ('visita_obra', 'Visitas de Obra'),
            ('visita_especialidad', 'Visitas por Especialidad'),
            ('visita_entrega_simplificada', 'Visitas de Entrega Simplificada'),
        ]
REUNION_STATES = [
            ('registrada', 'Registrada'),
            ('confirmada', 'Confirmada'),
            ('atendida', 'Atendida'),
            ('cancelada', 'Cancelada'),
            ('no_asistio', 'No Asistió'),
        ]
LISTA_TIPOS_DOCUMENTOS = [
    ('autorizacion_urbanizador_tercero', 'Autorización del Urbanizador responsable a un tercero para adelantar el trámite.'),
    ('certificacion_pasos_ruta', 'Certificación de Transmilenio S.A. pasos ruta SITP y Alimentadores.'),
    ('diseno_senalizacion', 'Planos de diseño de señalización horizontal y vertical de la vía aprobado por SDM.'),
    ('diseno_alcantarillado', 'Planos de diseño de las redes de alcantarillado pluvial y sanitario, aprobado por EAAB-ESP.'),
    ('diseno_fotometrico', 'Planos de diseño fotométrico (alumbrado publico), aprobado por la UAESP y/o CODENSA.'),
    ('estudio_riesgo', 'Oficio, concepto técnico y de los estudios detallados de amenaza y riesgo, debidamente aprobados por el IDIGER.'),
    ('permiso_ocupacion_cauce', 'Permiso de ocupación de cauce, aprobado por SDA.'),
    ('permiso_tratamiento_vegetal', 'Permiso de tratamiento a la vegetación emitido por la SDA.'),
    ('accion_popular', 'Acción Popular'),
    ('informe_tecnico', 'Informe Técnico'),
    ('sin_definir', 'Sin Definir')
    ]
ESTADOS_FLUJO_APROBACION = [
                ('borrador', 'Borrador'),
                ('vobo_coordinador', 'Vobo Coordinador Zona'),
                ('vobo_lider', 'Vobo Lider Área'),
                ('vobo_abogado', 'Vobo Abogado'),
                ('vobo_director_tecnico', 'Vobo Director Técnico'),
            ]
ORIGEN_PROCESO = [
            ('urbanizador', 'Urbanizador'),
            ('accion_popular', 'Acción Popular'),
            ('simplificado', 'Simplificado'),
        ]
TIPO_DOCUMENTOS = [
    ('cc', 'Cédula de Ciudadanía'),
    ('nit', 'Número de Identificación Tributario')
]
TIPO_PROYECTO = [
    ('area_cesion', 'Área de Cesión Urbanistica'),
    ('instrumentos_planeacion', 'Instrumentos de Planeación y Movilidad'),
]

_logger = logging.getLogger(__name__)

class urbanizadores_proyecto(models.Model):
    _name = 'urbanizadores.proyecto'
    _description = 'Proyecto de Urbanismo a Cargo de Terceros - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']
    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        track_visibility='onchange',
        size=255,
    )
    state = fields.Selection(
        string='Estado',
        required=True,
        track_visibility='onchange',
        selection=PROYECTO_STATES,
        default='previo',
    )
    tipo_proyecto = fields.Selection(
        string='Tipo de Proyecto',
        required=True,
        track_visibility='onchange',
        selection=TIPO_PROYECTO,
        default='area_cesion',
    )
    user_id = fields.Many2one(
        string='Coordinador',
        required=False,
        track_visibility='onchange',
        comodel_name='res.users',
        ondelete='restrict',
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    user_apoyo_id = fields.Many2one(
        string='Apoyo',
        required=False,
        track_visibility='onchange',
        comodel_name='res.users',
        ondelete='restrict',
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    urbanizadora_id = fields.Many2one(
        string='Urbanizador Responsable',
        required=False,
        track_visibility='onchange',
        comodel_name='res.partner',
        ondelete='restrict',
        domain="[('tipo_persona','=','jur')]",
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    tercero_urbanizadora_id = fields.Many2one(
        string='Urbanizador Responsable',
        required=False,
        track_visibility='onchange',
        comodel_name='urbanizadores.tercero',
        ondelete='restrict',
        # domain="[('tipo_persona','=','jur')]",
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    constructora_id = fields.Many2one(
        string='Constructor Responsable',
        required=False,
        track_visibility='onchange',
        comodel_name='res.partner',
        ondelete='restrict',
        domain="[('tipo_persona','=','jur')]",
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    tercero_constructora_id = fields.Many2one(
        string='Constructor Responsable',
        required=False,
        track_visibility='onchange',
        comodel_name='urbanizadores.tercero',
        ondelete='restrict',
        # domain="[('tipo_persona','=','jur')]",
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    fecha_inicio_proceso = fields.Date(
        string='Fecha de Inicio del Proceso',
        required=False,
        track_visibility='onchange',
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    direccion = fields.Char(
        string='Dirección',
        required=False,
        track_visibility='onchange',
        size=255,
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    resolucion_urbanismo_id = fields.Many2one(
        string='Resolución de Urbanismo',
        required=False,
        readonly=True,
        comodel_name='urbanizadores.proyecto.resolucion_urbanismo',
        ondelete='restrict',
        compute='_compute_resolucion_urbanismo_id',
        store=True,
    )
    localidad_id = fields.Many2one(
        string='Localidad',
        required=False,
        track_visibility='onchange',
        comodel_name='res.country.state.city.district',
        ondelete='restrict',
        readonly=True,
        states={
            'previo': [('readonly', False)],
        },
    )
    descripcion = fields.Text(
        string='Descripción del Objeto de la Licencia',
        required=False,
        readonly=True,
        states={
            'previo': [('readonly', False)],
        },
    )
    alcance_proceso = fields.Selection(
        string='Alcance del Proceso',
        required=False,
        track_visibility='onchange',
        help='''TOTAL: Corresponde a aquellos proyectos que ingresaron al IDU, respetando cada una de las etapas del proceso, es decir: Estudios y Diseños, Ejecución de Obras y Recibo de Obras.
PARCIAL: Corresponde a aquellos proyectos que ingresaron al IDU, sin respetar las etapas del proceso, es decir, con obras de cesión en ejecución o terminadas, por lo que aplica la validación de los Estudios y Diseños y de las obras ejecutadas, como requisito para el Recibo de Obras.''',
        selection=[
            ('total', 'Total'),
            ('parcial', 'Parcial'),
        ],
        default='total',
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    etapa_id = fields.Many2one(
        string='Etapa Actual',
        required=False,
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto.etapa',
        ondelete='restrict',
        readonly=True,
        domain="[('proyecto_id','=',id)]",
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    etapa_estado_id = fields.Many2one(
        string='Estado de la etapa',
        required=False,
        readonly=True,
        related='etapa_id.estado_id',
        comodel_name='urbanizadores.proyecto.etapa.estado',
        ondelete='restrict',
    )
    reunion_ids = fields.One2many(
        string='Reuniones',
        required=False,
        comodel_name='urbanizadores.reunion',
        inverse_name='proyecto_id',
        ondelete='restrict',
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    visita_ids = fields.One2many(
        string='Visitas',
        required=False,
        comodel_name='urbanizadores.proyecto.visita',
        inverse_name='proyecto_id',
        ondelete='restrict',
        readonly=True,
    )
    etapa_ids = fields.One2many(
        string='Etapas',
        required=False,
        comodel_name='urbanizadores.proyecto.etapa',
        inverse_name='proyecto_id',
        ondelete='restrict',
    )
    chip = fields.Char(
        string='CHIP',
        required=False,
        size=255,
    )
    zona_id = fields.Many2one(
        string='Zona',
        required=False,
        readonly=False,
        store=True,
        comodel_name='urbanizadores.proyecto.zona',
        compute='_compute_zona',
    )
    email = fields.Char(
        string='Correo de Notificaciones',
        required=False,
        size=255,
    )
    cod_identificador = fields.Integer(
        string='Número de Proyecto',
        required=False,
        default=0,
    )
    etapa_estado_nombre = fields.Char(
        string='Nombre del Estado de la etapa',
        related='etapa_id.estado_id.name',
        store=True,
    )
    etapa_nombre = fields.Char(
        string='Nombre de la etapa',
        related='etapa_id.tipo_id.name',
        store=True,
    )
    componente_nombre = fields.Char(
        string='Nombre del componente',
        related='producto_ids.componente_id.name',
        store=True,
    )
    vigencia_resolucion = fields.Date(
        string='Vigencia de la Resolución',
        related='resolucion_urbanismo_id.fecha_vencimiento',
        store=True,
    )
    numero_plano_urbanismo = fields.Char(
        string='Número del Plano de Urbanismo',
    )
    porcentaje_avance = fields.Float(
        string="Porcentaje de Avance",
        compute="_compute_porcentaje_avance",
    )
    es_proyecto_georeferenciado = fields.Selection(
        string='Es Proyecto Georeferenciado?',
        selection=[
            ('si', 'Si'),
            ('no', 'No')
        ],
        default='no',
        required=True,
    )
    georeferenciado_por_id = fields.Many2one(
        string='Georeferenciado por',
        comodel_name='res.users',
        ondelete='restrict',
    )
    # Pestaña Detalles
    numero_expediente_orfeo = fields.Char(
        string='Número de Expediente ORFEO',
        required=False,
        track_visibility='onchange',
        size=50,
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    origen = fields.Selection(
        string='Origen del Proceso',
        required=False,
        track_visibility='onchange',
        help='''ACCIÓN POPULAR: Corresponde a aquellos proyectos que ingresaron al IDU, como consecuencia del cumplimiento del urbanizador al fallo de una Acción Popular.
URBANIZADOR: Corresponde a aquellos proyectos que ingresaron al IDU, como iniciativa voluntaria del urbanizador de cumplir con las etapas del proceso para la entrega y recibo de las áreas de cesión.''',
        selection=ORIGEN_PROCESO,
        default='urbanizador',
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    tipo_tramite = fields.Selection(
        string='Tipo de Tramite',
        required=False,
        track_visibility='onchange',
        selection=TIPO_TRAMITE_STATE,
        default='normal',
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    # Pestaña Aspectos Legales
    poliza_ejecucion_obras_ids = fields.One2many(
        string='Poliza Ejecucion Obras',
        comodel_name='urbanizadores.proyecto.poliza',
        inverse_name='proyecto_id',
    )
    presupuesto_preliminar_nombre = fields.Char(
        string='Presupuesto Preliminar',
        size=255,
    )
    presupuesto_preliminar_archivo = fields.Binary(
        track_visibility='onchange',
        attachment=True,
    )
    presupuesto_preliminar_valor = fields.Float(
        string="Valor",
        track_visibility='onchange',
    )
    fecha_aceptacion = fields.Date(
        string='Fecha Aceptación',
        track_visibility='onchange',
    )
    numero_oficio_aceptacion = fields.Char(
        string='Número de Oficio de Aceptación',
        size=20,
        track_visibility='onchange',
    )
    acto_administrativo_nombre = fields.Char(
        string='Acto Administrativo',
        size=255,
    )
    acto_administrativo_archivo = fields.Binary(
        track_visibility='onchange',
        attachment=True,
    )
    numero_radicado_acto_administrativo = fields.Char(
        string='Número de Radicado Acto Administrativo',
        size=20,
        track_visibility='onchange',
    )
    fecha_acto_administrativo = fields.Date(
        string='Fecha Acto Administrativo',
        track_visibility='onchange',
    )
    cronograma_nombre = fields.Char(
        string='Acto Administrativo',
        size=255,
    )
    cronograma_archivo = fields.Binary(
        track_visibility='onchange',
        attachment=True,
    )
    numero_radicado_cronograma = fields.Char(
        string='Número de Radicado Cronograma',
        size=20,
        track_visibility='onchange',
    )
    fecha_cronograma = fields.Date(
        string='Fecha Cronograma',
        track_visibility='onchange',
    )
    # Pestaña Tramos Cesión
    area_cesion_m2 = fields.Float(
        string='Área Total de Cesión (m2)',
        required=False,
        track_visibility='onchange',
        readonly=True,
        digits=(10, 2),
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
        compute='_compute_area_cesion_m2',
        store=True,
    )
    plano_urbanismo_filename = fields.Char(
        string='Plano de Urbanismo',
        required=False,
        invisible=True,
        size=255,
    )
    plano_urbanismo = fields.Binary(
        string='Plano',
        required=False,
        attachment=True,
    )
    cesion_ids = fields.One2many(
        string='Tramos de Cesión',
        required=False,
        comodel_name='urbanizadores.proyecto.cesion',
        inverse_name='proyecto_id',
        ondelete='restrict',
    )
    # Pestaña Normativa Urbana
    titular_urbanizador = fields.Char(
        string='Titular/Urbanizador',
        size=50,
        help="Titular según lo definido en el instrumento.",
        track_visibility='onchange',
    )
    tipo_documento_titular = fields.Selection(
        string='Tipo Documento Titular',
        selection=TIPO_DOCUMENTOS,
        default='cc'
    )
    numero_identificacion_titular = fields.Char(
        string='Número de Identificacion Titular/Urbanizador',
        size=13,
        help="Número de Identificación del Titular/Urbanizador.",
        track_visibility='onchange',
    )
    representante_legal_titular = fields.Char(
        string='Representante Legal Titular',
        size=50,
        help="Representante Legal según lo definido en el instrumento.",
        track_visibility='onchange',
    )
    tipo_documento_rep_legal_titular = fields.Selection(
        string='Tipo Documento Representante Legal',
        selection=TIPO_DOCUMENTOS,
        default='cc'
    )
    numero_identificacion_rep_legal_titular = fields.Char(
        string='Número de Identificacion Representante Titular',
        size=13,
        help="Número de Identificación del Representante Legal del Titular/Urbanizador.",
        track_visibility='onchange',
    )
    resolucion_urbanismo_ids = fields.One2many(
        string='Resoluciones de Urbanismo',
        required=False,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('required', True), ('readonly', False)],
        },
        comodel_name='urbanizadores.proyecto.resolucion_urbanismo',
        inverse_name='proyecto_id',
        ondelete='restrict',
        readonly=True,
    )
    # Pestaña Documentos Asociados
    documentos_asociados_ids = fields.One2many(
        string='Documentos Asociados',
        comodel_name='urbanizadores.documentos_asociados',
        inverse_name='proyecto_id',
        ondelete='restrict',
    )
    paz_y_salvo_ids = fields.One2many(
        string='Paz y Salvos',
        comodel_name='urbanizadores.proyecto.paz_y_salvo',
        inverse_name='proyecto_id',
        ondelete='restrict',
    )
    # Pestaña Registro/Oficios Memorandos
    oficio_rechazo_ids = fields.One2many(
        string='Oficios de Observación',
        required=False,
        readonly=True,
        comodel_name='urbanizadores.proyecto.oficio_rechazo',
        inverse_name='proyecto_id',
        ondelete='restrict',
    )
    # Pestaña Cronograma
    cronograma_urbanizador_ids = fields.One2many(
        comodel_name='urbanizadores.proyecto.cronograma',
        inverse_name='proyecto_id',
    )
    cronograma_urbanizador_actividad_ids = fields.One2many(
        comodel_name='urbanizadores.proyecto.cronograma.actividad',
        inverse_name='proyecto_id',
    )
    # Pestaña Listado de Productos
    producto_ids = fields.One2many(
        string='Productos',
        required=False,
        readonly=True,
        comodel_name='urbanizadores.proyecto.producto',
        inverse_name='proyecto_id',
        ondelete='restrict',
        # compute='_compute_producto'
    )
    # Pestaña Cierre Documental
    ## Grupo Acta
    acta_final = fields.Binary(
        string='Acta Final',
        required=False,
        attachment=True,
    )
    acta_final_filename = fields.Char(
        string='Acta Final Nombre',
        required=False,
        invisible=True,
        size=255,
    )
    es_firma_exitosa = fields.Boolean(
        string='Fue firmado exitosamente?',
        default=False,
    )
    acta_final_firmada = fields.Binary(
        required=False,
        attachment=True,
    )
    acta_final_firmada_filename = fields.Char(
        string='Acta Final Firmada',
        required=False,
        invisible=True,
        size=255,
    )
    fecha_firma_acta = fields.Date(
        string='Fecha de Firma del Acta',
        required=False,
        track_visibility='onchange',
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    registro_fotografico = fields.Binary(
        string='Registro Fotográfico',
        required=False,
        attachment=True,
    )
    registro_fotografico_filename = fields.Char(
        string='Registro Fotográfico Nombre',
        required=False,
        invisible=True,
        size=255,
    )
    ## Grupo Poliza
    aseguradora_id = fields.Many2one(
        string='Compañia Aseguradora',
        required=False,
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto.aseguradora',
        ondelete='restrict',
    )
    numero_poliza = fields.Char(
        string='Número de Poliza',
        size=255,
    )
    vigencia_poliza_inicio = fields.Date(
        string='Vigencia Poliza Inicio',
        required=False,
        track_visibility='onchange',
    )
    vigencia_poliza_fin = fields.Date(
        string='Vigencia Poliza Fin',
        required=False,
        track_visibility='onchange',
    )
    valor_poliza = fields.Float(
        string='Valor de la Poliza',
    )
    poliza = fields.Binary(
        attachment=True,
    )
    poliza_filename = fields.Char(
        string='Poliza de Estabilidad de Obras',
        invisible=True,
        size=255,
    )
    constancia_poliza = fields.Binary(
        string='Acta de Seguimiento a Polizas',
        required=False,
        attachment=True,
    )
    constancia_poliza_filename = fields.Char(
        required=False,
        invisible=True,
        size=255,
    )
    ## Grupo Presupuesto
    presupuesto = fields.Float(
        string="Presupuesto de Obras",
    )
    fecha_aprobacion = fields.Date(
        string='Fecha de Aprobación',
    )
    archivo_presupuesto = fields.Binary(
        string='Archivo del Presupuesto',
        attachment=True,
    )
    archivo_presupuesto_filename = fields.Char(
        string='Presupuesto',
        size=255,
    )
    oficio_aceptacion_numero = fields.Char(
        string='Número Oficio de Aceptación',
        required=False,
        track_visibility='onchange',
        size=14,
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    # Grupo DADEP
    oficio_envio_dadep_numero = fields.Char(
        string='Número de Oficio Envío de Constancia al Urbanizador/DADEP/SDM/SDP',
        required=False,
        track_visibility='onchange',
        size=14,
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    oficio_envio_dadep_fecha = fields.Date(
        string='Fecha',
        required=False,
        track_visibility='onchange',
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
        },
    )
    ## Grupo Centro de Documentacion
    oficio_constancia_entrega_recibo_numero = fields.Char(
        string='Número de Memorando al Centro de Documentación',
        required=False,
        track_visibility='onchange',
        size=14,
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
            'finalizado': [('readonly', False)],
        },
    )
    oficio_constancia_entrega_recibo_fecha = fields.Date(
        string='Fecha',
        required=False,
        track_visibility='onchange',
        readonly=True,
        states={
            'previo': [('readonly', False)],
            'en_proceso': [('readonly', False)],
            'finalizado': [('readonly', False)],
        },
    )
    url_repositorio_institucional = fields.Char(
        string='Url Repositorio Institucional',
        track_visibility='onchange',
    )
    # Pestaña Observaciones
    observacion_ids = fields.One2many(
        string='Observaciones',
        required=False,
        comodel_name='urbanizadores.proyecto.observacion',
        inverse_name='proyecto_id',
        ondelete='restrict',
        readonly=False,
    )
    # Pestaña Flujo de Aprobacion
    flujo_aprobacion_ids = fields.One2many(
        string='Seccion FLujo Aprobacion',
        comodel_name='urbanizadores.proyecto.aprobacion',
        inverse_name='proyecto_id',
    )
    # Banderas
    boton_generar_certificado = fields.Boolean(
        compute='_compute_boton_generar_certificado',
        )
    iniciado_proceso_generar_certificado = fields.Boolean(
        default=False,
        )
    seccion_flujo_aprobacion_visible = fields.Boolean(
        compute='_compute_seccion_flujo_aprobacion_visible',
    )
    estado_flujo_aprobacion = fields.Selection(
        string='Estado FLujo Aprobacion',
        selection=ESTADOS_FLUJO_APROBACION,
        default='borrador',
    )
    tipo_constancia = fields.Selection(
        string='Tipo Constancia',
        selection=[
            ('simplificado', 'Simplificado'),
            ('regular', 'Regular'),
            ('instrumento', 'Instrumento'),
        ],
        compute='_compute_tipo_constancia',
    )
    bandera_usuario_habilitado_flujo = fields.Boolean(
        compute='_compute_usuario_habilitado_flujo'
    )
    bandera_usuario_coordinador = fields.Boolean(
        compute='_compute_usuario_coordinador'
    )
    bandera_usuario_jefe = fields.Boolean(
        compute='_compute_usuario_jefe'
    )
    hash_proyecto = fields.Char(
        size=21,
    )
    hash_visita = fields.Char(
        size=21,
    )
    hash_reunion = fields.Char(
        size=21,
    )
    hash_producto = fields.Char(
        size=21,
    )
    hash_oficio_rechazo = fields.Char(
        size=21,
    )
    hash_cesion = fields.Char(
        size=21,
    )
    hash_elemento = fields.Char(
        size=21,
    )
    hash_estructura = fields.Char(
        size=21,
    )
    hash_resolucion_urbanismo = fields.Char(
        size=21,
    )
    #INFO Reportes previamente generados y que guardo, para evitar su regeneracion, si no han cambiado
    reporte_estado_actual_contenido = fields.Binary(
        attachment=True
    )
    reporte_estado_actual_nombre = fields.Char(
        string='Reporte Estado Actual Proyecto',
    )

    # -------------------
    # methods
    # -------------------

    @api.one
    def _compute_producto(self):
        """ Calcula los productos asociados al proyecto
        """
        producto_ids = self.env['urbanizadores.proyecto.oficio_rechazo'].search([('proyecto_id', '=', self.id)])
        self.producto_ids = [(6, 0, producto_ids.ids)]

    @api.one
    def _compute_tipo_constancia(self):
        if self.tiene_instrumento == 'si':
            self.tipo_constancia = 'instrumento'
        else:
            if self.origen == 'simplificado':
                self.tipo_constancia = 'simplificado'
            else:
                self.tipo_constancia = 'regular'

    @api.one
    def _compute_usuario_jefe(self):
        if self.env.user.has_group('base_idu.group_jefe_dependencia'):
            self.bandera_usuario_jefe = True
        else:
            self.bandera_usuario_jefe = False

    @api.one
    def _compute_usuario_habilitado_flujo(self):
        ultima_aprobacion = self.flujo_aprobacion_ids.sorted(lambda a: a.create_date, reverse=True)
        if ultima_aprobacion:
            ultima_aprobacion = ultima_aprobacion[0]
            if self.env.uid == ultima_aprobacion.proximo_usuario_aprobacion_id.id:
                self.bandera_usuario_habilitado_flujo = True
            else:
                self.bandera_usuario_habilitado_flujo = False

    @api.one
    def _compute_usuario_coordinador(self):
        if (self.user_id and self.env.uid == self.user_id.id):
            self.bandera_usuario_coordinador = True
        else:
            self.bandera_usuario_coordinador = False

    @api.multi
    def ver_proyecto_visor(self):
        url = self.env['ir.config_parameter'].sudo().get_param('urbanizadores_idu.url_proyectos_sigidu')
        if not url:
            raise ValidationError("No se ha configurado la url del servicio de SIGIDU para urbanizadores. Por favor, informelo a soporte.")
        return {
            'type' : 'ir.actions.act_url',
            'url': '{},{}'.format(url, self.id),
            'target': 'new',
        }

    @api.one
    def unlink(self):
        self.check_access_rights('unlink')
        self.check_access_rule('unlink')
        for reunion in self.reunion_ids:
            reunion.unlink()
        for visita in self.visita_ids:
            visita.unlink()
        for resolucion in self.resolucion_urbanismo_ids:
            resolucion.unlink()
        for cesion in self.cesion_ids:
            cesion.unlink()
        for etapa in self.etapa_ids:
            etapa.unlink()
        for observacion in self.observacion_ids:
            observacion.unlink()
        res = super(urbanizadores_proyecto, self).unlink()
        return res

    @api.one
    @api.depends('user_id', 'oficio_rechazo_ids')
    def _compute_boton_generar_certificado(self):
        # Si el usuario de la sesion es el coordinador del proyecto o es el administrador del modulo, le permite generar el certificado
        if (self.user_id.id == self.env.uid or self.env.user.has_group('urbanizadores_idu.administrador')) and self.estado_flujo_aprobacion not in ('vobo_coordinador', 'vobo_lider', 'vobo_abogado', 'vobo_director_tecnico'):
        # TODO Se debe verificar que todos los oficios esten aceptados, la poliza no importa, ademas q dependiendo del tipo de certificado se tienen unas codiciones u otras.
        # oficios = self.oficio_rechazo_ids.filtered()
            self.boton_generar_certificado = True
        else:
            self.boton_generar_certificado = False

    @api.one
    def _compute_seccion_flujo_aprobacion_visible(self):
        # Si ya se inicio el flujo de aprobacion para generar el certificado y el usuario actual es el coordinador del proyecto o es el administrador del modulo, debe mostrar la pestaña del flujo de aprobacion.
        ultima_aprobacion = self.flujo_aprobacion_ids.sorted(lambda a: a.create_date, reverse=True)
        if ultima_aprobacion:
            ultima_aprobacion = ultima_aprobacion[0]
        usuario_vobo = ultima_aprobacion.proximo_usuario_aprobacion_id.id
        if (self.env.uid in (self.user_id.id, self.user_apoyo_id.id, usuario_vobo) or self.env.user.has_group('urbanizadores_idu.administrador')) and self.iniciado_proceso_generar_certificado or self.estado_flujo_aprobacion == 'vobo_director_tecnico':
        # TODO Se debe verificar que todos los oficios esten aceptados, la poliza no importa, ademas q dependiendo del tipo de certificado se tienen unas codiciones u otras.
        # oficios = self.oficio_rechazo_ids.filtered()
            self.seccion_flujo_aprobacion_visible = True
        else:
            self.seccion_flujo_aprobacion_visible = False

    @api.multi
    def generar_certificado(self):
        # FIXME Verificar porque no se esta activando
        self.iniciado_proceso_generar_certificado = True
        ruta_base = 'urbanizadores_ruta_plantillas'
        formato_reporte = 'docx'
        plantilla = ''
        datos = {}
        jefe_id = self.env['hr.department'].search([('abreviatura', '=', 'DTAI')]).manager_id.user_id
        lider_grupo_id = self.env['ir.config_parameter'].sudo().get_param('urbanizadores.proyectos.lider') or 0
        lider_grupo_nombre = ''
        if lider_grupo_id and lider_grupo_id.isdigit():
            try:
                lider_grupo_nombre = self.env['res.users'].sudo().browse(int(lider_grupo_id)).name
            except Exception:
                raise ValidationError("No se ha configurado el lider del grupo en el módulo")

        #INFO Las actas de entrega implificada no es obligatoria la poliza, en las demas si
        if self.tipo_constancia != 'simplificado':
            if not self.vigencia_poliza_inicio:
                raise ValidationError("Se debe diligenciar la información relacionada con la poliza.")

            datos.update(
                {
                    'poliza_inicio_dias_numero': datetime.strptime(self.vigencia_poliza_inicio, "%Y-%m-%d").day,
                    'poliza_inicio_dias_letras': numeros_a_letras(str(datetime.strptime(self.vigencia_poliza_inicio, "%Y-%m-%d").day)),
                    'poliza_inicio_mes': datetime.strptime(self.vigencia_poliza_inicio, "%Y-%m-%d").strftime("%B"),
                    'poliza_inicio_agno': datetime.strptime(self.vigencia_poliza_inicio, "%Y-%m-%d").year,
                    'numero_poliza': self.numero_poliza or 0,
                    'aseguradora_poliza': self.aseguradora_id.name or '',
                    'valor_poliza_numero': self.valor_poliza or 0,
                    'valor_poliza_letras': numeros_a_letras(str(int(self.valor_poliza) or 0)),
                }
            )

        fecha_actual = datetime.now()
        datos.update(
            {
                'dias_numero': fecha_actual.day,
                'dias_letras': numeros_a_letras(str(fecha_actual.day)),
                'mes_letras': fecha_actual.strftime("%B"),
                'agno_numero': fecha_actual.year,
                'director_tecnico_nombre':jefe_id.name or '',
                'coordinador_zona': self.user_id.name or '',
                'zona': self.zona_id.name or '',
                'lider_grupo': lider_grupo_nombre,
                'proyecto_nombre':self.name or '',
                'resoluciones_urbanismo':[
                    {
                        'numero':resolucion.name or '',
                        'fecha':resolucion.fecha_expedicion or '',
                        'autoridad':resolucion.autoridad_id.name or '',
                        'objeto':resolucion.objeto or '',
                    } for resolucion in self.resolucion_urbanismo_ids
                ],

                'observaciones':[
                    {'observacion': 'Las actas de recibo de la infraestructura y paz y salvos de las empresas de servicios públicos domiciliarios.'},
                    {'observacion': 'El Urbanizador responsable, se compromete a realizar la entrega a satisfacción ante la Secretaría.'}
                ],
                'titular_urbanizador':self.titular_urbanizador or '',
                'tipo_identificacion_titular': 'CC' if self.tipo_documento_titular == 'cc' else 'NIT',
                'numero_identificacion_titular':self.numero_identificacion_titular or '',
                'numero_plano_urbanismo':self.numero_plano_urbanismo or '',
                'cesiones':[
                    {
                        'cesion':cesion.descripcion or '',
                        'tipo_via':cesion.tipo_via or '',
                        'mojones':cesion.civ or '',
                        'area':cesion.area_cesion_m2 or 0,
                    } for cesion in self.cesion_ids
                ],
                'cesion_area_total': self.area_cesion_m2 or 0,
            }
        )

        datos['observaciones'].extend([
            {
                'observacion': observacion.name or '',
            } for observacion in self.observacion_ids
        ])

        datos['estudios_disenos'] = [
                {
                    'componente': producto.componente_id.name or '',
                    'producto': producto.tipo_id.name or '',
                    'oficio': producto.ultimo_numero_oficio or '',
                    'fecha': producto.ultima_fecha or '',
                } for producto in self.producto_ids.filtered(lambda p: p.etapa_id.tipo_id.name == 'Estudios y Diseños' and p.state == 'aceptado')
        ]
        datos['ejecucion_obras'] = [
                {
                    'componente': producto.componente_id.name or '',
                    'producto': producto.tipo_id.name or '',
                    'oficio': producto.ultimo_numero_oficio or '',
                    'fecha': producto.ultima_fecha or '',
                } for producto in self.producto_ids.filtered(lambda p: p.etapa_id.tipo_id.name == 'Ejecución de Obras' and p.state == 'aceptado')
        ]
        datos['recibo_obras'] = [
                {
                    'componente': producto.componente_id.name or '',
                    'producto': producto.tipo_id.name or '',
                    'oficio': producto.ultimo_numero_oficio or '',
                    'fecha': producto.ultima_fecha or '',
                } for producto in self.producto_ids.filtered(lambda p: p.etapa_id.tipo_id.name == 'Recibo de Obras' and p.state == 'aceptado')
        ]

        url_consulta = self.env['ir.config_parameter'].sudo().get_param('urbanizadores_idu.url_informacion_proyecto')
        url_consulta_proyecto = "{}/{}".format(url_consulta, base64.b64encode(str(self.id)))
        datos['constancia_qr'] = generar_codigo_qr(url_consulta_proyecto, carpeta_generacion='/tmp/imagenes', nombre_archivo='qr.png') or ''

        try:
            firma_jefe = self.env['firma_digital_idu.rubrica'].sudo().search([('funcionario_id', '=', jefe_id.id)])
            ruta_imagen_firma_jefe = '/tmp/imagenes/firma.png'

            with open(ruta_imagen_firma_jefe, 'wb') as firma:
                firma.write(base64.b64decode(firma_jefe.imagen_firma))
        except Exception:
            raise ValidationError("No esta configurada la rubrica del jefe del área")

        datos['rubrica_jefe'] = ruta_imagen_firma_jefe or ''
        planos_record = self.producto_ids.filtered(lambda p: p.etapa_id.tipo_id.name == 'Recibo de Obras' and p.tipo_id.name == 'Planos Record' and p.state == 'aceptado')
        datos['planos_record_radicado'] = planos_record.ultimo_numero_oficio or ''
        datos['planos_record_fecha'] = planos_record.ultima_fecha or ''
        datos['presupuesto_ejecutado_valor_numero'] = self.presupuesto or 0
        datos['presupuesto_ejecutado_valor_letras'] = numeros_a_letras(str(int(self.presupuesto) or 0))

        if self.tipo_constancia == 'regular':
            plantilla = 'plantilla_entrega_regular.odt'
        elif self.tipo_constancia == 'simplificado':
            plantilla = 'plantilla_entrega_simplificada.odt'
        else:
            plantilla = 'plantilla_entrega_instrumentos_urbanos.odt'
            datos.update(
                {
                    'poliza_ejecucion_obras':[

                        {
                            'tipo':poliza.tipo_poliza or '',
                            'numero':poliza.name or '',
                            'fecha':poliza.fecha or '',
                            'aseguradora':poliza.aseguradora_id.name or '',
                            'desde':poliza.vigencia_desde or '',
                            'hasta':poliza.vigencia_hasta or '',
                            'oficio_aceptacion':poliza.oficio_aceptacion or '',
                        } for poliza in self.poliza_ejecucion_obras_ids
                    ],
                    'paz_y_salvos': [
                        {
                            'autoridad': paz_y_salvo.esp_id.name if paz_y_salvo.esp_id else paz_y_salvo.autoridad_id.name,
                            'acto_administrativo': paz_y_salvo.acto_administrativo,
                            'fecha': paz_y_salvo.fecha,
                        } for paz_y_salvo in self.paz_y_salvo_ids
                    ],
                }
            )

        if datos and plantilla:
            reporte = Reporte(
                self,
                ruta_base,
                plantilla,
                datos,
            )

            #INFO Inicializo el flujo de aprobacion
            self.estado_flujo_aprobacion = 'borrador'
            reporte.generar_reporte(formato_reporte)
            return reporte.descargar_reporte("Constancia {} - {}".format(self.name, datetime.today().strftime("%Y-%m-%d %H.%M.%S")))

    @api.onchange('registro_fotografico_filename')
    def onchange_registro_fotografico(self):
        if not validar_formato(self.registro_fotografico_filename, ('pdf')):
            self.registro_fotografico = ''
            self.registro_fotografico_filename = ''
            return {'warning': {
                'title': ('Advertencia'),
                'message': ('Solo puede adjuntar archivos en formato PDF.')
            }}

    @api.model
    def buscar_o_crear(self, datos):
        """Busca si existe un proyecto a partir del número resolución urbanismo, si existe lo retorna, sinó lo crea desde 0"""
        proyecto = None
        resolucion = None
        if 'proyecto-nombre' in datos and 'resolucion-urbanismo' in datos and len(datos['proyecto-nombre']) > 1 and len(datos['resolucion-urbanismo']) > 1:
            proyecto = self.search([
                # '&',
                ('name', '=', datos['proyecto-nombre'].strip()),
                # ('resolucion_urbanismo_id.name', '=', datos['resolucion-urbanismo']),
                ])
        elif 'proyecto-nombre' in datos and datos['proyecto-nombre'] :
            proyecto = self.search([
                ('name', 'ilike', datos['proyecto-nombre']),
                ])
        if proyecto:
            return proyecto[0]
        elif 'proyecto-nombre' in datos and 'proyecto-direccion' in datos and 'proyecto-localidad' in datos and 'resolucion-urbanismo' in datos and 'urbanizador-nombre' in datos \
            and 'urbanizador-nit' in datos and 'constructor-nombre' in datos and 'constructor-nit' in datos:
            localidad_id = 0
            if datos.get('proyecto-localidad', False):
                localidad = self.env['res.country.state.city.district'].search([('name', '=', datos.get('proyecto-localidad').upper().strip())])
                localidad_id = localidad[0].id if localidad else 0
            urbanizadora = self.buscar_o_crear_organizacion(datos['urbanizador-nombre'], datos['urbanizador-nit'])
            constructora = self.buscar_o_crear_organizacion(datos['constructor-nombre'], datos['constructor-nit'])
            proyecto = self.create({
                'name': datos['proyecto-nombre'],
                'direccion': datos['proyecto-direccion'],
                'resolucion_urbanismo_ids': [
                    (0, False, {'name': datos['resolucion-urbanismo']})
                ],
                'constructora_id': constructora.id,
                'urbanizadora_id': urbanizadora.id,
                'email': datos['email'],
                'localidad_id': localidad_id,
            })
            return proyecto

    @api.model
    def buscar_o_crear_organizacion(self, name, documento_numero):
        """Busca o crea un urbanizador.tercero para que sea utilizado como urbanizador o constructor"""
        partner_model = self.env['urbanizadores.tercero']
        partner = partner_model.search([
            '&',
                ('tipo_persona', '=', 'jur'),
                '|',
                    ('identificacion_numero', '=', documento_numero),
                    ('nombres', 'ilike', name),
            ])
        if not partner:
            partner = partner_model.with_context(mail_create_nolog=True).create({
                'nombres': name,
                'tipo_persona': 'jur',
                'identificacion_numero': documento_numero,
            })
        if partner:
            return partner[0]
        return partner

    @api.one
    @api.depends('localidad_id')
    def _compute_zona(self):
        modelo_zona = self.env['urbanizadores.proyecto.zona']
        for zona in modelo_zona.search([]):
            if self.localidad_id in zona.localidad_ids:
                self.zona_id = zona.id
                break

    @api.one
    @api.depends('cesion_ids.area_cesion_m2')
    def _compute_area_cesion_m2(self):
        total = 0
        for tramo_cesion in self.cesion_ids:
            total += tramo_cesion.area_cesion_m2
        self.area_cesion_m2 = total

    @api.one
    @api.depends('resolucion_urbanismo_ids', 'resolucion_urbanismo_ids',)
    def _compute_resolucion_urbanismo_id(self):
        resolucion = self.env['urbanizadores.proyecto.resolucion_urbanismo'].search(
            [('proyecto_id', '=', self.id)],
            order='fecha_expedicion DESC', limit=1,
        )
        if resolucion:
            self.resolucion_urbanismo_id = resolucion.id
        else:
            self.resolucion_urbanismo_id = False

    @api.one
    @api.depends('etapa_ids.producto_ids.state')
    def _compute_porcentaje_avance(self):
        #INFO Cantidad de etapas reales, por lo cual no se tienen en cuenta las etapas que no sean: Estudios y Diseños, Ejecución de Obras, Recibo de Obras
        etapas = self.etapa_ids.filtered(lambda e: e.tipo_id.name in ['Estudios y Diseños', 'Ejecución de Obras', 'Recibo de Obras'])
        suma_porcentaje_avance_etapas = 0

        for etapa in etapas:
            suma_porcentaje_avance_etapas += etapa.porcentaje_avance

        self.porcentaje_avance = suma_porcentaje_avance_etapas / len(etapas) if etapas else 0

    @api.model
    def _cron_etapa_finalizada_sin_iniciar_siguiente(self):
        '''Metodo para el envio de recordatorios sobre las etapas que ya finalizaron, pero que no se ha iniciado con la siguiente.'''
        _logger.info("Verificando que la etapa de los proyectos haya finalizado y no se haya iniciado la siguiente etapa.")
        proyectos = self.search([('state', '=', 'en_proceso'), ])
        direcciones = ''
        datos = {'Proyecto':[], 'Zona':[], 'Etapa Anterior':[], 'Estado Etapa Anterior':[], 'Etapa Actual':[], 'Estado Etapa Actual':[]}

        for proyecto in proyectos:
            if proyecto and proyecto.etapa_ids:
                lista_etapas_ordenadas = proyecto.etapa_ids.sorted(key=lambda etapa: etapa.tipo_id.sequence)
                lista_etapas_ordenadas = lista_etapas_ordenadas[:3]
                etapa_anterior = None
                etapa_actual = None

                for etapa in lista_etapas_ordenadas:
                    if not etapa_anterior:
                        etapa_anterior = etapa
                        continue
                    if etapa_anterior.estado_id.name and not etapa_actual:
                        etapa_actual = etapa
                    if etapa_anterior.estado_id.name == 'Terminado' and etapa_actual.estado_id.name == 'Sin Iniciar':
                        datos['Proyecto'].append(proyecto.name)
                        datos['Zona'].append(proyecto.zona_id.name)
                        datos['Etapa Anterior'].append(etapa_anterior.tipo_id.name)
                        datos['Estado Etapa Anterior'].append(etapa_anterior.estado_id.name)
                        datos['Etapa Actual'].append(etapa_actual.tipo_id.name)
                        datos['Estado Etapa Actual'].append(etapa_actual.estado_id.name)

        #INFO Verifico que el diccionario contenga datos y no solo las cabeceras
        contenido_archivo = None
        if datos['Proyecto']:
            formato_titulo = {'bold':True, 'font_size':14, 'font_color':'black', 'align': 'center', 'valign': 'vcenter', 'text_justlast':True, 'text_wrap':True}
            formato_subtitulo = {'bold':True, 'font_size':12, 'align': 'center', 'valign': 'vcenter', 'text_wrap':True, 'text_justlast':True}
            formato_datos = {'valign': 'vcenter', 'font_size':10, 'align': 'center', 'text_wrap':True, }

            contenido_archivo = generar_archivo_excel(
                titulo='Listado de Proyectos que no han iniciado la siguiente etapa',
                datos=datos,
                formato_titulo=formato_titulo,
                altura_celda_titulo=60,
                formato_subtitulo=formato_subtitulo,
                altura_celda_subtitulo=40,
                formato_datos=formato_datos,
                altura_celda_datos=30
            )

        if contenido_archivo:
            try:
                administradores = self.env.ref('urbanizadores_idu.administrador').users
                plantilla = self.env.ref('urbanizadores_idu.plantilla_recordatorio_etapa_finalizada_no_continuo')
                for administrador in administradores:
                    direcciones += "{}, ".format(administrador.email)
                ctx = self.env.context.copy()
                ctx['direcciones_destinatario'] = direcciones

                enviar_mensaje_con_plantilla(
                    objeto=proyecto,
                    contexto=ctx,
                    plantilla=plantilla,
                    nombre_adj='Proyectos.xlsx',
                    contenido_adj=contenido_archivo
                    )
            except Exception as e:
                _logger.exception("No se pudo enviar el mensaje a: {0}, debido a {1}".format(direcciones, str(e)))
        _logger.info("Terminando de verificar que la etapa de los proyectos haya finalizado y no se haya iniciado la siguiente etapa.")

    @api.model
    def _cron_proyectos_terminados_componentes_sin_terminar(self):
        '''Metodo para el envio de recordatorios sobre los proyectos terminados, pero con alguno de sus componentes sin terminar.'''
        _logger.info("Verificando proyectos en estado terminado pero con componentes sin terminar.")
        proyectos = self.search([('state', '=', 'finalizado'), ], order='name ASC')
        ETAPAS_VALIDAS = ('Estudios y Diseños', 'Ejecución de Obras', 'Recibo de Obras')
        datos = {'Proyecto':[], 'Zona':[], 'Etapa':[], 'Estado Etapa':[], 'Componente':[], 'Producto':[], 'Estado Producto':[]}
        direcciones = ''

        for proyecto in proyectos:
            if proyecto.etapa_ids:
                etapas = proyecto.etapa_ids.filtered(lambda e: e.tipo_id.name in ETAPAS_VALIDAS).sorted(key=lambda e:e.tipo_id.sequence)
            else:
                etapas = ()

            for etapa in etapas:
                if etapa.estado_id.name != 'Terminado':
                    datos['Proyecto'].append(proyecto.name)
                    datos['Zona'].append(proyecto.zona_id.name)
                    datos['Etapa'].append(etapa.tipo_id.name)
                    datos['Estado Etapa'].append(etapa.estado_id.name)
                for producto in etapa.producto_ids:
                    if producto.state != 'aceptado':
                        datos['Proyecto'].append(proyecto.name)
                        datos['Zona'].append(proyecto.zona_id.name)
                        datos['Etapa'].append(etapa.tipo_id.name)
                        datos['Estado Etapa'].append(etapa.estado_id.name)
                        datos['Componente'].append(producto.componente_id.name)
                        datos['Producto'].append(producto.tipo_id.name)
                        datos['Estado Producto'].append(obtener_etiqueta_lista_select(PRODUCTO_STATES, producto.state))

        #INFO Verifico que el diccionario contenga datos y no solo las cabeceras
        contenido_archivo = None
        if datos['Proyecto']:
            formato_titulo = {'bold':True, 'font_size':14, 'font_color':'black', 'align': 'center', 'valign': 'vcenter', 'text_justlast':True, 'text_wrap':True}
            formato_subtitulo = {'bold':True, 'font_size':12, 'align': 'center', 'valign': 'vcenter', 'text_wrap':True, }
            formato_datos = {'valign': 'vcenter', 'font_size':10, 'align': 'center', 'text_wrap':True, }

            contenido_archivo = generar_archivo_excel(
                titulo='Listado de Proyectos Terminados, con productos sin terminar',
                datos=datos,
                formato_titulo=formato_titulo,
                altura_celda_titulo=60,
                formato_subtitulo=formato_subtitulo,
                altura_celda_subtitulo=40,
                formato_datos=formato_datos,
                altura_celda_datos=30,
                ancho_col=20
            )
        if contenido_archivo:
            try:
                administradores = self.env.ref('urbanizadores_idu.administrador').users
                plantilla = self.env.ref('urbanizadores_idu.plantilla_recordatorio_proyectos_terminados_componentes_no')

                for administrador in administradores:
                    direcciones += "{}, ".format(administrador.email)

                ctx = self.env.context.copy()
                ctx['direcciones_destinatario'] = direcciones

                enviar_mensaje_con_plantilla(
                    objeto=proyecto,
                    contexto=ctx,
                    plantilla=plantilla,
                    nombre_adj='Proyectos.xlsx',
                    contenido_adj=contenido_archivo
                    )
            except Exception as e:
                _logger.exception("No se pudo enviar el mensaje a: {0}, debido a {1}".format(direcciones, str(e)))
        _logger.info("Terminando de verificar los proyectos en estado terminado, pero con componentes sin terminar.")

    @api.model
    def _cron_proyectos_terminados_sin_acta(self):
        '''Metodo para el envio de recordatorios sobre los proyectos terminados, con todas sus etapas terminadas y con cada uno de sus productos aceptados, pero que no tienen acta de finalizacion cargada.'''
        _logger.info("Verificando proyectos en estado terminado pero que no tienen acta final.")
        proyectos = self.search([('state', '=', 'finalizado'), ('acta_final', '=', False), ], order='name ASC')
        datos = {'Proyecto':[], 'Zona':[], 'Localidad':[], 'Area':[], }
        direcciones = ''

        for proyecto in proyectos:
            proyecto_totalmente_terminado = True
            for etapa in proyecto.etapa_ids:
                if not proyecto_totalmente_terminado:
                    break
                if etapa.estado_id.name != 'Terminado':
                    proyecto_totalmente_terminado = False
                    break
                for producto in etapa.producto_ids:
                    if not proyecto_totalmente_terminado:
                        break
                    if producto.state != 'aceptado':
                        proyecto_totalmente_terminado = False
                        break
            if proyecto_totalmente_terminado:
                datos['Proyecto'].append(proyecto.name)
                datos['Zona'].append(proyecto.zona_id.name)
                datos['Localidad'].append(proyecto.localidad_id.name or ' ')
                datos['Area'].append(proyecto.area_cesion_m2)

        #INFO Verifico que el diccionario contenga datos y no solo las cabeceras
        contenido_archivo = None
        if datos['Proyecto']:
            formato_titulo = {'bold':True, 'font_size':14, 'font_color':'black', 'align': 'center', 'valign': 'vcenter', 'text_justlast':True, 'text_wrap':True}
            formato_subtitulo = {'bold':True, 'font_size':12, 'align': 'center', 'valign': 'vcenter', 'text_wrap':True, }
            formato_datos = {'valign': 'vcenter', 'font_size':10, 'align': 'center', 'text_wrap':True, }

            contenido_archivo = generar_archivo_excel(
                titulo='Listado de Proyectos Terminados, sin acta de terminación',
                datos=datos,
                formato_titulo=formato_titulo,
                altura_celda_titulo=60,
                formato_subtitulo=formato_subtitulo,
                altura_celda_subtitulo=40,
                formato_datos=formato_datos,
                altura_celda_datos=30,
                ancho_col=20
            )

        if contenido_archivo:
            try:
                administradores = self.env.ref('urbanizadores_idu.administrador').users
                plantilla = self.env.ref('urbanizadores_idu.plantilla_recordatorio_proyectos_terminados_sin_acta')
                for administrador in administradores:
                    direcciones += "{}, ".format(administrador.email)
                ctx = self.env.context.copy()
                ctx['direcciones_destinatario'] = direcciones
                enviar_mensaje_con_plantilla(
                    objeto=proyecto,
                    contexto=ctx,
                    plantilla=plantilla,
                    nombre_adj='Proyectos.xlsx',
                    contenido_adj=contenido_archivo
                    )
            except Exception as e:
                _logger.exception("No se pudo enviar el mensaje a: {0}, debido a {1}".format(direcciones, str(e)))
        _logger.info("Terminando de verificar los proyectos en estado terminado, pero sin acta final.")

    @api.model
    def _cron_proyectos_suspendidos(self):
        ''' Metodo para el envio de recordatorios sobre los proyectos suspendidos'''
        _logger.info("Verificando los proyectos suspendidos.")
        proyectos = self.search([('state', '=', 'suspendido')], order='name ASC')
        datos = {'Proyecto':[], 'Zona':[], 'Localidad':[], 'Area':[], }
        direcciones = ''
        for proyecto in proyectos:
            datos['Proyecto'].append(proyecto.name)
            datos['Zona'].append(proyecto.zona_id.name)
            datos['Localidad'].append(proyecto.localidad_id.name)
            datos['Area'].append(proyecto.area_cesion_m2)

        #INFO Verifico que el diccionario contenga datos y no solo las cabeceras
        contenido_archivo = None
        if datos['Proyecto']:
            formato_titulo = {'bold':True, 'font_size':14, 'font_color':'black', 'align': 'center', 'valign': 'vcenter', 'text_justlast':True, 'text_wrap':True}
            formato_subtitulo = {'bold':True, 'font_size':12, 'align': 'center', 'valign': 'vcenter', 'text_wrap':True, }
            formato_datos = {'valign': 'vcenter', 'font_size':10, 'align': 'center', 'text_wrap':True, }

            contenido_archivo = generar_archivo_excel(
                titulo='Listado de Proyectos suspendidos',
                datos=datos,
                formato_titulo=formato_titulo,
                altura_celda_titulo=60,
                formato_subtitulo=formato_subtitulo,
                altura_celda_subtitulo=40,
                formato_datos=formato_datos,
                altura_celda_datos=30,
                ancho_col=30
            )

        if contenido_archivo:
            try:
                administradores = self.env.ref('urbanizadores_idu.administrador').users
                plantilla = self.env.ref('urbanizadores_idu.plantilla_recordatorio_proyectos_suspendidos')

                for administrador in administradores:
                    direcciones += "{}, ".format(administrador.email)

                ctx = self.env.context.copy()
                ctx['direcciones_destinatario'] = direcciones

                enviar_mensaje_con_plantilla(
                    objeto=proyecto,
                    contexto=ctx,
                    plantilla=plantilla,
                    nombre_adj='Proyectos.xlsx',
                    contenido_adj=contenido_archivo
                    )
            except Exception as e:
                _logger.exception("No se pudo enviar el mensaje a: {0}, debido a {1}".format(direcciones, str(e)))
        _logger.info("Terminando de verificar los proyectos suspendidos.")

    @api.multi
    def etapa_view_button(self):
        return {
            'name': 'Etapas',
            'res_model': 'urbanizadores.proyecto.etapa',
            'domain': [('proyecto_id', '=', self.id)],
            'context': {'proyecto_id': self.id},
            'type': 'ir.actions.act_window',
            'view_mode': 'tree,form',
            'view_type': 'form',
        }

    @api.multi
    def reunion_view_button(self):
        return {
            'name': 'Reuniones',
            'res_model': 'urbanizadores.reunion',
            'domain': [('proyecto_id', '=', self.id)],
            'context': {'proyecto_id': self.id},
            'type': 'ir.actions.act_window',
            'view_mode': 'tree,form,calendar',
            'view_type': 'form',
        }

    @api.multi
    def cesion_view_button(self):
        return {
            'name': 'Tramos de Cesión',
            'res_model': 'urbanizadores.proyecto.cesion',
            'domain': [('proyecto_id', '=', self.id)],
            'context': {'proyecto_id': self.id},
            'type': 'ir.actions.act_window',
            'view_mode': 'tree,form',
            'view_type': 'form',
        }

    @api.multi
    def visita_view_button(self):
        return {
            'name': 'Visitas',
            'res_model': 'urbanizadores.proyecto.visita',
            'domain': [('proyecto_id', '=', self.id)],
            'context': {'proyecto_id': self.id},
            'type': 'ir.actions.act_window',
            'view_mode': 'tree,form,calendar',
            'view_type': 'form',
        }

    # -------------------
    # Workflow methods
    # -------------------
    def wkf_suspendido(self):
        #INFO Si el usuario no es administrador, se le obliga a diligenciar los campos
        if not self.env.user.has_group('urbanizadores_idu.administrador'):
            campos_requeridos = [
                'numero_expediente_orfeo',
                'localidad_id',
                'direccion',
                'fecha_inicio_proceso',
            ]
            falta_campo = False
            for campo in campos_requeridos:
                if not getattr(self, campo):
                    falta_campo = True
                    break
            if falta_campo:
                raise ValidationError('No es posible pasar el proyecto al estado SUSPENDIDO si no ha diligenciado todos los campos obligatorios: {}'.format(campos_requeridos))

        self.state = 'suspendido'

    def wkf_finalizado(self):
        #INFO Debido a que existen proyectos con documentación antigua y por lo cual no se tienen todos los productos en aceptado, sin embargo ya finalizaron los proyectos, se permite que el administrador los cambie a estado finalizado
        if not self.env.user.has_group('urbanizadores_idu.administrador'):
            campos_requeridos = [
                'oficio_aceptacion_numero',
                'fecha_firma_acta',
                'oficio_envio_dadep_fecha',
                'oficio_envio_dadep_numero',
                'numero_expediente_orfeo',
                'localidad_id',
                'direccion',
                'fecha_inicio_proceso',
            ]
            falta_campo = False
            for campo in campos_requeridos:
                if not getattr(self, campo):
                    falta_campo = True
                    break
            if falta_campo:
                raise ValidationError('No es posible pasar el proyecto al estado TERMINADO si no ha diligenciado todos los campos obligatorios: {}'.format(campos_requeridos))

            estado_de_productos = list(set(self.producto_ids.mapped('state')))
            if not (len(estado_de_productos) == 1 and estado_de_productos[0] == 'aceptado'):
                raise ValidationError('Por favor verifique que todos los productos se encuentren aprobados')
            if not self.acta_final:
                raise ValidationError('Por favor ingrese el acta final del proyecto, antes de cambiar a estado terminado')
        self.state = 'finalizado'

    def wkf_archivado(self):
        #INFO Si el usuario no es administrador, se le obliga a diligenciar los campos
        if not self.env.user.has_group('urbanizadores_idu.administrador'):
            campos_requeridos = [
                'oficio_aceptacion_numero',
                'fecha_firma_acta',
                'oficio_envio_dadep_fecha',
                'oficio_envio_dadep_numero',
                'oficio_constancia_entrega_recibo_fecha',
                'oficio_constancia_entrega_recibo_numero',
            ]
            falta_campo = False
            for campo in campos_requeridos:
                if not getattr(self, campo):
                    falta_campo = True
                    break
            if falta_campo:
                raise ValidationError('No es posible pasar el proyecto al estado ARCHIVADO si no ha diligenciado todos los campos obligatorios: {}'.format(campos_requeridos))

            estado_de_productos = list(set(self.producto_ids.mapped('state')))
            if not (len(estado_de_productos) == 1 and estado_de_productos[0] == 'aceptado'):
                raise ValidationError('Por favor verifique que todos los productos se encuentren aprobados')
        self.state = 'archivado'

    def wkf_previo(self):
        self.state = 'previo'

    def wkf_en_proceso(self):
        #INFO Si el usuario no es administrador, se le obliga a diligenciar los campos
        if not self.env.user.has_group('urbanizadores_idu.administrador'):
            campos_requeridos = [
                'numero_expediente_orfeo',
                'localidad_id',
                'direccion',
                'fecha_inicio_proceso',
                'tercero_urbanizadora_id',
                'tercero_constructora_id',
            ]
            falta_campo = False
            for campo in campos_requeridos:
                if not getattr(self, campo):
                    falta_campo = True
                    break
            if falta_campo:
                raise ValidationError('No es posible pasar el proyecto al estado EN EJECUCIÓN si no ha diligenciado todos los campos obligatorios: {}'.format(campos_requeridos))

        self.state = 'en_proceso'

    @api.one
    def reiniciar_workflow(self):
        return self.create_workflow()


class urbanizadores_proyecto_oficio_rechazo(models.Model):
    _name = 'urbanizadores.proyecto.oficio_rechazo'
    _description = 'Oficios de Observación de Proyectos de Urbanismo a Cargo de Terceros - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    def _domain_usuarios_modulo(self):
        if hasattr(self, 'env'):
            usuarios = self.env.ref('urbanizadores_idu.analista').users.ids
            return [('id','in',usuarios)]
        else:
            return []

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='No Oficio Memorando (Entrada)',
        required=False,
        readonly=False,
        track_visibility='onchange',
        size=50,
    )
    proyecto_id = fields.Many2one(
        string='Proyecto de Urbanismo',
        required=True,
        readonly=True,
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto',
        ondelete='restrict',
        default=lambda self: self._context.get('proyecto_id', self.env['urbanizadores.proyecto'].browse()),
    )
    zona_id = fields.Many2one(
        string='Zona',
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto.zona',
        related='proyecto_id.zona_id'
    )
    producto_id = fields.Many2one(
        string='Producto de Urbanismo',
        required=True,
        readonly=True,
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto.producto',
        ondelete='restrict',
        default=lambda self: self._context.get('producto_id', self.env['urbanizadores.proyecto.producto'].browse()),
    )
    fecha_expedicion = fields.Date(
        string='Fecha de Ingreso',
        readonly=False,
        required=False,
        track_visibility='onchange',
    )
    estado_oficio = fields.Char(
        string='Estado del documento',
        readonly=True,
    )
    etapa_nombre = fields.Char(
        string="Etapa",
        related="producto_id.etapa_id.tipo_id.name",
    )
    estado_etapa_nombre = fields.Char(
        string="Estado de la Etapa",
        related="producto_id.etapa_id.estado_id.name",
    )
    componente_nombre = fields.Char(
        string="Componente",
        related="producto_id.componente_id.name",
        store=True,
    )
    producto_nombre = fields.Char(
        string="Producto",
        related="producto_id.tipo_id.name",
    )
    state = fields.Selection(
        string="Estado del Producto",
        related="producto_id.state",
    )
    oficio_respuesta = fields.Char(
        string='No Oficio Memorando (Respuesta)',
        required=False,
        readonly=False,
        track_visibility='onchange',
        size=50,
    )
    fecha_respuesta = fields.Date(
        string='Fecha de Respuesta',
        required=False,
        readonly=False,
        track_visibility='onchange',
    )
    dias_respuesta = fields.Integer(
        string='Días de Respuesta',
        required=False,
        readonly=True,
    )
    observacion = fields.Text(
        string="Observaciones",
    )
    especialista_ids = fields.Many2many(
        string='Especialistas',
        comodel_name='res.users',
        ondelete='restrict',
        domain=_domain_usuarios_modulo,
    )
    seleccionado = fields.Boolean(
    )

    # -------------------
    # methods
    # -------------------

    @api.model
    def create(self, vals):
        res = super(urbanizadores_proyecto_oficio_rechazo, self).create(vals)
        duplicando = self.env.context.get('duplicando', False)
        if not self.env.user.has_group('urbanizadores_idu.administrador') and not duplicando:
            if res.state != 'entregado':
                raise ValidationError("No es posible crear un nuevo oficio en un estado diferente a En Proceso.")
        res.estado_oficio = obtener_etiqueta_lista_select(PRODUCTO_STATES, res.state)
        #INFO No se por que en vals no llega el proyecto_id, a pesar que antes de guardar el producto, si aparece en el oficio el proyecto, toco hacer:
        res.proyecto_id = res.producto_id.proyecto_id
        return res

    @api.one
    def write(self, vals):
        if (self.name and self.fecha_expedicion and 'fecha_respuesta' in vals):
            fecha_inicial = fields.Date.from_string(self.fecha_expedicion)
            fecha_terminacion = fields.Date.from_string(vals['fecha_respuesta'])
            #INFO Si el usuario es administrador, no valide las fechas
            if not self.env.user.has_group('urbanizadores_idu.administrador'):
                validar_fecha(fecha_inicial, fecha_terminacion)
            vals['dias_respuesta'] = workdays.networkdays(fecha_inicial, fecha_terminacion)
            vals['estado_oficio'] = obtener_etiqueta_lista_select(PRODUCTO_STATES, self.state)
        res = super(urbanizadores_proyecto_oficio_rechazo, self).write(vals)
        return res

class urbanizadores_proyecto_resolucion_urbanismo(models.Model):
    _name = 'urbanizadores.proyecto.resolucion_urbanismo'
    _description = 'Resolución de Urbanismo de Proyectos de Urbanismo a Cargo de Terceros - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='No Acto Administrativo/Resolución',
        required=True,
        track_visibility='onchange',
        size=255,
    )
    proyecto_id = fields.Many2one(
        string='Proyecto de Urbanismo',
        required=True,
        readonly=True,
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto',
        ondelete='restrict',
        default=lambda self: self._context.get('proyecto_id', self.env['urbanizadores.proyecto'].browse()),
    )
    fecha_expedicion = fields.Date(
        string='Fecha de Expedición',
        required=False,
        track_visibility='onchange',
    )
    fecha_vencimiento = fields.Date(
        string='Fecha de Vencimiento',
        required=False,
        track_visibility='onchange',
    )
    autoridad_id = fields.Many2one(
        string='Expedida por',
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto.resolucion_urbanismo.autoridad',
        ondelete='restrict',
    )
    objeto = fields.Char(
        string='Objeto',
        track_visibility='onchange',
        size=255,
    )
    numero_plano_urbanismo = fields.Char(
        string='Número Plano de Urbanismo',
        required=False,
        track_visibility='onchange',
        size=50,
    )
    archivo_resolucion = fields.Binary(
        string="Documento",
        attachment=True,
    )
    archivo_nombre = fields.Char(
        string="Nombre del Archivo",
        size=150,
    )

#     _sql_constraints = [
#         ('unique_name', 'unique(name)', 'Este número de resolución ya está registrado'),
#     ]
    # TODO Validar Consistenca de Fechas
    # -------------------
    # methods
    # -------------------

    @api.model
    def create(self, vals):
        proyecto_resolucion_urbanismo = super(urbanizadores_proyecto_resolucion_urbanismo, self).create(vals)
        duplicando = self.env.context.get('duplicando', False)
        if not self.env.user.has_group('urbanizadores_idu.administrador') and not duplicando:
            if proyecto_resolucion_urbanismo.proyecto_id.state in PROYECTO_ESTADOS_TERMINADO:
                raise ValidationError('No puede adicionar un nuevo registro para un proyecto ya {0}'.format(proyecto_resolucion_urbanismo.proyecto_id.state))
        return proyecto_resolucion_urbanismo

    @api.one
    def write(self, vals):
        duplicando = self.env.context.get('duplicando', False)
        if not self.env.user.has_group('urbanizadores_idu.administrador') and not duplicando:
            if self.proyecto_id.state in PROYECTO_ESTADOS_TERMINADO:
                raise ValidationError('No puede modificar un registro para un proyecto ya {0}'.format(self.proyecto_id.state))
        res = super(urbanizadores_proyecto_resolucion_urbanismo, self).write(vals)
        return res


class urbanizadores_proyecto_producto_documento(models.Model):
    _name = 'urbanizadores.proyecto.producto.documento'
    _description = 'Documentos Productos - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Descripción',
        required=False,
        track_visibility='onchange',
        size=255,
    )
    oficio = fields.Binary(
        string='Oficio',
        attachment=True,
    )
    oficio_nombre = fields.Char(
        required=False,
        size=255,
    )
    producto_id = fields.Many2one(
        string='Producto',
        comodel_name='urbanizadores.proyecto.producto',
        ondelete='restrict',
    )

class urbanizadores_proyecto_producto(models.Model):
    _name = 'urbanizadores.proyecto.producto'
    _description = 'Productos de Proyectos de Urbanismo a Cargo de Terceros - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=255,
        readonly=True,
        states={
            'entregado': [('readonly', False)],
        },
        compute='_compute_name',
    )
    etapa_id = fields.Many2one(
        string='Etapa',
        required=True,
        readonly=False,
        comodel_name='urbanizadores.proyecto.etapa',
        ondelete='restrict',
        domain="[('proyecto_id','=',proyecto_id)]",
        default=lambda self: self._context.get('etapa_id', self.env['urbanizadores.proyecto.etapa'].browse()),
    )
    proyecto_id = fields.Many2one(
        string='Proyecto de Urbanismo',
        required=False,
        readonly=True,
        related='etapa_id.proyecto_id',
        comodel_name='urbanizadores.proyecto',
        ondelete='restrict',
        store=True,
    )
    proyecto_zona_id = fields.Many2one(
        string='Zona del Proyecto de Urbanismo',
        required=False,
        readonly=True,
        related='etapa_id.proyecto_id.zona_id',
        comodel_name='urbanizadores.proyecto.zona',
        ondelete='restrict',
        store=True,
    )
    etapa_tipo_id = fields.Many2one(
        string='Tipo de Etapa',
        required=False,
        readonly=False,
        invisible=True,
        related='etapa_id.tipo_id',
        comodel_name='urbanizadores.proyecto.etapa.tipo',
        ondelete='restrict',
        store=True,
    )
    componente_id = fields.Many2one(
        string='Componente',
        required=True,
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto.componente',
        ondelete='restrict',
        readonly=False,
        states={
            'entregado': [('readonly', False)],
        },
    )
    tipo_id = fields.Many2one(
        string='Producto',
        required=True,
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto.producto.tipo',
        ondelete='restrict',
        domain="[('etapa_id','=',etapa_tipo_id),('componente_id','=',componente_id)]",
        readonly=False,
        states={
            'entregado': [('readonly', False)],
        },
    )
    state = fields.Selection(
        string='Estado',
        required=True,
        track_visibility='onchange',
        selection=PRODUCTO_STATES,
        default='sin_iniciar',
    )
    contador_devoluciones = fields.Integer(
        string='Número de Devoluciones',
        required=False,
        readonly=True,
        default=0,
    )
    editable = fields.Boolean(
        default=True,
        compute='es_editable'
    )
    etapa_estado = fields.Char(
        string='Estado Etapa Creación Producto',
        required=False,
        track_visibility='onchange',
        size=255,
        readonly=True,
    )
    etapa_nombre = fields.Char(
        string="Etapa",
        related="etapa_tipo_id.name",
        store=True,
        )
    tipo_estructura = fields.Selection(
        string='Tipo de Estructura',
        related='proyecto_id.tipo_tramite',
    )
    # Pestaña Oficios / Memorandos
    oficio_rechazo_ids = fields.One2many(
        string='Registro Oficios/Memorandos',
        required=False,
        comodel_name='urbanizadores.proyecto.oficio_rechazo',
        inverse_name='producto_id',
        ondelete='restrict',
        copy=True,
    )
    # Visita
    producto_visita_ids = fields.One2many(
        string='Visita / Correo',
        required=False,
        comodel_name='urbanizadores.proyecto.producto.visita',
        inverse_name='producto_id',
        ondelete='restrict',
        copy=True,
    )
    # Tramos de Cesion
    cesion_ids = fields.One2many(
        string="Tramos de Cesión",
        related='proyecto_id.cesion_ids',
    )
    # Documento Aceptado
    documento_ids = fields.One2many(
        string='Documento',
        comodel_name='urbanizadores.proyecto.producto.documento',
        inverse_name='producto_id',
    )
    # Banderas
    ocultar_vobo_radicados = fields.Boolean(
        compute='_compute_ocultar_vobo_radicados',
    )
    editar_calidad_materiales = fields.Boolean(
        compute='_compute_editar_calidad_materiales',
    )
    editar_calidad_procesos = fields.Boolean(
        compute='_compute_editar_calidad_procesos',
    )
    editar_material_espesor = fields.Boolean(
        compute='_compute_editar_material_espesor',
    )
    ultima_fecha = fields.Date(
        compute='_compute_ultimo_oficio',
    )
    ultimo_numero_oficio = fields.Char(
        compute='_compute_ultimo_oficio',
    )

    # -------------------
    # methods
    # -------------------
    @api.one
    def _compute_ultimo_oficio(self):
        oficio = self.env['urbanizadores.proyecto.oficio_rechazo'].search(
            [('producto_id', '=', self.id)],
            order='fecha_respuesta DESC', limit=1,
        )
        if oficio :
            if oficio.estado_oficio in ['Devuelto con Observaciones', 'Aceptado', 'Enviado a Centro de Documentación']:
                self.ultimo_numero_oficio = oficio.oficio_respuesta
                self.ultima_fecha = oficio.fecha_respuesta
            elif oficio.estado_oficio == 'En Proceso':
                oficio = self.env['urbanizadores.proyecto.oficio_rechazo'].search(
                    [('producto_id', '=', self.id)],
                    order='fecha_expedicion DESC', limit=1,
                    )
                if oficio:
                    self.ultimo_numero_oficio = oficio.name
                    self.ultima_fecha = oficio.fecha_expedicion

    def _compute_ocultar_vobo_radicados(self):
        if self.componente_id.name == 'Pavimentos':
            if self.tipo_id.name == 'Estudio de suelos y diseño de pavimentos y espacio público asociado':
                self.ocultar_vobo_radicados = 1
            else:
                self.ocultar_vobo_radicados = 0

    def _compute_editar_calidad_materiales(self):
        if self.componente_id.name == 'Pavimentos':
            if self.tipo_id.name == 'Calidad de materiales en pavimentos y espacio público asociado':
                self.editar_calidad_materiales = 1
            else:
                self.editar_calidad_materiales = 0

    def _compute_editar_calidad_procesos(self):
        if self.componente_id.name == 'Pavimentos':
            if self.tipo_id.name == 'Calidad de Procesos constructivos en pavimentos y espacio público asociado':
                self.editar_calidad_procesos = 1
            else:
                self.editar_calidad_procesos = 0

    def _compute_editar_material_espesor(self):
        if self.componente_id.name == 'Pavimentos':
            if self.tipo_id.name == 'Estudio de suelos y diseño de pavimentos y espacio público asociado':
                self.editar_material_espesor = 0
            else:
                self.editar_material_espesor = 1

    @api.onchange('componente_id')
    def _onchange_componente_id(self):
        self.tipo_id = False

    def es_editable(self):
        if self.state != 'aceptado':
            if self.env.user.has_group('urbanizadores_idu.especialista'):
                if self.env.uid in self.componente_id.users_id.ids and self.env.uid in self.proyecto_zona_id.user_ids.ids:
                    self.editable = True
                else:
                    self.editable = False
            else:
                self.editable = True
        else:
            self.editable = False

    @api.model
    def create(self, vals):
        duplicando = self.env.context.get('duplicando', False)
        proyecto_producto = super(urbanizadores_proyecto_producto, self).create(vals)
        if proyecto_producto:
            proyecto_producto.etapa_estado = proyecto_producto.etapa_id.estado_id.name
        if not self.env.user.has_group('urbanizadores_idu.administrador') and not duplicando:
            if proyecto_producto.proyecto_id.state in PROYECTO_ESTADOS_TERMINADO:
                raise ValidationError('No puede adicionar un nuevo registro para un proyecto ya {0}'.format(proyecto_producto.proyecto_id.state))
        return proyecto_producto

    @api.one
    def write(self, vals):
        duplicando = self.env.context.get('duplicando', False)
        if not self.env.user.has_group('urbanizadores_idu.administrador') and not duplicando:
            if self.proyecto_id.state in PROYECTO_ESTADOS_TERMINADO:
                raise ValidationError('No puede modificar un registro para un proyecto ya {0}'.format(self.proyecto_id.state))
        res = super(urbanizadores_proyecto_producto, self).write(vals)
        return res

    @api.one
    def unlink(self):
        self.check_access_rights('unlink')
        self.check_access_rule('unlink')
        for visita in self.producto_visita_ids:
            visita.unlink()
        for oficio in self.oficio_rechazo_ids:
            oficio.unlink()
        res = super(urbanizadores_proyecto_producto, self).unlink()
        return res

    @api.one
    @api.depends('tipo_id')
    def _compute_name(self):
        self.name = "{} - {}".format(self.componente_id.name, self.tipo_id.name)

    @api.multi
    def producto_edit_button(self):
        return {
            'name': 'Editar Producto',
            'res_model': 'urbanizadores.proyecto.producto',
            'res_id': self.id,
            'context': {},
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'view_type': 'form',
        }

    @api.model
    def _cron_oficios_salida_vencidos(self, meses, estado_oficio):
        '''Metodo usado para el envio de recordatorios sobre el vencimiento de oficios de salida en estado devuelto con observaciones 3 y 6 meses. Los productos que pertenecen a proyectos en Proceso, sacar el ultimo oficio y si es de respuesta verificar la fecha de respuesta, si han pasado mas de x meses, enviar notificacion, el ultimo viernes del mes.'''
        if not isinstance(estado_oficio, list):
            raise Exception("Estado de Oficio, debe ser una lista con los estados de los oficios permitidos")
        if not isinstance(meses, int):
            raise Exception("Los meses deben ser un numero entero positivo, con el cual se calcula el disparo de la notificacion.")
            _logger.exception("Los meses deben ser un numero entero positivo, con el cual se calcula el disparo de la notificacion.")
        _logger.info("Verificando los oficios de respuesta vencidos en estado, devuelto con observaciones")
        intervalo = timedelta(weeks=meses * 4)
        fecha_actual = datetime.now()
        productos = self.search([('state', '=', 'devuelto'), ('proyecto_id.state', '=', 'en_proceso')])
        datos = {'Proyecto':[], 'Etapa':[], 'Zona':[], 'Oficio':[], 'Fecha Oficio':[], 'Componente':[], 'Producto':[], 'Estado Producto':[]}
        direcciones = ''
        mensaje_3_meses = 'Los oficios que se encuentran en el archivo adjunto, no han obtenido respuesta por parte del constructor, en estos últimos 3 meses, favor comunicarse con ellos para seguir el proceso de recibo de áreas.'
        mensaje_6_meses = 'Los proyectos que se encuentran en el archivo adjunto, serán pasados a estado suspendido próximamente!! , favor revisar y comunicarse con ellos antes del vencimiento final, para poder seguir con el recibo de áreas.'
        mensaje = mensaje_3_meses if meses == 3 else mensaje_6_meses

        for producto in productos:
            lista_oficios_ordenados = producto.oficio_rechazo_ids.filtered(lambda o: o.state in estado_oficio and o.fecha_respuesta).sorted(key=lambda oficio:datetime.strptime(oficio.fecha_respuesta, "%Y-%m-%d"), reverse=True)
            ultimo_oficio = lista_oficios_ordenados[0] if lista_oficios_ordenados and lista_oficios_ordenados[0] else 0
            if ultimo_oficio:
                if (datetime.strptime(ultimo_oficio.fecha_respuesta, "%Y-%m-%d") + intervalo) < fecha_actual:
                    datos['Proyecto'].append(ultimo_oficio.proyecto_id.name)
                    datos['Etapa'].append(producto.etapa_id.tipo_id.name)
                    datos['Zona'].append(ultimo_oficio.proyecto_id.zona_id.name)
                    datos['Oficio'].append(ultimo_oficio.oficio_respuesta)
                    datos['Fecha Oficio'].append(ultimo_oficio.fecha_respuesta)
                    datos['Componente'].append(producto.componente_id.name)
                    datos['Producto'].append(producto.tipo_id.name)
                    datos['Estado Producto'].append(obtener_etiqueta_lista_select(PRODUCTO_STATES, producto.state))

        #INFO Verifico que el diccionario contenga datos y no solo las cabeceras
        contenido_archivo = None
        if datos['Proyecto']:
            formato_titulo = {'bold':True, 'font_size':14, 'font_color':'black', 'align': 'center', 'valign': 'vcenter', 'text_justlast':True, 'text_wrap':True}
            formato_subtitulo = {'bold':True, 'font_size':12, 'align': 'center', 'valign': 'vcenter', 'text_wrap':True, }
            formato_datos = {'valign': 'vcenter', 'font_size':10, 'align': 'center', 'text_wrap':True, }

            contenido_archivo = generar_archivo_excel(
                titulo='Listado de Proyectos en Ejecución, con oficios de salida vencidos.',
                datos=datos,
                formato_titulo=formato_titulo,
                altura_celda_titulo=60,
                formato_subtitulo=formato_subtitulo,
                altura_celda_subtitulo=40,
                formato_datos=formato_datos,
                altura_celda_datos=30,
                ancho_col=40
            )

        if contenido_archivo:
            try:
                administradores = self.env.ref('urbanizadores_idu.administrador').users
                plantilla = self.env.ref('urbanizadores_idu.plantilla_recordatorio_vencimiento_oficio')
                for administrador in administradores:
                    direcciones += "{}, ".format(administrador.email)
                ctx = self.env.context.copy()
                ctx['direcciones_destinatario'] = direcciones
                ctx['mensaje'] = mensaje
                enviar_mensaje_con_plantilla(
                    objeto=producto,
                    contexto=ctx,
                    plantilla=plantilla,
                    nombre_adj='Proyectos.xlsx',
                    contenido_adj=contenido_archivo
                    )
            except Exception as e:
                _logger.exception("No se pudo enviar el mensaje a: {0}, debido a {1}".format(direcciones, str(e)))
        _logger.info("Terminando de verificar los oficios de respuesta vencidos en estado, devuelto con observaciones")

    @api.model
    def _cron_oficios_entrada_vencidos(self, dias_vencimiento):
        '''Metodo usado para el envio de recordatorios sobre el vencimiento de oficios de entrada a los 35 dias. Los productos que pertenecen a proyectos en Proceso, sacar el ultimo oficio y
        si es de respuesta verificar la fecha de respuesta, si han pasado mas de x meses, enviar notificacion, el ultimo viernes del mes.'''
        _logger.info("Verificando los oficios de entrada vencidos.")
        if not isinstance(dias_vencimiento, int):
            raise Exception("Los meses deben ser un numero entero positivo, con el cual se calcula el disparo de la notificacion.")
            _logger.exception("Los meses deben ser un numero entero positivo, con el cual se calcula el disparo de la notificacion.")

        intervalo = timedelta(days=dias_vencimiento)
        fecha_actual = datetime.now()
        productos = self.search([('state', '=', 'entregado'), ('proyecto_id.state', '=', 'en_proceso')])
        datos = {'Proyecto':[], 'Etapa':[], 'Zona':[], 'Oficio':[], 'Fecha Oficio':[], 'Componente':[], 'Producto':[], 'Estado Producto':[]}
        direcciones = ''

        for producto in productos:
            lista_oficios_ordenados = producto.oficio_rechazo_ids.filtered(lambda o: o.state == 'entregado' and not o.fecha_respuesta).sorted(
                key=lambda oficio:datetime.strptime(oficio.fecha_expedicion, "%Y-%m-%d"),
                reverse=True
                )
            ultimo_oficio = lista_oficios_ordenados[0] if lista_oficios_ordenados and lista_oficios_ordenados[0] else 0
            if ultimo_oficio:
                if (datetime.strptime(ultimo_oficio.fecha_expedicion, "%Y-%m-%d") + intervalo) < fecha_actual:
                    datos['Proyecto'].append(ultimo_oficio.proyecto_id.name)
                    datos['Etapa'].append(producto.etapa_id.tipo_id.name)
                    datos['Zona'].append(ultimo_oficio.proyecto_id.zona_id.name)
                    datos['Oficio'].append(ultimo_oficio.name)
                    datos['Fecha Oficio'].append(ultimo_oficio.fecha_expedicion)
                    datos['Componente'].append(producto.componente_id.name)
                    datos['Producto'].append(producto.tipo_id.name)
                    datos['Estado Producto'].append(obtener_etiqueta_lista_select(PRODUCTO_STATES, producto.state))

        #INFO Verifico que el diccionario contenga datos y no solo las cabeceras
        contenido_archivo = None
        if datos['Proyecto']:
            formato_titulo = {'bold':True, 'font_size':14, 'font_color':'black', 'align': 'center', 'valign': 'vcenter', 'text_justlast':True, 'text_wrap':True}
            formato_subtitulo = {'bold':True, 'font_size':12, 'align': 'center', 'valign': 'vcenter', 'text_wrap':True, }
            formato_datos = {'valign': 'vcenter', 'font_size':10, 'align': 'center', 'text_wrap':True, }

            contenido_archivo = generar_archivo_excel(
                titulo='Listado de Proyectos en Ejecución, con oficios de entrada con más de 35 días.',
                datos=datos,
                formato_titulo=formato_titulo,
                altura_celda_titulo=60,
                formato_subtitulo=formato_subtitulo,
                altura_celda_subtitulo=40,
                formato_datos=formato_datos,
                altura_celda_datos=30,
                ancho_col=30
            )

        if contenido_archivo:
            try:
                administradores = self.env.ref('urbanizadores_idu.administrador').users
                plantilla = self.env.ref('urbanizadores_idu.plantilla_recordatorio_vencimiento_oficio_entrada')
                for administrador in administradores:
                    direcciones += "{}, ".format(administrador.email)
                ctx = self.env.context.copy()
                ctx['direcciones_destinatario'] = direcciones
                enviar_mensaje_con_plantilla(
                    objeto=producto,
                    contexto=ctx,
                    plantilla=plantilla,
                    nombre_adj='Oficios.xlsx',
                    contenido_adj=contenido_archivo
                    )
            except Exception as e:
                _logger.exception("No se pudo enviar el mensaje a: {0}, debido a {1}".format(direcciones, str(e)))
        _logger.info("Terminando de verificar los oficios de entrada vencidos.")

    @api.model
    def _cron_proyectos_en_ejecucion_inactivos(self, meses_vencimiento):
        '''Metodo usado para enviar la notificacion de los proyectos, que se encuentran en ejecucion, pero que llevan 6 meses sin actividad'''
        _logger.info("Verificando los proyectos en estado ejecucion que llevan 6 meses sin actividad.")
        if not isinstance(meses_vencimiento, int):
            raise Exception("Los meses deben ser un numero entero positivo, con el cual se calcula el disparo de la notificacion.")
            _logger.exception("Los meses deben ser un numero entero positivo, con el cual se calcula el disparo de la notificacion.")
        intervalo = timedelta(weeks=meses_vencimiento * 4)
        fecha_actual = datetime.now()
        productos = self.search([('proyecto_id.state', '=', 'en_proceso'), ])
        datos = {'Proyecto':[], 'Etapa':[], 'Zona':[], 'Oficio':[], 'Fecha Oficio':[], 'Componente':[], 'Producto':[], 'Estado Producto':[]}
        direcciones = ''
        for producto in productos:
            if producto and producto.oficio_rechazo_ids:
                lista_oficios_ordenados = producto.oficio_rechazo_ids.sorted(
                        key=lambda oficio:datetime.strptime(oficio.fecha_respuesta or oficio.fecha_expedicion or oficio.create_date , "%Y-%m-%d"),
                        reverse=True
                        )
                ultimo_oficio = lista_oficios_ordenados[0] if lista_oficios_ordenados and lista_oficios_ordenados[0] else 0
                if ultimo_oficio :
                    fecha = None
                    oficio = None
                    if ultimo_oficio.fecha_respuesta:
                        fecha = ultimo_oficio.fecha_respuesta
                        oficio = ultimo_oficio.oficio_respuesta
                    elif ultimo_oficio.fecha_expedicion:
                        fecha = ultimo_oficio.fecha_expedicion
                        oficio = ultimo_oficio.name
                    else :
                        fecha = ultimo_oficio.create_date.split()[0]
                        oficio = 'Sin Oficio'
                    if (datetime.strptime(fecha, "%Y-%m-%d") + intervalo) < fecha_actual :
                        datos['Proyecto'].append(ultimo_oficio.proyecto_id.name)
                        datos['Etapa'].append(producto.etapa_id.tipo_id.name)
                        datos['Zona'].append(ultimo_oficio.proyecto_id.zona_id.name)
                        datos['Oficio'].append(ultimo_oficio.oficio_respuesta)
                        datos['Fecha Oficio'].append(fecha)
                        datos['Componente'].append(producto.componente_id.name)
                        datos['Producto'].append(producto.tipo_id.name)
                        datos['Estado Producto'].append(obtener_etiqueta_lista_select(PRODUCTO_STATES, producto.state))

        #INFO Verifico que el diccionario contenga datos y no solo las cabeceras
        contenido_archivo = None
        if datos['Proyecto']:
            formato_titulo = {'bold':True, 'font_size':14, 'font_color':'black', 'align': 'center', 'valign': 'vcenter', 'text_justlast':True, 'text_wrap':True}
            formato_subtitulo = {'bold':True, 'font_size':12, 'align': 'center', 'valign': 'vcenter', 'text_wrap':True, }
            formato_datos = {'valign': 'vcenter', 'font_size':10, 'align': 'center', 'text_wrap':True, }

            contenido_archivo = generar_archivo_excel(
                titulo='Listado de Proyectos en Ejecución, sin actividad por 6 meses',
                datos=datos,
                formato_titulo=formato_titulo,
                altura_celda_titulo=60,
                formato_subtitulo=formato_subtitulo,
                altura_celda_subtitulo=40,
                formato_datos=formato_datos,
                altura_celda_datos=30,
                ancho_col=30
            )

        if contenido_archivo:
            try:
                administradores = self.env.ref('urbanizadores_idu.administrador').users
                plantilla = self.env.ref('urbanizadores_idu.plantilla_recordatorio_proyecto_en_ejecucion_inactivo')

                for administrador in administradores:
                    direcciones += "{}, ".format(administrador.email)

                ctx = self.env.context.copy()
                ctx['direcciones_destinatario'] = direcciones

                enviar_mensaje_con_plantilla(
                    objeto=producto,
                    contexto=ctx,
                    plantilla=plantilla,
                    nombre_adj='Proyectos.xlsx',
                    contenido_adj=contenido_archivo
                    )
            except Exception as e:
                _logger.exception("No se pudo enviar el mensaje a: {0}, debido a {1}".format(direcciones, str(e)))
        _logger.info("Terminando de verificar los proyectos en estado ejecucion que llevan mucho tiempo sin actividad.")

    @api.model
    def _cron_proyectos_en_ejecucion_producto_evaluacion_condicional(self, meses_vencimiento):
        '''Metodo usado para notificar de los proyectos que estan en ejecucion y tiene el producto: Evaluacion condicional aceptado y han pasado mas de 12 meses sin terminar el proyecto.'''
        _logger.info("Verificando los proyectos en estado ejecucion con producto evaluacion condicional con mucho tiempo sin actualizaciones.")
        if not isinstance(meses_vencimiento, int):
            raise Exception("Los meses deben ser un numero entero positivo, con el cual se calcula el disparo de la notificacion.")
            _logger.exception("Los meses deben ser un numero entero positivo, con el cual se calcula el disparo de la notificacion.")
        intervalo = timedelta(weeks=meses_vencimiento * 4)
        fecha_actual = datetime.now()
        productos = self.search([('proyecto_id.state', '=', 'en_proceso'), ('tipo_id.name', '=', 'Evaluación de condición Superficial y Estructural'), ('state', '=', 'aceptado')])
        datos = {'Proyecto':[], 'Etapa':[], 'Zona':[], 'Oficio':[], 'Fecha Oficio':[], 'Componente':[], 'Producto':[], 'Estado Producto':[]}
        direcciones = ''
        for producto in productos:
            if producto and producto.oficio_rechazo_ids:
                lista_oficios_ordenados = producto.oficio_rechazo_ids.sorted(
                    key=lambda oficio:datetime.strptime(oficio.fecha_respuesta or oficio.fecha_expedicion or oficio.create_date , "%Y-%m-%d"),
                    reverse=True
                    )
                ultimo_oficio = lista_oficios_ordenados[0] if lista_oficios_ordenados and lista_oficios_ordenados[0] else 0
                if ultimo_oficio :
                    fecha = None
                    oficio = None
                    if ultimo_oficio.fecha_respuesta:
                        fecha = ultimo_oficio.fecha_respuesta
                        oficio = ultimo_oficio.oficio_respuesta
                    elif ultimo_oficio.fecha_expedicion:
                        fecha = ultimo_oficio.fecha_expedicion
                        oficio = ultimo_oficio.name
                    else :
                        fecha = ultimo_oficio.create_date.split()[0]
                        oficio = 'Sin Oficio'
                    if (datetime.strptime(fecha, "%Y-%m-%d") + intervalo) < fecha_actual :
                        datos['Proyecto'].append(ultimo_oficio.proyecto_id.name)
                        datos['Etapa'].append(producto.etapa_id.tipo_id.name)
                        datos['Zona'].append(ultimo_oficio.proyecto_id.zona_id.name)
                        datos['Oficio'].append(oficio)
                        datos['Fecha Oficio'].append(fecha)
                        datos['Componente'].append(producto.componente_id.name)
                        datos['Producto'].append(producto.tipo_id.name)
                        datos['Estado Producto'].append(obtener_etiqueta_lista_select(PRODUCTO_STATES, producto.state))

        #INFO Verifico que el diccionario contenga datos y no solo las cabeceras
        contenido_archivo = None
        if datos['Proyecto']:
            formato_titulo = {'bold':True, 'font_size':14, 'font_color':'black', 'align': 'center', 'valign': 'vcenter', 'text_justlast':True, 'text_wrap':True}
            formato_subtitulo = {'bold':True, 'font_size':12, 'align': 'center', 'valign': 'vcenter', 'text_wrap':True, }
            formato_datos = {'valign': 'vcenter', 'font_size':10, 'align': 'center', 'text_wrap':True, }

            contenido_archivo = generar_archivo_excel(
                titulo='Listado de Proyectos en Ejecución, con el producto: Evaluación condicional aceptado',
                datos=datos,
                formato_titulo=formato_titulo,
                altura_celda_titulo=60,
                formato_subtitulo=formato_subtitulo,
                altura_celda_subtitulo=40,
                formato_datos=formato_datos,
                altura_celda_datos=30,
                ancho_col=30
            )

        if contenido_archivo:
            try:
                administradores = self.env.ref('urbanizadores_idu.administrador').users
                plantilla = self.env.ref('urbanizadores_idu.plantilla_recordatorio_pry_ejecucion_producto_eval_condicional')
                for administrador in administradores:
                    direcciones += "{}, ".format(administrador.email)
                ctx = self.env.context.copy()
                ctx['direcciones_destinatario'] = direcciones
                enviar_mensaje_con_plantilla(
                    objeto=producto,
                    contexto=ctx,
                    plantilla=plantilla,
                    nombre_adj='Proyectos.xlsx',
                    contenido_adj=contenido_archivo
                    )
            except Exception as e:
                _logger.exception("No se pudo enviar el mensaje a: {0}, debido a {1}".format(direcciones, str(e)))
        _logger.info("Terminando de verificar los proyectos en estado ejecucion con producto evaluacion condicional con mucho tiempo sin actualizaciones.")

    # -------------------
    # Workflow methods
    # -------------------

    def wkf_aceptado(self):
        self.state = 'aceptado'

    def wkf_aceptado_condicionado(self):
        self.state = 'aceptado_condicionado'

    def wkf_entregado(self):
        self.state = 'entregado'

    def wkf_devuelto(self):
        self.state = 'devuelto'
        self.contador_devoluciones += 1

    def wkf_centro_documentacion(self):
        self.state = 'centro_documentacion'

    def wkf_sin_iniciar(self):
        self.state = 'sin_iniciar'

    @api.one
    def reiniciar_workflow(self):
        return self.create_workflow()

class urbanizadores_proyecto_componente(models.Model):
    _name = 'urbanizadores.proyecto.componente'
    _description = 'Componente de Proyectos de Urbanismo a Cargo de 3ros - Urbanizadores'
    _inherit = ['models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        size=255,
    )
    users_id = fields.Many2many(
        string='Especialistas',
        required=False,
        comodel_name='res.users',
        ondelete='restrict',
    )

    _sql_constraints = [
        ('unique_name', 'unique(name)', 'Este name ya está registrado'),
    ]

    # -------------------
    # methods
    # -------------------

class urbanizadores_proyecto_producto_tipo(models.Model):
    _name = 'urbanizadores.proyecto.producto.tipo'
    _description = 'Tipo de Productos de Proyectos de Urbanismo a Cargo de 3ros - Urbanizadores'
    _inherit = ['models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        size=255,
    )
    nombre_interno = fields.Char(
        string='Nombre interno',
    )
    etapa_id = fields.Many2one(
        string='Etapa',
        required=True,
        comodel_name='urbanizadores.proyecto.etapa.tipo',
        ondelete='restrict',
    )
    componente_id = fields.Many2one(
        string='Componente',
        required=True,
        comodel_name='urbanizadores.proyecto.componente',
        ondelete='restrict',
    )

    _sql_constraints = [
        ('unique_name', 'unique(name, etapa_id, componente_id)', 'Este nombre ya está registrado'),
    ]

    # -------------------
    # methods
    # -------------------

class urbanizadores_proyecto_etapa_tipo(models.Model):
    _name = 'urbanizadores.proyecto.etapa.tipo'
    _description = 'Tipos de Etapas de Proyectos de Urbanismo a Cargo de Terceros - Urbanizadores'
    _inherit = ['models.soft_delete.mixin']
    _order = 'sequence ASC'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        size=255,
    )
    nombre_interno = fields.Char(
        string='Nombre interno',
        required=True,
        size=255,
    )
    sequence = fields.Integer(
        string="Orden",
    )

    _sql_constraints = [
        ('unique_name', 'unique(name)', 'Este name ya está registrado'),
        ('unique_nombre_interno', 'unique(nombre_interno)', 'Este nombre interno ya está registrado'),
    ]

    # -------------------
    # methods
    # -------------------

class urbanizadores_proyecto_etapa_estado(models.Model):
    _name = 'urbanizadores.proyecto.etapa.estado'
    _description = 'Estado de Etapas de Proyectos de Urbanismo a Cargo de 3ros - Urbanizadores'
    _inherit = ['models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        size=255,
    )
    tipo_id = fields.Many2one(
        string='Tipo de Etapa',
        required=True,
        comodel_name='urbanizadores.proyecto.etapa.tipo',
        ondelete='restrict',
    )
    descripcion = fields.Text(
        string='Descripción',
        required=False,
    )

    _sql_constraints = [
        ('unique_name', 'unique(name,tipo_id)', 'Este nombre ya está registrado para la etapa'),
    ]

    # -------------------
    # methods
    # -------------------

class urbanizadores_proyecto_elemento(models.Model):
    _name = 'urbanizadores.proyecto.elemento'
    _description = 'Elementos de Proyectos de Urbanismo a Cargo de Terceros - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Descripción del Elemento',
        required=False,
        track_visibility='onchange',
        size=255,
        readonly=False,
    )
    cesion_id = fields.Many2one(
        string='Tramo de Cesión',
        required=True,
        track_visibility='onchange',
        readonly=True,
        comodel_name='urbanizadores.proyecto.cesion',
        ondelete='restrict',
        default=lambda self: self._context.get('cesion_id', self.env['urbanizadores.proyecto.cesion'].browse()),
    )
    estructura_ids = fields.One2many(
        string='Estructura',
        required=False,
        track_visibility='onchange',
        readonly=False,
        comodel_name='urbanizadores.proyecto.elemento.estructura',
        inverse_name='elemento_id',
        ondelete='restrict',
        copy=True,
    )
    # -------------------
    # methods
    # -------------------

    @api.model
    def create(self, vals):
        duplicando = self.env.context.get('duplicando', False)
        proyecto_elemento = super(urbanizadores_proyecto_elemento, self).create(vals)
        if proyecto_elemento.cesion_id.proyecto_id.state in PROYECTO_ESTADOS_TERMINADO and not duplicando:
            raise ValidationError('No puede adicionar un nuevo registro para un proyecto ya {0}'.format(proyecto_elemento.cesion_id.proyecto_id.state))
        return proyecto_elemento

    @api.one
    def write(self, vals):
        duplicando = self.env.context.get('duplicando', False)
        if self.cesion_id.proyecto_id.state in PROYECTO_ESTADOS_TERMINADO and not duplicando:
            raise ValidationError('No puede modificar un registro para un proyecto ya {0}'.format(self.cesion_id.proyecto_id.state))
        res = super(urbanizadores_proyecto_elemento, self).write(vals)
        return res

    @api.multi
    def open_formview_button(self):
        return {
            'name': 'Editar Estructura de Elemento',
            'res_model': 'urbanizadores.proyecto.elemento',
            'res_id': self.id,
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'view_type': 'form',
            'target': 'new',
        }

    @api.multi
    def guardar_fake_button(self):
        return self.open_formview_button()

    @api.multi
    def guardar_y_cerrar_fake_button(self):
        return

class urbanizadores_proyecto_elemento_estructura(models.Model):
    _name = 'urbanizadores.proyecto.elemento.estructura'
    _description = 'Estructura de Elementos de Proyectos de Urbanismo a Cargo de Terceros - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Material',
        required=False,
        track_visibility='onchange',
        size=255,
    )
    elemento_id = fields.Many2one(
        string='Elemento',
        required=False,
        track_visibility='onchange',
        readonly=True,
        comodel_name='urbanizadores.proyecto.elemento',
        ondelete='restrict',
        default=lambda self: self._context.get('elemento_id', self.env['urbanizadores.proyecto.elemento'].browse()),
    )
    espesor_cm = fields.Float(
        string='Espesor (cm)',
        digits=(10, 2),
        track_visibility='onchange',
        required=True,
    )
    producto_id = fields.Many2one(
        string='Producto',
        track_visibility='onchange',
        required=False,
        readonly=False,
        comodel_name='urbanizadores.proyecto.producto',
    )
    esta_validado_calidad_obra = fields.Boolean(
        string='VoBo Calidad Obra',
        required=False,
    )
    radicado_calidad_obra = fields.Char(
        string='Rad. Calidad Obra',
        required=False
    )
    esta_validado_calidad_materiales = fields.Boolean(
        string='VoBo Calidad Materiales',
        required=False,
    )
    radicado_calidad_materiales = fields.Char(
        string='Rad. Calidad Materiales',
        required=False
    )

    # -------------------
    # methods
    # -------------------

    @api.model
    def create(self, vals):
        duplicando = self.env.context.get('duplicando', False)
        proyecto_elemento_estructura = super(urbanizadores_proyecto_elemento_estructura, self).create(vals)
        if proyecto_elemento_estructura.elemento_id.cesion_id.proyecto_id.state in PROYECTO_ESTADOS_TERMINADO and not duplicando:
            raise ValidationError('No puede adicionar un nuevo registro para un proyecto ya {0}'.format(proyecto_elemento_estructura.elemento_id.cesion_id.proyecto_id.state))
        return proyecto_elemento_estructura

    @api.one
    def write(self, vals):
        duplicando = self.env.context.get('duplicando', False)
        if self.elemento_id.cesion_id.proyecto_id.state in PROYECTO_ESTADOS_TERMINADO and not duplicando:
            raise ValidationError('No puede modificar un registro para un proyecto ya {0}'.format(self.elemento_id.cesion_id.proyecto_id.state))
        res = super(urbanizadores_proyecto_elemento_estructura, self).write(vals)
        return res

class urbanizadores_proyecto_cesion(models.Model):
    _name = 'urbanizadores.proyecto.cesion'
    _description = 'Tramos de Cesiones de Proyectos de Urbanismo a Cargo de Terceros - Urbanizadores'
    _inherit = ['models.soft_delete.mixin', 'mail.thread']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=255,
    )
    proyecto_id = fields.Many2one(
        string='Proyecto',
        required=True,
        readonly=True,
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto',
        ondelete='restrict',
        default=lambda self: self._context.get('proyecto_id', self.env['urbanizadores.proyecto'].browse()),
    )
    civ = fields.Char(
        string='Mojones',
        required=False,
        track_visibility='onchange',
        size=500,
    )
    area_cesion_m2 = fields.Float(
        string='Área de Cesión (m2)',
        required=True,
        track_visibility='onchange',
        digits=(10, 2),
    )
    elemento_ids = fields.One2many(
        string='Área Parcial',
        required=False,
        comodel_name='urbanizadores.proyecto.elemento',
        inverse_name='cesion_id',
        ondelete='restrict',
        copy=True,
    )
    descripcion = fields.Char(
        string='Descripción del Tramo',
        required=False,
        track_visibility='onchange',
        size=255,
    )
    tipo_tramite = fields.Selection(
        string='Tipo de Trámite',
        required=True,
        track_visibility='onchange',
        selection=[
            ('normal', 'Áreas de cesión que inician con trámite normal'),
            ('validacion', 'Áreas de cesión que inician con trámite de validación'),
        ],
        default='normal',
    )
    tipo_via = fields.Selection(
        string='Tipo de Vía',
        required=True,
        track_visibility='onchange',
        selection=[
            ('vp', 'VP'),
            ('v0', 'V0'),
            ('v1', 'V1'),
            ('v2', 'V2'),
            ('v3', 'V3'),
            ('v4', 'V4'),
            ('v5', 'V5'),
            ('v6', 'V6'),
            ('v7', 'V7'),
            ('v8', 'V8'),
            ('v9', 'V9'),
        ],
        default='v0',
    )

    # -------------------
    # methods
    # -------------------

    @api.model
    def create(self, vals):
        duplicando = self.env.context.get('duplicando', False)
        proyecto_cesion = super(urbanizadores_proyecto_cesion, self).create(vals)
        if not self.env.user.has_group('urbanizadores_idu.administrador') and not duplicando:
            if proyecto_cesion.proyecto_id.state in PROYECTO_ESTADOS_TERMINADO:
                raise ValidationError('No puede adicionar un nuevo registro para un proyecto ya {0}'.format(proyecto_cesion.proyecto_id.state))
        return proyecto_cesion

    @api.one
    def write(self, vals):
        duplicando = self.env.context.get('duplicando', False)
        if not self.env.user.has_group('urbanizadores_idu.administrador') and not duplicando:
            if self.proyecto_id.state in PROYECTO_ESTADOS_TERMINADO:
                raise ValidationError('No puede modificar un registro para un proyecto ya {0}'.format(self.proyecto_id.state))
        res = super(urbanizadores_proyecto_cesion, self).write(vals)
        return res

    @api.one
    @api.depends('elemento_ids.area_m2')
    def _compute_area_cesion_m2(self):
        total = 0
        for elemento in self.elemento_ids:
            total += elemento.area_m2
        self.area_cesion_m2 = total

class urbanizadores_proyecto_etapa(models.Model):
    _name = 'urbanizadores.proyecto.etapa'
    _description = 'Etapas de Proyectos de Urbanismo a Cargo de Terceros - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        size=255,
        compute='_compute_name',
        store=False,
    )
    proyecto_id = fields.Many2one(
        string='Proyecto de Urbanismo',
        required=True,
        readonly=True,
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto',
        ondelete='restrict',
        default=lambda self: self._context.get('proyecto_id', self.env['urbanizadores.proyecto'].browse()),
    )
    tipo_id = fields.Many2one(
        string='Tipo',
        required=True,
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto.etapa.tipo',
        ondelete='restrict',
    )
    estado_id = fields.Many2one(
        string='Estado',
        required=True,
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto.etapa.estado',
        ondelete='restrict',
        domain="[('tipo_id','=',tipo_id)]",
    )
    fecha_inicio = fields.Date(
        string='Fecha de Inicio',
        required=False,
        track_visibility='onchange',
    )
    fecha_fin = fields.Date(
        string='Fecha de Terminación',
        required=False,
        track_visibility='onchange',
    )
    numero_oficio_aprobacion = fields.Char(
        string='Número de Oficio de Aprobación',
        required=False,
        track_visibility='onchange',
        size=50,
    )
    producto_ids = fields.One2many(
        string='Productos',
        required=False,
        comodel_name='urbanizadores.proyecto.producto',
        inverse_name='etapa_id',
        ondelete='restrict',
    )
    editable = fields.Boolean(
        default=True,
        compute='es_editable_es_especialista'
    )
    es_especialista = fields.Boolean(
        default=False,
        compute='es_editable_es_especialista'
    )
    porcentaje_avance = fields.Float(
        string="Porcentaje de Avance",
        compute="_compute_porcentaje_avance",
    )
    mostrar_progreso = fields.Boolean(
        default=True,
        compute="_compute_mostrar_progreso",
    )

    # -------------------
    # methods
    # -------------------
    @api.one
    def es_editable_es_especialista(self):
        # for etapa in self:
        if self.env.user.has_group('urbanizadores_idu.especialista'):
            self.es_especialista = True
            if self.env.uid in self.proyecto_id.zona_id.user_ids.ids:
                self.editable = True
            else:
                self.editable = False
        else:
            self.es_especialista = False
            self.editable = True

    @api.model
    def create(self, vals):
        proyecto_etapa = super(urbanizadores_proyecto_etapa, self).create(vals)
        duplicando = self.env.context.get('duplicando', False)
        if not self.env.user.has_group('urbanizadores_idu.administrador') and not duplicando:
            if proyecto_etapa.proyecto_id.state in PROYECTO_ESTADOS_TERMINADO:
                raise ValidationError('No puede adicionar un nuevo registro para un proyecto ya {0}'.format(proyecto_etapa.proyecto_id.state))
        return proyecto_etapa

    @api.one
    def write(self, vals):
        duplicando = self.env.context.get('duplicando', False)
        if not self.env.user.has_group('urbanizadores_idu.administrador') and not duplicando:
            if self.proyecto_id.state in PROYECTO_ESTADOS_TERMINADO:
                raise ValidationError('No puede modificar un registro para un proyecto ya {0}'.format(self.proyecto_id.state))
        res = super(urbanizadores_proyecto_etapa, self).write(vals)
        return res

    @api.one
    def unlink(self):
        self.check_access_rights('unlink')
        self.check_access_rule('unlink')
        for producto in self.producto_ids:
            producto.unlink()
        res = super(urbanizadores_proyecto_etapa, self).unlink()
        return res

    @api.one
    @api.depends('producto_ids')
    def _compute_porcentaje_avance(self):
        # Cantidad de productos en total de la etapa, sin contar los que tengan estado N/A
        cant_productos = self.producto_ids.filtered(lambda p: p.tipo_id.name != 'N/A')
        cant_productos_terminados = cant_productos.filtered(lambda p: p.state == 'aceptado')
        self.porcentaje_avance = float(len(cant_productos_terminados)) / len(cant_productos) * 100 if cant_productos else 0

    @api.one
    @api.depends('tipo_id', 'estado_id')
    def _compute_name(self):
        self.name = '{}'.format(self.tipo_id.name, self.estado_id.name)

    @api.one
    @api.depends('tipo_id')
    def _compute_mostrar_progreso(self):
        # Debido a que en Urbanizadores, crearon las 'etapas': Derechos de Petición y Organismos de Control y Varios, las cuales no seria como tal etapas, no se debe mostrar el avance para estas.
        self.mostrar_progreso = not self.tipo_id.name in ['Derechos de Petición y Organismos de Control', 'Varios']

    @api.onchange('tipo_id')
    def _onchange_tipo_id(self):
        self.estado_id = False

    @api.multi
    def producto_view_button(self):
        return {
            'name': 'Productos',
            'res_model': 'urbanizadores.proyecto.producto',
            'domain': [('etapa_id', '=', self.id)],
            'context': {'etapa_id': self.id},
            'type': 'ir.actions.act_window',
            'view_mode': 'tree,form',
            'view_type': 'form',
        }

    @api.model
    def _cron_etapas_con_productos_terminados(self):
        '''Metodo para el envio de recordatorios sobre las etapas que tienen todos sus productos aceptados, pero no esta en estado terminado.'''
        _logger.info("Verificando las etapas que tienen sus productos aceptados, pero que no estan en estado terminado.")
        etapas = self.search([('tipo_id.name', 'in', ('Estudios y Diseños', 'Ejecución de Obras', 'Recibo de Obras')), ('estado_id.name', '!=', 'Terminado'), ('producto_ids', '!=', False)])
        datos = {'Proyecto':[], 'Etapa':[]}
        direcciones = ''
        for etapa in etapas:
            etapa_totalmente_terminada = True
            for producto in etapa.producto_ids:
                if not etapa_totalmente_terminada:
                    break
                if producto.state != 'aceptado':
                    etapa_totalmente_terminada = False
                    break
            if etapa_totalmente_terminada:
                    datos['Proyecto'].append(etapa.proyecto_id.name)
                    datos['Etapa'].append(etapa.name)
        # Verifico que el diccionario contenga datos y no solo las cabeceras
        contenido_archivo = None
        if datos['Proyecto']:
            formato_titulo = {'bold':True, 'font_size':14, 'font_color':'black', 'align': 'center', 'valign': 'vcenter', 'text_justlast':True, 'text_wrap':True}
            formato_subtitulo = {'bold':True, 'font_size':12, 'align': 'center', 'valign': 'vcenter', 'text_wrap':True, }
            formato_datos = {'valign': 'vcenter', 'font_size':10, 'align': 'center', 'text_wrap':True, }
            contenido_archivo = generar_archivo_excel(
                titulo='Listado de Proyectos, cuyas etapas tienen todos los productos terminados, pero no estan terminadas',
                datos=datos,
                formato_titulo=formato_titulo,
                altura_celda_titulo=60,
                formato_subtitulo=formato_subtitulo,
                altura_celda_subtitulo=40,
                formato_datos=formato_datos,
                altura_celda_datos=30,
                ancho_col=50
            )
        if contenido_archivo:
            try:
                administradores = self.env.ref('urbanizadores_idu.administrador').users
                plantilla = self.env.ref('urbanizadores_idu.plantilla_recordatorio_etapas_no_terminadas')
                for administrador in administradores:
                    direcciones += "{}, ".format(administrador.email)
                ctx = self.env.context.copy()
                ctx['direcciones_destinatario'] = direcciones
                enviar_mensaje_con_plantilla(
                    objeto=etapa,
                    contexto=ctx,
                    plantilla=plantilla,
                    nombre_adj='Proyectos.xlsx',
                    contenido_adj=contenido_archivo
                    )
            except Exception as e:
                _logger.exception("No se pudo enviar el mensaje a: {0}, debido a {1}".format(direcciones, str(e)))
        _logger.info("Terminando de verificar los proyectos en estado terminado, pero sin acta final.")

class urbanizadores_proyecto_visita(models.Model):
    _name = 'urbanizadores.proyecto.visita'
    _description = 'Visitas de Proyectos de Urbanismo a Cargo de Terceros - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']
    _order = "fecha_inicio DESC "

    def _default_correo(self):
        proyecto_id = self._context.get('proyecto_id')
        if proyecto_id:
            reg = self.env['urbanizadores.proyecto'].browse(proyecto_id)
            if reg:
                return reg.email
        return ''

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Asunto',
        required=False,
        track_visibility='onchange',
        size=255,
        readonly=True,
        states={
            'programada': [('readonly', False)],
        },
    )
    proyecto_id = fields.Many2one(
        string='Proyecto de Urbanismo',
        required=True,
        readonly=True,
        comodel_name='urbanizadores.proyecto',
        ondelete='restrict',
        default=lambda self: self._context.get('proyecto_id', self.env['urbanizadores.proyecto'].browse()),
    )
    user_ids = fields.Many2many(
        string='Especialistas',
        required=False,
        comodel_name='res.users',
        ondelete='restrict',
        track_visibility='onchange',
        readonly=True,
        states={
            'programada': [('readonly', False)],
        },
        #INFO Hack para que aparezcan incluso los usuarios inactivos
        domain=['|',('active','=',True),('active','=',False)],
    )
    fecha_inicio = fields.Datetime(
        string='Fecha inicio',
        required=True,
        track_visibility='onchange',
        readonly=True,
        states={
            'programada': [('readonly', False)],
        },
    )
    fecha_fin = fields.Datetime(
        string='Fecha fin',
        required=True,
        track_visibility='onchange',
        readonly=True,
        states={
            'programada': [('readonly', False)],
        },
    )
    fecha_permitir_cambio = fields.Datetime(
        string='Permitir Cambios Hasta el',
        required=False,
        help='''Indica la fecha hasta la cual se permite realizar el cambio de la información de la visita por parte del especialista.''',
    )
    adjunto_acta_filename = fields.Char(
        string='adjunto_acta',
        required=False,
        invisible=True,
        size=255,
    )
    adjunto_acta = fields.Binary(
        string='Acta',
        required=False,
        attachment=True,
        readonly=True,
        states={
            'realizada': [('readonly', False)],
        },
        copy=True,
    )
    state = fields.Selection(
        string='Estado',
        required=True,
        track_visibility='onchange',
        selection=VISITA_STATES,
        default='programada',
    )
    observacion_ids = fields.One2many(
        string='Observaciones por Especialista',
        required=False,
        comodel_name='urbanizadores.proyecto.visita.detalle',
        inverse_name='visita_id',
        ondelete='restrict',
        readonly=True,
        track_visibility='onchange',
        states={
            'realizada': [('readonly', False)],
            'cancelada': [('readonly', False)],
            },
        copy=True,
    )
    observacion_visita = fields.Text(
        string='Observaciones visita',
        help='Indica la respuesta que dio el constructor o urbanizador sobre la visita',
        readonly=True,
        track_visibility='onchange',
        states={
            'aceptada': [('readonly', False)],
            'realizada': [('readonly', False)],
            'cancelada': [('readonly', False)],
            },
        )
    es_editable = fields.Boolean(
        default=True,
        compute='es_editable_es_especialista'
    )
    zona = fields.Char(
        string="Zona",
        store=True,
        related="proyecto_id.zona_id.name",
    )
    localidad = fields.Char(
        string="Localidad",
        store=True,
        related="proyecto_id.localidad_id.name",
    )
    tipo_id = fields.Many2one(
        string="Tipo de Visita",
        comodel_name="urbanizadores.visita.tipo",
        ondelete="restrict",
        track_visibility='onchange',
    )
    tipo_visita = fields.Selection(
        string='Tipo visita',
        related='tipo_id.tipos_visita',
    )
    subtipo_visita_obra = fields.Selection(
        string='Subtipo visita de obra',
        selection=[
            ('no_aplica', 'No aplica'),
            ('entrega_simplificada', 'Visita de entrega simplificada'),
            ('inspeccion_final', 'Visita de inspección final'),
            ('seguimiento', 'Visita de seguimiento'),
        ],
        default='no_aplica',
        required=True,
    )
    tercero_contacto_id = fields.Many2one(
        string='Contacto',
        track_visibility='onchange',
        comodel_name='urbanizadores.tercero',
        ondelete='restrict',
    )
    correo_electronico = fields.Char(
        string='Correo Electrónico',
        default=_default_correo,
        required=True,
    )

    # -------------------
    # methods
    # -------------------
    @api.model
    def create(self, vals):
        #TODO Permitir la configuracion de la cantidad de dias que los especialistas tienen para modificar la visita. Actualmente 10 dias luego del agendamiento
        duplicando = self.env.context.get('duplicando', False)
        MAX_DIAS_CANCELAR = 10
        if vals.get('fecha_fin'):
            cal = Colombia()
            #INFO Se tiene en cuenta dias laborales, no calendario para la fecha limite
            fecha_limite = cal.add_working_days(fields.Date.from_string(vals.get('fecha_fin')), MAX_DIAS_CANCELAR)
            vals['fecha_permitir_cambio'] = fields.Date.to_string(fecha_limite)
        proyecto_visita = super(urbanizadores_proyecto_visita, self).create(vals)

        #INFO Si el usuario es administrador, no valide las fechas
        if not self.env.user.has_group('urbanizadores_idu.administrador') and not duplicando:
            validar_fecha(proyecto_visita.fecha_inicio, proyecto_visita.fecha_fin)

        if proyecto_visita.proyecto_id.state in PROYECTO_ESTADOS_TERMINADO and not duplicando:
            raise ValidationError('No puede adicionar un nuevo registro para un proyecto ya {0}'.format(proyecto_visita.proyecto_id.state))

        #INFO Cuando un administrador o coordinador del modulo crea una visita en el pasado, no se envia mensaje. Issue #368
        hoy = fields.Date.to_string(datetime.now())
        fecha_inicio = vals.get('fecha_inicio')

        if (fecha_inicio and fecha_inicio >= hoy) and not duplicando:

            #INFO Si la visita se crea desde el BackEnd, el tercero debe confirmarla o rechazarla
            if not self.env.user.has_group('urbanizadores_idu.api'):
                fecha_hora_inicio = localizar_fecha(proyecto_visita, proyecto_visita.fecha_inicio, retornar_str=True)
                fecha_hora_fin = localizar_fecha(proyecto_visita, proyecto_visita.fecha_fin, retornar_str=True)
                plantilla = self.env.ref('urbanizadores_idu.plantilla_citacion_visita_tercero')
                ctx = self.env.context.copy()

                dominio = self.env['ir.config_parameter'].get_param('web.base.url', '')
                if not dominio:
                    raise ValidationError("No esta configurado correctamente la variable de dominio del servidor Odoo v9. Por favor informele a la mesa de ayuda.")

                direcciones = "{},{}".format(proyecto_visita.proyecto_id.email, proyecto_visita.tercero_contacto_id.email)
                boton = {
                    'titulo':'Confirmar/Rechazar Visita',
                    'url': '{}/urbanizadores/confirmar_visita/{}'.format(dominio, proyecto_visita.id),
                }
                datos = {
                    'fecha_inicio': fecha_hora_inicio,
                    'fecha_fin':fecha_hora_fin,
                    'dir_correo' : direcciones,
                    'dir_cita':proyecto_visita.proyecto_id.direccion,
                }
                ctx.update({'datos' : datos, 'boton' : boton})

                enviar_mensaje_con_plantilla(
                    objeto=proyecto_visita,
                    contexto=ctx,
                    plantilla=plantilla,
                    )
            else:  #INFO Si la visita se crea desde la VUC, el IDU la acepta/rechaza y le asigna especialistas
                direcciones = ''
                nombres = ''
                administradores = self.env.ref('urbanizadores_idu.administrador').users
                for administrador in administradores:
                    direcciones += "{}, ".format(administrador.email)
                for especialista in proyecto_visita.user_ids:
                    nombres += "{}, ".format(especialista.name)
                ctx = self.env.context.copy()
                ctx.update({'dir_correo' : direcciones})
                boton = {
                    'titulo':'Ir a la Visita',
                    'url': url_vista_boton(proyecto_visita),
                }
                ctx.update({'boton' : boton})
                fecha_hora_inicio = localizar_fecha(proyecto_visita, proyecto_visita.fecha_inicio, retornar_str=True)
                fecha_hora_fin = localizar_fecha(proyecto_visita, proyecto_visita.fecha_fin, retornar_str=True)
                tema = vals.get('name', proyecto_visita.name)
                plantilla = self.env.ref('urbanizadores_idu.plantilla_envio_msj_visita')
                datos = {
                        'fecha_inicio': fecha_hora_inicio,
                        'fecha_fin':fecha_hora_fin,
                        'especialista': nombres or 'No definido',
                        'dir_correo' : direcciones,
                        'evento':'Creación',
                        'dir_cita':proyecto_visita.proyecto_id.direccion,
                    }
                ctx.update({'datos' : datos})

                enviar_mensaje_con_plantilla(
                    objeto=proyecto_visita,
                    contexto=ctx,
                    plantilla=plantilla,
                    boton_plantilla=boton
                    )
        return proyecto_visita

    @api.one
    def write(self, vals):
        duplicando = self.env.context.get('duplicando', False)
        if self.proyecto_id.state in PROYECTO_ESTADOS_TERMINADO and not duplicando:
            raise ValidationError('No puede modificar un registro para un proyecto ya {0}'.format(self.proyecto_id.state))

        #INFO Solo se permite cancelar la visita, si tambien se indica la observación o justificación de la misma
        if 'state' in vals and vals['state'] == 'cancelada' and (not self.observacion_visita and 'observacion_visita' not in vals):
            raise ValidationError('No se puede cancelar una visita, sin agregar una observación antes.')

        hoy = datetime.now()
        fecha_cancelar = fields.Datetime.from_string(self.fecha_permitir_cambio)

        if self.env.user.has_group('urbanizadores_idu.especialista') and hoy > fecha_cancelar and not duplicando:
            raise ValidationError('''No se puede modificar la visita despues del {} por favor pida al administrador del módulo
                que permita el cambio o solicite al coordinador del proyecto que realice el ajuste requerido.'''.format(
                localizar_fecha(self, self.fecha_permitir_cambio, retornar_str=True)
            ))

        #INFO No permitir editar el campo fecha_permitir_cambio solo a los administradores del módulo
        if vals.get('fecha_permitir_cambio') and not self.env.user.has_group('urbanizadores_idu.administrador') and not duplicando:
            del vals['fecha_permitir_cambio']

        #INFO Cuando se actualicen las fechas de forma masiva no debe validar
        if not duplicando:
            #INFO Si el usuario es administrador, no valide las fechas
            if not self.env.user.has_group('urbanizadores_idu.administrador'):
                validar_fecha(self.fecha_inicio, self.fecha_fin)

        #INFO Informar sobre un cambio en la fecha, estado o especialistas de la visita
        if (vals.get('state', False) or vals.get('fecha_inicio', False) or vals.get('fecha_fin', False) or vals.get('user_ids', False)) :

            if (vals.get('state', False) == 'cancelada' or self.state == 'cancelada') and not duplicando:
                #INFO Es necesario localizar las fechas/horas, antes de mostrarlas
                fecha_hora_inicio = localizar_fecha(self, vals.get('fecha_inicio', self.fecha_inicio), retornar_str=True)
                fecha_hora_fin = localizar_fecha(self, vals.get('fecha_fin', self.fecha_fin), retornar_str=True)

                #TODO Generar en la configuracion un espacio para ver y editar las plantillas de envio de correo
                plantilla = self.env.ref('urbanizadores_idu.plantilla_envio_msj_visita')
                ctx = self.env.context.copy()

                #INFO Envio los datos que por alguna razon necesito procesarlos antes
                direcciones = ''
                direcciones += "{}, ".format(self.proyecto_id.email or '')
                direcciones += "{}, ".format(self.proyecto_id.tercero_constructora_id.email or '')
                direcciones += "{}, ".format(self.proyecto_id.tercero_urbanizadora_id.email or '')
                nombres = ''

                for especialista in self.user_ids:
                    direcciones += "{},".format(especialista.email)
                    nombres += "{},".format(especialista.name)

                datos = {
                    'estado': vals.get('state', self.state),
                    'evento': "Actualización",
                    'fecha_inicio': fecha_hora_inicio,
                    'fecha_fin': fecha_hora_fin,
                    'especialista': nombres or 'No definido',
                    'dir_cita': self.proyecto_id.direccion,
                    'dir_correo':direcciones,
                    }
                ctx.update({'datos' : datos})

                enviar_mensaje_con_plantilla(
                    objeto=self,
                    contexto=ctx,
                    plantilla=plantilla,
                    )

            if (vals.get('state', False) == 'aceptada' or self.state == 'aceptada') and not duplicando:
                nombre_evento = self.proyecto_id.name
                # Es necesario localizar las fechas/horas, antes de mostrarlas
                fecha_hora_inicio = localizar_fecha(self, vals.get('fecha_inicio', self.fecha_inicio), retornar_str=True)
                fecha_hora_fin = localizar_fecha(self, vals.get('fecha_fin', self.fecha_fin), retornar_str=True)

                evento_ics = generar_evento_calendario(
                                self,
                                nombre_evento,
                                localizar_fecha(self, self.fecha_inicio, retornar_str=False),
                                localizar_fecha(self, self.fecha_fin, retornar_str=False)
                                )

                plantilla = self.env.ref('urbanizadores_idu.plantilla_envio_msj_visita')
                ctx = self.env.context.copy()

                # Envio los datos que por alguna razon necesito procesarlos antes
                msj_adicional = ''
                direcciones = ''
                direcciones += "{}, ".format(self.proyecto_id.email or '')
                direcciones += "{}, ".format(self.proyecto_id.tercero_constructora_id.email or '')
                direcciones += "{}, ".format(self.proyecto_id.tercero_urbanizadora_id.email or '')
                nombres = ''
                #TODO Crear en la configuracion una variable para poder modificar estos datos
                if self.tipo_id.tipos_visita == 'visita_topografica':
                    msj_adicional = '''
                    Les recordamos que para el agendamiento de topografía en las actividades de localización topográfica, nivelación rasante y/o meta física, se solicita previamente informar mediante correo
                    electrónico a piedad.romero@idu.gov.co y ricardo.bermudez@idu.gov.co, el cumplimiento de las condiciones técnicas mínimas que justifiquen el desplazamiento de nuestra especialista
                    (disponibilidad de la comisión topográfica con equipos, certificación de calibración vigente y materialización previa de; mojones, vértices de apoyo y abscisado de las vías cada 5m, de
                    acuerdo al diseño geométrico recibido anticipadamente por el IDU).desplazamiento de nuestra especialista (disponibilidad de la comisión topográfica con equipos calibrados y materialización
                    previa de: mojones, vértices de apoyo y abscisado de las vías cada 5m)
                    '''

                for especialista in self.user_ids:
                    direcciones += "{},".format(especialista.email)
                    nombres += "{},".format(especialista.name)

                datos = {
                    'estado': vals.get('state', self.state),
                    'evento': "Actualización",
                    'fecha_inicio': fecha_hora_inicio,
                    'fecha_fin': fecha_hora_fin,
                    'especialista': nombres or 'No definido',
                    'dir_cita': self.proyecto_id.direccion,
                    'dir_correo':direcciones,
                    }
                ctx.update({'datos' : datos, 'msj_adicional': msj_adicional})

                enviar_mensaje_con_plantilla(
                    objeto=self,
                    contexto=ctx,
                    plantilla=plantilla,
                    nombre_adj='invitacion_evento.ics',
                    contenido_adj=evento_ics
                    )

        if not self.proyecto_id.email:
            raise ValidationError('''No se puede enviar el mensaje debido a que el proyecto no tiene asociado un correo electrónico.''')

        res = super(urbanizadores_proyecto_visita, self).write(vals)
        return res

    @api.model
    def _cron_no_asignacion_especialista_visita(self, horas_vencimiento):
        '''Metodo usado para enviar la notificacion, cuando ha pasado el tiempo limite sin que se haya asignado especialista a la visita.'''
        _logger.info("Iniciando la verificacion de las visitas sin tramite de especialista.")
        if not isinstance(horas_vencimiento, int):
            raise Exception("Las horas deben ser un numero entero positivo, con el cual se calcula el disparo de la notificacion.")
            _logger.exception("Las horas deben ser un numero entero positivo, con el cual se calcula el disparo de la notificacion.")
        intervalo = timedelta(hours=horas_vencimiento)
        hora_actual = datetime.now()
        hora_cita = None
        visitas = self.search([('state', '=', 'programada')])
        for visita in visitas:
            try:
                hora_cita = datetime.strptime(visita.create_date, "%Y-%m-%d %H:%M:%S")
            except Exception as e:
                _logger.exception("Hora de la cita no valida, en la cita: {}. Error: {}".format(visita.id, str(e)))
            try:
                #INFO Si pasaron 24 horas despues de creada la cita, pero no se le ha asigando especialista, se envia mensaje automaticamente para recordarle que asigne el especialista
                if (hora_cita + intervalo) < hora_actual:
                    plantilla = self.env.ref('urbanizadores_idu.plantilla_recordatorio_no_asignacion_especialista_cita')
                    direcciones = ''
                    administradores = self.env.ref('urbanizadores_idu.administrador').users
                    for administrador in administradores:
                        direcciones += "{}, ".format(administrador.email)
                    ctx = self.env.context.copy()
                    ctx.update({'direcciones_destinatario' : direcciones})
                    boton = {
                        'title':'Ir a la Visita',
                        'url': url_vista_boton(visita),
                    }
                    ctx.update({'boton_confirmar' : boton, 'tipo_cita':visita.tipo_id.name  or 'No Asignado'})
                    enviar_mensaje_con_plantilla(
                                objeto=visita,
                                contexto=ctx,
                                plantilla=plantilla
                                )
            except Exception as e:
                _logger.exception("No se pudo enviar el mensaje al usuario {0}, debido a {1}".format(visita.contacto_id.id, str(e)))
        _logger.info("Terminando la verificacion de las visitas sin tramite de especialista.")

    @api.one
    @api.constrains('fecha_inicio', 'fecha_fin')
    def _check_fecha(self):
        today = fields.Date.to_string(datetime.now())
        #INFO  Los Administradores y Coordinadores del modulo, pueden crear visitas en fechas pasadas. Issue #368
        if not self.env.user.has_group('urbanizadores_idu.administrador') and not self.env.user.has_group('urbanizadores_idu.coordinador'):
            if (self.fecha_inicio and self.fecha_inicio <= today) and (self.fecha_fin and self.fecha_fin > self.fecha_inicio) :
                raise ValidationError("Debe agendarse la cita para una fecha posterior a hoy")

    @api.onchange('fecha_inicio', 'fecha_fin')
    def _onchange_fecha(self):
        try:
            self._check_fecha()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.one
    def es_editable_es_especialista(self):
        if self.env.user.has_group('urbanizadores_idu.especialista'):
            self.es_especialista = True
            if self.env.uid in self.proyecto_id.zona_id.user_ids.ids:
                self.editable = True
            else:
                self.editable = False
        else:
            self.es_especialista = False
            self.editable = True

    @api.model
    def buscar_visitas_en_conflicto(self, fecha_hora_inicio_propuesta, fecha_hora_fin_propuesta, tipo_reunion, permitir_reunion_por_zona, zona):
        """Busca si ya existen visitas creadas que pueden estar en conflicto con una reunión con las fechas y horas propuestas pasadas como parámetros
        """
        if not permitir_reunion_por_zona or not zona:
            return self.search([
                '|',
                    '|',
                        '&',
                            ('fecha_inicio', '<=', fecha_hora_inicio_propuesta),
                            ('fecha_fin', '>=', fecha_hora_inicio_propuesta),
                        '&',
                            ('fecha_inicio', '<=', fecha_hora_fin_propuesta),
                            ('fecha_fin', '>=', fecha_hora_inicio_propuesta),
                        '&',
                            ('fecha_inicio', '>', fecha_hora_inicio_propuesta),
                            ('fecha_fin', '<', fecha_hora_fin_propuesta),
                ('state', '!=', 'cancelada'),
                ('tipo_id.tipos_visita', '=', tipo_reunion),
            ])
        else:
            return self.search([
                '|',
                    '|',
                        '&',
                            ('fecha_inicio', '<=', fecha_hora_inicio_propuesta),
                            ('fecha_fin', '>=', fecha_hora_inicio_propuesta),
                        '&',
                            ('fecha_inicio', '<=', fecha_hora_fin_propuesta),
                            ('fecha_fin', '>=', fecha_hora_inicio_propuesta),
                        '&',
                            ('fecha_inicio', '>', fecha_hora_inicio_propuesta),
                            ('fecha_fin', '<', fecha_hora_fin_propuesta),
                ('state', '!=', 'cancelada'),
                ('tipo_id.tipos_visita', '=', tipo_reunion),
                ('zona', '=', zona),
            ])

class urbanizadores_reunion(models.Model):
    _name = 'urbanizadores.reunion'
    _description = 'Reuniones de Proyectos de Urbanismo a Cargo de Terceros - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']
    _order = 'fecha_hora_inicio DESC'

    def _default_correo(self):
        proyecto_id = self._context.get('proyecto_id')
        if proyecto_id:
            reg = self.env['urbanizadores.proyecto'].browse(proyecto_id)
            if reg:
                return reg.email
        return ''

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        size=255,
        compute='_compute_name',
        store=True,
        track_visibility='onchange',
    )
    proyecto_id = fields.Many2one(
        string='Proyecto de Urbanismo',
        required=True,
        readonly=True,
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto',
        ondelete='restrict',
        default=lambda self: self._context.get('proyecto_id', self.env['urbanizadores.proyecto'].browse()),
    )
    tipo_proyecto = fields.Selection(
        related='proyecto_id.tipo_proyecto'
    )
    fecha_hora_inicio = fields.Datetime(
        string='Fecha y Hora de Inicio',
        required=True,
        track_visibility='onchange',
        default=fields.Datetime.now,
        readonly=True,
        states={
            'registrada': [('readonly', False)],
        },
    )
    fecha_hora_fin = fields.Datetime(
        string='Fecha y Hora de Finalización',
        required=True,
        track_visibility='onchange',
        default=fields.Datetime.now,
        readonly=True,
        states={
            'registrada': [('readonly', False)],
        },
    )
    user_ids = fields.Many2many(
        string='Atendido por',
        required=False,
        comodel_name='res.users',
        ondelete='restrict',
        track_visibility='onchange',
        readonly=True,
        states={
            'registrada': [('readonly', False)],
        },
        #INFO Hack para que aparezcan incluso los usuarios inactivos
        domain=['|',('active','=',True),('active','=',False)],
    )
    contacto_id = fields.Many2one(
        string='Contacto',
        required=False,
        track_visibility='onchange',
        comodel_name='res.partner',
        ondelete='restrict',
        readonly=True,
        states={
            'registrada': [('readonly', False)],
        },
    )
    tercero_contacto_id = fields.Many2one(
        string='Contacto',
        required=False,
        track_visibility='onchange',
        comodel_name='urbanizadores.tercero',
        ondelete='restrict',
        readonly=True,
        states={
            'registrada': [('readonly', False)],
        },
    )
    tema = fields.Text(
        string='Tema',
        required=False,
        readonly=True,
        track_visibility='onchange',
        states={
            'registrada': [('readonly', False)],
        },
    )
    state = fields.Selection(
        string='Estado',
        required=True,
        track_visibility='onchange',
        selection=REUNION_STATES,
        default='registrada',
    )
    zona = fields.Char(
        string="Zona",
        store=True,
        related="proyecto_id.zona_id.name",
    )
    localidad_id = fields.Many2one(
        string='Localidad',
        related="proyecto_id.localidad_id",
        store=True,
        )
    tipo_id = fields.Many2one(
        string="Tipo de Reunión",
        comodel_name="urbanizadores.reunion.tipo",
        ondelete="restrict",
        track_visibility='onchange',
        default=lambda self: self.env['urbanizadores.reunion.tipo'].search([('tipos_reunion', '=', self._context.get('tipo','mesa_trabajo'))]),
    )
    observacion_reunion = fields.Text(
        string='Observaciones de la Reunión',
        help='Indica la respuesta que dio el constructor o urbanizador sobre la reunión',
        readonly=True,
        track_visibility='onchange',
        states={
            'registrada': [('readonly', False)],
            'confirmada': [('readonly', False)],
            },
        )
    correo_electronico = fields.Char(
        string='Correo Electrónico',
        required=True,
        default=_default_correo,
    )
    adjunto_acta_filename = fields.Char(
        required=False,
        invisible=True,
        size=255,
    )
    adjunto_acta = fields.Binary(
        string='Acta',
        required=False,
        attachment=True,
        readonly=True,
        states={
            'atendida': [('readonly', False)],
        },
        copy=True,
    )

    # -------------------
    # methods
    # -------------------

    @api.model
    def create(self, vals):
        duplicando = self.env.context.get('duplicando', False)
        reunion = super(urbanizadores_reunion, self).create(vals)

        #INFO Le permito al administrador crear las reuniones sin validarle
        if not self.env.user.has_group('urbanizadores_idu.administrador') and not duplicando:
            validar_fecha(reunion.fecha_hora_inicio, reunion.fecha_hora_fin)

        #INFO Los proyectos en estados terminados, no pueden ser modificados
        if reunion.proyecto_id and reunion.proyecto_id.state in PROYECTO_ESTADOS_TERMINADO and not duplicando:
            raise ValidationError('No puede adicionar un nuevo registro para un proyecto ya {0}'.format(reunion.proyecto_id.state))

        #INFO Solo envia mensaje de la notificacion de la reunion, si fue creada para una fecha futura
        hoy = fields.Date.to_string(datetime.now())

        if (reunion.fecha_hora_inicio and reunion.fecha_hora_inicio >= hoy) and not duplicando:

            #INFO Se crea la reunion desde el BackEnd, por lo cual el tercero debe confirmarla
            direccion_reunion = self.env['ir.config_parameter'].get_param('urbanizadores.direccion_reunion', 'No configurada')
            if not self.env.user.has_group('urbanizadores_idu.api'):
                fecha_hora_inicio = localizar_fecha(reunion, reunion.fecha_hora_inicio, retornar_str=True)
                fecha_hora_fin = localizar_fecha(reunion, reunion.fecha_hora_fin, retornar_str=True)
                plantilla = self.env.ref('urbanizadores_idu.plantilla_citacion_reunion_tercero')
                ctx = self.env.context.copy()

                dominio = self.env['ir.config_parameter'].get_param('web.base.url', '')
                if not dominio:
                    raise ValidationError("No esta configurado correctamente la variable de dominio del servidor. Por favor informele al soporte.")

                direcciones = "{},{}".format(reunion.proyecto_id.email, reunion.correo_electronico or reunion.tercero_contacto_id.email or '')

                boton = {
                    'titulo':'Confirmar/Rechazar Reunión',
                    'url': '{}/urbanizadores/confirmar_reunion/{}'.format(dominio, reunion.id),
                }

                datos = {
                    'fecha_inicio': fecha_hora_inicio,
                    'fecha_fin':fecha_hora_fin,
                    'dir_correo' : direcciones,
                    'dir_cita':direccion_reunion,
                }
                ctx.update({'datos' : datos, 'boton' : boton})

                enviar_mensaje_con_plantilla(
                    objeto=reunion,
                    contexto=ctx,
                    plantilla=plantilla,
                    )

            #INFO Si la visita se crea desde la VUC, el IDU la acepta/rechaza y le asigna especialistas
            else:
                direcciones = ''
                nombres = ''
                administradores = self.env.ref('urbanizadores_idu.administrador').users
                for administrador in administradores:
                    direcciones += "{}, ".format(administrador.email)
                ctx = self.env.context.copy()
                boton = {
                    'titulo':'Ir a la Reunión',
                    'url': url_vista_boton(reunion),
                }
                ctx.update({'dir_correo' : direcciones, 'boton' : boton})
                fecha_hora_inicio = localizar_fecha(reunion, reunion.fecha_hora_inicio, retornar_str=True)
                fecha_hora_fin = localizar_fecha(reunion, reunion.fecha_hora_fin, retornar_str=True)
                tema = vals.get('name', reunion.tema)
                plantilla = self.env.ref('urbanizadores_idu.plantilla_envio_msj_reunion')
                datos = {
                        'fecha_inicio': fecha_hora_inicio,
                        'fecha_fin':fecha_hora_fin,
                        'especialista': nombres or 'No definido',
                        'dir_correo' : direcciones,
                        'evento':'Creación',
                        'dir_cita':direccion_reunion,
                    }
                ctx.update({'datos' : datos})

                enviar_mensaje_con_plantilla(
                    objeto=reunion,
                    contexto=ctx,
                    plantilla=plantilla,
                    boton_plantilla=boton
                    )
        return reunion

    @api.one
    def write(self, vals):
        duplicando = self.env.context.get('duplicando', False)

        if self.proyecto_id.state and self.proyecto_id.state in PROYECTO_ESTADOS_TERMINADO and not self.proyecto_id.state == 'rechazado' and not duplicando:
            raise ValidationError('No puede modificar un registro para un proyecto ya {0}'.format(self.proyecto_id.state))

        #INFO Solo se permite cancelar la mesa de trabajo, si tambien se indica la observación o justificación de la misma
        if 'state' in vals and vals['state'] == 'cancelada' and (not self.observacion_reunion and 'observacion_reunion' not in vals):
            raise ValidationError("No se puede cancelar la mesa de trabajo, sin antes diligenciar las observaciones.")

        #INFO Le permito al administrador modificar las reuniones sin validarle
        if not self.env.user.has_group('urbanizadores_idu.administrador') and not duplicando:
            validar_fecha(self.fecha_hora_inicio, self.fecha_hora_fin)

        # Verificar que las fechas que actualiza esten bien final>inicial
        if (vals.get('state', False) or vals.get('user_ids', False) or vals.get('fecha_hora_inicio', False) or vals.get('fecha_hora_fin', False) or vals.get('tema', False)) and not duplicando :
            #TODO Crear el espacio en la configuracion, para que puedan editarlo
            direccion_reunion = self.env['ir.config_parameter'].get_param('urbanizadores.direccion_reunion', 'No configurada')

            #INFO Si cancelan la mesa de trabajo, enviar el mensaje por correo electronico
            if vals.get('state', False) == 'cancelada' or self.state == 'cancelada':

                fecha_hora_inicio = localizar_fecha(self, vals.get('fecha_hora_inicio', self.fecha_hora_inicio), retornar_str=True)
                fecha_hora_fin = localizar_fecha(self, vals.get('fecha_hora_fin', self.fecha_hora_fin), retornar_str=True)

                plantilla = self.env.ref('urbanizadores_idu.plantilla_envio_msj_reunion')
                ctx = self.env.context.copy()
                nombres = ""
                direcciones = ""

                for especialista in self.user_ids:
                    nombres += "{},".format(especialista.name)
                    direcciones += "{},".format(especialista.email)

                direcciones += "{}, ".format(self.tercero_contacto_id.email)
                direcciones += "{}, ".format(self.proyecto_id.email)

                datos = {
                    'estado': vals.get('state', self.state),
                    'fecha_inicio': fecha_hora_inicio,
                    'fecha_fin':fecha_hora_fin,
                    'especialista': nombres or 'No definido',
                    'dir_correo' : direcciones,
                    'evento':'Actualización',
                    'dir_cita': direccion_reunion,
                }
                ctx.update({'datos' : datos})

                enviar_mensaje_con_plantilla(
                    objeto=self,
                    contexto=ctx,
                    plantilla=plantilla,
                    )

            #INFO Si confirman la mesa de trabajo, generar el evento de calendario y enviar el mensaje por correo electronico
            if vals.get('state', False) == 'confirmada' or self.state == 'confirmada':
                cargo = self.tercero_contacto_id.function if self.tercero_contacto_id.function else self.tercero_contacto_id.name
                celular = self.tercero_contacto_id.mobile if self.tercero_contacto_id.mobile else "No tiene celular registrado"
                telefono = self.tercero_contacto_id.phone if self.tercero_contacto_id.phone else "No tiene teléfono fijo registrado"
                enviar_nota(self, "Se confirmó la reunión por {}, con teléfono móvil {} y teléfono fijo {}".format(cargo, celular, telefono))

                dominio = self.env['ir.config_parameter'].get_param('web.base.url', '')
                if not dominio:
                    raise ValidationError("No esta configurado correctamente la variable de dominio del servidor. Por favor informele al soporte.")

                nombre_evento = self.proyecto_id.name
                fecha_hora_inicio = localizar_fecha(self, vals.get('fecha_hora_inicio', self.fecha_hora_inicio), retornar_str=True)
                fecha_hora_fin = localizar_fecha(self, vals.get('fecha_hora_fin', self.fecha_hora_fin), retornar_str=True)

                evento_ics = generar_evento_calendario(
                    self,
                    nombre_evento,
                    localizar_fecha(self, vals.get('fecha_hora_inicio', self.fecha_hora_inicio), retornar_str=False),
                    localizar_fecha(self, vals.get('fecha_hora_fin', self.fecha_hora_fin), retornar_str=False)
                    )

                plantilla = self.env.ref('urbanizadores_idu.plantilla_envio_msj_reunion')
                ctx = self.env.context.copy()
                nombres = ""
                direcciones = ""

                for especialista in self.user_ids:
                    nombres += "{},".format(especialista.name)
                    direcciones += "{},".format(especialista.email)

                direcciones += "{}, ".format(self.tercero_contacto_id.email)
                direcciones += "{}, ".format(self.proyecto_id.email)

                datos = {
                    'estado': vals.get('state', self.state),
                    'fecha_inicio': fecha_hora_inicio,
                    'fecha_fin':fecha_hora_fin,
                    'especialista': nombres or 'No definido',
                    'dir_correo' : direcciones,
                    'evento':'Actualización',
                    'dir_cita': direccion_reunion,
                }
                ctx.update({'datos' : datos})

                enviar_mensaje_con_plantilla(
                    objeto=self,
                    contexto=ctx,
                    plantilla=plantilla,
                    nombre_adj='invitacion_evento.ics',
                    contenido_adj=evento_ics
                    )

        res = super(urbanizadores_reunion, self).write(vals)
        return res

    @api.one
    @api.depends('proyecto_id.name', 'fecha_hora_inicio', 'state')
    def _compute_name(self):
        self.name = "Mesa de Trabajo: {} ({})".format(self.proyecto_id.name, self.state)

    @api.model
    def buscar_mesas_trabajo_en_conflicto(self, fecha_hora_inicio_propuesta, fecha_hora_fin_propuesta, tipo_reunion, permitir_reunion_por_zona, zona):
        """Busca si ya existen reuniones creadas que pueden tener conflicto con una reunión
        con las fechas y horas propuestas pasadas como parámetros
        """
        if not permitir_reunion_por_zona or not zona:
            return self.search([
                '|',
                    '|',
                        '&',
                            ('fecha_hora_inicio', '<=', fecha_hora_inicio_propuesta),
                            ('fecha_hora_fin', '>=', fecha_hora_inicio_propuesta),
                        '&',
                            ('fecha_hora_inicio', '<=', fecha_hora_fin_propuesta),
                            ('fecha_hora_fin', '>=', fecha_hora_inicio_propuesta),
                    '&',
                        ('fecha_hora_inicio', '>', fecha_hora_inicio_propuesta),
                        ('fecha_hora_fin', '<', fecha_hora_fin_propuesta),
                ('state', '!=', 'cancelada'),
                ('tipo_id.tipos_reunion', '=', tipo_reunion),
            ])
        else:
            return self.search([
                '|',
                    '|',
                        '&',
                            ('fecha_hora_inicio', '<=', fecha_hora_inicio_propuesta),
                            ('fecha_hora_fin', '>=', fecha_hora_inicio_propuesta),
                        '&',
                            ('fecha_hora_inicio', '<=', fecha_hora_fin_propuesta),
                            ('fecha_hora_fin', '>=', fecha_hora_inicio_propuesta),
                    '&',
                        ('fecha_hora_inicio', '>', fecha_hora_inicio_propuesta),
                        ('fecha_hora_fin', '<', fecha_hora_fin_propuesta),
                ('state', '!=', 'cancelada'),
                ('tipo_id.tipos_reunion', '=', tipo_reunion),
                ('zona', '=', zona),
            ])

    @api.model
    def _cron_no_asignacion_especialista_reunion(self, horas_vencimiento):
        '''Metodo usado para enviar la notificacion, cuando ha pasado el tiempo limite sin que se haya asignado especialista a la mesa de trabajo.'''
        _logger.info("Iniciando verificacion de mesas de trabajo sin especialista asignado")
        if not isinstance(horas_vencimiento, int):
            raise Exception("Las horas deben ser un numero entero positivo, con el cual se calcula el disparo de la notificacion.")
            _logger.exception("Las horas deben ser un numero entero positivo, con el cual se calcula el disparo de la notificacion.")
        intervalo = timedelta(hours=horas_vencimiento)
        hora_actual = datetime.now()
        hora_cita = None
        reuniones = self.search([('state', '=', 'registrada')])
        for reunion in reuniones:
            try:
                hora_cita = datetime.strptime(reunion.create_date, "%Y-%m-%d %H:%M:%S")
            except Exception as e:
                _logger.exception("Hora de la cita no valida, en la cita: {}. Error: {}".format(reunion.id, str(e)))
            try:
                #INFO Si pasaron 24 horas despues de creada la reunion, pero no se le ha asigando especialista, se envia mensaje automaticamente para recordarle que asigne el especialista
                if (hora_cita + intervalo) < hora_actual:
                    plantilla = self.env.ref('urbanizadores_idu.plantilla_recordatorio_no_asignacion_especialista_cita')
                    direcciones = ''
                    administradores = self.env.ref('urbanizadores_idu.administrador').users
                    for administrador in administradores:
                        direcciones += "{}, ".format(administrador.email)
                    ctx = self.env.context.copy()
                    ctx.update({'direcciones_destinatario' : direcciones})
                    boton = {
                        'title':'Ir a la Mesa de Trabajo',
                        'url': url_vista_boton(reunion),
                    }
                    ctx.update({'boton_confirmar' : boton, 'tipo_cita':reunion.tipo_id.name or 'No Asignado'})
                    enviar_mensaje_con_plantilla(
                                objeto=reunion,
                                contexto=ctx,
                                plantilla=plantilla
                                )
            except Exception as e:
                _logger.exception("No se pudo enviar el mensaje al usuario {0}, debido a {1}".format(reunion.contacto_id.id, str(e)))
        _logger.info("Terminando verificacion de mesas de trabajo sin especialista asignado")

class urbanizadores_proyecto_visita_detalle(models.Model):
    _name = 'urbanizadores.proyecto.visita.detalle'
    _description = 'Visitas Detalle de Proyectos de Urbanismo a Cargo de Terceros - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']
    # -------------------
    # Fields
    # -------------------
    user_id = fields.Many2one(
        string='Especialista',
        required=True,
        track_visibility='onchange',
        comodel_name='res.users',
        ondelete='restrict',
        default=lambda self: self._context.get('uid', False),
        readonly=True,
    )
    photo_ids = fields.One2many(
        string='Galeria de Fotos',
        required=False,
        comodel_name='photo_gallery.photo',
        inverse_name='urbanizadores_proyecto_visita_id',
        copy=True,
        ondelete='restrict',
    )
    visita_id = fields.Many2one(
        string='Visita',
        required=True,
        readonly=True,
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto.visita',
        ondelete='restrict',
        default=lambda self: self._context.get('visita_id', self.env['urbanizadores.proyecto.visita'].browse()),
    )

    # -------------------
    # methods
    # -------------------
    @api.model
    def create(self, vals):
        observacion_visita = self.env['urbanizadores.proyecto.visita'].browse(vals.get('visita_id')).observacion_visita if self.env['urbanizadores.proyecto.visita'].browse(
            vals.get('visita_id', 0)) else 'Sin Observaciones'
        if 'photo_ids' in vals:
            for photo in vals['photo_ids']:
                photo[2]['name'] = observacion_visita or 'Sin Orbservación'
        proyecto_visita_detalle = super(urbanizadores_proyecto_visita_detalle, self).create(vals)
        return proyecto_visita_detalle

    @api.one
    def write(self, vals):
        res = super(urbanizadores_proyecto_visita_detalle, self).write(vals)
        return res

class urbanizadores_proyecto_zona(models.Model):
    _name = 'urbanizadores.proyecto.zona'
    _description = 'Zonas en donde quedan ubicados los proyectos - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']
    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='nombre',
        size=255,
        required=True,
    )
    proyecto_ids = fields.One2many(
        string='Proyecto',
        required=False,
        comodel_name='urbanizadores.proyecto',
        inverse_name='zona_id',
        ondelete='restrict',
        readonly=True,
    )
    user_ids = fields.Many2many(
        string='Especialistas',
        required=False,
        comodel_name='res.users',
        ondelete='restrict',
    )
    localidad_ids = fields.Many2many(
        string="Localidades",
        help="Indica las localidades que pertenecen a la zona.",
        comodel_name="res.country.state.city.district",
        ondelete='restrict',
    )

class urbanizadores_proyecto_producto_visita(models.Model):
    _name = 'urbanizadores.proyecto.producto.visita'
    _description = 'Visitas realizadas a un producto sobre un proyecto - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']
    # -------------------
    # Fields
    # -------------------
    user_id = fields.Many2one(
        string='Especialista',
        required=True,
        track_visibility='onchange',
        comodel_name='res.users',
        ondelete='restrict',
        default=lambda self: self._context.get('uid', False),
        readonly=True,
    )
    fecha = fields.Datetime(
        string='Fecha',
        required=False,
        track_visibility='onchange',
        default=lambda self: datetime.now()
    )
    observaciones = fields.Text(
        string='Observaciones',
        required=False,
    )
    adjunto_acta = fields.Binary(
        string='Adjunto',
        required=False,
        track_visibility='onchange',
        attachment=True,
        copy=True,
    )
    adjunto_acta_filename = fields.Char(
        string='Adjunto Acta',
        )
    producto_id = fields.Many2one(
        string='Producto de Urbanismo',
        required=False,
        readonly=True,
        invisible=True,
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto.producto',
        ondelete='restrict',
    )
    tipo = fields.Selection(
        string='Tipo',
        required=True,
        track_visibility='onchange',
        selection=[
            ('visita', 'Visita'),
            ('correo', 'Correo'),
        ],
        default='visita',
    )

class urbanizadores_proyecto_producto_subtipo(models.Model):
    _name = 'urbanizadores.proyecto.producto.subtipo'
    _description = 'Sub tipos de Productos de Proyectos de Urbanismo - Urbanizadores'
    _inherit = ['models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        size=255,
    )
    _sql_constraints = [
        ('unique_name', 'unique(name)', 'Este name ya está registrado'),
    ]

class urbanizadores_tercero(models.Model):
    _name = 'urbanizadores.tercero'
    _description = 'Terceros usados en Urbanizadores - Urbanizadores'
    _inherit = ['mail.thread']
    # -------------------
    # Fields
    # -------------------

    nombres = fields.Char(
        string='Nombre',
        size=150,
        track_visibility='onchange',
    )
    apellidos = fields.Char(
        string='Apellido',
        size=150,
        track_visibility='onchange',
    )
    name = fields.Char(
        string='Nombre',
        size=255,
        compute='_compute_name',
    )
    identificacion_numero = fields.Char(
        string="Número de identificación",
        size=20,
        track_visibility='onchange',
    )
    tipo_persona = fields.Selection(
        string='Tipo de Persona',
        selection=[
            ('nat', 'Persona Natural'),
            ('jur', 'Persona Juridica'),
        ],
        default='nat',
        track_visibility='onchange',
        )
    id_portal_idu = fields.Char(
        string="Id del portal idu",
        size=20
        )
    direccion = fields.Char(
        string="Dirección Principal de la Empresa",
        size=100,
        track_visibility='onchange',
        )
    email = fields.Char(
        string='Correo Electrónico',
        size=150,
        track_visibility='onchange',
    )
    phone = fields.Char(
        string='Teléfono Fijo',
        size=10,
        track_visibility='onchange',
    )
    mobile = fields.Char(
        string='Teléfono Celular',
        size=13,
        track_visibility='onchange',
    )
    notas = fields.Text(
        string='Notas sobre el contacto'
    )
    function = fields.Char(
        string='Cargo',
        size=50,
        track_visibility='onchange',
    )
    lang = fields.Char(
        string='Idioma',
        size=7
    )
    parent_id = fields.Many2one(
        string='Empresa',
        required=False,
        comodel_name='urbanizadores.tercero',
        ondelete='set null',
        track_visibility='onchange',
    )
    child_ids = fields.One2many(
        string='Contacto',
        required=False,
        readonly=False,
        comodel_name='urbanizadores.tercero',
        inverse_name='parent_id',
        ondelete='restrict',
        track_visibility='onchange',
    )

    # -------------------
    # methods
    # -------------------

    @api.one
    def _compute_name(self):
        if self.nombres and self.apellidos:
            self.name = "{} {}".format(self.nombres, self.apellidos)
        elif self.nombres:
            self.name = self.nombres
        else:
            self.name = "Sin Nombre"
# Deshabilitado, mientras se pueden validar los datos desde la pagina, ya que si ingresan datos mal desde el formulario da error, pero no indica por que.
#     @api.onchange('email')
#     def onchange_email(self):
#         try:
#             self._check_email()
#         except Exception as e:
#             return {
#                 'warning': { 'message': e.name }
#             }
#
#     @api.one
#     @api.constrains('email')
#     def _check_email(self):
#         if (self.email != False) and (re.match("^[^@]+@[^@]+\.[^@]+$", self.email) == None):
#             raise ValidationError('El email no es válido.')
#
#     @api.onchange('phone')
#     def onchange_phone(self):
#         try:
#             self._check_phone()
#         except Exception as e:
#             return {
#                 'warning': { 'message': e.name }
#             }
#
#     @api.one
#     @api.constrains('phone')
#     def _check_phone(self):
#         if (self.phone != False) and (re.match('^\d{7}$', self.phone) == None):
#             raise ValidationError('El número teléfonico no sigue el formato correcto, ej.  4035696')
#
#     @api.onchange('mobile')
#     def onchange_mobile(self):
#         try:
#             self._check_mobile()
#         except Exception as e:
#             return {
#                 'warning': { 'message': e.name }
#             }
#
#     @api.one
#     @api.constrains('mobile')
#     def _check_mobile(self):
#         if (self.mobile != False) and (re.match('^\d{10}$', self.mobile) == None):
#             raise ValidationError('El número celular no sigue el formato correcto, ej.  3112563458')

    @api.model
    def buscar_o_crear_partner_desde_portal(self, nombres, apellidos, numero_identificacion, correo_electronico, id_portal_idu):
        terceros = self.search([
            '&',
                ('tipo_persona', '=', 'nat'),
                '|',
                    ('identificacion_numero', '=', numero_identificacion),
                        '|',
                        ('email', '=', correo_electronico),
                        ('id_portal_idu', '=', id_portal_idu)
            ])
        if terceros:
            tercero = terceros[0]
            if not tercero.id_portal_idu:
                tercero.id_portal_idu = id_portal_idu
            return tercero
        # Si no lo encontró, lo crea
        nuevo_tercero = {
            'nombres':nombres,
            'apellidos':apellidos,
            'identificacion_numero':numero_identificacion,
            'tipo_persona':'nat',
            'id_portal_idu':id_portal_idu,
            'email':correo_electronico,
        }
        tercero = self.create(nuevo_tercero)
        return tercero


class urbanizadores_proyecto_observacion(models.Model):
    _name = 'urbanizadores.proyecto.observacion'
    _description = 'Observaciones Asociadas al Proyecto - Urbanizadores'
    _inherit = ['mail.thread']

    # -------------------
    # Fields
    # -------------------

    name = fields.Text(
        string='Descripción',
        track_visibility='onchange',
    )
    proyecto_id = fields.Many2one(
        string='Proyecto',
        required=False,
        comodel_name='urbanizadores.proyecto',
        ondelete='set null',
        track_visibility='onchange',
    )


class urbanizadores_reunion_tipo(models.Model):
    _name = 'urbanizadores.reunion.tipo'
    _description = 'Tipo de Reunión a realizarse - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------

    name = fields.Char(
        string='Nombre del tipo de mesa de trabajo',
        compute='_compute_name',
    )
    tipos_reunion = fields.Selection(
        string='Tipo de Mesa de Trabajo',
        selection=LISTA_TIPOS_REUNION,
        default='mesa_trabajo',
        track_visibility='onchange',
        required=True,
    )
    lunes = fields.Boolean(
        default=False,
    )
    martes = fields.Boolean(
        default=False,
    )
    miercoles = fields.Boolean(
        default=False,
    )
    jueves = fields.Boolean(
        default=False,
    )
    viernes = fields.Boolean(
        default=False,
    )
    # TODO se debe validar que lo ingresado sea una hora valida HH:MM
    hora_inicio = fields.Char(
        string="Hora de Inicio de Atención (HH:MM)",
        default='07:00',
        track_visibility='onchange',
        required=True,
    )
    hora_fin = fields.Char(
        string="Hora de Finalización de Atención (HH:MM)",
        default='16:00',
        track_visibility='onchange',
        required=True,
    )
    # TODO Validar que la duracion de la cita sea un numero valido
    duracion = fields.Integer(
        string="Duración en Minutos de Cada Cita",
        default=60,
        track_visibility='onchange',
        required=True,
    )
    dias_antelacion_cancelacion = fields.Integer(
        string="Días de antelación para permitir cancelar la mesa de trabajo",
        default=1,
        track_visibility='onchange',
        required=True,
    )
    permitir_reunion_por_zonas = fields.Boolean(
        string="Mesas de Trabajo por zonas",
        help="Permitir crear mesas de trabajo en el mismo horario pero para diferentes zonas?",
        track_visibility='onchange',
    )
    fecha_inicio_vacaciones = fields.Date(
        string='Fecha del Inicio de las Vacaciones',
    )
    fecha_fin_vacaciones = fields.Date(
        string='Fecha del Fin de las Vacaciones',
    )
    hora_inicio_almuerzo = fields.Char(
        string="Hora de Inicio de Almuerzo (HH:MM)",
        default='12:00',
        track_visibility='onchange',
    )
    hora_fin_almuerzo = fields.Char(
        string="Hora de Finalización de Almuerzo (HH:MM)",
        default='14:00',
        track_visibility='onchange',
    )

    _sql_constraints = [
        ('unique_name', 'unique(name)', 'Este tipo de mesa de trabajo ya esta configurada'),
    ]

    @api.one
    def _compute_name(self):
        self.name = obtener_etiqueta_lista_select(LISTA_TIPOS_REUNION, self.tipos_reunion)

class urbanizadores_visita_tipo(models.Model):
    _name = 'urbanizadores.visita.tipo'
    _description = 'Tipo de Visita a realizarse - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------

    name = fields.Char(
        string='Nombre del tipo de visita',
        compute='_compute_name',
    )
    tipos_visita = fields.Selection(
        string='Tipo de Visita',
        selection=LISTA_TIPOS_VISITA,
        default='visita_obra',
        track_visibility='onchange',
        required=True,
    )
    lunes = fields.Boolean(
        default=False,
    )
    martes = fields.Boolean(
        default=False,
    )
    miercoles = fields.Boolean(
        default=False,
    )
    jueves = fields.Boolean(
        default=False,
    )
    viernes = fields.Boolean(
        default=False,
    )
    # TODO se debe validar que lo ingresado sea una hora valida HH:MM
    hora_inicio = fields.Char(
        string="Hora de Inicio de Atención (HH:MM)",
        default='07:00',
        track_visibility='onchange',
        required=True,
    )
    hora_fin = fields.Char(
        string="Hora de Finalización de Atención (HH:MM)",
        default='16:00',
        track_visibility='onchange',
        required=True,
    )
    # TODO Validar que la duracion de la cita sea un numero valido
    duracion = fields.Integer(
        string="Duración en Minutos de Cada Cita",
        default=60,
        track_visibility='onchange',
        required=True,
    )
    dias_antelacion_cancelacion = fields.Integer(
        string="Días de antelación para permitir cancelar la visita",
        default=1,
        track_visibility='onchange',
        required=True,
    )
    permitir_visitas_por_zonas = fields.Boolean(
        string="Visitas por zonas",
        help="Permitir crear visitas en el mismo horario pero para diferentes zonas?",
        track_visibility='onchange',
    )
    fecha_inicio_vacaciones = fields.Date(
        string='Fecha del Inicio de las Vacaciones',
    )
    fecha_fin_vacaciones = fields.Date(
        string='Fecha del Fin de las Vacaciones',
    )
    hora_inicio_almuerzo = fields.Char(
        string="Hora de Inicio de Almuerzo (HH:MM)",
        default='12:00',
        track_visibility='onchange',
    )
    hora_fin_almuerzo = fields.Char(
        string="Hora de Finalización de Almuerzo (HH:MM)",
        default='14:00',
        track_visibility='onchange',
    )

    _sql_constraints = [
        ('unique_name', 'unique(name)', 'Este tipo de visita ya esta configurada'),
    ]

    @api.one
    def _compute_name(self):
        self.name = obtener_etiqueta_lista_select(LISTA_TIPOS_VISITA, self.tipos_visita)


class urbanizadores_documentos_asociados(models.Model):
    _name = 'urbanizadores.documentos_asociados'
    _description = 'Documentos Asociados al Proyecto - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------

    name = fields.Char(
        string='Nombre del Documento Asociado',
        compute='_compute_name',
    )
    tipo_documento = fields.Selection(
        string='Descripcion',
        selection=LISTA_TIPOS_DOCUMENTOS,
        default='autorizacion_urbanizador_tercero',
        track_visibility='onchange',
    )
    lista_chequeo_id = fields.Many2one(
        string='Lista de Chequeo',
        comodel_name='urbanizadores.proyecto.lista_chequeo',
        ondelete='restrict',
    )
    archivo = fields.Binary(
        string='Archivo',
        track_visibility='onchange',
        attachment=True,
    )
    archivo_filename = fields.Char(
        string='Archivo',
    )
    oficio_entrada = fields.Char(
        string="Oficio de Aceptación",
        track_visibility='onchange',
    )
    fecha_oficio_entrada = fields.Date(
        string='Fecha del Oficio de Aceptación',
        track_visibility='onchange',
    )
    aprobado = fields.Boolean(
        string="VoBo",
        track_visibility='onchange',
    )
    proyecto_id = fields.Many2one(
        string="Proyecto",
        comodel_name="urbanizadores.proyecto",
        default=lambda self: self._context.get('proyecto_id', self.env['urbanizadores.proyecto'].browse()),
    )

    @api.one
    def _compute_name(self):
        if self.tipo_documento:
            self.name = obtener_etiqueta_lista_select(LISTA_TIPOS_DOCUMENTOS, self.tipo_documento)

class urbanizadores_proyecto_poliza(models.Model):
    _name = 'urbanizadores.proyecto.poliza'
    _description = 'Polizas del Proyecto - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------

    name = fields.Char(
        string='Número',
    )
    fecha = fields.Date(
        string='Fecha',
        default=fields.Date.context_today,
    )
    aseguradora_id = fields.Many2one(
        string='Aseguradora',
        comodel_name='urbanizadores.proyecto.aseguradora',
        ondelete='restrict',
    )
    tipo_poliza = fields.Selection(
        string='Tipo de Poliza',
        track_visibility='onchange',
        selection=[
            ('responsabilidad_civil', 'Responsabilidad Civil'),
            ('poliza_cumplimiento', 'Poliza de Cumplimiento'),
        ],
    )
    vigencia_desde = fields.Date(
        string='Vigencia Desde',
        track_visibility='onchange',
    )
    vigencia_hasta = fields.Date(
        string='Vigencia Hasta',
        track_visibility='onchange',
    )
    oficio_aceptacion = fields.Char(
        string='Oficio Aceptación',
        track_visibility='onchange',
        size=20,
    )
    fecha_oficio = fields.Date(
        string='Fecha del Oficio',
        track_visibility='onchange',
    )
    poliza_nombre = fields.Char(
        string='Poliza',
        size=255,
    )
    poliza_archivo = fields.Binary(
        attachment=True,
        track_visibility='onchange',
    )
    observaciones = fields.Char(
        string='Observaciones',
        size=30,
    )
    proyecto_id = fields.Many2one(
        string='Proyecto',
        comodel_name='urbanizadores.proyecto',
        ondelete='restrict',
    )

class urbanizadores_proyecto_lista_chequeo(models.Model):
    _name = 'urbanizadores.proyecto.lista_chequeo'
    _description = 'Lista de Chequeo - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------

    name = fields.Char(
        string='Item Lista Chequeo',
        track_visibility='onchange',
    )

class urbanizadores_proyecto_aprobacion(models.Model):
    _name = 'urbanizadores.proyecto.aprobacion'
    _description = 'Flujo de Aprobacion'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------

    archivo_certificado = fields.Binary(
        string='Certificado',
        attachment=True,
    )
    archivo_certificado_nombre = fields.Char(
        size=255,
    )
    observaciones = fields.Char(
        string='Observaciones',
        track_visibility='onchange',
        size=300,
    )
    proximo_usuario_aprobacion_id = fields.Many2one(
        string='Próximo VoBo',
        comodel_name='res.users',
        ondelete='restrict',
    )
    proyecto_id = fields.Many2one(
        string='proyecto',
        comodel_name='urbanizadores.proyecto',
        ondelete='restrict',
        default=lambda self: self._context.get('proyecto_id', None),
    )
    estado_flujo_aprobacion = fields.Selection(
        selection=ESTADOS_FLUJO_APROBACION,
    )
    estado = fields.Char(
        string='Estado del Evento',
    )
    bandera_usuario_jefe = fields.Boolean(
        compute='_compute_usuario_jefe'
    )

    @api.one
    def _compute_usuario_jefe(self):
        if self.env.user.has_group('base_idu.group_jefe_dependencia') or self.env.user.has_group('urbanizadores_idu.administrador'):
            self.bandera_usuario_jefe = True

class urbanizadores_proyecto_cronograma(models.Model):
    _name = 'urbanizadores.proyecto.cronograma'
    _description = 'Cronograma - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------

    numero_cronograma = fields.Integer(
        string='Número de Cronograma',
        track_visibility='onchange',
    )
    numero_oficio = fields.Char(
        string='Número de Oficio',
        track_visibility='onchange',
        size=14,
    )
    fecha = fields.Date(
        string='Fecha',
        default=fields.Date.context_today,
    )
    archivo_cronograma = fields.Binary(
        string='Cronograma',
        attachment=True,
    )
    archivo_cronograma_nombre = fields.Char(
        size=255,
    )
    observaciones = fields.Char(
        string='Observaciones',
        track_visibility='onchange',
        size=300,
    )
    proyecto_id = fields.Many2one(
        string='Proyecto de Urbanismo',
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto',
        ondelete='restrict',
        default=lambda self: self._context.get('proyecto_id', None),
    )

class urbanizadores_proyecto_cronograma_actividad(models.Model):
    _name = 'urbanizadores.proyecto.cronograma.actividad'
    _description = 'Actividad Cronograma - Urbanizadores'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------

    actividad = fields.Char(
        string='Actividad',
        track_visibility='onchange',
        size=200,
    )
    fecha_inicio = fields.Date(
        string='Fecha Inicio',
        default=fields.Date.context_today,
    )
    fecha_fin = fields.Date(
        string='Fecha Fin',
        default=fields.Date.context_today,
    )
    state = fields.Selection(
        string='Estado',
        selection=[
            ('sin_iniciar', 'Sin Iniciar'),
            ('en_ejecucion', 'En Ejecucion'),
            ('atrasado', 'Atrasado'),
            ('terminado', 'Terminado'),
        ],
        default='sin_iniciar',
    )
    observaciones = fields.Char(
        string='Observaciones',
        track_visibility='onchange',
        size=200,
    )
    proyecto_id = fields.Many2one(
        string='Proyecto de Urbanismo',
        track_visibility='onchange',
        comodel_name='urbanizadores.proyecto',
        ondelete='restrict',
        default=lambda self: self._context.get('proyecto_id', None),
    )

class urbanizadores_proyecto_aseguradora(models.Model):
    _name = 'urbanizadores.proyecto.aseguradora'
    _description = 'Urbanizadores - Aseguradora'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------

    name = fields.Char(
        string='Aseguradora',
        track_visibility='onchange',
        size=200,
        required=True,
    )

class urbanizadores_proyecto_esp(models.Model):
    _name = 'urbanizadores.proyecto.esp'
    _description = 'Urbanizadores - esp'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------

    name = fields.Char(
        string='Empresa de Servicios Público',
        track_visibility='onchange',
        size=200,
        required=True,
    )

class urbanizadores_proyecto_paz_y_salvo(models.Model):
    _name = 'urbanizadores.proyecto.paz_y_salvo'
    _description = 'Urbanizadores - Paz y Salvo'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Empresa de Servicios Público',
        track_visibility='onchange',
        size=200,
        compute='_compute_name',
    )
    esp_id = fields.Many2one(
        string='Empresa de Servicios Públicos',
        comodel_name='urbanizadores.proyecto.esp',
        ondelete='restrict',
    )
    autoridad_id = fields.Many2one(
        string='Autoridad',
        comodel_name='urbanizadores.proyecto.resolucion_urbanismo.autoridad',
        ondelete='restrict',
    )
    acto_administrativo = fields.Char(
        string='Acto Administrativo',
    )
    archivo = fields.Binary(
        string='Archivo',
        attachment=True,
    )
    archivo_nombre = fields.Char()
    fecha = fields.Date(
        string='Fecha',
        default=fields.Date.context_today,
    )
    proyecto_id = fields.Many2one(
        string='Proyecto',
        comodel_name='urbanizadores.proyecto',
        ondelete='restrict',
        default=lambda self: self._context.get('proyecto_id', self.env['urbanizadores.proyecto'].browse()),
    )

    def _compute_name(self):
        if self.esp_id:
            self.name = "{} {}".format(self.proyecto_id.name, self.esp_id.name)
        elif self.autoridad_id:
            self.name = "{} {}".format(self.proyecto_id.name, self.autoridad_id.name)
        else:
            self.name = 'Sin Información'

class urbanizadores_proyecto_resolucion_urbanismo_autoridad(models.Model):
    _name = 'urbanizadores.proyecto.resolucion_urbanismo.autoridad'
    _description = 'Urbanizadores - Resolucion Urbanismo Autoridad'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------

    name = fields.Char(
        string='Autoridad',
        track_visibility='onchange',
        size=200,
        required=True,
    )
