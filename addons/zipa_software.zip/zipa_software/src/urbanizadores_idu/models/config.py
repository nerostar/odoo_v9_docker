# -*- coding: utf-8 -*-

from openerp import models, fields, api


class urbanizadores_idu_config_settings(models.TransientModel):
    _name = 'urbanizadores_idu.config'
    _inherit = 'res.config.settings'

    usuario = fields.Char(
        string = 'Usuario para confirmar citas y reuniones',
        default = 'usuario_api',
        size = 200,
        help = 'nombre del usuario con permisos restringidos que confirmara citas y reuniones.', 
    )

    @api.one
    def set_usuario(self):
        url_ids = self.env['ir.config_parameter'].search([('key','=','urbanizadores_idu.usuario_agendamiento')])
        if len(url_ids):
            url_ids.write({
                'value': self.usuario,
            })
        else:
            self.env['ir.config_parameter'].create({
                'key': 'urbanizadores_idu.usuario_agendamiento',
                'value': self.usuario,
            })

    def get_default_usuario(self, cr, uid, fields, context):
        value = self.pool.get('ir.config_parameter').get_param(cr, uid, 'urbanizadores_idu.usuario_agendamiento', default='', context=context)
        return {'usuario': value}
