{
    'name': 'Bochica: Seguimiento Proyectos de Intervención de Urbanizadores y/o Terceros',
    'version': '1.0',
    'depends': [
        'base',
        'base_idu',
        'model_security',
        'photo_gallery',
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'wizards/crear_proyecto_view.xml',
        'wizards/proyecto_rechazar_view.xml',
        'wizards/producto_rechazar_view.xml',
        'wizards/reporte_proyecto_view.xml',
        'wizards/reporte_consolidado_proyecto_view.xml',
        'wizards/reporte_reuniones_proyecto_view.xml',
        'wizards/reporte_consolidado_visitas_view.xml',
        'wizards/reporte_visitas_view.xml',
        'wizards/configurar_agendamiento_view.xml',
        'wizards/combinar_proyectos_view.xml',
        'wizards/reporte_documentos_proyecto_view.xml',
        'wizards/reporte_indicadores_view.xml',
        'wizards/duplicar_proyecto_view.xml',
        'wizards/cambio_estado_flujo_aprobacion_view.xml',
        'views/urbanizadores_view.xml',
        'views/photo_gallery_view.xml',
        'views/main_templates.xml',
        'workflow/proyecto_workflow.xml',
        'workflow/proyecto_producto_workflow.xml',
        'data/tareas_programadas_data.xml',
        'data/urbanizadores_idu_data.xml',
        'views/config_view.xml',
        'views/portal_templates.xml',
    ],
    'test': [
    ],
    'demo': [
    ],
    'installable': True,
    'description': """
## Dependencias módulos Python
## Configuración adicional
    """,
}
