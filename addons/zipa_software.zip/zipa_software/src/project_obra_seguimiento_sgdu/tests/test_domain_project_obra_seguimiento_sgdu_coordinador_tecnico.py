# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import AccessError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class test_security_project_obra_seguimiento_sgdu_coordinador_tecnico(common.TransactionCase):
    def test_000_project_obra_seguimiento_sgdu_coordinador_tecnico_search(self):
        """ project_obra_seguimiento_sgdu.coordinador_tecnico Verifica reglas de dominio en operación READ """
        user_coordinador_tecnico_01 = self.ref('project_obra_seguimiento_sgdu.coordinador_tecnico_user_01')
        user_coordinador_tecnico_02 = self.ref('project_obra_seguimiento_sgdu.coordinador_tecnico_user_02')

        # ----------------------------
        # project_obra.sgdu.informe_avance
        # ----------------------------
        sgdu_informe_avance_model = self.env['project_obra.sgdu.informe_avance']
        self.assertEqual(1000, sgdu_informe_avance_model.sudo(user_coordinador_tecnico_01).search_count([]))
        self.assertEqual(1000, sgdu_informe_avance_model.sudo(user_coordinador_tecnico_02).search_count([]))

        # ----------------------------
        # project_obra.sgdu.informe_avance.detalle_componente
        # ----------------------------
        sgdu_informe_avance_detalle_componente_model = self.env['project_obra.sgdu.informe_avance.detalle_componente']
        self.assertEqual(1000, sgdu_informe_avance_detalle_componente_model.sudo(user_coordinador_tecnico_01).search_count([]))
        self.assertEqual(1000, sgdu_informe_avance_detalle_componente_model.sudo(user_coordinador_tecnico_02).search_count([]))

    def test_010_project_obra_seguimiento_sgdu_coordinador_tecnico_create(self):
        """ project_obra_seguimiento_sgdu.coordinador_tecnico Verifica reglas de dominio en operación CREATE """
        user_coordinador_tecnico_01 = self.ref('project_obra_seguimiento_sgdu.coordinador_tecnico_user_01')
        user_coordinador_tecnico_02 = self.ref('project_obra_seguimiento_sgdu.coordinador_tecnico_user_02')

        # ----------------------------
        # project_obra.sgdu.informe_avance
        # ----------------------------
        sgdu_informe_avance_model = self.env['project_obra.sgdu.informe_avance']
        # Creación permitida
        vals = {
            'state': "nuevo",
            'company_id': self.ref('project_obra_seguimiento_sgdu.company_id_01'),
            'currency_id': self.ref('project_obra_seguimiento_sgdu.currency_id_01'),
            'user_id': self.ref('project_obra_seguimiento_sgdu.user_id_01'),
            'fecha': "2002-09-12",
            'periodo_fecha_inicio': "1970-01-23",
            'periodo_fecha_fin': "1990-09-29",
            'semana': 18140269,
            'dias_ejecucion': 58590956,
            'proyecto_id': self.ref('project_obra_seguimiento_sgdu.proyecto_id_01'),
            'etapa_actual_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_id_01'),
            'etapa_actual_tipo_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_tipo_id_01'),
            'avance_por_componente_ids': [
                (4, self.ref('project_obra_seguimiento_sgdu.avance_por_componente_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_coordinador_tecnico_01).create(vals)

        # Creación NO permitida
        vals = {
            'state': "nuevo",
            'company_id': self.ref('project_obra_seguimiento_sgdu.company_id_01'),
            'currency_id': self.ref('project_obra_seguimiento_sgdu.currency_id_01'),
            'user_id': self.ref('project_obra_seguimiento_sgdu.user_id_01'),
            'fecha': "1990-12-12",
            'periodo_fecha_inicio': "1974-05-03",
            'periodo_fecha_fin': "2000-10-07",
            'semana': 12724342,
            'dias_ejecucion': 11501710,
            'proyecto_id': self.ref('project_obra_seguimiento_sgdu.proyecto_id_01'),
            'etapa_actual_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_id_01'),
            'etapa_actual_tipo_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_tipo_id_01'),
            'avance_por_componente_ids': [
                (4, self.ref('project_obra_seguimiento_sgdu.avance_por_componente_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_coordinador_tecnico_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(sgdu_informe_avance_model))

        # ----------------------------
        # project_obra.sgdu.informe_avance.detalle_componente
        # ----------------------------
        sgdu_informe_avance_detalle_componente_model = self.env['project_obra.sgdu.informe_avance.detalle_componente']
        # Creación permitida
        vals = {
            'informe_id': self.ref('project_obra_seguimiento_sgdu.informe_id_01'),
            'componente_id': self.ref('project_obra_seguimiento_sgdu.componente_id_01'),
            'ejecutado_porcentaje_fisico': 42444738.9068,
        }
        sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_coordinador_tecnico_01).create(vals)

        # Creación NO permitida
        vals = {
            'informe_id': self.ref('project_obra_seguimiento_sgdu.informe_id_01'),
            'componente_id': self.ref('project_obra_seguimiento_sgdu.componente_id_01'),
            'ejecutado_porcentaje_fisico': 21423761.0572,
        }
        try:
            sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_coordinador_tecnico_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(sgdu_informe_avance_detalle_componente_model))

    def test_020_project_obra_seguimiento_sgdu_coordinador_tecnico_write(self):
        """ project_obra_seguimiento_sgdu.coordinador_tecnico Verifica reglas de dominio en operación WRITE """
        user_coordinador_tecnico_01 = self.ref('project_obra_seguimiento_sgdu.coordinador_tecnico_user_01')
        user_coordinador_tecnico_02 = self.ref('project_obra_seguimiento_sgdu.coordinador_tecnico_user_02')

        # ----------------------------
        # project_obra.sgdu.informe_avance
        # ----------------------------
        sgdu_informe_avance_model = self.env['project_obra.sgdu.informe_avance']
        # Actualización permitida
        vals = {
            'state': "nuevo",
            'company_id': self.ref('project_obra_seguimiento_sgdu.company_id_01'),
            'currency_id': self.ref('project_obra_seguimiento_sgdu.currency_id_01'),
            'user_id': self.ref('project_obra_seguimiento_sgdu.user_id_01'),
            'fecha': "1991-05-12",
            'periodo_fecha_inicio': "1983-06-27",
            'periodo_fecha_fin': "1996-11-09",
            'semana': 27122641,
            'dias_ejecucion': 62102840,
            'proyecto_id': self.ref('project_obra_seguimiento_sgdu.proyecto_id_01'),
            'etapa_actual_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_id_01'),
            'etapa_actual_tipo_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_tipo_id_01'),
            'avance_por_componente_ids': [
                (4, self.ref('project_obra_seguimiento_sgdu.avance_por_componente_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_coordinador_tecnico_01).search([], limit=1)
        sgdu_informe_avance.sudo(user_coordinador_tecnico_01).write(vals)

        # Actualización NO permitida
        vals = {
            'state': "devuelto",
            'company_id': self.ref('project_obra_seguimiento_sgdu.company_id_01'),
            'currency_id': self.ref('project_obra_seguimiento_sgdu.currency_id_01'),
            'user_id': self.ref('project_obra_seguimiento_sgdu.user_id_01'),
            'fecha': "1992-09-18",
            'periodo_fecha_inicio': "1988-07-10",
            'periodo_fecha_fin': "1994-02-12",
            'semana': 35453903,
            'dias_ejecucion': 39194085,
            'proyecto_id': self.ref('project_obra_seguimiento_sgdu.proyecto_id_01'),
            'etapa_actual_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_id_01'),
            'etapa_actual_tipo_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_tipo_id_01'),
            'avance_por_componente_ids': [
                (4, self.ref('project_obra_seguimiento_sgdu.avance_por_componente_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_coordinador_tecnico_01).search([], limit=1)
        try:
            sgdu_informe_avance.sudo(user_coordinador_tecnico_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(sgdu_informe_avance_model))

        # ----------------------------
        # project_obra.sgdu.informe_avance.detalle_componente
        # ----------------------------
        sgdu_informe_avance_detalle_componente_model = self.env['project_obra.sgdu.informe_avance.detalle_componente']
        # Actualización permitida
        vals = {
            'informe_id': self.ref('project_obra_seguimiento_sgdu.informe_id_01'),
            'componente_id': self.ref('project_obra_seguimiento_sgdu.componente_id_01'),
            'ejecutado_porcentaje_fisico': 90536263.8921,
        }
        sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_coordinador_tecnico_01).search([], limit=1)
        sgdu_informe_avance_detalle_componente.sudo(user_coordinador_tecnico_01).write(vals)

        # Actualización NO permitida
        vals = {
            'informe_id': self.ref('project_obra_seguimiento_sgdu.informe_id_01'),
            'componente_id': self.ref('project_obra_seguimiento_sgdu.componente_id_01'),
            'ejecutado_porcentaje_fisico': 73288876.5794,
        }
        sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_coordinador_tecnico_01).search([], limit=1)
        try:
            sgdu_informe_avance_detalle_componente.sudo(user_coordinador_tecnico_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(sgdu_informe_avance_detalle_componente_model))

    def test_030_project_obra_seguimiento_sgdu_coordinador_tecnico_unlink(self):
        """ project_obra_seguimiento_sgdu.coordinador_tecnico Verifica reglas de dominio en operación UNLINK - Delete """
        user_coordinador_tecnico_01 = self.ref('project_obra_seguimiento_sgdu.coordinador_tecnico_user_01')
        user_coordinador_tecnico_02 = self.ref('project_obra_seguimiento_sgdu.coordinador_tecnico_user_02')

        # ----------------------------
        # project_obra.sgdu.informe_avance
        # ----------------------------
        sgdu_informe_avance_model = self.env['project_obra.sgdu.informe_avance']
        # Eliminación permitida
        sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_coordinador_tecnico_01).search([], limit=1)
        sgdu_informe_avance.sudo(user_coordinador_tecnico_01).unlink()

        # Eliminación NO permitida
        sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_coordinador_tecnico_01).search([], limit=1)
        try:
            sgdu_informe_avance.sudo(user_coordinador_tecnico_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(sgdu_informe_avance_model))

        # ----------------------------
        # project_obra.sgdu.informe_avance.detalle_componente
        # ----------------------------
        sgdu_informe_avance_detalle_componente_model = self.env['project_obra.sgdu.informe_avance.detalle_componente']
        # Eliminación permitida
        sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_coordinador_tecnico_01).search([], limit=1)
        sgdu_informe_avance_detalle_componente.sudo(user_coordinador_tecnico_01).unlink()

        # Eliminación NO permitida
        sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_coordinador_tecnico_01).search([], limit=1)
        try:
            sgdu_informe_avance_detalle_componente.sudo(user_coordinador_tecnico_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(sgdu_informe_avance_detalle_componente_model))


if __name__ == '__main__':
    unittest2.main()