# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import AccessError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class test_workflow_sgdu_informe_avance(common.TransactionCase):
    def test_000_sgdu_informe_avance_01(self):
        """ sgdu_informe_avance verifica flujo de trabajo"""
        user_project_obra_seguimiento_sgdu_coordinador_tecnico = self.ref('project_obra_seguimiento_sgdu.coordinador_tecnico_user_01')
        user_project_obra_seguimiento_sgdu_aprueba_informes = self.ref('project_obra_seguimiento_sgdu.aprueba_informes_user_01')
        user_project_group_project_manager = self.ref('project_obra_seguimiento_sgdu.group_project_manager_user_01')
        user_project_group_project_user = self.ref('project_obra_seguimiento_sgdu.group_project_user_user_01')
        user_project_edt_idu_group_project_user_externo = self.ref('project_obra_seguimiento_sgdu.group_project_user_externo_user_01')
        sgdu_informe_avance_model = self.env['project_obra.sgdu.informe_avance']
        sgdu_informe_avance = sgdu_informe_avance_model.search([], limit=1)

        # ----------------------------
        # [nuevo] -> [por_revisar]
        # ----------------------------
        self.assertEqual(sgdu_informe_avance.state, 'nuevo')
        sgdu_informe_avance.sudo(GRUPO_SIN_PERMISO).signal_workflow('wkf_nuevo__por_revisar')
        self.assertEqual(sgdu_informe_avance.state, 'nuevo')
        sgdu_informe_avance.sudo(user_project_obra_seguimiento_sgdu_coordinador_tecnico).signal_workflow('wkf_nuevo__por_revisar')
        self.assertEqual(sgdu_informe_avance.state, 'por_revisar')
        self.assertEqual(sgdu_informe_avance.nombre_campo, 'valor esperado al cambiar de estado')

        # ----------------------------
        # [por_revisar] -> [devuelto]
        # ----------------------------
        self.assertEqual(sgdu_informe_avance.state, 'por_revisar')
        sgdu_informe_avance.sudo(GRUPO_SIN_PERMISO).signal_workflow('wkf_por_revisar__devuelto')
        self.assertEqual(sgdu_informe_avance.state, 'por_revisar')
        sgdu_informe_avance.sudo(user_project_obra_seguimiento_sgdu_aprueba_informes).signal_workflow('wkf_por_revisar__devuelto')
        self.assertEqual(sgdu_informe_avance.state, 'devuelto')
        self.assertEqual(sgdu_informe_avance.nombre_campo, 'valor esperado al cambiar de estado')

        # ----------------------------
        # [devuelto] -> [por_revisar]
        # ----------------------------
        self.assertEqual(sgdu_informe_avance.state, 'devuelto')
        sgdu_informe_avance.sudo(GRUPO_SIN_PERMISO).signal_workflow('wkf_devuelto__por_revisar')
        self.assertEqual(sgdu_informe_avance.state, 'devuelto')
        sgdu_informe_avance.sudo(user_project_obra_seguimiento_sgdu_coordinador_tecnico).signal_workflow('wkf_devuelto__por_revisar')
        self.assertEqual(sgdu_informe_avance.state, 'por_revisar')
        self.assertEqual(sgdu_informe_avance.nombre_campo, 'valor esperado al cambiar de estado')

        # ----------------------------
        # [por_revisar] -> [aprobado]
        # ----------------------------
        self.assertEqual(sgdu_informe_avance.state, 'por_revisar')
        sgdu_informe_avance.signal_workflow('wkf_por_revisar__aprobado')
        self.assertEqual(sgdu_informe_avance.state, 'aprobado')
        self.assertEqual(sgdu_informe_avance.nombre_campo, 'valor esperado al cambiar de estado')

        # ----------------------------
        # [aprobado] -> [publicado]
        # ----------------------------
        self.assertEqual(sgdu_informe_avance.state, 'aprobado')
        sgdu_informe_avance.signal_workflow('wkf_aprobado__publicado')
        self.assertEqual(sgdu_informe_avance.state, 'publicado')
        self.assertEqual(sgdu_informe_avance.nombre_campo, 'valor esperado al cambiar de estado')


if __name__ == '__main__':
    unittest2.main()