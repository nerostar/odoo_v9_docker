# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_project_obra_sgdu_informe_avance(common.TransactionCase):
    def test_crud_validaciones(self):
        sgdu_informe_avance_model = self.env['project_obra.sgdu.informe_avance']
        vals = {
            'state': "aprobado",
            'company_id': self.ref('project_obra_seguimiento_sgdu.company_id_01'),
            'currency_id': self.ref('project_obra_seguimiento_sgdu.currency_id_01'),
            'user_id': self.ref('project_obra_seguimiento_sgdu.user_id_01'),
            'fecha': "1998-11-15",
            'periodo_fecha_inicio': "1972-04-17",
            'periodo_fecha_fin': "1972-03-06",
            'semana': 40187285,
            'dias_ejecucion': 16131264,
            'proyecto_id': self.ref('project_obra_seguimiento_sgdu.proyecto_id_01'),
            'etapa_actual_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_id_01'),
            'etapa_actual_tipo_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_tipo_id_01'),
            'avance_por_componente_ids': [
                (4, self.ref('project_obra_seguimiento_sgdu.avance_por_componente_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        sgdu_informe_avance = sgdu_informe_avance_model.create(vals)

        # Campos computados
        vals_update = {
            'cabecera_id': 'Valor a usarse para calculo',
        }
        sgdu_informe_avance.write(vals_update)
        self.assertEqual(sgdu_informe_avance.name, 'Valor Esperado')
        vals_update = {
            'periodo_fecha_fin': 'Valor a usarse para calculo',
            'fecha': 'Valor a usarse para calculo',
        }
        sgdu_informe_avance.write(vals_update)
        self.assertEqual(sgdu_informe_avance.programado_porcentaje_avance_fisico, 'Valor Esperado')
        vals_update = {
            'periodo_fecha_fin': 'Valor a usarse para calculo',
            'fecha': 'Valor a usarse para calculo',
        }
        sgdu_informe_avance.write(vals_update)
        self.assertEqual(sgdu_informe_avance.ejecutado_porcentaje_avance_fisico, 'Valor Esperado')

        # Campos con api.constrain
        vals_update = {
            'periodo_fecha_inicio': 'Valor a usarse para romper la validación',
        }
        try:
            sgdu_informe_avance.write(vals_update)
        except ValidationError, e:
            pass
        else:
            self.fail('No se generó exception de validación para "periodo_fecha_inicio"')
        vals_update = {
            'periodo_fecha_fin': 'Valor a usarse para romper la validación',
        }
        try:
            sgdu_informe_avance.write(vals_update)
        except ValidationError, e:
            pass
        else:
            self.fail('No se generó exception de validación para "periodo_fecha_fin"')
        vals_update = {
            'programado_porcentaje_avance_fisico': 'Valor a usarse para romper la validación',
        }
        try:
            sgdu_informe_avance.write(vals_update)
        except ValidationError, e:
            pass
        else:
            self.fail('No se generó exception de validación para "programado_porcentaje_avance_fisico"')
        vals_update = {
            'ejecutado_porcentaje_avance_fisico': 'Valor a usarse para romper la validación',
        }
        try:
            sgdu_informe_avance.write(vals_update)
        except ValidationError, e:
            pass
        else:
            self.fail('No se generó exception de validación para "ejecutado_porcentaje_avance_fisico"')


if __name__ == '__main__':
    unittest2.main()