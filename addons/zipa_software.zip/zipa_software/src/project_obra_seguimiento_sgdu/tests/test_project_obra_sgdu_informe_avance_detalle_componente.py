# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_project_obra_sgdu_informe_avance_detalle_componente(common.TransactionCase):
    def test_crud_validaciones(self):
        sgdu_informe_avance_detalle_componente_model = self.env['project_obra.sgdu.informe_avance.detalle_componente']
        vals = {
            'informe_id': self.ref('project_obra_seguimiento_sgdu.informe_id_01'),
            'componente_id': self.ref('project_obra_seguimiento_sgdu.componente_id_01'),
            'ejecutado_porcentaje_fisico': 86032667.5018,
        }
        sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.create(vals)

        # Campos computados
        vals_update = {
            'informe_id': 'Valor a usarse para calculo',
            'componente_id': 'Valor a usarse para calculo',
        }
        sgdu_informe_avance_detalle_componente.write(vals_update)
        self.assertEqual(sgdu_informe_avance_detalle_componente.name, 'Valor Esperado')
        self.assertEqual(sgdu_informe_avance_detalle_componente.programado_porcentaje_fisico, 'Valor Esperado')

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()