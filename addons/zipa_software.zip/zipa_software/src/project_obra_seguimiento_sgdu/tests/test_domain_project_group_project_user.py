# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import AccessError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class test_security_project_group_project_user(common.TransactionCase):
    def test_000_project_group_project_user_search(self):
        """ project.group_project_user Verifica reglas de dominio en operación READ """
        user_group_project_user_01 = self.ref('project_obra_seguimiento_sgdu.group_project_user_user_01')
        user_group_project_user_02 = self.ref('project_obra_seguimiento_sgdu.group_project_user_user_02')

        # ----------------------------
        # project_obra.sgdu.informe_avance
        # ----------------------------
        sgdu_informe_avance_model = self.env['project_obra.sgdu.informe_avance']
        self.assertEqual(1000, sgdu_informe_avance_model.sudo(user_group_project_user_01).search_count([]))
        self.assertEqual(1000, sgdu_informe_avance_model.sudo(user_group_project_user_02).search_count([]))

        # ----------------------------
        # project_obra.sgdu.informe_avance.detalle_componente
        # ----------------------------
        sgdu_informe_avance_detalle_componente_model = self.env['project_obra.sgdu.informe_avance.detalle_componente']
        self.assertEqual(1000, sgdu_informe_avance_detalle_componente_model.sudo(user_group_project_user_01).search_count([]))
        self.assertEqual(1000, sgdu_informe_avance_detalle_componente_model.sudo(user_group_project_user_02).search_count([]))

    def test_010_project_group_project_user_create(self):
        """ project.group_project_user Verifica reglas de dominio en operación CREATE """
        user_group_project_user_01 = self.ref('project_obra_seguimiento_sgdu.group_project_user_user_01')
        user_group_project_user_02 = self.ref('project_obra_seguimiento_sgdu.group_project_user_user_02')

        # ----------------------------
        # project_obra.sgdu.informe_avance
        # ----------------------------
        sgdu_informe_avance_model = self.env['project_obra.sgdu.informe_avance']
        # Creación permitida
        vals = {
            'state': "por_revisar",
            'company_id': self.ref('project_obra_seguimiento_sgdu.company_id_01'),
            'currency_id': self.ref('project_obra_seguimiento_sgdu.currency_id_01'),
            'user_id': self.ref('project_obra_seguimiento_sgdu.user_id_01'),
            'fecha': "2009-03-06",
            'periodo_fecha_inicio': "1971-10-13",
            'periodo_fecha_fin': "2010-11-29",
            'semana': 34655090,
            'dias_ejecucion': 73160878,
            'proyecto_id': self.ref('project_obra_seguimiento_sgdu.proyecto_id_01'),
            'etapa_actual_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_id_01'),
            'etapa_actual_tipo_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_tipo_id_01'),
            'avance_por_componente_ids': [
                (4, self.ref('project_obra_seguimiento_sgdu.avance_por_componente_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_group_project_user_01).create(vals)

        # Creación NO permitida
        vals = {
            'state': "publicado",
            'company_id': self.ref('project_obra_seguimiento_sgdu.company_id_01'),
            'currency_id': self.ref('project_obra_seguimiento_sgdu.currency_id_01'),
            'user_id': self.ref('project_obra_seguimiento_sgdu.user_id_01'),
            'fecha': "1970-01-04",
            'periodo_fecha_inicio': "1989-09-16",
            'periodo_fecha_fin': "2007-11-24",
            'semana': 67237980,
            'dias_ejecucion': 89315115,
            'proyecto_id': self.ref('project_obra_seguimiento_sgdu.proyecto_id_01'),
            'etapa_actual_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_id_01'),
            'etapa_actual_tipo_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_tipo_id_01'),
            'avance_por_componente_ids': [
                (4, self.ref('project_obra_seguimiento_sgdu.avance_por_componente_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_group_project_user_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(sgdu_informe_avance_model))

        # ----------------------------
        # project_obra.sgdu.informe_avance.detalle_componente
        # ----------------------------
        sgdu_informe_avance_detalle_componente_model = self.env['project_obra.sgdu.informe_avance.detalle_componente']
        # Creación permitida
        vals = {
            'informe_id': self.ref('project_obra_seguimiento_sgdu.informe_id_01'),
            'componente_id': self.ref('project_obra_seguimiento_sgdu.componente_id_01'),
            'ejecutado_porcentaje_fisico': 71314411.8627,
        }
        sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_group_project_user_01).create(vals)

        # Creación NO permitida
        vals = {
            'informe_id': self.ref('project_obra_seguimiento_sgdu.informe_id_01'),
            'componente_id': self.ref('project_obra_seguimiento_sgdu.componente_id_01'),
            'ejecutado_porcentaje_fisico': 65123665.232,
        }
        try:
            sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_group_project_user_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(sgdu_informe_avance_detalle_componente_model))

    def test_020_project_group_project_user_write(self):
        """ project.group_project_user Verifica reglas de dominio en operación WRITE """
        user_group_project_user_01 = self.ref('project_obra_seguimiento_sgdu.group_project_user_user_01')
        user_group_project_user_02 = self.ref('project_obra_seguimiento_sgdu.group_project_user_user_02')

        # ----------------------------
        # project_obra.sgdu.informe_avance
        # ----------------------------
        sgdu_informe_avance_model = self.env['project_obra.sgdu.informe_avance']
        # Actualización permitida
        vals = {
            'state': "aprobado",
            'company_id': self.ref('project_obra_seguimiento_sgdu.company_id_01'),
            'currency_id': self.ref('project_obra_seguimiento_sgdu.currency_id_01'),
            'user_id': self.ref('project_obra_seguimiento_sgdu.user_id_01'),
            'fecha': "2007-10-10",
            'periodo_fecha_inicio': "2001-02-10",
            'periodo_fecha_fin': "2017-04-26",
            'semana': 54832653,
            'dias_ejecucion': 21057362,
            'proyecto_id': self.ref('project_obra_seguimiento_sgdu.proyecto_id_01'),
            'etapa_actual_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_id_01'),
            'etapa_actual_tipo_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_tipo_id_01'),
            'avance_por_componente_ids': [
                (4, self.ref('project_obra_seguimiento_sgdu.avance_por_componente_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_group_project_user_01).search([], limit=1)
        sgdu_informe_avance.sudo(user_group_project_user_01).write(vals)

        # Actualización NO permitida
        vals = {
            'state': "aprobado",
            'company_id': self.ref('project_obra_seguimiento_sgdu.company_id_01'),
            'currency_id': self.ref('project_obra_seguimiento_sgdu.currency_id_01'),
            'user_id': self.ref('project_obra_seguimiento_sgdu.user_id_01'),
            'fecha': "1999-12-31",
            'periodo_fecha_inicio': "1987-05-03",
            'periodo_fecha_fin': "2012-05-02",
            'semana': 21002790,
            'dias_ejecucion': 73972974,
            'proyecto_id': self.ref('project_obra_seguimiento_sgdu.proyecto_id_01'),
            'etapa_actual_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_id_01'),
            'etapa_actual_tipo_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_tipo_id_01'),
            'avance_por_componente_ids': [
                (4, self.ref('project_obra_seguimiento_sgdu.avance_por_componente_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            sgdu_informe_avance.sudo(user_group_project_user_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(sgdu_informe_avance_model))

        # ----------------------------
        # project_obra.sgdu.informe_avance.detalle_componente
        # ----------------------------
        sgdu_informe_avance_detalle_componente_model = self.env['project_obra.sgdu.informe_avance.detalle_componente']
        # Actualización permitida
        vals = {
            'informe_id': self.ref('project_obra_seguimiento_sgdu.informe_id_01'),
            'componente_id': self.ref('project_obra_seguimiento_sgdu.componente_id_01'),
            'ejecutado_porcentaje_fisico': 74841989.6952,
        }
        sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_group_project_user_01).search([], limit=1)
        sgdu_informe_avance_detalle_componente.sudo(user_group_project_user_01).write(vals)

        # Actualización NO permitida
        vals = {
            'informe_id': self.ref('project_obra_seguimiento_sgdu.informe_id_01'),
            'componente_id': self.ref('project_obra_seguimiento_sgdu.componente_id_01'),
            'ejecutado_porcentaje_fisico': 15260399.8423,
        }
        sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            sgdu_informe_avance_detalle_componente.sudo(user_group_project_user_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(sgdu_informe_avance_detalle_componente_model))

    def test_030_project_group_project_user_unlink(self):
        """ project.group_project_user Verifica reglas de dominio en operación UNLINK - Delete """
        user_group_project_user_01 = self.ref('project_obra_seguimiento_sgdu.group_project_user_user_01')
        user_group_project_user_02 = self.ref('project_obra_seguimiento_sgdu.group_project_user_user_02')

        # ----------------------------
        # project_obra.sgdu.informe_avance
        # ----------------------------
        sgdu_informe_avance_model = self.env['project_obra.sgdu.informe_avance']
        # Eliminación permitida
        sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_group_project_user_01).search([], limit=1)
        sgdu_informe_avance.sudo(user_group_project_user_01).unlink()

        # Eliminación NO permitida
        sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            sgdu_informe_avance.sudo(user_group_project_user_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(sgdu_informe_avance_model))

        # ----------------------------
        # project_obra.sgdu.informe_avance.detalle_componente
        # ----------------------------
        sgdu_informe_avance_detalle_componente_model = self.env['project_obra.sgdu.informe_avance.detalle_componente']
        # Eliminación permitida
        sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_group_project_user_01).search([], limit=1)
        sgdu_informe_avance_detalle_componente.sudo(user_group_project_user_01).unlink()

        # Eliminación NO permitida
        sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_group_project_user_01).search([], limit=1)
        try:
            sgdu_informe_avance_detalle_componente.sudo(user_group_project_user_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(sgdu_informe_avance_detalle_componente_model))


if __name__ == '__main__':
    unittest2.main()