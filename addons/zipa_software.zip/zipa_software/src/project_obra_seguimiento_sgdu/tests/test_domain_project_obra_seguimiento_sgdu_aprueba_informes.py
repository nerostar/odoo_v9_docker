# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import AccessError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class test_security_project_obra_seguimiento_sgdu_aprueba_informes(common.TransactionCase):
    def test_000_project_obra_seguimiento_sgdu_aprueba_informes_search(self):
        """ project_obra_seguimiento_sgdu.aprueba_informes Verifica reglas de dominio en operación READ """
        user_aprueba_informes_01 = self.ref('project_obra_seguimiento_sgdu.aprueba_informes_user_01')
        user_aprueba_informes_02 = self.ref('project_obra_seguimiento_sgdu.aprueba_informes_user_02')

        # ----------------------------
        # project_obra.sgdu.informe_avance
        # ----------------------------
        sgdu_informe_avance_model = self.env['project_obra.sgdu.informe_avance']
        self.assertEqual(1000, sgdu_informe_avance_model.sudo(user_aprueba_informes_01).search_count([]))
        self.assertEqual(1000, sgdu_informe_avance_model.sudo(user_aprueba_informes_02).search_count([]))

        # ----------------------------
        # project_obra.sgdu.informe_avance.detalle_componente
        # ----------------------------
        sgdu_informe_avance_detalle_componente_model = self.env['project_obra.sgdu.informe_avance.detalle_componente']
        self.assertEqual(1000, sgdu_informe_avance_detalle_componente_model.sudo(user_aprueba_informes_01).search_count([]))
        self.assertEqual(1000, sgdu_informe_avance_detalle_componente_model.sudo(user_aprueba_informes_02).search_count([]))

    def test_010_project_obra_seguimiento_sgdu_aprueba_informes_create(self):
        """ project_obra_seguimiento_sgdu.aprueba_informes Verifica reglas de dominio en operación CREATE """
        user_aprueba_informes_01 = self.ref('project_obra_seguimiento_sgdu.aprueba_informes_user_01')
        user_aprueba_informes_02 = self.ref('project_obra_seguimiento_sgdu.aprueba_informes_user_02')

        # ----------------------------
        # project_obra.sgdu.informe_avance
        # ----------------------------
        sgdu_informe_avance_model = self.env['project_obra.sgdu.informe_avance']
        # Creación permitida
        vals = {
            'state': "pre_aprobado",
            'company_id': self.ref('project_obra_seguimiento_sgdu.company_id_01'),
            'currency_id': self.ref('project_obra_seguimiento_sgdu.currency_id_01'),
            'user_id': self.ref('project_obra_seguimiento_sgdu.user_id_01'),
            'fecha': "1974-09-18",
            'periodo_fecha_inicio': "1999-04-14",
            'periodo_fecha_fin': "1976-08-13",
            'semana': 16430141,
            'dias_ejecucion': 74792083,
            'proyecto_id': self.ref('project_obra_seguimiento_sgdu.proyecto_id_01'),
            'etapa_actual_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_id_01'),
            'etapa_actual_tipo_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_tipo_id_01'),
            'avance_por_componente_ids': [
                (4, self.ref('project_obra_seguimiento_sgdu.avance_por_componente_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_aprueba_informes_01).create(vals)

        # Creación NO permitida
        vals = {
            'state': "aprobado",
            'company_id': self.ref('project_obra_seguimiento_sgdu.company_id_01'),
            'currency_id': self.ref('project_obra_seguimiento_sgdu.currency_id_01'),
            'user_id': self.ref('project_obra_seguimiento_sgdu.user_id_01'),
            'fecha': "1995-06-28",
            'periodo_fecha_inicio': "1996-06-02",
            'periodo_fecha_fin': "2005-04-10",
            'semana': 36276309,
            'dias_ejecucion': 74407220,
            'proyecto_id': self.ref('project_obra_seguimiento_sgdu.proyecto_id_01'),
            'etapa_actual_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_id_01'),
            'etapa_actual_tipo_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_tipo_id_01'),
            'avance_por_componente_ids': [
                (4, self.ref('project_obra_seguimiento_sgdu.avance_por_componente_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_aprueba_informes_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(sgdu_informe_avance_model))

        # ----------------------------
        # project_obra.sgdu.informe_avance.detalle_componente
        # ----------------------------
        sgdu_informe_avance_detalle_componente_model = self.env['project_obra.sgdu.informe_avance.detalle_componente']
        # Creación permitida
        vals = {
            'informe_id': self.ref('project_obra_seguimiento_sgdu.informe_id_01'),
            'componente_id': self.ref('project_obra_seguimiento_sgdu.componente_id_01'),
            'ejecutado_porcentaje_fisico': 65128247.4457,
        }
        sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_aprueba_informes_01).create(vals)

        # Creación NO permitida
        vals = {
            'informe_id': self.ref('project_obra_seguimiento_sgdu.informe_id_01'),
            'componente_id': self.ref('project_obra_seguimiento_sgdu.componente_id_01'),
            'ejecutado_porcentaje_fisico': 28946052.4852,
        }
        try:
            sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_aprueba_informes_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(sgdu_informe_avance_detalle_componente_model))

    def test_020_project_obra_seguimiento_sgdu_aprueba_informes_write(self):
        """ project_obra_seguimiento_sgdu.aprueba_informes Verifica reglas de dominio en operación WRITE """
        user_aprueba_informes_01 = self.ref('project_obra_seguimiento_sgdu.aprueba_informes_user_01')
        user_aprueba_informes_02 = self.ref('project_obra_seguimiento_sgdu.aprueba_informes_user_02')

        # ----------------------------
        # project_obra.sgdu.informe_avance
        # ----------------------------
        sgdu_informe_avance_model = self.env['project_obra.sgdu.informe_avance']
        # Actualización permitida
        vals = {
            'state': "nuevo",
            'company_id': self.ref('project_obra_seguimiento_sgdu.company_id_01'),
            'currency_id': self.ref('project_obra_seguimiento_sgdu.currency_id_01'),
            'user_id': self.ref('project_obra_seguimiento_sgdu.user_id_01'),
            'fecha': "1976-02-06",
            'periodo_fecha_inicio': "2016-06-01",
            'periodo_fecha_fin': "1983-04-05",
            'semana': 22549566,
            'dias_ejecucion': 8035036,
            'proyecto_id': self.ref('project_obra_seguimiento_sgdu.proyecto_id_01'),
            'etapa_actual_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_id_01'),
            'etapa_actual_tipo_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_tipo_id_01'),
            'avance_por_componente_ids': [
                (4, self.ref('project_obra_seguimiento_sgdu.avance_por_componente_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_aprueba_informes_01).search([], limit=1)
        sgdu_informe_avance.sudo(user_aprueba_informes_01).write(vals)

        # Actualización NO permitida
        vals = {
            'state': "publicado",
            'company_id': self.ref('project_obra_seguimiento_sgdu.company_id_01'),
            'currency_id': self.ref('project_obra_seguimiento_sgdu.currency_id_01'),
            'user_id': self.ref('project_obra_seguimiento_sgdu.user_id_01'),
            'fecha': "1978-05-27",
            'periodo_fecha_inicio': "2008-05-16",
            'periodo_fecha_fin': "1971-04-21",
            'semana': 50933043,
            'dias_ejecucion': 50063702,
            'proyecto_id': self.ref('project_obra_seguimiento_sgdu.proyecto_id_01'),
            'etapa_actual_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_id_01'),
            'etapa_actual_tipo_id': self.ref('project_obra_seguimiento_sgdu.etapa_actual_tipo_id_01'),
            'avance_por_componente_ids': [
                (4, self.ref('project_obra_seguimiento_sgdu.avance_por_componente_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_aprueba_informes_01).search([], limit=1)
        try:
            sgdu_informe_avance.sudo(user_aprueba_informes_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(sgdu_informe_avance_model))

        # ----------------------------
        # project_obra.sgdu.informe_avance.detalle_componente
        # ----------------------------
        sgdu_informe_avance_detalle_componente_model = self.env['project_obra.sgdu.informe_avance.detalle_componente']
        # Actualización permitida
        vals = {
            'informe_id': self.ref('project_obra_seguimiento_sgdu.informe_id_01'),
            'componente_id': self.ref('project_obra_seguimiento_sgdu.componente_id_01'),
            'ejecutado_porcentaje_fisico': 2118032.73346,
        }
        sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_aprueba_informes_01).search([], limit=1)
        sgdu_informe_avance_detalle_componente.sudo(user_aprueba_informes_01).write(vals)

        # Actualización NO permitida
        vals = {
            'informe_id': self.ref('project_obra_seguimiento_sgdu.informe_id_01'),
            'componente_id': self.ref('project_obra_seguimiento_sgdu.componente_id_01'),
            'ejecutado_porcentaje_fisico': 7074020.20384,
        }
        sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_aprueba_informes_01).search([], limit=1)
        try:
            sgdu_informe_avance_detalle_componente.sudo(user_aprueba_informes_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(sgdu_informe_avance_detalle_componente_model))

    def test_030_project_obra_seguimiento_sgdu_aprueba_informes_unlink(self):
        """ project_obra_seguimiento_sgdu.aprueba_informes Verifica reglas de dominio en operación UNLINK - Delete """
        user_aprueba_informes_01 = self.ref('project_obra_seguimiento_sgdu.aprueba_informes_user_01')
        user_aprueba_informes_02 = self.ref('project_obra_seguimiento_sgdu.aprueba_informes_user_02')

        # ----------------------------
        # project_obra.sgdu.informe_avance
        # ----------------------------
        sgdu_informe_avance_model = self.env['project_obra.sgdu.informe_avance']
        # Eliminación permitida
        sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_aprueba_informes_01).search([], limit=1)
        sgdu_informe_avance.sudo(user_aprueba_informes_01).unlink()

        # Eliminación NO permitida
        sgdu_informe_avance = sgdu_informe_avance_model.sudo(user_aprueba_informes_01).search([], limit=1)
        try:
            sgdu_informe_avance.sudo(user_aprueba_informes_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(sgdu_informe_avance_model))

        # ----------------------------
        # project_obra.sgdu.informe_avance.detalle_componente
        # ----------------------------
        sgdu_informe_avance_detalle_componente_model = self.env['project_obra.sgdu.informe_avance.detalle_componente']
        # Eliminación permitida
        sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_aprueba_informes_01).search([], limit=1)
        sgdu_informe_avance_detalle_componente.sudo(user_aprueba_informes_01).unlink()

        # Eliminación NO permitida
        sgdu_informe_avance_detalle_componente = sgdu_informe_avance_detalle_componente_model.sudo(user_aprueba_informes_01).search([], limit=1)
        try:
            sgdu_informe_avance_detalle_componente.sudo(user_aprueba_informes_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(sgdu_informe_avance_detalle_componente_model))


if __name__ == '__main__':
    unittest2.main()