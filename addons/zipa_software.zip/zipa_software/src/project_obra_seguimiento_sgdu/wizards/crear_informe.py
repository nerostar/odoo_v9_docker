# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api
from openerp.exceptions import ValidationError,Warning
import datetime as DT
import logging
_logger = logging.getLogger(__name__)


class project_obra_seguimiento_sgdu_wizard_informe(models.TransientModel):
    _name = 'project_obra.sgdu.wizard.crear_informe'
    _description = 'Wizard para Crear Informe SGDU'

    def ultima_semana(self):
        hoy = DT.date.today()
        ultima_semana = hoy - DT.timedelta(days=6)
        return ultima_semana.strftime('%Y-%m-%d')

    # -------------------
    # Fields
    # -------------------
    user_id = fields.Many2one(
        string='Autor',
        required=True,
        track_visibility='onchange',
        comodel_name='res.users',
        ondelete='restrict',
        readonly=True,
        default=lambda self: self._context.get('uid', self.env['res.users'].browse()),
    )
    proyecto_id = fields.Many2one(
        string='Proyecto',
        required=True,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
    )
    periodo_fecha_inicio = fields.Date(
        string='Desde',
        required=True,
        track_visibility='onchange',
        help='''Fecha de Inicio del periodo a reportarse''',
        default=ultima_semana,
    )
    periodo_fecha_fin = fields.Date(
        string='Hasta',
        required=True,
        track_visibility='onchange',
        help='''Fecha de finalización del periodo a reportarse''',
        default=fields.Date.today,
    )
    semana = fields.Integer(
        string='Semana No',
        required=True,
        track_visibility='onchange',
    )

    # -------------------
    # methods
    # -------------------

    @api.one
    def _check_fechas(self):
        if(self.periodo_fecha_inicio and self.periodo_fecha_fin and
           self.periodo_fecha_inicio > self.periodo_fecha_fin
            ):
            raise ValidationError("Fecha de inicio {} no puede ser posterior a la de finalización {}".format(
                self.periodo_fecha_inicio, self.periodo_fecha_fin)
            )

    @api.one
    @api.constrains('periodo_fecha_inicio')
    def _check_periodo_fecha_inicio(self):
        self._check_fechas()

    @api.one
    @api.constrains('periodo_fecha_fin')
    def _check_periodo_fecha_fin(self):
        self._check_fechas()

    @api.onchange('periodo_fecha_inicio')
    def _onchange_periodo_fecha_inicio(self):
        try:
            self._check_periodo_fecha_inicio()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.onchange('periodo_fecha_fin')
    def _onchange_periodo_fecha_fin(self):
        try:
            self._check_periodo_fecha_fin()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.onchange('user_id')
    def _onchange_user_id(self):
        # TODO: Listar solo proyectos en prefactibilidad
        pass

    @api.multi
    def crear_informe(self):
        self.ensure_one()
        tipo_etapa_ids = self.env['project_obra.proyecto.etapa.tipo'].search([('name','in',["Prefactibilidad", "Factibilidad", "Estudios y Diseños"])]).ids
        # tomar proyecto y buscar etapa en prefactibilidad
        etapa_found = self.env['project_obra.proyecto.etapa'].search([
            ('proyecto_id','=',self.proyecto_id.id),
            ('tipo_id','in',tipo_etapa_ids),
            ('state','=','open'),
        ], limit=1, order='id DESC')
        if not etapa_found:
            raise Warning('El proyecto no se encuentra en la etapa de pre-factibilidad, factibilidad o Estudios y diseños')
        data_cabecera = {
            'user_id': self.user_id.id,
            'fecha': self.periodo_fecha_fin,
            'periodo_fecha_inicio': self.periodo_fecha_inicio,
            'periodo_fecha_fin': self.periodo_fecha_fin,
            'semana': self.semana,
            'proyecto_id': self.proyecto_id.id,
            'etapa_actual_id': etapa_found.id,
        }
        # Crear lineas para reportar componentes
        componentes = self.env['project_obra.proyecto.frente_obra'].search([
            ('proyecto_id', '=', self.proyecto_id.id),
            ('tipo_etapa_id', '=', etapa_found.tipo_id.id)
        ])
        if not len(componentes):
            componentes = self.env['project_obra.proyecto.frente_obra'].search([('proyecto_id', '=', self.proyecto_id.id)])

        lineas_componente = []
        for c in componentes:
            lineas_componente.append(
                (0,0,{ # Crea una linea por cada componente
                    'componente_id': c.id,
                    'ejecutado_porcentaje_fisico': 0,
                })
            )

        cabecera = self.env['project_obra.informe_cabecera'].create(data_cabecera)
        # Crear informe sgdu
        informe = self.env['project_obra.sgdu.informe_avance'].with_context(cabecera_id=cabecera.id).create({
            'cabecera_id': cabecera.id,
            'avance_por_componente_ids': lineas_componente,
        })
        # redireccionar a informe
        return {
            'type': 'ir.actions.act_window',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'project_obra.sgdu.informe_avance',
            'res_id': informe.id,
        }
