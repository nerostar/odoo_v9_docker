# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api
from openerp.exceptions import ValidationError


class project_obra_sgdu_informe_avance(models.Model):
    _name = 'project_obra.sgdu.informe_avance'
    _description = 'Informe Avance de Prefactibilidad'
    _inherit = ['mail.thread', 'models.soft_delete.mixin', 'project_obra.informe.workflow_mixin']
    _inherits = {
        'project_obra.informe_cabecera': 'cabecera_id',
    }

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=100,
        compute='_compute_name',
        store=True,
    )
    programado_porcentaje_avance_fisico = fields.Float(
        string='Porcentaje Programado de Avance Físico',
        required=False,
        track_visibility='onchange',
        compute='_compute_programado_porcentaje_avance_fisico',
        store=True,
    )
    ejecutado_porcentaje_avance_fisico = fields.Float(
        string='Porcentaje Ejecutado de Avance Físico',
        required=False,
        track_visibility='onchange',
        compute='_compute_ejecutado_porcentaje_avance_fisico',
        store=True,
    )
    avance_por_componente_ids = fields.One2many(
        string='Avances Por Componente',
        required=False,
        readonly=False,
        comodel_name='project_obra.sgdu.informe_avance.detalle_componente',
        inverse_name='informe_id',
        ondelete='restrict',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    cabecera_id = fields.Many2one(
        comodel_name="project_obra.informe_cabecera",
        ondelete='restrict',
        required=True,
    )

    # -------------------
    # methods
    # -------------------

    @api.model
    def create(self, vals):
        sgdu_informe_avance = super(project_obra_sgdu_informe_avance, self).create(vals)
        return sgdu_informe_avance

    @api.one
    def write(self, vals):
        res = super(project_obra_sgdu_informe_avance, self).write(vals)
        return res

    @api.one
    @api.depends('cabecera_id')
    def _compute_name(self):
        self.name = self.name = "Informe {} - {} ({})".format(self.proyecto_id.name, self.fecha, self.state)

    @api.one
    def compute_programado_porcentaje_avance_fisico(self):
        self._compute_programado_porcentaje_avance_fisico()
        return True

    @api.one
    @api.depends('periodo_fecha_fin', 'state')
    def _compute_programado_porcentaje_avance_fisico(self):
        total = 0
        for a in self.avance_por_componente_ids:
            total += (a.componente_id._calcular_ejecucion_esperada(self.periodo_fecha_fin) * (float(a.componente_id.peso or 0)/100.0))
            # print a.name, total, a.componente_id._calcular_ejecucion_esperada(self.periodo_fecha_fin), (a.componente_id.peso or 0)
        self.programado_porcentaje_avance_fisico = total

    @api.one
    @api.depends('periodo_fecha_fin', 'fecha', 'avance_por_componente_ids.ejecutado_porcentaje_fisico')
    def _compute_ejecutado_porcentaje_avance_fisico(self):
        total = 0
        for a in self.avance_por_componente_ids:
            total += (a.ejecutado_porcentaje_fisico * (float(a.componente_id.peso or 0)/100.0))
            # print a.name, total, a.ejecutado_porcentaje_fisico, (a.componente_id.peso or 0)
        self.ejecutado_porcentaje_avance_fisico = total

    @api.one
    @api.constrains('periodo_fecha_inicio')
    def _check_periodo_fecha_inicio(self):
        if self.periodo_fecha_inicio == 'Condición de Validation':
            raise ValidationError("MENSAJE DE ERROR DE VALIDACIÓN")

    @api.one
    @api.constrains('periodo_fecha_fin')
    def _check_periodo_fecha_fin(self):
        if self.periodo_fecha_fin == 'Condición de Validation':
            raise ValidationError("MENSAJE DE ERROR DE VALIDACIÓN")

    @api.one
    @api.constrains('programado_porcentaje_avance_fisico')
    def _check_programado_porcentaje_avance_fisico(self):
        if self.programado_porcentaje_avance_fisico == 'Condición de Validation':
            raise ValidationError("MENSAJE DE ERROR DE VALIDACIÓN")

    @api.one
    @api.constrains('ejecutado_porcentaje_avance_fisico')
    def _check_ejecutado_porcentaje_avance_fisico(self):
        if self.ejecutado_porcentaje_avance_fisico == 'Condición de Validation':
            raise ValidationError("MENSAJE DE ERROR DE VALIDACIÓN")

    @api.onchange('periodo_fecha_inicio')
    def _onchange_periodo_fecha_inicio(self):
        try:
            self._check_periodo_fecha_inicio()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.onchange('periodo_fecha_fin')
    def _onchange_periodo_fecha_fin(self):
        try:
            self._check_periodo_fecha_fin()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.onchange('programado_porcentaje_avance_fisico')
    def _onchange_programado_porcentaje_avance_fisico(self):
        try:
            self._check_programado_porcentaje_avance_fisico()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.onchange('ejecutado_porcentaje_avance_fisico')
    def _onchange_ejecutado_porcentaje_avance_fisico(self):
        try:
            self._check_ejecutado_porcentaje_avance_fisico()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }


class project_obra_sgdu_informe_avance_detalle_componente(models.Model):
    _name = 'project_obra.sgdu.informe_avance.detalle_componente'
    _description = 'Informe Avance de Componente de Prefactibilidad'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        readonly=True,
        track_visibility='onchange',
        size=255,
        compute='_compute_name',
        store=True,
    )
    informe_id = fields.Many2one(
        string='Informe',
        required=True,
        readonly=True,
        track_visibility='onchange',
        comodel_name='project_obra.sgdu.informe_avance',
        ondelete='restrict',
        default=lambda self: self._context.get('informe_id', self.env['project_obra.sgdu.informe_avance'].browse()),
    )
    state = fields.Selection(
        string='Estado de la Cabecera Informe',
        required=False,
        readonly=True,
        related='informe_id.cabecera_id.state',
    )
    proyecto_id = fields.Many2one(
        string='Proyecto',
        required=True,
        readonly=True,
        track_visibility='onchange',
        related='informe_id.proyecto_id',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
    )
    etapa_actual_tipo_id = fields.Many2one(
        string='Etapa Actual (tipo)',
        required=False,
        readonly=True,
        track_visibility='onchange',
        related='informe_id.etapa_actual_tipo_id',
        comodel_name='project_obra.proyecto.etapa.tipo',
        ondelete='restrict',
    )
    componente_id = fields.Many2one(
        string='Componente',
        required=True,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.frente_obra',
        ondelete='restrict',
        domain="[('proyecto_id','=',proyecto_id),('tipo_etapa_id','=',etapa_actual_tipo_id)]",
    )
    componente_peso = fields.Integer(
        string='Peso Componente',
        required=False,
        readonly=True,
        related='componente_id.peso',
    )
    programado_porcentaje_fisico = fields.Float(
        string='% Avance Programado',
        required=False,
        track_visibility='onchange',
        compute='_compute_programado_porcentaje_fisico',
    )
    ejecutado_porcentaje_fisico = fields.Float(
        string='% Avance Ejecutado',
        required=True,
        readonly=False,
        track_visibility='onchange',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )

    # -------------------
    # methods
    # -------------------

    @api.model
    def create(self, vals):
        sgdu_informe_avance_detalle_componente = super(project_obra_sgdu_informe_avance_detalle_componente, self).create(vals)
        return sgdu_informe_avance_detalle_componente

    @api.one
    def write(self, vals):
        res = super(project_obra_sgdu_informe_avance_detalle_componente, self).write(vals)
        return res

    @api.one
    @api.depends('informe_id', 'componente_id')
    def _compute_name(self):
        self.name = "{} - {}".format(self.informe_id.name, self.componente_id.name)

    @api.one
    def _compute_programado_porcentaje_fisico(self):
        self.programado_porcentaje_fisico = self.componente_id._calcular_ejecucion_esperada(self.informe_id.periodo_fecha_fin)

    @api.one
    @api.constrains('ejecutado_porcentaje_fisico')
    def _check_ejecutado_porcentaje_fisico(self):
        if self.ejecutado_porcentaje_fisico < 0 or self.ejecutado_porcentaje_fisico > 100:
            raise ValidationError("El porcentaje ejecutado debe ser un valor entre 0 y 100")

    @api.onchange('ejecutado_porcentaje_fisico')
    def _onchange_ejecutado_porcentaje_fisico(self):
        try:
            self._check_ejecutado_porcentaje_fisico()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }
