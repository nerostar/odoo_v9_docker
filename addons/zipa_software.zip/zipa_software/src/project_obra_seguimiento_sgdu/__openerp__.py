{
    'name': 'Seguimiento Proyectos SGDU',
    'version': '1.0',
    'depends': [
        'base',
        'model_security',
        'project_obra_portafolio_idu',
        'project_obra_seguimiento_idu',
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/project_obra_view.xml',
        'wizards/crear_informe_view.xml',
        'workflow/sgdu_informe_avance_workflow.xml',
    ],
    'test': [
        #'tests/001_users.yml',
    ],
    'demo': [
        #'tests/001_users.yml',
    ],
    'installable': True,
    'description': """
## Dependencias módulos Python
## Configuración adicional
    """,
}

