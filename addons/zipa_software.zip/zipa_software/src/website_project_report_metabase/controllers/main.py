# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp.addons.web import http
from openerp.addons.web.http import request

class controller(http.Controller):

    ###########################################################################################
    # TABLEROS DE CONTROL
    ###########################################################################################

    @http.route(['/zipa/tableros_control'], type='http', auth="user", website=True)
    def tableros_control_index(self, **kwargs):

        tablero_control_model = request.env['tablero.tablero']

        datos = {}

        datos_tableros = tablero_control_model.search([['active', '=', True]])

        datos['tableros_json'] = datos_tableros
        return request.website.render(
            "website_project_report_metabase.tableros_control",
            datos,
        )