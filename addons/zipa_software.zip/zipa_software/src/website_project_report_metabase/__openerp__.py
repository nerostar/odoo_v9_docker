{
    'name': 'Website portafolio de tableros de control',
    'version': '1.0',
    'depends': [
        'website_project_idu',
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/main_templates.xml',
        'views/tablero_control_template.xml',
    ],
    'installable': True,
    'description': 
        """
            Sitio Web de acceso para ver los tableros de control del IDU
        """,
}

