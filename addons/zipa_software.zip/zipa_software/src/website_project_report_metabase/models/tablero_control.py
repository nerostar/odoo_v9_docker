# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, api, fields


class tablero_tablero(models.Model):
    _name = 'tablero.tablero'
    _description = 'tablero de control'
    #_inherit = ['mail.thread']
    #_order = 'sequence, numero ASC'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        size=255,
    )
    descripcion = fields.Text(
        string='Descripción del tablero',
        required=False,
    )
    url_image = fields.Char(
        string='URL imagen',
        required=False,
        size=255,
    )
    url_tablero = fields.Char(
        string='URL tablero',
        required=True,
        size=255,
    )
    active = fields.Boolean(
        string='Activo',
        default=True,
    )
    

    # -------------------
    # methods
    # -------------------