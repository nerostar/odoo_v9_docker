{
    'name': 'Seguimiento a Construcciones',
    'version': '1.0',
    'depends': [
        'base',
        'model_security',
        'project_obra_portafolio_idu',
        'project_obra_seguimiento_idu',
        'project_obra_seguimiento_dtm',
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/project_obra_view.xml',
        'workflow/construccion_informe_avance_workflow.xml',
        'wizards/wizard_reporte_informe_construccion.xml',
        'wizards/relacionar_frente_a_informe_view.xml',
    ],
    'test': [
    ],
    'demo': [
    ],
    'installable': True,
    'description': """
## Dependencias módulos Python
## Configuración adicional
    """,
}
