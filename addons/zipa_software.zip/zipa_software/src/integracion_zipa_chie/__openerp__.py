{
    'name': 'Integracion Zipa Chie',
    'version': '1.0',
    'depends': [
        'base',
        'base_idu',
        'contrato_idu',
        'project_obra_portafolio_idu',
        'plan_anual_adquisiciones_idu'
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
        'views/main.xml',
    ],
    'installable': True,
    'description': 
        """
        """,
}

