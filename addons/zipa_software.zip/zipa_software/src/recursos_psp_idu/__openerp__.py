{
    'name': 'Recursos PSP',
    'version': '1.0',
    'depends': [
        'base',
        'base_idu',
        'hr',
        'plan_desarrollo_distrital',
        'project_portafolio_idu',
        'plan_anual_adquisiciones_idu',
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/recursos_psp_view.xml',
        'views/hr_view.xml',
        'views/project_view.xml',
        'data/sequences.xml',
        'wizards/generar_cupo_view.xml',
        'workflow/recursos_psp_workflow.xml',
    ],
    'test': [
        'tests/001_users.yml',
    ],
    'demo': [
        'demo/hr.categoria.csv',
        'demo/hr.department.grupo_funcional.csv',
        'demo/hr.department.tema.csv',
        'demo/hr.department.desempeno.csv',
    ],
    'installable': True,
    'description': """
## Dependencias módulos Python
## Configuración adicional
    """,
}

