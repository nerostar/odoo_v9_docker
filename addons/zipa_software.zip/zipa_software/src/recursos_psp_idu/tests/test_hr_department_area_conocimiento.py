# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_hr_department_area_conocimiento(common.TransactionCase):
    def test_crud_validaciones(self):
        department_area_conocimiento_model = self.env['hr.department.area_conocimiento']
        vals = {
            'name': "Illo dignissimos maxime ut reiciendis.",
            'codigo_siac': 22176260,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
        }
        department_area_conocimiento = department_area_conocimiento_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()