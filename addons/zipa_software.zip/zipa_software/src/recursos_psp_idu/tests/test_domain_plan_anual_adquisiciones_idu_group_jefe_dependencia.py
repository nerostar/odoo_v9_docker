# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import AccessError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class test_security_plan_anual_adquisiciones_idu_group_jefe_dependencia(common.TransactionCase):
    def test_000_plan_anual_adquisiciones_idu_group_jefe_dependencia_search(self):
        """ plan_anual_adquisiciones_idu.group_jefe_dependencia Verifica reglas de dominio en operación READ """
        user_group_jefe_dependencia_01 = self.ref('plan_anual_adquisiciones_idu.group_jefe_dependencia_user_01')
        user_group_jefe_dependencia_02 = self.ref('plan_anual_adquisiciones_idu.group_jefe_dependencia_user_02')

        # ----------------------------
        # plan_anual_adquisiciones.plan
        # ----------------------------
        plan_model = self.env['plan_anual_adquisiciones.plan']
        self.assertEqual(1000, plan_model.sudo(user_group_jefe_dependencia_01).search_count([]))
        self.assertEqual(1000, plan_model.sudo(user_group_jefe_dependencia_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea
        # ----------------------------
        plan_linea_model = self.env['plan_anual_adquisiciones.plan.linea']
        self.assertEqual(1000, plan_linea_model.sudo(user_group_jefe_dependencia_01).search_count([]))
        self.assertEqual(1000, plan_linea_model.sudo(user_group_jefe_dependencia_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.tipo_proceso
        # ----------------------------
        tipo_proceso_model = self.env['plan_anual_adquisiciones.tipo_proceso']
        self.assertEqual(1000, tipo_proceso_model.sudo(user_group_jefe_dependencia_01).search_count([]))
        self.assertEqual(1000, tipo_proceso_model.sudo(user_group_jefe_dependencia_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.modalidad_seleccion
        # ----------------------------
        modalidad_seleccion_model = self.env['plan_anual_adquisiciones.modalidad_seleccion']
        self.assertEqual(1000, modalidad_seleccion_model.sudo(user_group_jefe_dependencia_01).search_count([]))
        self.assertEqual(1000, modalidad_seleccion_model.sudo(user_group_jefe_dependencia_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.solicitud_cambio
        # ----------------------------
        solicitud_cambio_model = self.env['plan_anual_adquisiciones.solicitud_cambio']
        self.assertEqual(1000, solicitud_cambio_model.sudo(user_group_jefe_dependencia_01).search_count([]))
        self.assertEqual(1000, solicitud_cambio_model.sudo(user_group_jefe_dependencia_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.pago_programado
        # ----------------------------
        plan_linea_pago_programado_model = self.env['plan_anual_adquisiciones.plan.linea.pago_programado']
        self.assertEqual(1000, plan_linea_pago_programado_model.sudo(user_group_jefe_dependencia_01).search_count([]))
        self.assertEqual(1000, plan_linea_pago_programado_model.sudo(user_group_jefe_dependencia_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.cupo_psp
        # ----------------------------
        cupo_psp_model = self.env['plan_anual_adquisiciones.cupo_psp']
        self.assertEqual(1000, cupo_psp_model.sudo(user_group_jefe_dependencia_01).search_count([]))
        self.assertEqual(1000, cupo_psp_model.sudo(user_group_jefe_dependencia_02).search_count([]))

        # ----------------------------
        # hr.categoria
        # ----------------------------
        categoria_model = self.env['hr.categoria']
        self.assertEqual(1000, categoria_model.sudo(user_group_jefe_dependencia_01).search_count([]))
        self.assertEqual(1000, categoria_model.sudo(user_group_jefe_dependencia_02).search_count([]))

        # ----------------------------
        # hr.department.grupo_funcional
        # ----------------------------
        department_grupo_funcional_model = self.env['hr.department.grupo_funcional']
        self.assertEqual(1000, department_grupo_funcional_model.sudo(user_group_jefe_dependencia_01).search_count([]))
        self.assertEqual(1000, department_grupo_funcional_model.sudo(user_group_jefe_dependencia_02).search_count([]))

        # ----------------------------
        # hr.department.tema
        # ----------------------------
        department_tema_model = self.env['hr.department.tema']
        self.assertEqual(1000, department_tema_model.sudo(user_group_jefe_dependencia_01).search_count([]))
        self.assertEqual(1000, department_tema_model.sudo(user_group_jefe_dependencia_02).search_count([]))

        # ----------------------------
        # hr.department.desempeno
        # ----------------------------
        department_desempeno_model = self.env['hr.department.desempeno']
        self.assertEqual(1000, department_desempeno_model.sudo(user_group_jefe_dependencia_01).search_count([]))
        self.assertEqual(1000, department_desempeno_model.sudo(user_group_jefe_dependencia_02).search_count([]))

        # ----------------------------
        # hr.department.area_conocimiento
        # ----------------------------
        department_area_conocimiento_model = self.env['hr.department.area_conocimiento']
        self.assertEqual(1000, department_area_conocimiento_model.sudo(user_group_jefe_dependencia_01).search_count([]))
        self.assertEqual(1000, department_area_conocimiento_model.sudo(user_group_jefe_dependencia_02).search_count([]))

        # ----------------------------
        # project_idu.recurso
        # ----------------------------
        recurso_model = self.env['project_idu.recurso']
        self.assertEqual(1000, recurso_model.sudo(user_group_jefe_dependencia_01).search_count([]))
        self.assertEqual(1000, recurso_model.sudo(user_group_jefe_dependencia_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.financiacion
        # ----------------------------
        plan_linea_financiacion_model = self.env['plan_anual_adquisiciones.plan.linea.financiacion']
        self.assertEqual(1000, plan_linea_financiacion_model.sudo(user_group_jefe_dependencia_01).search_count([]))
        self.assertEqual(1000, plan_linea_financiacion_model.sudo(user_group_jefe_dependencia_02).search_count([]))

    def test_010_plan_anual_adquisiciones_idu_group_jefe_dependencia_create(self):
        """ plan_anual_adquisiciones_idu.group_jefe_dependencia Verifica reglas de dominio en operación CREATE """
        user_group_jefe_dependencia_01 = self.ref('plan_anual_adquisiciones_idu.group_jefe_dependencia_user_01')
        user_group_jefe_dependencia_02 = self.ref('plan_anual_adquisiciones_idu.group_jefe_dependencia_user_02')

        # ----------------------------
        # plan_anual_adquisiciones.plan
        # ----------------------------
        plan_model = self.env['plan_anual_adquisiciones.plan']
        # Creación permitida
        vals = {
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
            'abierto_edicion': True,
            'vigencia': 8397051,
            'state': "en_ejecucion",
            'linea_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.linea_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_final': "2015-01-06",
            'fecha_inicial': "1973-08-01",
            'version': 3416903,
        }
        plan = plan_model.sudo(user_group_jefe_dependencia_01).create(vals)

        # Creación NO permitida
        vals = {
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
            'abierto_edicion': False,
            'vigencia': 33187637,
            'state': "inicial",
            'linea_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.linea_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_final': "2001-02-12",
            'fecha_inicial': "1986-01-19",
            'version': 15449514,
        }
        try:
            plan = plan_model.sudo(user_group_jefe_dependencia_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(plan_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea
        # ----------------------------
        plan_linea_model = self.env['plan_anual_adquisiciones.plan.linea']
        # Creación permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'state': "inicial",
            'tipo': "inversion",
            'codigo_unspsc': "Et doloribus ut eligendi tenetur.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "obra",
            'tipo_proceso_id': self.ref('plan_anual_adquisiciones_idu.tipo_proceso_id_01'),
            'modalidad_seleccion_id': self.ref('plan_anual_adquisiciones_idu.modalidad_seleccion_id_01'),
            'localizacion': "77",
            'localidad_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'objeto_contractual': "Eligendi ut qui totam impedit ipsam.",
            'plazo_ejecucion_meses': 47651507,
            'a_monto_agotable': False,
            'observaciones': "Quia quis voluptate aut ipsam et voluptas.",
            'no_aplica_unidad_medida_mt': False,
            'unidad_meta_fisica_id': self.ref('plan_anual_adquisiciones_idu.unidad_meta_fisica_id_01'),
            'cantidad_meta_fisica': 31035995.5268,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'pago_programado_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.pago_programado_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        plan_linea = plan_linea_model.sudo(user_group_jefe_dependencia_01).create(vals)

        # Creación NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'state': "inicial",
            'tipo': "funcionamiento",
            'codigo_unspsc': "Est cumque omnis sequi.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "obra",
            'tipo_proceso_id': self.ref('plan_anual_adquisiciones_idu.tipo_proceso_id_01'),
            'modalidad_seleccion_id': self.ref('plan_anual_adquisiciones_idu.modalidad_seleccion_id_01'),
            'localizacion': "localidad",
            'localidad_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'objeto_contractual': "Consequatur est aperiam et doloremque sit quasi esse.",
            'plazo_ejecucion_meses': 1671393,
            'a_monto_agotable': True,
            'observaciones': "Error reiciendis repellendus consequatur iste quis omnis.",
            'no_aplica_unidad_medida_mt': False,
            'unidad_meta_fisica_id': self.ref('plan_anual_adquisiciones_idu.unidad_meta_fisica_id_01'),
            'cantidad_meta_fisica': 17322608.5584,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'pago_programado_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.pago_programado_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            plan_linea = plan_linea_model.sudo(user_group_jefe_dependencia_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(plan_linea_model))

        # ----------------------------
        # plan_anual_adquisiciones.tipo_proceso
        # ----------------------------
        tipo_proceso_model = self.env['plan_anual_adquisiciones.tipo_proceso']
        # Creación permitida
        vals = {
            'name': "Et officiis sapiente et atque corporis.",
        }
        tipo_proceso = tipo_proceso_model.sudo(user_group_jefe_dependencia_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Perspiciatis optio sequi eos vel corporis.",
        }
        try:
            tipo_proceso = tipo_proceso_model.sudo(user_group_jefe_dependencia_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(tipo_proceso_model))

        # ----------------------------
        # plan_anual_adquisiciones.modalidad_seleccion
        # ----------------------------
        modalidad_seleccion_model = self.env['plan_anual_adquisiciones.modalidad_seleccion']
        # Creación permitida
        vals = {
            'name': "Autem et et tempore rerum.",
        }
        modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_jefe_dependencia_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Qui quia reiciendis natus ut.",
        }
        try:
            modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_jefe_dependencia_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(modalidad_seleccion_model))

        # ----------------------------
        # plan_anual_adquisiciones.solicitud_cambio
        # ----------------------------
        solicitud_cambio_model = self.env['plan_anual_adquisiciones.solicitud_cambio']
        # Creación permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tipo_cambio': "adicionar",
            'plan_linea_nueva_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_nueva_id_01'),
            'justificacion': "Nihil eius et at quam et.",
            'state': "rechazado",
        }
        solicitud_cambio = solicitud_cambio_model.sudo(user_group_jefe_dependencia_01).create(vals)

        # Creación NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tipo_cambio': "eliminar",
            'plan_linea_nueva_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_nueva_id_01'),
            'justificacion': "A temporibus omnis culpa iure modi ipsa.",
            'state': "radicado",
        }
        try:
            solicitud_cambio = solicitud_cambio_model.sudo(user_group_jefe_dependencia_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(solicitud_cambio_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.pago_programado
        # ----------------------------
        plan_linea_pago_programado_model = self.env['plan_anual_adquisiciones.plan.linea.pago_programado']
        # Creación permitida
        vals = {
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'mes': "8",
            'valor': 81951050.3507,
        }
        plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_jefe_dependencia_01).create(vals)

        # Creación NO permitida
        vals = {
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'mes': "6",
            'valor': 71650985.5333,
        }
        try:
            plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_jefe_dependencia_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(plan_linea_pago_programado_model))

        # ----------------------------
        # plan_anual_adquisiciones.cupo_psp
        # ----------------------------
        cupo_psp_model = self.env['plan_anual_adquisiciones.cupo_psp']
        # Creación permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'state': "en_ejecucion",
            'tipo': "inversion",
            'codigo_unspsc': "Modi quae hic provident possimus sed quia.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "obra",
            'presupuesto': 89664961.5561,
            'recurso_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.recurso_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'categoria_id': self.ref('plan_anual_adquisiciones_idu.categoria_id_01'),
            'localizacion': "localidad",
            'objeto_contractual': "Modi consequatur hic laboriosam dicta nostrum.",
            'plazo_ejecucion_dias': 57311258,
            'honorarios_mes': 75418574.7698,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        cupo_psp = cupo_psp_model.sudo(user_group_jefe_dependencia_01).create(vals)

        # Creación NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'state': "finalizado",
            'tipo': "funcionamiento",
            'codigo_unspsc': "Commodi non voluptas architecto ad atque vel voluptatum.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "obra",
            'presupuesto': 15837169.9416,
            'recurso_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.recurso_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'categoria_id': self.ref('plan_anual_adquisiciones_idu.categoria_id_01'),
            'localizacion': "77",
            'objeto_contractual': "Et sint minus ut dolor.",
            'plazo_ejecucion_dias': 71372785,
            'honorarios_mes': 19094959.3811,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            cupo_psp = cupo_psp_model.sudo(user_group_jefe_dependencia_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(cupo_psp_model))

        # ----------------------------
        # hr.categoria
        # ----------------------------
        categoria_model = self.env['hr.categoria']
        # Creación permitida
        vals = {
            'name': "Aliquam et ipsum officiis adipisci ut.",
            'codigo_siac': 57739762,
        }
        categoria = categoria_model.sudo(user_group_jefe_dependencia_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Sapiente magni maiores aliquam explicabo laborum eius.",
            'codigo_siac': 92708365,
        }
        try:
            categoria = categoria_model.sudo(user_group_jefe_dependencia_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(categoria_model))

        # ----------------------------
        # hr.department.grupo_funcional
        # ----------------------------
        department_grupo_funcional_model = self.env['hr.department.grupo_funcional']
        # Creación permitida
        vals = {
            'name': "Sapiente aut fugit et maxime.",
            'codigo_siac': 35917914,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tema_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.tema_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_jefe_dependencia_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Provident pariatur soluta culpa maiores corporis est.",
            'codigo_siac': 33361799,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tema_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.tema_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_jefe_dependencia_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(department_grupo_funcional_model))

        # ----------------------------
        # hr.department.tema
        # ----------------------------
        department_tema_model = self.env['hr.department.tema']
        # Creación permitida
        vals = {
            'name': "Aut omnis qui unde.",
            'codigo_siac': 92278199,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_tema = department_tema_model.sudo(user_group_jefe_dependencia_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Omnis quia ab reiciendis dolorem maiores explicabo.",
            'codigo_siac': 21211580,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            department_tema = department_tema_model.sudo(user_group_jefe_dependencia_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(department_tema_model))

        # ----------------------------
        # hr.department.desempeno
        # ----------------------------
        department_desempeno_model = self.env['hr.department.desempeno']
        # Creación permitida
        vals = {
            'name': "Omnis porro vitae saepe dolorem.",
            'codigo_siac': 53702985,
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_desempeno = department_desempeno_model.sudo(user_group_jefe_dependencia_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Velit cum quia fuga reprehenderit deserunt consequatur.",
            'codigo_siac': 29935703,
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            department_desempeno = department_desempeno_model.sudo(user_group_jefe_dependencia_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(department_desempeno_model))

        # ----------------------------
        # hr.department.area_conocimiento
        # ----------------------------
        department_area_conocimiento_model = self.env['hr.department.area_conocimiento']
        # Creación permitida
        vals = {
            'name': "Nobis nostrum eum sapiente voluptatem sint.",
            'codigo_siac': 87789887,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
        }
        department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_jefe_dependencia_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Provident modi assumenda in quisquam.",
            'codigo_siac': 20560755,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
        }
        try:
            department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_jefe_dependencia_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(department_area_conocimiento_model))

        # ----------------------------
        # project_idu.recurso
        # ----------------------------
        recurso_model = self.env['project_idu.recurso']
        # Creación permitida
        vals = {
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'cupo_id': self.ref('plan_anual_adquisiciones_idu.cupo_id_01'),
        }
        recurso = recurso_model.sudo(user_group_jefe_dependencia_01).create(vals)

        # Creación NO permitida
        vals = {
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'cupo_id': self.ref('plan_anual_adquisiciones_idu.cupo_id_01'),
        }
        try:
            recurso = recurso_model.sudo(user_group_jefe_dependencia_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(recurso_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.financiacion
        # ----------------------------
        plan_linea_financiacion_model = self.env['plan_anual_adquisiciones.plan.linea.financiacion']
        # Creación permitida
        vals = {
            'centro_costo_id': self.ref('plan_anual_adquisiciones_idu.centro_costo_id_01'),
            'fuente_id': self.ref('plan_anual_adquisiciones_idu.fuente_id_01'),
            'rubro_id': self.ref('plan_anual_adquisiciones_idu.rubro_id_01'),
            'presupuesto': 95259881.0047,
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
        }
        plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_jefe_dependencia_01).create(vals)

        # Creación NO permitida
        vals = {
            'centro_costo_id': self.ref('plan_anual_adquisiciones_idu.centro_costo_id_01'),
            'fuente_id': self.ref('plan_anual_adquisiciones_idu.fuente_id_01'),
            'rubro_id': self.ref('plan_anual_adquisiciones_idu.rubro_id_01'),
            'presupuesto': 37657360.7758,
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
        }
        try:
            plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_jefe_dependencia_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(plan_linea_financiacion_model))

    def test_020_plan_anual_adquisiciones_idu_group_jefe_dependencia_write(self):
        """ plan_anual_adquisiciones_idu.group_jefe_dependencia Verifica reglas de dominio en operación WRITE """
        user_group_jefe_dependencia_01 = self.ref('plan_anual_adquisiciones_idu.group_jefe_dependencia_user_01')
        user_group_jefe_dependencia_02 = self.ref('plan_anual_adquisiciones_idu.group_jefe_dependencia_user_02')

        # ----------------------------
        # plan_anual_adquisiciones.plan
        # ----------------------------
        plan_model = self.env['plan_anual_adquisiciones.plan']
        # Actualización permitida
        vals = {
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
            'abierto_edicion': True,
            'vigencia': 63805202,
            'state': "inicial",
            'linea_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.linea_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_final': "1994-01-21",
            'fecha_inicial': "1975-09-11",
            'version': 60490115,
        }
        plan = plan_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        plan.sudo(user_group_jefe_dependencia_01).write(vals)

        # Actualización NO permitida
        vals = {
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
            'abierto_edicion': True,
            'vigencia': 54675344,
            'state': "en_ejecucion",
            'linea_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.linea_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_final': "2007-01-03",
            'fecha_inicial': "1990-03-26",
            'version': 97206835,
        }
        plan = plan_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            plan.sudo(user_group_jefe_dependencia_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(plan_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea
        # ----------------------------
        plan_linea_model = self.env['plan_anual_adquisiciones.plan.linea']
        # Actualización permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'state': "aprobado",
            'tipo': "funcionamiento",
            'codigo_unspsc': "Placeat illum architecto officiis.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "psp",
            'tipo_proceso_id': self.ref('plan_anual_adquisiciones_idu.tipo_proceso_id_01'),
            'modalidad_seleccion_id': self.ref('plan_anual_adquisiciones_idu.modalidad_seleccion_id_01'),
            'localizacion': "localidad",
            'localidad_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'objeto_contractual': "Odit quaerat vero id ullam placeat tempore.",
            'plazo_ejecucion_meses': 19032138,
            'a_monto_agotable': True,
            'observaciones': "Doloremque voluptas dolores consequuntur odio quis iusto.",
            'no_aplica_unidad_medida_mt': False,
            'unidad_meta_fisica_id': self.ref('plan_anual_adquisiciones_idu.unidad_meta_fisica_id_01'),
            'cantidad_meta_fisica': 69211312.7613,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'pago_programado_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.pago_programado_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        plan_linea = plan_linea_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        plan_linea.sudo(user_group_jefe_dependencia_01).write(vals)

        # Actualización NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'state': "finalizado",
            'tipo': "inversion",
            'codigo_unspsc': "Odio et praesentium et et neque.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "obra",
            'tipo_proceso_id': self.ref('plan_anual_adquisiciones_idu.tipo_proceso_id_01'),
            'modalidad_seleccion_id': self.ref('plan_anual_adquisiciones_idu.modalidad_seleccion_id_01'),
            'localizacion': "localidad",
            'localidad_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'objeto_contractual': "Sint aut illo dignissimos autem facere commodi molestias.",
            'plazo_ejecucion_meses': 21790257,
            'a_monto_agotable': True,
            'observaciones': "Perferendis saepe eum pariatur iure quia.",
            'no_aplica_unidad_medida_mt': False,
            'unidad_meta_fisica_id': self.ref('plan_anual_adquisiciones_idu.unidad_meta_fisica_id_01'),
            'cantidad_meta_fisica': 91327822.1483,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'pago_programado_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.pago_programado_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        plan_linea = plan_linea_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            plan_linea.sudo(user_group_jefe_dependencia_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(plan_linea_model))

        # ----------------------------
        # plan_anual_adquisiciones.tipo_proceso
        # ----------------------------
        tipo_proceso_model = self.env['plan_anual_adquisiciones.tipo_proceso']
        # Actualización permitida
        vals = {
            'name': "Atque ut quia vero iure.",
        }
        tipo_proceso = tipo_proceso_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        tipo_proceso.sudo(user_group_jefe_dependencia_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Consectetur voluptate sit expedita.",
        }
        tipo_proceso = tipo_proceso_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            tipo_proceso.sudo(user_group_jefe_dependencia_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(tipo_proceso_model))

        # ----------------------------
        # plan_anual_adquisiciones.modalidad_seleccion
        # ----------------------------
        modalidad_seleccion_model = self.env['plan_anual_adquisiciones.modalidad_seleccion']
        # Actualización permitida
        vals = {
            'name': "Natus quod ut illum.",
        }
        modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        modalidad_seleccion.sudo(user_group_jefe_dependencia_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Iste ut dolor et rerum odio expedita impedit.",
        }
        modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            modalidad_seleccion.sudo(user_group_jefe_dependencia_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(modalidad_seleccion_model))

        # ----------------------------
        # plan_anual_adquisiciones.solicitud_cambio
        # ----------------------------
        solicitud_cambio_model = self.env['plan_anual_adquisiciones.solicitud_cambio']
        # Actualización permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tipo_cambio': "modificar",
            'plan_linea_nueva_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_nueva_id_01'),
            'justificacion': "Illo maiores soluta voluptatem.",
            'state': "aprobado",
        }
        solicitud_cambio = solicitud_cambio_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        solicitud_cambio.sudo(user_group_jefe_dependencia_01).write(vals)

        # Actualización NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tipo_cambio': "modificar",
            'plan_linea_nueva_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_nueva_id_01'),
            'justificacion': "Minus ut quibusdam occaecati qui quo itaque.",
            'state': "rechazado",
        }
        solicitud_cambio = solicitud_cambio_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            solicitud_cambio.sudo(user_group_jefe_dependencia_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(solicitud_cambio_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.pago_programado
        # ----------------------------
        plan_linea_pago_programado_model = self.env['plan_anual_adquisiciones.plan.linea.pago_programado']
        # Actualización permitida
        vals = {
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'mes': "4",
            'valor': 46850876.2813,
        }
        plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        plan_linea_pago_programado.sudo(user_group_jefe_dependencia_01).write(vals)

        # Actualización NO permitida
        vals = {
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'mes': "12",
            'valor': 49509889.1416,
        }
        plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            plan_linea_pago_programado.sudo(user_group_jefe_dependencia_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(plan_linea_pago_programado_model))

        # ----------------------------
        # plan_anual_adquisiciones.cupo_psp
        # ----------------------------
        cupo_psp_model = self.env['plan_anual_adquisiciones.cupo_psp']
        # Actualización permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'state': "en_ejecucion",
            'tipo': "inversion",
            'codigo_unspsc': "In optio non ut voluptas harum saepe incidunt.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "obra",
            'presupuesto': 76949580.5368,
            'recurso_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.recurso_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'categoria_id': self.ref('plan_anual_adquisiciones_idu.categoria_id_01'),
            'localizacion': "66",
            'objeto_contractual': "Id dolor aut sint ab aut eveniet.",
            'plazo_ejecucion_dias': 81526241,
            'honorarios_mes': 26274009.863,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        cupo_psp = cupo_psp_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        cupo_psp.sudo(user_group_jefe_dependencia_01).write(vals)

        # Actualización NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'state': "aprobado",
            'tipo': "inversion",
            'codigo_unspsc': "Et quia eligendi facere officiis saepe.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "obra",
            'presupuesto': 94941325.537,
            'recurso_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.recurso_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'categoria_id': self.ref('plan_anual_adquisiciones_idu.categoria_id_01'),
            'localizacion': "66",
            'objeto_contractual': "Est voluptatem iure mollitia dignissimos est expedita.",
            'plazo_ejecucion_dias': 20660713,
            'honorarios_mes': 2906852.64358,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        cupo_psp = cupo_psp_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            cupo_psp.sudo(user_group_jefe_dependencia_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(cupo_psp_model))

        # ----------------------------
        # hr.categoria
        # ----------------------------
        categoria_model = self.env['hr.categoria']
        # Actualización permitida
        vals = {
            'name': "Nam vero cupiditate quasi at id iure libero.",
            'codigo_siac': 35702726,
        }
        categoria = categoria_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        categoria.sudo(user_group_jefe_dependencia_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Impedit earum nemo possimus mollitia omnis veniam.",
            'codigo_siac': 20397391,
        }
        categoria = categoria_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            categoria.sudo(user_group_jefe_dependencia_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(categoria_model))

        # ----------------------------
        # hr.department.grupo_funcional
        # ----------------------------
        department_grupo_funcional_model = self.env['hr.department.grupo_funcional']
        # Actualización permitida
        vals = {
            'name': "Maxime laboriosam adipisci ut a architecto doloribus quia sed.",
            'codigo_siac': 49293736,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tema_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.tema_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        department_grupo_funcional.sudo(user_group_jefe_dependencia_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Maiores voluptatem autem nobis ut voluptatem.",
            'codigo_siac': 93730692,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tema_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.tema_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            department_grupo_funcional.sudo(user_group_jefe_dependencia_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(department_grupo_funcional_model))

        # ----------------------------
        # hr.department.tema
        # ----------------------------
        department_tema_model = self.env['hr.department.tema']
        # Actualización permitida
        vals = {
            'name': "Omnis aspernatur natus quam dolorum.",
            'codigo_siac': 4161667,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_tema = department_tema_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        department_tema.sudo(user_group_jefe_dependencia_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Autem et suscipit explicabo qui.",
            'codigo_siac': 61212880,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_tema = department_tema_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            department_tema.sudo(user_group_jefe_dependencia_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(department_tema_model))

        # ----------------------------
        # hr.department.desempeno
        # ----------------------------
        department_desempeno_model = self.env['hr.department.desempeno']
        # Actualización permitida
        vals = {
            'name': "Est suscipit aut aspernatur officiis voluptates qui.",
            'codigo_siac': 79599244,
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_desempeno = department_desempeno_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        department_desempeno.sudo(user_group_jefe_dependencia_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Et eius optio et omnis fuga amet et repellendus.",
            'codigo_siac': 66996293,
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_desempeno = department_desempeno_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            department_desempeno.sudo(user_group_jefe_dependencia_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(department_desempeno_model))

        # ----------------------------
        # hr.department.area_conocimiento
        # ----------------------------
        department_area_conocimiento_model = self.env['hr.department.area_conocimiento']
        # Actualización permitida
        vals = {
            'name': "Eos reiciendis veritatis accusamus laudantium rerum blanditiis architecto.",
            'codigo_siac': 62038289,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
        }
        department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        department_area_conocimiento.sudo(user_group_jefe_dependencia_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Non sunt odit dolorem impedit.",
            'codigo_siac': 4366409,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
        }
        department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            department_area_conocimiento.sudo(user_group_jefe_dependencia_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(department_area_conocimiento_model))

        # ----------------------------
        # project_idu.recurso
        # ----------------------------
        recurso_model = self.env['project_idu.recurso']
        # Actualización permitida
        vals = {
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'cupo_id': self.ref('plan_anual_adquisiciones_idu.cupo_id_01'),
        }
        recurso = recurso_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        recurso.sudo(user_group_jefe_dependencia_01).write(vals)

        # Actualización NO permitida
        vals = {
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'cupo_id': self.ref('plan_anual_adquisiciones_idu.cupo_id_01'),
        }
        recurso = recurso_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            recurso.sudo(user_group_jefe_dependencia_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(recurso_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.financiacion
        # ----------------------------
        plan_linea_financiacion_model = self.env['plan_anual_adquisiciones.plan.linea.financiacion']
        # Actualización permitida
        vals = {
            'centro_costo_id': self.ref('plan_anual_adquisiciones_idu.centro_costo_id_01'),
            'fuente_id': self.ref('plan_anual_adquisiciones_idu.fuente_id_01'),
            'rubro_id': self.ref('plan_anual_adquisiciones_idu.rubro_id_01'),
            'presupuesto': 13489868.3292,
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
        }
        plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        plan_linea_financiacion.sudo(user_group_jefe_dependencia_01).write(vals)

        # Actualización NO permitida
        vals = {
            'centro_costo_id': self.ref('plan_anual_adquisiciones_idu.centro_costo_id_01'),
            'fuente_id': self.ref('plan_anual_adquisiciones_idu.fuente_id_01'),
            'rubro_id': self.ref('plan_anual_adquisiciones_idu.rubro_id_01'),
            'presupuesto': 93274442.3043,
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
        }
        plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            plan_linea_financiacion.sudo(user_group_jefe_dependencia_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(plan_linea_financiacion_model))

    def test_030_plan_anual_adquisiciones_idu_group_jefe_dependencia_unlink(self):
        """ plan_anual_adquisiciones_idu.group_jefe_dependencia Verifica reglas de dominio en operación UNLINK - Delete """
        user_group_jefe_dependencia_01 = self.ref('plan_anual_adquisiciones_idu.group_jefe_dependencia_user_01')
        user_group_jefe_dependencia_02 = self.ref('plan_anual_adquisiciones_idu.group_jefe_dependencia_user_02')

        # ----------------------------
        # plan_anual_adquisiciones.plan
        # ----------------------------
        plan_model = self.env['plan_anual_adquisiciones.plan']
        # Eliminación permitida
        plan = plan_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        plan.sudo(user_group_jefe_dependencia_01).unlink()

        # Eliminación NO permitida
        plan = plan_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            plan.sudo(user_group_jefe_dependencia_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(plan_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea
        # ----------------------------
        plan_linea_model = self.env['plan_anual_adquisiciones.plan.linea']
        # Eliminación permitida
        plan_linea = plan_linea_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        plan_linea.sudo(user_group_jefe_dependencia_01).unlink()

        # Eliminación NO permitida
        plan_linea = plan_linea_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            plan_linea.sudo(user_group_jefe_dependencia_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(plan_linea_model))

        # ----------------------------
        # plan_anual_adquisiciones.tipo_proceso
        # ----------------------------
        tipo_proceso_model = self.env['plan_anual_adquisiciones.tipo_proceso']
        # Eliminación permitida
        tipo_proceso = tipo_proceso_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        tipo_proceso.sudo(user_group_jefe_dependencia_01).unlink()

        # Eliminación NO permitida
        tipo_proceso = tipo_proceso_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            tipo_proceso.sudo(user_group_jefe_dependencia_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(tipo_proceso_model))

        # ----------------------------
        # plan_anual_adquisiciones.modalidad_seleccion
        # ----------------------------
        modalidad_seleccion_model = self.env['plan_anual_adquisiciones.modalidad_seleccion']
        # Eliminación permitida
        modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        modalidad_seleccion.sudo(user_group_jefe_dependencia_01).unlink()

        # Eliminación NO permitida
        modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            modalidad_seleccion.sudo(user_group_jefe_dependencia_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(modalidad_seleccion_model))

        # ----------------------------
        # plan_anual_adquisiciones.solicitud_cambio
        # ----------------------------
        solicitud_cambio_model = self.env['plan_anual_adquisiciones.solicitud_cambio']
        # Eliminación permitida
        solicitud_cambio = solicitud_cambio_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        solicitud_cambio.sudo(user_group_jefe_dependencia_01).unlink()

        # Eliminación NO permitida
        solicitud_cambio = solicitud_cambio_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            solicitud_cambio.sudo(user_group_jefe_dependencia_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(solicitud_cambio_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.pago_programado
        # ----------------------------
        plan_linea_pago_programado_model = self.env['plan_anual_adquisiciones.plan.linea.pago_programado']
        # Eliminación permitida
        plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        plan_linea_pago_programado.sudo(user_group_jefe_dependencia_01).unlink()

        # Eliminación NO permitida
        plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            plan_linea_pago_programado.sudo(user_group_jefe_dependencia_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(plan_linea_pago_programado_model))

        # ----------------------------
        # plan_anual_adquisiciones.cupo_psp
        # ----------------------------
        cupo_psp_model = self.env['plan_anual_adquisiciones.cupo_psp']
        # Eliminación permitida
        cupo_psp = cupo_psp_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        cupo_psp.sudo(user_group_jefe_dependencia_01).unlink()

        # Eliminación NO permitida
        cupo_psp = cupo_psp_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            cupo_psp.sudo(user_group_jefe_dependencia_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(cupo_psp_model))

        # ----------------------------
        # hr.categoria
        # ----------------------------
        categoria_model = self.env['hr.categoria']
        # Eliminación permitida
        categoria = categoria_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        categoria.sudo(user_group_jefe_dependencia_01).unlink()

        # Eliminación NO permitida
        categoria = categoria_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            categoria.sudo(user_group_jefe_dependencia_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(categoria_model))

        # ----------------------------
        # hr.department.grupo_funcional
        # ----------------------------
        department_grupo_funcional_model = self.env['hr.department.grupo_funcional']
        # Eliminación permitida
        department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        department_grupo_funcional.sudo(user_group_jefe_dependencia_01).unlink()

        # Eliminación NO permitida
        department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            department_grupo_funcional.sudo(user_group_jefe_dependencia_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(department_grupo_funcional_model))

        # ----------------------------
        # hr.department.tema
        # ----------------------------
        department_tema_model = self.env['hr.department.tema']
        # Eliminación permitida
        department_tema = department_tema_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        department_tema.sudo(user_group_jefe_dependencia_01).unlink()

        # Eliminación NO permitida
        department_tema = department_tema_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            department_tema.sudo(user_group_jefe_dependencia_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(department_tema_model))

        # ----------------------------
        # hr.department.desempeno
        # ----------------------------
        department_desempeno_model = self.env['hr.department.desempeno']
        # Eliminación permitida
        department_desempeno = department_desempeno_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        department_desempeno.sudo(user_group_jefe_dependencia_01).unlink()

        # Eliminación NO permitida
        department_desempeno = department_desempeno_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            department_desempeno.sudo(user_group_jefe_dependencia_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(department_desempeno_model))

        # ----------------------------
        # hr.department.area_conocimiento
        # ----------------------------
        department_area_conocimiento_model = self.env['hr.department.area_conocimiento']
        # Eliminación permitida
        department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        department_area_conocimiento.sudo(user_group_jefe_dependencia_01).unlink()

        # Eliminación NO permitida
        department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            department_area_conocimiento.sudo(user_group_jefe_dependencia_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(department_area_conocimiento_model))

        # ----------------------------
        # project_idu.recurso
        # ----------------------------
        recurso_model = self.env['project_idu.recurso']
        # Eliminación permitida
        recurso = recurso_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        recurso.sudo(user_group_jefe_dependencia_01).unlink()

        # Eliminación NO permitida
        recurso = recurso_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            recurso.sudo(user_group_jefe_dependencia_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(recurso_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.financiacion
        # ----------------------------
        plan_linea_financiacion_model = self.env['plan_anual_adquisiciones.plan.linea.financiacion']
        # Eliminación permitida
        plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        plan_linea_financiacion.sudo(user_group_jefe_dependencia_01).unlink()

        # Eliminación NO permitida
        plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_jefe_dependencia_01).search([], limit=1)
        try:
            plan_linea_financiacion.sudo(user_group_jefe_dependencia_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(plan_linea_financiacion_model))


if __name__ == '__main__':
    unittest2.main()