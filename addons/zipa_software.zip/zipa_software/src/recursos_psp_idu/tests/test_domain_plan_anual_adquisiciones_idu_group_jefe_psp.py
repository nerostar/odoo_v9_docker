# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import AccessError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class test_security_plan_anual_adquisiciones_idu_group_jefe_psp(common.TransactionCase):
    def test_000_plan_anual_adquisiciones_idu_group_jefe_psp_search(self):
        """ plan_anual_adquisiciones_idu.group_jefe_psp Verifica reglas de dominio en operación READ """
        user_group_jefe_psp_01 = self.ref('plan_anual_adquisiciones_idu.group_jefe_psp_user_01')
        user_group_jefe_psp_02 = self.ref('plan_anual_adquisiciones_idu.group_jefe_psp_user_02')

        # ----------------------------
        # plan_anual_adquisiciones.plan
        # ----------------------------
        plan_model = self.env['plan_anual_adquisiciones.plan']
        self.assertEqual(1000, plan_model.sudo(user_group_jefe_psp_01).search_count([]))
        self.assertEqual(1000, plan_model.sudo(user_group_jefe_psp_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea
        # ----------------------------
        plan_linea_model = self.env['plan_anual_adquisiciones.plan.linea']
        self.assertEqual(1000, plan_linea_model.sudo(user_group_jefe_psp_01).search_count([]))
        self.assertEqual(1000, plan_linea_model.sudo(user_group_jefe_psp_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.tipo_proceso
        # ----------------------------
        tipo_proceso_model = self.env['plan_anual_adquisiciones.tipo_proceso']
        self.assertEqual(1000, tipo_proceso_model.sudo(user_group_jefe_psp_01).search_count([]))
        self.assertEqual(1000, tipo_proceso_model.sudo(user_group_jefe_psp_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.modalidad_seleccion
        # ----------------------------
        modalidad_seleccion_model = self.env['plan_anual_adquisiciones.modalidad_seleccion']
        self.assertEqual(1000, modalidad_seleccion_model.sudo(user_group_jefe_psp_01).search_count([]))
        self.assertEqual(1000, modalidad_seleccion_model.sudo(user_group_jefe_psp_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.solicitud_cambio
        # ----------------------------
        solicitud_cambio_model = self.env['plan_anual_adquisiciones.solicitud_cambio']
        self.assertEqual(1000, solicitud_cambio_model.sudo(user_group_jefe_psp_01).search_count([]))
        self.assertEqual(1000, solicitud_cambio_model.sudo(user_group_jefe_psp_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.pago_programado
        # ----------------------------
        plan_linea_pago_programado_model = self.env['plan_anual_adquisiciones.plan.linea.pago_programado']
        self.assertEqual(1000, plan_linea_pago_programado_model.sudo(user_group_jefe_psp_01).search_count([]))
        self.assertEqual(1000, plan_linea_pago_programado_model.sudo(user_group_jefe_psp_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.cupo_psp
        # ----------------------------
        cupo_psp_model = self.env['plan_anual_adquisiciones.cupo_psp']
        self.assertEqual(1000, cupo_psp_model.sudo(user_group_jefe_psp_01).search_count([]))
        self.assertEqual(1000, cupo_psp_model.sudo(user_group_jefe_psp_02).search_count([]))

        # ----------------------------
        # hr.categoria
        # ----------------------------
        categoria_model = self.env['hr.categoria']
        self.assertEqual(1000, categoria_model.sudo(user_group_jefe_psp_01).search_count([]))
        self.assertEqual(1000, categoria_model.sudo(user_group_jefe_psp_02).search_count([]))

        # ----------------------------
        # hr.department.grupo_funcional
        # ----------------------------
        department_grupo_funcional_model = self.env['hr.department.grupo_funcional']
        self.assertEqual(1000, department_grupo_funcional_model.sudo(user_group_jefe_psp_01).search_count([]))
        self.assertEqual(1000, department_grupo_funcional_model.sudo(user_group_jefe_psp_02).search_count([]))

        # ----------------------------
        # hr.department.tema
        # ----------------------------
        department_tema_model = self.env['hr.department.tema']
        self.assertEqual(1000, department_tema_model.sudo(user_group_jefe_psp_01).search_count([]))
        self.assertEqual(1000, department_tema_model.sudo(user_group_jefe_psp_02).search_count([]))

        # ----------------------------
        # hr.department.desempeno
        # ----------------------------
        department_desempeno_model = self.env['hr.department.desempeno']
        self.assertEqual(1000, department_desempeno_model.sudo(user_group_jefe_psp_01).search_count([]))
        self.assertEqual(1000, department_desempeno_model.sudo(user_group_jefe_psp_02).search_count([]))

        # ----------------------------
        # hr.department.area_conocimiento
        # ----------------------------
        department_area_conocimiento_model = self.env['hr.department.area_conocimiento']
        self.assertEqual(1000, department_area_conocimiento_model.sudo(user_group_jefe_psp_01).search_count([]))
        self.assertEqual(1000, department_area_conocimiento_model.sudo(user_group_jefe_psp_02).search_count([]))

        # ----------------------------
        # project_idu.recurso
        # ----------------------------
        recurso_model = self.env['project_idu.recurso']
        self.assertEqual(1000, recurso_model.sudo(user_group_jefe_psp_01).search_count([]))
        self.assertEqual(1000, recurso_model.sudo(user_group_jefe_psp_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.financiacion
        # ----------------------------
        plan_linea_financiacion_model = self.env['plan_anual_adquisiciones.plan.linea.financiacion']
        self.assertEqual(1000, plan_linea_financiacion_model.sudo(user_group_jefe_psp_01).search_count([]))
        self.assertEqual(1000, plan_linea_financiacion_model.sudo(user_group_jefe_psp_02).search_count([]))

    def test_010_plan_anual_adquisiciones_idu_group_jefe_psp_create(self):
        """ plan_anual_adquisiciones_idu.group_jefe_psp Verifica reglas de dominio en operación CREATE """
        user_group_jefe_psp_01 = self.ref('plan_anual_adquisiciones_idu.group_jefe_psp_user_01')
        user_group_jefe_psp_02 = self.ref('plan_anual_adquisiciones_idu.group_jefe_psp_user_02')

        # ----------------------------
        # plan_anual_adquisiciones.plan
        # ----------------------------
        plan_model = self.env['plan_anual_adquisiciones.plan']
        # Creación permitida
        vals = {
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
            'abierto_edicion': True,
            'vigencia': 18159896,
            'state': "finalizado",
            'linea_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.linea_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_final': "1983-11-18",
            'fecha_inicial': "2013-02-03",
            'version': 66892764,
        }
        plan = plan_model.sudo(user_group_jefe_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
            'abierto_edicion': True,
            'vigencia': 42157677,
            'state': "finalizado",
            'linea_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.linea_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_final': "1977-06-28",
            'fecha_inicial': "1976-01-15",
            'version': 87163911,
        }
        try:
            plan = plan_model.sudo(user_group_jefe_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(plan_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea
        # ----------------------------
        plan_linea_model = self.env['plan_anual_adquisiciones.plan.linea']
        # Creación permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'state': "inicial",
            'tipo': "inversion",
            'codigo_unspsc': "Quia aperiam deleniti laudantium.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "psp",
            'tipo_proceso_id': self.ref('plan_anual_adquisiciones_idu.tipo_proceso_id_01'),
            'modalidad_seleccion_id': self.ref('plan_anual_adquisiciones_idu.modalidad_seleccion_id_01'),
            'localizacion': "localidad",
            'localidad_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'objeto_contractual': "Tenetur ut provident est nihil optio aspernatur.",
            'plazo_ejecucion_meses': 5843678,
            'a_monto_agotable': False,
            'observaciones': "Aut dolorem illo soluta ipsum voluptas et quas.",
            'no_aplica_unidad_medida_mt': True,
            'unidad_meta_fisica_id': self.ref('plan_anual_adquisiciones_idu.unidad_meta_fisica_id_01'),
            'cantidad_meta_fisica': 63048720.7031,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'pago_programado_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.pago_programado_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        plan_linea = plan_linea_model.sudo(user_group_jefe_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'state': "aprobado",
            'tipo': "funcionamiento",
            'codigo_unspsc': "Et nostrum dolores soluta aut rerum repudiandae aut.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "obra",
            'tipo_proceso_id': self.ref('plan_anual_adquisiciones_idu.tipo_proceso_id_01'),
            'modalidad_seleccion_id': self.ref('plan_anual_adquisiciones_idu.modalidad_seleccion_id_01'),
            'localizacion': "77",
            'localidad_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'objeto_contractual': "Eum deleniti et eligendi omnis earum facere.",
            'plazo_ejecucion_meses': 4064670,
            'a_monto_agotable': False,
            'observaciones': "Ex quibusdam nemo eum voluptates illum eligendi.",
            'no_aplica_unidad_medida_mt': True,
            'unidad_meta_fisica_id': self.ref('plan_anual_adquisiciones_idu.unidad_meta_fisica_id_01'),
            'cantidad_meta_fisica': 61474215.0261,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'pago_programado_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.pago_programado_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            plan_linea = plan_linea_model.sudo(user_group_jefe_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(plan_linea_model))

        # ----------------------------
        # plan_anual_adquisiciones.tipo_proceso
        # ----------------------------
        tipo_proceso_model = self.env['plan_anual_adquisiciones.tipo_proceso']
        # Creación permitida
        vals = {
            'name': "Sunt est illo odio.",
        }
        tipo_proceso = tipo_proceso_model.sudo(user_group_jefe_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Sit harum voluptatem a consectetur.",
        }
        try:
            tipo_proceso = tipo_proceso_model.sudo(user_group_jefe_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(tipo_proceso_model))

        # ----------------------------
        # plan_anual_adquisiciones.modalidad_seleccion
        # ----------------------------
        modalidad_seleccion_model = self.env['plan_anual_adquisiciones.modalidad_seleccion']
        # Creación permitida
        vals = {
            'name': "Pariatur sit quis culpa cupiditate aliquam numquam.",
        }
        modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_jefe_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Et eos perferendis aut quia velit totam.",
        }
        try:
            modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_jefe_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(modalidad_seleccion_model))

        # ----------------------------
        # plan_anual_adquisiciones.solicitud_cambio
        # ----------------------------
        solicitud_cambio_model = self.env['plan_anual_adquisiciones.solicitud_cambio']
        # Creación permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tipo_cambio': "eliminar",
            'plan_linea_nueva_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_nueva_id_01'),
            'justificacion': "Enim dolor sed velit quia deserunt quia.",
            'state': "rechazado",
        }
        solicitud_cambio = solicitud_cambio_model.sudo(user_group_jefe_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tipo_cambio': "modificar",
            'plan_linea_nueva_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_nueva_id_01'),
            'justificacion': "Velit eveniet magnam nisi consequatur.",
            'state': "aprobado",
        }
        try:
            solicitud_cambio = solicitud_cambio_model.sudo(user_group_jefe_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(solicitud_cambio_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.pago_programado
        # ----------------------------
        plan_linea_pago_programado_model = self.env['plan_anual_adquisiciones.plan.linea.pago_programado']
        # Creación permitida
        vals = {
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'mes': "10",
            'valor': 34804124.6216,
        }
        plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_jefe_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'mes': "1",
            'valor': 51969065.3417,
        }
        try:
            plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_jefe_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(plan_linea_pago_programado_model))

        # ----------------------------
        # plan_anual_adquisiciones.cupo_psp
        # ----------------------------
        cupo_psp_model = self.env['plan_anual_adquisiciones.cupo_psp']
        # Creación permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'state': "aprobado",
            'tipo': "funcionamiento",
            'codigo_unspsc': "Sint id deleniti provident et.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "obra",
            'presupuesto': 7404363.09632,
            'recurso_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.recurso_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'categoria_id': self.ref('plan_anual_adquisiciones_idu.categoria_id_01'),
            'localizacion': "66",
            'objeto_contractual': "Cupiditate recusandae consequatur eius quasi impedit quo dolorem voluptas.",
            'plazo_ejecucion_dias': 80916712,
            'honorarios_mes': 846894.728882,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        cupo_psp = cupo_psp_model.sudo(user_group_jefe_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'state': "finalizado",
            'tipo': "funcionamiento",
            'codigo_unspsc': "Qui a ut ipsum adipisci labore sint atque dolorum.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "obra",
            'presupuesto': 13705018.7393,
            'recurso_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.recurso_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'categoria_id': self.ref('plan_anual_adquisiciones_idu.categoria_id_01'),
            'localizacion': "localidad",
            'objeto_contractual': "Aliquam distinctio saepe qui officia consequatur iusto dolorem.",
            'plazo_ejecucion_dias': 97340769,
            'honorarios_mes': 139263.959077,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            cupo_psp = cupo_psp_model.sudo(user_group_jefe_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(cupo_psp_model))

        # ----------------------------
        # hr.categoria
        # ----------------------------
        categoria_model = self.env['hr.categoria']
        # Creación permitida
        vals = {
            'name': "Pariatur rerum voluptates autem.",
            'codigo_siac': 22970849,
        }
        categoria = categoria_model.sudo(user_group_jefe_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Nobis molestiae qui eveniet error.",
            'codigo_siac': 35589855,
        }
        try:
            categoria = categoria_model.sudo(user_group_jefe_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(categoria_model))

        # ----------------------------
        # hr.department.grupo_funcional
        # ----------------------------
        department_grupo_funcional_model = self.env['hr.department.grupo_funcional']
        # Creación permitida
        vals = {
            'name': "Numquam quae reprehenderit consectetur culpa nihil hic.",
            'codigo_siac': 37518706,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tema_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.tema_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_jefe_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Odio cumque error dolore dolores eos enim.",
            'codigo_siac': 24073891,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tema_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.tema_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_jefe_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(department_grupo_funcional_model))

        # ----------------------------
        # hr.department.tema
        # ----------------------------
        department_tema_model = self.env['hr.department.tema']
        # Creación permitida
        vals = {
            'name': "Unde dolor quibusdam provident facere.",
            'codigo_siac': 35685189,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_tema = department_tema_model.sudo(user_group_jefe_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Dolorum quo est ea eum adipisci.",
            'codigo_siac': 41941831,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            department_tema = department_tema_model.sudo(user_group_jefe_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(department_tema_model))

        # ----------------------------
        # hr.department.desempeno
        # ----------------------------
        department_desempeno_model = self.env['hr.department.desempeno']
        # Creación permitida
        vals = {
            'name': "Et aut inventore nihil consectetur quia dolorum.",
            'codigo_siac': 27522971,
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_desempeno = department_desempeno_model.sudo(user_group_jefe_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Atque nemo minus dolorem omnis ullam.",
            'codigo_siac': 45493707,
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            department_desempeno = department_desempeno_model.sudo(user_group_jefe_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(department_desempeno_model))

        # ----------------------------
        # hr.department.area_conocimiento
        # ----------------------------
        department_area_conocimiento_model = self.env['hr.department.area_conocimiento']
        # Creación permitida
        vals = {
            'name': "Praesentium sit eum odit modi quibusdam.",
            'codigo_siac': 60884502,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
        }
        department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_jefe_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Totam eum qui ut itaque.",
            'codigo_siac': 12711017,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
        }
        try:
            department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_jefe_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(department_area_conocimiento_model))

        # ----------------------------
        # project_idu.recurso
        # ----------------------------
        recurso_model = self.env['project_idu.recurso']
        # Creación permitida
        vals = {
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'cupo_id': self.ref('plan_anual_adquisiciones_idu.cupo_id_01'),
        }
        recurso = recurso_model.sudo(user_group_jefe_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'cupo_id': self.ref('plan_anual_adquisiciones_idu.cupo_id_01'),
        }
        try:
            recurso = recurso_model.sudo(user_group_jefe_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(recurso_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.financiacion
        # ----------------------------
        plan_linea_financiacion_model = self.env['plan_anual_adquisiciones.plan.linea.financiacion']
        # Creación permitida
        vals = {
            'centro_costo_id': self.ref('plan_anual_adquisiciones_idu.centro_costo_id_01'),
            'fuente_id': self.ref('plan_anual_adquisiciones_idu.fuente_id_01'),
            'rubro_id': self.ref('plan_anual_adquisiciones_idu.rubro_id_01'),
            'presupuesto': 43741714.4732,
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
        }
        plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_jefe_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'centro_costo_id': self.ref('plan_anual_adquisiciones_idu.centro_costo_id_01'),
            'fuente_id': self.ref('plan_anual_adquisiciones_idu.fuente_id_01'),
            'rubro_id': self.ref('plan_anual_adquisiciones_idu.rubro_id_01'),
            'presupuesto': 29386438.7014,
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
        }
        try:
            plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_jefe_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(plan_linea_financiacion_model))

    def test_020_plan_anual_adquisiciones_idu_group_jefe_psp_write(self):
        """ plan_anual_adquisiciones_idu.group_jefe_psp Verifica reglas de dominio en operación WRITE """
        user_group_jefe_psp_01 = self.ref('plan_anual_adquisiciones_idu.group_jefe_psp_user_01')
        user_group_jefe_psp_02 = self.ref('plan_anual_adquisiciones_idu.group_jefe_psp_user_02')

        # ----------------------------
        # plan_anual_adquisiciones.plan
        # ----------------------------
        plan_model = self.env['plan_anual_adquisiciones.plan']
        # Actualización permitida
        vals = {
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
            'abierto_edicion': True,
            'vigencia': 48589269,
            'state': "en_ejecucion",
            'linea_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.linea_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_final': "1996-12-09",
            'fecha_inicial': "1989-11-23",
            'version': 45345632,
        }
        plan = plan_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        plan.sudo(user_group_jefe_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
            'abierto_edicion': False,
            'vigencia': 3006683,
            'state': "inicial",
            'linea_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.linea_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_final': "1995-07-05",
            'fecha_inicial': "1974-01-21",
            'version': 10102888,
        }
        plan = plan_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            plan.sudo(user_group_jefe_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(plan_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea
        # ----------------------------
        plan_linea_model = self.env['plan_anual_adquisiciones.plan.linea']
        # Actualización permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'state': "finalizado",
            'tipo': "funcionamiento",
            'codigo_unspsc': "Ut quidem ea architecto nemo deserunt ut.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "obra",
            'tipo_proceso_id': self.ref('plan_anual_adquisiciones_idu.tipo_proceso_id_01'),
            'modalidad_seleccion_id': self.ref('plan_anual_adquisiciones_idu.modalidad_seleccion_id_01'),
            'localizacion': "localidad",
            'localidad_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'objeto_contractual': "Iusto quasi aliquid illo porro sunt autem facere.",
            'plazo_ejecucion_meses': 57817506,
            'a_monto_agotable': True,
            'observaciones': "Inventore cupiditate culpa et suscipit ipsum in.",
            'no_aplica_unidad_medida_mt': False,
            'unidad_meta_fisica_id': self.ref('plan_anual_adquisiciones_idu.unidad_meta_fisica_id_01'),
            'cantidad_meta_fisica': 15650453.9195,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'pago_programado_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.pago_programado_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        plan_linea = plan_linea_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        plan_linea.sudo(user_group_jefe_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'state': "aprobado",
            'tipo': "inversion",
            'codigo_unspsc': "Ipsum voluptas illo sapiente facere expedita quisquam sit vel.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "psp",
            'tipo_proceso_id': self.ref('plan_anual_adquisiciones_idu.tipo_proceso_id_01'),
            'modalidad_seleccion_id': self.ref('plan_anual_adquisiciones_idu.modalidad_seleccion_id_01'),
            'localizacion': "66",
            'localidad_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'objeto_contractual': "Perferendis cumque velit officiis corrupti.",
            'plazo_ejecucion_meses': 24346531,
            'a_monto_agotable': False,
            'observaciones': "Libero aliquam id et ipsam ut.",
            'no_aplica_unidad_medida_mt': True,
            'unidad_meta_fisica_id': self.ref('plan_anual_adquisiciones_idu.unidad_meta_fisica_id_01'),
            'cantidad_meta_fisica': 88838366.4761,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'pago_programado_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.pago_programado_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        plan_linea = plan_linea_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            plan_linea.sudo(user_group_jefe_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(plan_linea_model))

        # ----------------------------
        # plan_anual_adquisiciones.tipo_proceso
        # ----------------------------
        tipo_proceso_model = self.env['plan_anual_adquisiciones.tipo_proceso']
        # Actualización permitida
        vals = {
            'name': "Repudiandae quis ut in repudiandae nihil doloremque rerum.",
        }
        tipo_proceso = tipo_proceso_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        tipo_proceso.sudo(user_group_jefe_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Modi eveniet enim alias voluptatem hic ducimus.",
        }
        tipo_proceso = tipo_proceso_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            tipo_proceso.sudo(user_group_jefe_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(tipo_proceso_model))

        # ----------------------------
        # plan_anual_adquisiciones.modalidad_seleccion
        # ----------------------------
        modalidad_seleccion_model = self.env['plan_anual_adquisiciones.modalidad_seleccion']
        # Actualización permitida
        vals = {
            'name': "Quaerat consequuntur dolorem qui amet eius.",
        }
        modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        modalidad_seleccion.sudo(user_group_jefe_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Quidem expedita aut eligendi laborum praesentium quo est.",
        }
        modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            modalidad_seleccion.sudo(user_group_jefe_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(modalidad_seleccion_model))

        # ----------------------------
        # plan_anual_adquisiciones.solicitud_cambio
        # ----------------------------
        solicitud_cambio_model = self.env['plan_anual_adquisiciones.solicitud_cambio']
        # Actualización permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tipo_cambio': "eliminar",
            'plan_linea_nueva_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_nueva_id_01'),
            'justificacion': "At veritatis ipsum voluptates.",
            'state': "rechazado",
        }
        solicitud_cambio = solicitud_cambio_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        solicitud_cambio.sudo(user_group_jefe_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tipo_cambio': "adicionar",
            'plan_linea_nueva_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_nueva_id_01'),
            'justificacion': "Fuga molestiae atque odit atque quod dolor suscipit eos.",
            'state': "aprobado",
        }
        solicitud_cambio = solicitud_cambio_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            solicitud_cambio.sudo(user_group_jefe_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(solicitud_cambio_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.pago_programado
        # ----------------------------
        plan_linea_pago_programado_model = self.env['plan_anual_adquisiciones.plan.linea.pago_programado']
        # Actualización permitida
        vals = {
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'mes': "11",
            'valor': 5896666.58834,
        }
        plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        plan_linea_pago_programado.sudo(user_group_jefe_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'mes': "2",
            'valor': 15097662.585,
        }
        plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            plan_linea_pago_programado.sudo(user_group_jefe_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(plan_linea_pago_programado_model))

        # ----------------------------
        # plan_anual_adquisiciones.cupo_psp
        # ----------------------------
        cupo_psp_model = self.env['plan_anual_adquisiciones.cupo_psp']
        # Actualización permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'state': "en_ejecucion",
            'tipo': "funcionamiento",
            'codigo_unspsc': "Eos rerum aut et.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "obra",
            'presupuesto': 12234193.8313,
            'recurso_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.recurso_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'categoria_id': self.ref('plan_anual_adquisiciones_idu.categoria_id_01'),
            'localizacion': "77",
            'objeto_contractual': "Eius vitae nisi recusandae repudiandae consequatur dolores quaerat.",
            'plazo_ejecucion_dias': 18864261,
            'honorarios_mes': 76271011.2598,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        cupo_psp = cupo_psp_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        cupo_psp.sudo(user_group_jefe_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'state': "aprobado",
            'tipo': "inversion",
            'codigo_unspsc': "Blanditiis exercitationem quia error iste.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "psp",
            'presupuesto': 26037909.4231,
            'recurso_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.recurso_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'categoria_id': self.ref('plan_anual_adquisiciones_idu.categoria_id_01'),
            'localizacion': "localidad",
            'objeto_contractual': "Ab officia magni quia minima voluptates ullam.",
            'plazo_ejecucion_dias': 52716888,
            'honorarios_mes': 4210544.5301,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        cupo_psp = cupo_psp_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            cupo_psp.sudo(user_group_jefe_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(cupo_psp_model))

        # ----------------------------
        # hr.categoria
        # ----------------------------
        categoria_model = self.env['hr.categoria']
        # Actualización permitida
        vals = {
            'name': "Quasi voluptate omnis ut quaerat aut itaque.",
            'codigo_siac': 72757154,
        }
        categoria = categoria_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        categoria.sudo(user_group_jefe_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Voluptatem dolor quasi doloribus dolor sed molestiae.",
            'codigo_siac': 61653170,
        }
        categoria = categoria_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            categoria.sudo(user_group_jefe_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(categoria_model))

        # ----------------------------
        # hr.department.grupo_funcional
        # ----------------------------
        department_grupo_funcional_model = self.env['hr.department.grupo_funcional']
        # Actualización permitida
        vals = {
            'name': "Beatae nihil dolor beatae velit illo ipsam.",
            'codigo_siac': 51431605,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tema_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.tema_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        department_grupo_funcional.sudo(user_group_jefe_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Sint quo quis commodi delectus.",
            'codigo_siac': 43575836,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tema_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.tema_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            department_grupo_funcional.sudo(user_group_jefe_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(department_grupo_funcional_model))

        # ----------------------------
        # hr.department.tema
        # ----------------------------
        department_tema_model = self.env['hr.department.tema']
        # Actualización permitida
        vals = {
            'name': "Ea iste accusamus sit est quo nostrum velit.",
            'codigo_siac': 87595596,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_tema = department_tema_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        department_tema.sudo(user_group_jefe_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Et voluptas tenetur omnis minima nobis impedit voluptas.",
            'codigo_siac': 83298422,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_tema = department_tema_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            department_tema.sudo(user_group_jefe_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(department_tema_model))

        # ----------------------------
        # hr.department.desempeno
        # ----------------------------
        department_desempeno_model = self.env['hr.department.desempeno']
        # Actualización permitida
        vals = {
            'name': "Est suscipit delectus porro quas dolorem.",
            'codigo_siac': 11029971,
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_desempeno = department_desempeno_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        department_desempeno.sudo(user_group_jefe_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Et vel rerum occaecati officiis numquam exercitationem.",
            'codigo_siac': 45337108,
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_desempeno = department_desempeno_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            department_desempeno.sudo(user_group_jefe_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(department_desempeno_model))

        # ----------------------------
        # hr.department.area_conocimiento
        # ----------------------------
        department_area_conocimiento_model = self.env['hr.department.area_conocimiento']
        # Actualización permitida
        vals = {
            'name': "Animi et et et sed.",
            'codigo_siac': 43283659,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
        }
        department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        department_area_conocimiento.sudo(user_group_jefe_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Fugit rem ut dolore est veritatis sequi.",
            'codigo_siac': 69926465,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
        }
        department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            department_area_conocimiento.sudo(user_group_jefe_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(department_area_conocimiento_model))

        # ----------------------------
        # project_idu.recurso
        # ----------------------------
        recurso_model = self.env['project_idu.recurso']
        # Actualización permitida
        vals = {
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'cupo_id': self.ref('plan_anual_adquisiciones_idu.cupo_id_01'),
        }
        recurso = recurso_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        recurso.sudo(user_group_jefe_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'cupo_id': self.ref('plan_anual_adquisiciones_idu.cupo_id_01'),
        }
        recurso = recurso_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            recurso.sudo(user_group_jefe_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(recurso_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.financiacion
        # ----------------------------
        plan_linea_financiacion_model = self.env['plan_anual_adquisiciones.plan.linea.financiacion']
        # Actualización permitida
        vals = {
            'centro_costo_id': self.ref('plan_anual_adquisiciones_idu.centro_costo_id_01'),
            'fuente_id': self.ref('plan_anual_adquisiciones_idu.fuente_id_01'),
            'rubro_id': self.ref('plan_anual_adquisiciones_idu.rubro_id_01'),
            'presupuesto': 24816670.7442,
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
        }
        plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        plan_linea_financiacion.sudo(user_group_jefe_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'centro_costo_id': self.ref('plan_anual_adquisiciones_idu.centro_costo_id_01'),
            'fuente_id': self.ref('plan_anual_adquisiciones_idu.fuente_id_01'),
            'rubro_id': self.ref('plan_anual_adquisiciones_idu.rubro_id_01'),
            'presupuesto': 3556307.96084,
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
        }
        plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            plan_linea_financiacion.sudo(user_group_jefe_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(plan_linea_financiacion_model))

    def test_030_plan_anual_adquisiciones_idu_group_jefe_psp_unlink(self):
        """ plan_anual_adquisiciones_idu.group_jefe_psp Verifica reglas de dominio en operación UNLINK - Delete """
        user_group_jefe_psp_01 = self.ref('plan_anual_adquisiciones_idu.group_jefe_psp_user_01')
        user_group_jefe_psp_02 = self.ref('plan_anual_adquisiciones_idu.group_jefe_psp_user_02')

        # ----------------------------
        # plan_anual_adquisiciones.plan
        # ----------------------------
        plan_model = self.env['plan_anual_adquisiciones.plan']
        # Eliminación permitida
        plan = plan_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        plan.sudo(user_group_jefe_psp_01).unlink()

        # Eliminación NO permitida
        plan = plan_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            plan.sudo(user_group_jefe_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(plan_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea
        # ----------------------------
        plan_linea_model = self.env['plan_anual_adquisiciones.plan.linea']
        # Eliminación permitida
        plan_linea = plan_linea_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        plan_linea.sudo(user_group_jefe_psp_01).unlink()

        # Eliminación NO permitida
        plan_linea = plan_linea_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            plan_linea.sudo(user_group_jefe_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(plan_linea_model))

        # ----------------------------
        # plan_anual_adquisiciones.tipo_proceso
        # ----------------------------
        tipo_proceso_model = self.env['plan_anual_adquisiciones.tipo_proceso']
        # Eliminación permitida
        tipo_proceso = tipo_proceso_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        tipo_proceso.sudo(user_group_jefe_psp_01).unlink()

        # Eliminación NO permitida
        tipo_proceso = tipo_proceso_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            tipo_proceso.sudo(user_group_jefe_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(tipo_proceso_model))

        # ----------------------------
        # plan_anual_adquisiciones.modalidad_seleccion
        # ----------------------------
        modalidad_seleccion_model = self.env['plan_anual_adquisiciones.modalidad_seleccion']
        # Eliminación permitida
        modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        modalidad_seleccion.sudo(user_group_jefe_psp_01).unlink()

        # Eliminación NO permitida
        modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            modalidad_seleccion.sudo(user_group_jefe_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(modalidad_seleccion_model))

        # ----------------------------
        # plan_anual_adquisiciones.solicitud_cambio
        # ----------------------------
        solicitud_cambio_model = self.env['plan_anual_adquisiciones.solicitud_cambio']
        # Eliminación permitida
        solicitud_cambio = solicitud_cambio_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        solicitud_cambio.sudo(user_group_jefe_psp_01).unlink()

        # Eliminación NO permitida
        solicitud_cambio = solicitud_cambio_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            solicitud_cambio.sudo(user_group_jefe_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(solicitud_cambio_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.pago_programado
        # ----------------------------
        plan_linea_pago_programado_model = self.env['plan_anual_adquisiciones.plan.linea.pago_programado']
        # Eliminación permitida
        plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        plan_linea_pago_programado.sudo(user_group_jefe_psp_01).unlink()

        # Eliminación NO permitida
        plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            plan_linea_pago_programado.sudo(user_group_jefe_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(plan_linea_pago_programado_model))

        # ----------------------------
        # plan_anual_adquisiciones.cupo_psp
        # ----------------------------
        cupo_psp_model = self.env['plan_anual_adquisiciones.cupo_psp']
        # Eliminación permitida
        cupo_psp = cupo_psp_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        cupo_psp.sudo(user_group_jefe_psp_01).unlink()

        # Eliminación NO permitida
        cupo_psp = cupo_psp_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            cupo_psp.sudo(user_group_jefe_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(cupo_psp_model))

        # ----------------------------
        # hr.categoria
        # ----------------------------
        categoria_model = self.env['hr.categoria']
        # Eliminación permitida
        categoria = categoria_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        categoria.sudo(user_group_jefe_psp_01).unlink()

        # Eliminación NO permitida
        categoria = categoria_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            categoria.sudo(user_group_jefe_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(categoria_model))

        # ----------------------------
        # hr.department.grupo_funcional
        # ----------------------------
        department_grupo_funcional_model = self.env['hr.department.grupo_funcional']
        # Eliminación permitida
        department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        department_grupo_funcional.sudo(user_group_jefe_psp_01).unlink()

        # Eliminación NO permitida
        department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            department_grupo_funcional.sudo(user_group_jefe_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(department_grupo_funcional_model))

        # ----------------------------
        # hr.department.tema
        # ----------------------------
        department_tema_model = self.env['hr.department.tema']
        # Eliminación permitida
        department_tema = department_tema_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        department_tema.sudo(user_group_jefe_psp_01).unlink()

        # Eliminación NO permitida
        department_tema = department_tema_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            department_tema.sudo(user_group_jefe_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(department_tema_model))

        # ----------------------------
        # hr.department.desempeno
        # ----------------------------
        department_desempeno_model = self.env['hr.department.desempeno']
        # Eliminación permitida
        department_desempeno = department_desempeno_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        department_desempeno.sudo(user_group_jefe_psp_01).unlink()

        # Eliminación NO permitida
        department_desempeno = department_desempeno_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            department_desempeno.sudo(user_group_jefe_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(department_desempeno_model))

        # ----------------------------
        # hr.department.area_conocimiento
        # ----------------------------
        department_area_conocimiento_model = self.env['hr.department.area_conocimiento']
        # Eliminación permitida
        department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        department_area_conocimiento.sudo(user_group_jefe_psp_01).unlink()

        # Eliminación NO permitida
        department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            department_area_conocimiento.sudo(user_group_jefe_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(department_area_conocimiento_model))

        # ----------------------------
        # project_idu.recurso
        # ----------------------------
        recurso_model = self.env['project_idu.recurso']
        # Eliminación permitida
        recurso = recurso_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        recurso.sudo(user_group_jefe_psp_01).unlink()

        # Eliminación NO permitida
        recurso = recurso_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            recurso.sudo(user_group_jefe_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(recurso_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.financiacion
        # ----------------------------
        plan_linea_financiacion_model = self.env['plan_anual_adquisiciones.plan.linea.financiacion']
        # Eliminación permitida
        plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        plan_linea_financiacion.sudo(user_group_jefe_psp_01).unlink()

        # Eliminación NO permitida
        plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_jefe_psp_01).search([], limit=1)
        try:
            plan_linea_financiacion.sudo(user_group_jefe_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(plan_linea_financiacion_model))


if __name__ == '__main__':
    unittest2.main()