# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_hr_department_desempeno(common.TransactionCase):
    def test_crud_validaciones(self):
        department_desempeno_model = self.env['hr.department.desempeno']
        vals = {
            'name': "Facilis est facere ut nostrum maiores.",
            'codigo_siac': 25576622,
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_desempeno = department_desempeno_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()