# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import AccessError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class test_security_plan_anual_adquisiciones_idu_group_asesor_psp(common.TransactionCase):
    def test_000_plan_anual_adquisiciones_idu_group_asesor_psp_search(self):
        """ plan_anual_adquisiciones_idu.group_asesor_psp Verifica reglas de dominio en operación READ """
        user_group_asesor_psp_01 = self.ref('plan_anual_adquisiciones_idu.group_asesor_psp_user_01')
        user_group_asesor_psp_02 = self.ref('plan_anual_adquisiciones_idu.group_asesor_psp_user_02')

        # ----------------------------
        # plan_anual_adquisiciones.plan
        # ----------------------------
        plan_model = self.env['plan_anual_adquisiciones.plan']
        self.assertEqual(1000, plan_model.sudo(user_group_asesor_psp_01).search_count([]))
        self.assertEqual(1000, plan_model.sudo(user_group_asesor_psp_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea
        # ----------------------------
        plan_linea_model = self.env['plan_anual_adquisiciones.plan.linea']
        self.assertEqual(1000, plan_linea_model.sudo(user_group_asesor_psp_01).search_count([]))
        self.assertEqual(1000, plan_linea_model.sudo(user_group_asesor_psp_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.tipo_proceso
        # ----------------------------
        tipo_proceso_model = self.env['plan_anual_adquisiciones.tipo_proceso']
        self.assertEqual(1000, tipo_proceso_model.sudo(user_group_asesor_psp_01).search_count([]))
        self.assertEqual(1000, tipo_proceso_model.sudo(user_group_asesor_psp_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.modalidad_seleccion
        # ----------------------------
        modalidad_seleccion_model = self.env['plan_anual_adquisiciones.modalidad_seleccion']
        self.assertEqual(1000, modalidad_seleccion_model.sudo(user_group_asesor_psp_01).search_count([]))
        self.assertEqual(1000, modalidad_seleccion_model.sudo(user_group_asesor_psp_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.solicitud_cambio
        # ----------------------------
        solicitud_cambio_model = self.env['plan_anual_adquisiciones.solicitud_cambio']
        self.assertEqual(1000, solicitud_cambio_model.sudo(user_group_asesor_psp_01).search_count([]))
        self.assertEqual(1000, solicitud_cambio_model.sudo(user_group_asesor_psp_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.pago_programado
        # ----------------------------
        plan_linea_pago_programado_model = self.env['plan_anual_adquisiciones.plan.linea.pago_programado']
        self.assertEqual(1000, plan_linea_pago_programado_model.sudo(user_group_asesor_psp_01).search_count([]))
        self.assertEqual(1000, plan_linea_pago_programado_model.sudo(user_group_asesor_psp_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.cupo_psp
        # ----------------------------
        cupo_psp_model = self.env['plan_anual_adquisiciones.cupo_psp']
        self.assertEqual(1000, cupo_psp_model.sudo(user_group_asesor_psp_01).search_count([]))
        self.assertEqual(1000, cupo_psp_model.sudo(user_group_asesor_psp_02).search_count([]))

        # ----------------------------
        # hr.categoria
        # ----------------------------
        categoria_model = self.env['hr.categoria']
        self.assertEqual(1000, categoria_model.sudo(user_group_asesor_psp_01).search_count([]))
        self.assertEqual(1000, categoria_model.sudo(user_group_asesor_psp_02).search_count([]))

        # ----------------------------
        # hr.department.grupo_funcional
        # ----------------------------
        department_grupo_funcional_model = self.env['hr.department.grupo_funcional']
        self.assertEqual(1000, department_grupo_funcional_model.sudo(user_group_asesor_psp_01).search_count([]))
        self.assertEqual(1000, department_grupo_funcional_model.sudo(user_group_asesor_psp_02).search_count([]))

        # ----------------------------
        # hr.department.tema
        # ----------------------------
        department_tema_model = self.env['hr.department.tema']
        self.assertEqual(1000, department_tema_model.sudo(user_group_asesor_psp_01).search_count([]))
        self.assertEqual(1000, department_tema_model.sudo(user_group_asesor_psp_02).search_count([]))

        # ----------------------------
        # hr.department.desempeno
        # ----------------------------
        department_desempeno_model = self.env['hr.department.desempeno']
        self.assertEqual(1000, department_desempeno_model.sudo(user_group_asesor_psp_01).search_count([]))
        self.assertEqual(1000, department_desempeno_model.sudo(user_group_asesor_psp_02).search_count([]))

        # ----------------------------
        # hr.department.area_conocimiento
        # ----------------------------
        department_area_conocimiento_model = self.env['hr.department.area_conocimiento']
        self.assertEqual(1000, department_area_conocimiento_model.sudo(user_group_asesor_psp_01).search_count([]))
        self.assertEqual(1000, department_area_conocimiento_model.sudo(user_group_asesor_psp_02).search_count([]))

        # ----------------------------
        # project_idu.recurso
        # ----------------------------
        recurso_model = self.env['project_idu.recurso']
        self.assertEqual(1000, recurso_model.sudo(user_group_asesor_psp_01).search_count([]))
        self.assertEqual(1000, recurso_model.sudo(user_group_asesor_psp_02).search_count([]))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.financiacion
        # ----------------------------
        plan_linea_financiacion_model = self.env['plan_anual_adquisiciones.plan.linea.financiacion']
        self.assertEqual(1000, plan_linea_financiacion_model.sudo(user_group_asesor_psp_01).search_count([]))
        self.assertEqual(1000, plan_linea_financiacion_model.sudo(user_group_asesor_psp_02).search_count([]))

    def test_010_plan_anual_adquisiciones_idu_group_asesor_psp_create(self):
        """ plan_anual_adquisiciones_idu.group_asesor_psp Verifica reglas de dominio en operación CREATE """
        user_group_asesor_psp_01 = self.ref('plan_anual_adquisiciones_idu.group_asesor_psp_user_01')
        user_group_asesor_psp_02 = self.ref('plan_anual_adquisiciones_idu.group_asesor_psp_user_02')

        # ----------------------------
        # plan_anual_adquisiciones.plan
        # ----------------------------
        plan_model = self.env['plan_anual_adquisiciones.plan']
        # Creación permitida
        vals = {
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
            'abierto_edicion': False,
            'vigencia': 82129376,
            'state': "en_ejecucion",
            'linea_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.linea_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_final': "2001-11-16",
            'fecha_inicial': "2007-03-09",
            'version': 14208807,
        }
        plan = plan_model.sudo(user_group_asesor_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
            'abierto_edicion': False,
            'vigencia': 67606753,
            'state': "finalizado",
            'linea_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.linea_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_final': "1988-08-06",
            'fecha_inicial': "1995-10-26",
            'version': 45684247,
        }
        try:
            plan = plan_model.sudo(user_group_asesor_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(plan_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea
        # ----------------------------
        plan_linea_model = self.env['plan_anual_adquisiciones.plan.linea']
        # Creación permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'state': "finalizado",
            'tipo': "inversion",
            'codigo_unspsc': "Ipsum suscipit et et enim rem.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "psp",
            'tipo_proceso_id': self.ref('plan_anual_adquisiciones_idu.tipo_proceso_id_01'),
            'modalidad_seleccion_id': self.ref('plan_anual_adquisiciones_idu.modalidad_seleccion_id_01'),
            'localizacion': "77",
            'localidad_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'objeto_contractual': "Non in magni dolorem vitae iste enim.",
            'plazo_ejecucion_meses': 32769332,
            'a_monto_agotable': True,
            'observaciones': "Commodi facilis et tempora exercitationem autem.",
            'no_aplica_unidad_medida_mt': False,
            'unidad_meta_fisica_id': self.ref('plan_anual_adquisiciones_idu.unidad_meta_fisica_id_01'),
            'cantidad_meta_fisica': 14654445.4245,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'pago_programado_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.pago_programado_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        plan_linea = plan_linea_model.sudo(user_group_asesor_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'state': "en_ejecucion",
            'tipo': "funcionamiento",
            'codigo_unspsc': "Officia expedita aliquid repellendus quia molestiae.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "obra",
            'tipo_proceso_id': self.ref('plan_anual_adquisiciones_idu.tipo_proceso_id_01'),
            'modalidad_seleccion_id': self.ref('plan_anual_adquisiciones_idu.modalidad_seleccion_id_01'),
            'localizacion': "66",
            'localidad_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'objeto_contractual': "Corporis vel rem cupiditate maxime occaecati sit.",
            'plazo_ejecucion_meses': 3178595,
            'a_monto_agotable': False,
            'observaciones': "Sapiente amet dignissimos voluptatibus et rerum.",
            'no_aplica_unidad_medida_mt': True,
            'unidad_meta_fisica_id': self.ref('plan_anual_adquisiciones_idu.unidad_meta_fisica_id_01'),
            'cantidad_meta_fisica': 21426808.7665,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'pago_programado_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.pago_programado_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            plan_linea = plan_linea_model.sudo(user_group_asesor_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(plan_linea_model))

        # ----------------------------
        # plan_anual_adquisiciones.tipo_proceso
        # ----------------------------
        tipo_proceso_model = self.env['plan_anual_adquisiciones.tipo_proceso']
        # Creación permitida
        vals = {
            'name': "Ea sit aliquid voluptas ipsam aliquid temporibus.",
        }
        tipo_proceso = tipo_proceso_model.sudo(user_group_asesor_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Sequi omnis nam autem omnis.",
        }
        try:
            tipo_proceso = tipo_proceso_model.sudo(user_group_asesor_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(tipo_proceso_model))

        # ----------------------------
        # plan_anual_adquisiciones.modalidad_seleccion
        # ----------------------------
        modalidad_seleccion_model = self.env['plan_anual_adquisiciones.modalidad_seleccion']
        # Creación permitida
        vals = {
            'name': "Ipsum et quam sed labore enim.",
        }
        modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_asesor_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Odit est veritatis molestiae consequuntur culpa et qui.",
        }
        try:
            modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_asesor_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(modalidad_seleccion_model))

        # ----------------------------
        # plan_anual_adquisiciones.solicitud_cambio
        # ----------------------------
        solicitud_cambio_model = self.env['plan_anual_adquisiciones.solicitud_cambio']
        # Creación permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tipo_cambio': "eliminar",
            'plan_linea_nueva_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_nueva_id_01'),
            'justificacion': "Eum odit similique qui ut quo optio aperiam voluptatem.",
            'state': "pre_aprobado",
        }
        solicitud_cambio = solicitud_cambio_model.sudo(user_group_asesor_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tipo_cambio': "modificar",
            'plan_linea_nueva_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_nueva_id_01'),
            'justificacion': "Corporis est ut dolorem magnam.",
            'state': "pre_aprobado",
        }
        try:
            solicitud_cambio = solicitud_cambio_model.sudo(user_group_asesor_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(solicitud_cambio_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.pago_programado
        # ----------------------------
        plan_linea_pago_programado_model = self.env['plan_anual_adquisiciones.plan.linea.pago_programado']
        # Creación permitida
        vals = {
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'mes': "8",
            'valor': 12433560.8208,
        }
        plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_asesor_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'mes': "10",
            'valor': 30230034.4383,
        }
        try:
            plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_asesor_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(plan_linea_pago_programado_model))

        # ----------------------------
        # plan_anual_adquisiciones.cupo_psp
        # ----------------------------
        cupo_psp_model = self.env['plan_anual_adquisiciones.cupo_psp']
        # Creación permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'state': "en_ejecucion",
            'tipo': "inversion",
            'codigo_unspsc': "Fugit non nulla occaecati deserunt.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "psp",
            'presupuesto': 75515269.5718,
            'recurso_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.recurso_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'categoria_id': self.ref('plan_anual_adquisiciones_idu.categoria_id_01'),
            'localizacion': "localidad",
            'objeto_contractual': "Facilis id eos vero rerum repudiandae.",
            'plazo_ejecucion_dias': 29789299,
            'honorarios_mes': 88622697.8585,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        cupo_psp = cupo_psp_model.sudo(user_group_asesor_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'state': "en_ejecucion",
            'tipo': "funcionamiento",
            'codigo_unspsc': "Voluptatem animi neque assumenda molestiae ipsum sint.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "psp",
            'presupuesto': 21866289.5444,
            'recurso_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.recurso_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'categoria_id': self.ref('plan_anual_adquisiciones_idu.categoria_id_01'),
            'localizacion': "66",
            'objeto_contractual': "Molestias molestiae totam ea sed.",
            'plazo_ejecucion_dias': 22613268,
            'honorarios_mes': 78230430.7172,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            cupo_psp = cupo_psp_model.sudo(user_group_asesor_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(cupo_psp_model))

        # ----------------------------
        # hr.categoria
        # ----------------------------
        categoria_model = self.env['hr.categoria']
        # Creación permitida
        vals = {
            'name': "Deleniti hic minus incidunt quis provident et dolorem maiores.",
            'codigo_siac': 70976661,
        }
        categoria = categoria_model.sudo(user_group_asesor_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Labore et nam aliquam quas eaque earum.",
            'codigo_siac': 21949109,
        }
        try:
            categoria = categoria_model.sudo(user_group_asesor_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(categoria_model))

        # ----------------------------
        # hr.department.grupo_funcional
        # ----------------------------
        department_grupo_funcional_model = self.env['hr.department.grupo_funcional']
        # Creación permitida
        vals = {
            'name': "Mollitia ratione numquam fugit recusandae et eos recusandae impedit.",
            'codigo_siac': 49270378,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tema_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.tema_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_asesor_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Harum dolorem dicta est laborum eveniet laboriosam assumenda.",
            'codigo_siac': 1035119,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tema_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.tema_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_asesor_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(department_grupo_funcional_model))

        # ----------------------------
        # hr.department.tema
        # ----------------------------
        department_tema_model = self.env['hr.department.tema']
        # Creación permitida
        vals = {
            'name': "Consequuntur nam enim quaerat et ut sit.",
            'codigo_siac': 53559189,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_tema = department_tema_model.sudo(user_group_asesor_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Suscipit qui ut voluptatem unde voluptas doloremque facilis.",
            'codigo_siac': 33858,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            department_tema = department_tema_model.sudo(user_group_asesor_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(department_tema_model))

        # ----------------------------
        # hr.department.desempeno
        # ----------------------------
        department_desempeno_model = self.env['hr.department.desempeno']
        # Creación permitida
        vals = {
            'name': "Consequatur quo expedita aut rem.",
            'codigo_siac': 54203713,
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_desempeno = department_desempeno_model.sudo(user_group_asesor_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Repudiandae animi id sint magnam occaecati repellendus maxime.",
            'codigo_siac': 47692437,
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        try:
            department_desempeno = department_desempeno_model.sudo(user_group_asesor_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(department_desempeno_model))

        # ----------------------------
        # hr.department.area_conocimiento
        # ----------------------------
        department_area_conocimiento_model = self.env['hr.department.area_conocimiento']
        # Creación permitida
        vals = {
            'name': "Omnis fugiat accusamus nihil id sint iure velit cumque.",
            'codigo_siac': 14202361,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
        }
        department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_asesor_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'name': "Et explicabo ut iusto architecto magni qui.",
            'codigo_siac': 89486449,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
        }
        try:
            department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_asesor_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(department_area_conocimiento_model))

        # ----------------------------
        # project_idu.recurso
        # ----------------------------
        recurso_model = self.env['project_idu.recurso']
        # Creación permitida
        vals = {
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'cupo_id': self.ref('plan_anual_adquisiciones_idu.cupo_id_01'),
        }
        recurso = recurso_model.sudo(user_group_asesor_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'cupo_id': self.ref('plan_anual_adquisiciones_idu.cupo_id_01'),
        }
        try:
            recurso = recurso_model.sudo(user_group_asesor_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(recurso_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.financiacion
        # ----------------------------
        plan_linea_financiacion_model = self.env['plan_anual_adquisiciones.plan.linea.financiacion']
        # Creación permitida
        vals = {
            'centro_costo_id': self.ref('plan_anual_adquisiciones_idu.centro_costo_id_01'),
            'fuente_id': self.ref('plan_anual_adquisiciones_idu.fuente_id_01'),
            'rubro_id': self.ref('plan_anual_adquisiciones_idu.rubro_id_01'),
            'presupuesto': 13756693.7749,
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
        }
        plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_asesor_psp_01).create(vals)

        # Creación NO permitida
        vals = {
            'centro_costo_id': self.ref('plan_anual_adquisiciones_idu.centro_costo_id_01'),
            'fuente_id': self.ref('plan_anual_adquisiciones_idu.fuente_id_01'),
            'rubro_id': self.ref('plan_anual_adquisiciones_idu.rubro_id_01'),
            'presupuesto': 95663085.3597,
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
        }
        try:
            plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_asesor_psp_01).create(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad creando {}'.format(plan_linea_financiacion_model))

    def test_020_plan_anual_adquisiciones_idu_group_asesor_psp_write(self):
        """ plan_anual_adquisiciones_idu.group_asesor_psp Verifica reglas de dominio en operación WRITE """
        user_group_asesor_psp_01 = self.ref('plan_anual_adquisiciones_idu.group_asesor_psp_user_01')
        user_group_asesor_psp_02 = self.ref('plan_anual_adquisiciones_idu.group_asesor_psp_user_02')

        # ----------------------------
        # plan_anual_adquisiciones.plan
        # ----------------------------
        plan_model = self.env['plan_anual_adquisiciones.plan']
        # Actualización permitida
        vals = {
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
            'abierto_edicion': True,
            'vigencia': 7533687,
            'state': "inicial",
            'linea_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.linea_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_final': "2002-10-27",
            'fecha_inicial': "2007-10-23",
            'version': 3298116,
        }
        plan = plan_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        plan.sudo(user_group_asesor_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
            'abierto_edicion': False,
            'vigencia': 93394986,
            'state': "en_ejecucion",
            'linea_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.linea_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_final': "1980-01-09",
            'fecha_inicial': "1991-01-04",
            'version': 63678345,
        }
        plan = plan_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            plan.sudo(user_group_asesor_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(plan_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea
        # ----------------------------
        plan_linea_model = self.env['plan_anual_adquisiciones.plan.linea']
        # Actualización permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'state': "en_ejecucion",
            'tipo': "funcionamiento",
            'codigo_unspsc': "Nesciunt aut mollitia ullam molestias.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "psp",
            'tipo_proceso_id': self.ref('plan_anual_adquisiciones_idu.tipo_proceso_id_01'),
            'modalidad_seleccion_id': self.ref('plan_anual_adquisiciones_idu.modalidad_seleccion_id_01'),
            'localizacion': "77",
            'localidad_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'objeto_contractual': "Aut veniam aut itaque.",
            'plazo_ejecucion_meses': 32394080,
            'a_monto_agotable': True,
            'observaciones': "Magni rerum non possimus incidunt recusandae odit qui ab.",
            'no_aplica_unidad_medida_mt': True,
            'unidad_meta_fisica_id': self.ref('plan_anual_adquisiciones_idu.unidad_meta_fisica_id_01'),
            'cantidad_meta_fisica': 82316735.0926,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'pago_programado_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.pago_programado_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        plan_linea = plan_linea_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        plan_linea.sudo(user_group_asesor_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'state': "en_ejecucion",
            'tipo': "funcionamiento",
            'codigo_unspsc': "Officia odio sequi quae ut quia consequatur quas accusantium.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "psp",
            'tipo_proceso_id': self.ref('plan_anual_adquisiciones_idu.tipo_proceso_id_01'),
            'modalidad_seleccion_id': self.ref('plan_anual_adquisiciones_idu.modalidad_seleccion_id_01'),
            'localizacion': "localidad",
            'localidad_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.localidad_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'objeto_contractual': "Magnam sint voluptates ut et nihil rerum.",
            'plazo_ejecucion_meses': 67067388,
            'a_monto_agotable': False,
            'observaciones': "Est id veniam aut et.",
            'no_aplica_unidad_medida_mt': True,
            'unidad_meta_fisica_id': self.ref('plan_anual_adquisiciones_idu.unidad_meta_fisica_id_01'),
            'cantidad_meta_fisica': 11314245.8838,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'pago_programado_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.pago_programado_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'solicitud_cambio_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.solicitud_cambio_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        plan_linea = plan_linea_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            plan_linea.sudo(user_group_asesor_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(plan_linea_model))

        # ----------------------------
        # plan_anual_adquisiciones.tipo_proceso
        # ----------------------------
        tipo_proceso_model = self.env['plan_anual_adquisiciones.tipo_proceso']
        # Actualización permitida
        vals = {
            'name': "Eum dolore omnis at est quaerat.",
        }
        tipo_proceso = tipo_proceso_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        tipo_proceso.sudo(user_group_asesor_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Amet laboriosam qui iure numquam dolorum rerum.",
        }
        tipo_proceso = tipo_proceso_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            tipo_proceso.sudo(user_group_asesor_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(tipo_proceso_model))

        # ----------------------------
        # plan_anual_adquisiciones.modalidad_seleccion
        # ----------------------------
        modalidad_seleccion_model = self.env['plan_anual_adquisiciones.modalidad_seleccion']
        # Actualización permitida
        vals = {
            'name': "In ea quibusdam sint eius animi earum laboriosam eos.",
        }
        modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        modalidad_seleccion.sudo(user_group_asesor_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Esse sint voluptatibus at.",
        }
        modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            modalidad_seleccion.sudo(user_group_asesor_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(modalidad_seleccion_model))

        # ----------------------------
        # plan_anual_adquisiciones.solicitud_cambio
        # ----------------------------
        solicitud_cambio_model = self.env['plan_anual_adquisiciones.solicitud_cambio']
        # Actualización permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tipo_cambio': "eliminar",
            'plan_linea_nueva_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_nueva_id_01'),
            'justificacion': "Ut et assumenda est.",
            'state': "pre_aprobado",
        }
        solicitud_cambio = solicitud_cambio_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        solicitud_cambio.sudo(user_group_asesor_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tipo_cambio': "modificar",
            'plan_linea_nueva_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_nueva_id_01'),
            'justificacion': "Quasi ea numquam aperiam et laborum enim eos.",
            'state': "borrador",
        }
        solicitud_cambio = solicitud_cambio_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            solicitud_cambio.sudo(user_group_asesor_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(solicitud_cambio_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.pago_programado
        # ----------------------------
        plan_linea_pago_programado_model = self.env['plan_anual_adquisiciones.plan.linea.pago_programado']
        # Actualización permitida
        vals = {
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'mes': "12",
            'valor': 40300863.742,
        }
        plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        plan_linea_pago_programado.sudo(user_group_asesor_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'mes': "7",
            'valor': 46838561.8308,
        }
        plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            plan_linea_pago_programado.sudo(user_group_asesor_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(plan_linea_pago_programado_model))

        # ----------------------------
        # plan_anual_adquisiciones.cupo_psp
        # ----------------------------
        cupo_psp_model = self.env['plan_anual_adquisiciones.cupo_psp']
        # Actualización permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'state': "inicial",
            'tipo': "inversion",
            'codigo_unspsc': "Est minus animi nisi id officia repellendus.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "obra",
            'presupuesto': 55131717.6078,
            'recurso_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.recurso_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'categoria_id': self.ref('plan_anual_adquisiciones_idu.categoria_id_01'),
            'localizacion': "77",
            'objeto_contractual': "Rerum fugit dolorum qui aut.",
            'plazo_ejecucion_dias': 99025832,
            'honorarios_mes': 36261774.1381,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        cupo_psp = cupo_psp_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        cupo_psp.sudo(user_group_asesor_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'plan_id': self.ref('plan_anual_adquisiciones_idu.plan_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'state': "en_ejecucion",
            'tipo': "inversion",
            'codigo_unspsc': "Eveniet consequatur ut molestiae enim.",
            'proyecto_institucional_id': self.ref('plan_anual_adquisiciones_idu.proyecto_institucional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'clase_proceso': "psp",
            'presupuesto': 99500385.696,
            'recurso_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.recurso_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'categoria_id': self.ref('plan_anual_adquisiciones_idu.categoria_id_01'),
            'localizacion': "66",
            'objeto_contractual': "Et aliquid iure eius et vitae nihil sed.",
            'plazo_ejecucion_dias': 95486922,
            'honorarios_mes': 96105301.6913,
            'financiacion_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.financiacion_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        cupo_psp = cupo_psp_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            cupo_psp.sudo(user_group_asesor_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(cupo_psp_model))

        # ----------------------------
        # hr.categoria
        # ----------------------------
        categoria_model = self.env['hr.categoria']
        # Actualización permitida
        vals = {
            'name': "Neque vero dolor sequi labore est dolorum ut.",
            'codigo_siac': 35723191,
        }
        categoria = categoria_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        categoria.sudo(user_group_asesor_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Alias ab est ipsum rerum voluptatem.",
            'codigo_siac': 15712770,
        }
        categoria = categoria_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            categoria.sudo(user_group_asesor_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(categoria_model))

        # ----------------------------
        # hr.department.grupo_funcional
        # ----------------------------
        department_grupo_funcional_model = self.env['hr.department.grupo_funcional']
        # Actualización permitida
        vals = {
            'name': "Corrupti molestias vero possimus est hic illo excepturi.",
            'codigo_siac': 15038186,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tema_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.tema_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        department_grupo_funcional.sudo(user_group_asesor_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Non aliquid qui unde quia eius natus dignissimos pariatur.",
            'codigo_siac': 76239496,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tema_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.tema_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            department_grupo_funcional.sudo(user_group_asesor_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(department_grupo_funcional_model))

        # ----------------------------
        # hr.department.tema
        # ----------------------------
        department_tema_model = self.env['hr.department.tema']
        # Actualización permitida
        vals = {
            'name': "Provident magnam doloremque ut maxime.",
            'codigo_siac': 48445444,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_tema = department_tema_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        department_tema.sudo(user_group_asesor_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Tempora fugit voluptatem a et consequatur.",
            'codigo_siac': 25996548,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_tema = department_tema_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            department_tema.sudo(user_group_asesor_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(department_tema_model))

        # ----------------------------
        # hr.department.desempeno
        # ----------------------------
        department_desempeno_model = self.env['hr.department.desempeno']
        # Actualización permitida
        vals = {
            'name': "Optio deleniti numquam quo et animi.",
            'codigo_siac': 98032473,
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_desempeno = department_desempeno_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        department_desempeno.sudo(user_group_asesor_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Ut ex qui ullam.",
            'codigo_siac': 64784729,
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'area_conocimiento_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.area_conocimiento_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_desempeno = department_desempeno_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            department_desempeno.sudo(user_group_asesor_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(department_desempeno_model))

        # ----------------------------
        # hr.department.area_conocimiento
        # ----------------------------
        department_area_conocimiento_model = self.env['hr.department.area_conocimiento']
        # Actualización permitida
        vals = {
            'name': "Labore laboriosam voluptatem debitis ut.",
            'codigo_siac': 6609698,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
        }
        department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        department_area_conocimiento.sudo(user_group_asesor_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'name': "Nulla doloremque sit omnis voluptatibus.",
            'codigo_siac': 2188997,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
        }
        department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            department_area_conocimiento.sudo(user_group_asesor_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(department_area_conocimiento_model))

        # ----------------------------
        # project_idu.recurso
        # ----------------------------
        recurso_model = self.env['project_idu.recurso']
        # Actualización permitida
        vals = {
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'cupo_id': self.ref('plan_anual_adquisiciones_idu.cupo_id_01'),
        }
        recurso = recurso_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        recurso.sudo(user_group_asesor_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'cupo_id': self.ref('plan_anual_adquisiciones_idu.cupo_id_01'),
        }
        recurso = recurso_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            recurso.sudo(user_group_asesor_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(recurso_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.financiacion
        # ----------------------------
        plan_linea_financiacion_model = self.env['plan_anual_adquisiciones.plan.linea.financiacion']
        # Actualización permitida
        vals = {
            'centro_costo_id': self.ref('plan_anual_adquisiciones_idu.centro_costo_id_01'),
            'fuente_id': self.ref('plan_anual_adquisiciones_idu.fuente_id_01'),
            'rubro_id': self.ref('plan_anual_adquisiciones_idu.rubro_id_01'),
            'presupuesto': 39635143.7379,
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
        }
        plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        plan_linea_financiacion.sudo(user_group_asesor_psp_01).write(vals)

        # Actualización NO permitida
        vals = {
            'centro_costo_id': self.ref('plan_anual_adquisiciones_idu.centro_costo_id_01'),
            'fuente_id': self.ref('plan_anual_adquisiciones_idu.fuente_id_01'),
            'rubro_id': self.ref('plan_anual_adquisiciones_idu.rubro_id_01'),
            'presupuesto': 38505137.8354,
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'company_id': self.ref('plan_anual_adquisiciones_idu.company_id_01'),
        }
        plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            plan_linea_financiacion.sudo(user_group_asesor_psp_01).write(vals)
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad actualizando {}'.format(plan_linea_financiacion_model))

    def test_030_plan_anual_adquisiciones_idu_group_asesor_psp_unlink(self):
        """ plan_anual_adquisiciones_idu.group_asesor_psp Verifica reglas de dominio en operación UNLINK - Delete """
        user_group_asesor_psp_01 = self.ref('plan_anual_adquisiciones_idu.group_asesor_psp_user_01')
        user_group_asesor_psp_02 = self.ref('plan_anual_adquisiciones_idu.group_asesor_psp_user_02')

        # ----------------------------
        # plan_anual_adquisiciones.plan
        # ----------------------------
        plan_model = self.env['plan_anual_adquisiciones.plan']
        # Eliminación permitida
        plan = plan_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        plan.sudo(user_group_asesor_psp_01).unlink()

        # Eliminación NO permitida
        plan = plan_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            plan.sudo(user_group_asesor_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(plan_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea
        # ----------------------------
        plan_linea_model = self.env['plan_anual_adquisiciones.plan.linea']
        # Eliminación permitida
        plan_linea = plan_linea_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        plan_linea.sudo(user_group_asesor_psp_01).unlink()

        # Eliminación NO permitida
        plan_linea = plan_linea_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            plan_linea.sudo(user_group_asesor_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(plan_linea_model))

        # ----------------------------
        # plan_anual_adquisiciones.tipo_proceso
        # ----------------------------
        tipo_proceso_model = self.env['plan_anual_adquisiciones.tipo_proceso']
        # Eliminación permitida
        tipo_proceso = tipo_proceso_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        tipo_proceso.sudo(user_group_asesor_psp_01).unlink()

        # Eliminación NO permitida
        tipo_proceso = tipo_proceso_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            tipo_proceso.sudo(user_group_asesor_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(tipo_proceso_model))

        # ----------------------------
        # plan_anual_adquisiciones.modalidad_seleccion
        # ----------------------------
        modalidad_seleccion_model = self.env['plan_anual_adquisiciones.modalidad_seleccion']
        # Eliminación permitida
        modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        modalidad_seleccion.sudo(user_group_asesor_psp_01).unlink()

        # Eliminación NO permitida
        modalidad_seleccion = modalidad_seleccion_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            modalidad_seleccion.sudo(user_group_asesor_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(modalidad_seleccion_model))

        # ----------------------------
        # plan_anual_adquisiciones.solicitud_cambio
        # ----------------------------
        solicitud_cambio_model = self.env['plan_anual_adquisiciones.solicitud_cambio']
        # Eliminación permitida
        solicitud_cambio = solicitud_cambio_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        solicitud_cambio.sudo(user_group_asesor_psp_01).unlink()

        # Eliminación NO permitida
        solicitud_cambio = solicitud_cambio_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            solicitud_cambio.sudo(user_group_asesor_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(solicitud_cambio_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.pago_programado
        # ----------------------------
        plan_linea_pago_programado_model = self.env['plan_anual_adquisiciones.plan.linea.pago_programado']
        # Eliminación permitida
        plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        plan_linea_pago_programado.sudo(user_group_asesor_psp_01).unlink()

        # Eliminación NO permitida
        plan_linea_pago_programado = plan_linea_pago_programado_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            plan_linea_pago_programado.sudo(user_group_asesor_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(plan_linea_pago_programado_model))

        # ----------------------------
        # plan_anual_adquisiciones.cupo_psp
        # ----------------------------
        cupo_psp_model = self.env['plan_anual_adquisiciones.cupo_psp']
        # Eliminación permitida
        cupo_psp = cupo_psp_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        cupo_psp.sudo(user_group_asesor_psp_01).unlink()

        # Eliminación NO permitida
        cupo_psp = cupo_psp_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            cupo_psp.sudo(user_group_asesor_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(cupo_psp_model))

        # ----------------------------
        # hr.categoria
        # ----------------------------
        categoria_model = self.env['hr.categoria']
        # Eliminación permitida
        categoria = categoria_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        categoria.sudo(user_group_asesor_psp_01).unlink()

        # Eliminación NO permitida
        categoria = categoria_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            categoria.sudo(user_group_asesor_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(categoria_model))

        # ----------------------------
        # hr.department.grupo_funcional
        # ----------------------------
        department_grupo_funcional_model = self.env['hr.department.grupo_funcional']
        # Eliminación permitida
        department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        department_grupo_funcional.sudo(user_group_asesor_psp_01).unlink()

        # Eliminación NO permitida
        department_grupo_funcional = department_grupo_funcional_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            department_grupo_funcional.sudo(user_group_asesor_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(department_grupo_funcional_model))

        # ----------------------------
        # hr.department.tema
        # ----------------------------
        department_tema_model = self.env['hr.department.tema']
        # Eliminación permitida
        department_tema = department_tema_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        department_tema.sudo(user_group_asesor_psp_01).unlink()

        # Eliminación NO permitida
        department_tema = department_tema_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            department_tema.sudo(user_group_asesor_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(department_tema_model))

        # ----------------------------
        # hr.department.desempeno
        # ----------------------------
        department_desempeno_model = self.env['hr.department.desempeno']
        # Eliminación permitida
        department_desempeno = department_desempeno_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        department_desempeno.sudo(user_group_asesor_psp_01).unlink()

        # Eliminación NO permitida
        department_desempeno = department_desempeno_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            department_desempeno.sudo(user_group_asesor_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(department_desempeno_model))

        # ----------------------------
        # hr.department.area_conocimiento
        # ----------------------------
        department_area_conocimiento_model = self.env['hr.department.area_conocimiento']
        # Eliminación permitida
        department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        department_area_conocimiento.sudo(user_group_asesor_psp_01).unlink()

        # Eliminación NO permitida
        department_area_conocimiento = department_area_conocimiento_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            department_area_conocimiento.sudo(user_group_asesor_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(department_area_conocimiento_model))

        # ----------------------------
        # project_idu.recurso
        # ----------------------------
        recurso_model = self.env['project_idu.recurso']
        # Eliminación permitida
        recurso = recurso_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        recurso.sudo(user_group_asesor_psp_01).unlink()

        # Eliminación NO permitida
        recurso = recurso_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            recurso.sudo(user_group_asesor_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(recurso_model))

        # ----------------------------
        # plan_anual_adquisiciones.plan.linea.financiacion
        # ----------------------------
        plan_linea_financiacion_model = self.env['plan_anual_adquisiciones.plan.linea.financiacion']
        # Eliminación permitida
        plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        plan_linea_financiacion.sudo(user_group_asesor_psp_01).unlink()

        # Eliminación NO permitida
        plan_linea_financiacion = plan_linea_financiacion_model.sudo(user_group_asesor_psp_01).search([], limit=1)
        try:
            plan_linea_financiacion.sudo(user_group_asesor_psp_01).unlink()
        except AccessError:
            pass
        else:
            self.fail('No se generó Exception de seguridad Eliminando {}'.format(plan_linea_financiacion_model))


if __name__ == '__main__':
    unittest2.main()