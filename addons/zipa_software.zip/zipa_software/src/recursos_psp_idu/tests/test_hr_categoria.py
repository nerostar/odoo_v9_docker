# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_hr_categoria(common.TransactionCase):
    def test_crud_validaciones(self):
        categoria_model = self.env['hr.categoria']
        vals = {
            'name': "In est eum aperiam delectus qui nulla modi.",
            'codigo_siac': 11268069,
        }
        categoria = categoria_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()