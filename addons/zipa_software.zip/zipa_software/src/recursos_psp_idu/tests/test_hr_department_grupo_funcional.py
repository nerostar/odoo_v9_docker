# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_hr_department_grupo_funcional(common.TransactionCase):
    def test_crud_validaciones(self):
        department_grupo_funcional_model = self.env['hr.department.grupo_funcional']
        vals = {
            'name': "Et et consequuntur quo.",
            'codigo_siac': 15866269,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'tema_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.tema_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_grupo_funcional = department_grupo_funcional_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()