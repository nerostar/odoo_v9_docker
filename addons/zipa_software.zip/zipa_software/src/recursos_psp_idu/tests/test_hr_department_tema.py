# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_hr_department_tema(common.TransactionCase):
    def test_crud_validaciones(self):
        department_tema_model = self.env['hr.department.tema']
        vals = {
            'name': "Voluptatibus eum libero nam ducimus est aspernatur quam.",
            'codigo_siac': 42716896,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'desempeno_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.desempeno_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        department_tema = department_tema_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()