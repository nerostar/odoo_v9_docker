# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_plan_anual_adquisiciones_cupo_psp(common.TransactionCase):
    def test_crud_validaciones(self):
        cupo_psp_model = self.env['plan_anual_adquisiciones.cupo_psp']
        vals = {
            'codigo': 81895662,
            'dependencia_id': self.ref('plan_anual_adquisiciones_idu.dependencia_id_01'),
            'recurso_ids': [
                (4, self.ref('plan_anual_adquisiciones_idu.recurso_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'grupo_funcional_id': self.ref('plan_anual_adquisiciones_idu.grupo_funcional_id_01'),
            'tema_id': self.ref('plan_anual_adquisiciones_idu.tema_id_01'),
            'desempeno_id': self.ref('plan_anual_adquisiciones_idu.desempeno_id_01'),
            'categoria_id': self.ref('plan_anual_adquisiciones_idu.categoria_id_01'),
            'plan_linea_id': self.ref('plan_anual_adquisiciones_idu.plan_linea_id_01'),
            'plazo_ejecucion_dias': 93176736,
            'honorarios_mes': 78786790.384,
            'state': "finalizado",
            'codigo_unspsc': "Maxime aperiam iste qui dolorum.",
            'fuente_id': self.ref('plan_anual_adquisiciones_idu.fuente_id_01'),
            'tipo_proceso_id': self.ref('plan_anual_adquisiciones_idu.tipo_proceso_id_01'),
            'presupuesto': 61115642.9643,
            'localizacion': "66",
            'objeto_contractual': "Ut dolorem quos consectetur ducimus nemo deleniti.",
        }
        cupo_psp = cupo_psp_model.create(vals)

        # Campos computados
        vals_update = {
            'dependencia_id': 'Valor a usarse para calculo',
            'desempeno_id': 'Valor a usarse para calculo',
            'categoria_id': 'Valor a usarse para calculo',
        }
        cupo_psp.write(vals_update)
        self.assertEqual(cupo_psp.name, 'Valor Esperado')

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()