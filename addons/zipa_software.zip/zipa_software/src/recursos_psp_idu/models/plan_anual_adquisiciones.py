# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api
from openerp.exceptions import ValidationError
from openerp.exceptions import Warning


class plan_anual_adquisiciones_cupo_psp(models.Model):
    _name = 'plan_anual_adquisiciones.cupo_psp'
    _description = 'Cupo PSP'
    _inherit = ['plan_anual_adquisiciones.plan.linea',
                'mail.thread']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        size=255,
        compute='_compute_name',
        store = True,
    )
    codigo = fields.Char(
        string='Código del cupo',
        readonly=True,
    )
    plan_id = fields.Many2one(
        string='Plan',
        required=True,
        readonly=False,
        track_visibility='onchange',
        comodel_name='plan_anual_adquisiciones.plan',
        ondelete='restrict',
    )
    vigencia = fields.Integer(
        string='Vigencia',
        required=False,
        related='plan_id.vigencia',
    )
    plan_linea_id = fields.Many2one(
        string='Línea del Plan',
        required=False,
        track_visibility='onchange',
        comodel_name='plan_anual_adquisiciones.plan.linea',
        ondelete='restrict',
    )
    state = fields.Selection(
        string='Estado',
        required=True,
        track_visibility='onchange',
        selection=[
            ('nuevo', 'Nuevo'),
            ('por_validar', 'Por Validar'),
            ('validado', 'Validado'),
            ('pre_aprobado', 'Pre-aprobado'),
            ('aprobado', 'Aprobado'),
            ('linea_paa', 'Línea PAA creada'),
            ('rechazado', 'Rechazado'),
            ('anulado', 'Anulado'),
        ],
        default='nuevo',
    )
    currency_id = fields.Many2one(
        string='Moneda',
        required=False,
        readonly=True,
        invisible=True,
        related='plan_id.currency_id',
        comodel_name='res.currency',
        ondelete='restrict',
    )
    tipo = fields.Selection(
        string='Tipo',
        required=True,
        track_visibility='onchange',
        selection=[
            ('inversion', 'inversion'),
            ('funcionamiento', 'funcionamiento'),
        ],
        default='inversion',
    )
    codigo_unspsc = fields.Char(
        string='Código UNSPSC',
        required=False,
        track_visibility='onchange',
        size=255,
    )
    proyecto_institucional_id = fields.Many2one(
        string='Proyecto Institucional',
        required=False,
        track_visibility='onchange',
        comodel_name='plan_desarrollo_distrital.proyecto_institucional',
        ondelete='restrict',
    )
    dependencia_id = fields.Many2one(
        string='Dependencia',
        required=True,
        track_visibility='onchange',
        comodel_name='hr.department',
        ondelete='restrict',
    )
    clase_proceso = fields.Selection(
        string='Clase Proceso',
        required=True,
        readonly=True,
        selection=[
            ('psp', 'psp'),
            ('obra', 'obra'),
        ],
        default='psp',
    )
    tipo_proceso_id = fields.Many2one(
        string='Tipo Proceso',
        comodel_name='plan_anual_adquisiciones.tipo_proceso',
        ondelete='restrict',
        default=lambda self: self._get_id_contrato_nuevo(),
        readonly=True
    )
    modalidad_seleccion_id = fields.Many2one(
        string='Modalidad de Selección',
        comodel_name='plan_anual_adquisiciones.modalidad_seleccion',
        ondelete='restrict',
        readonly=True,
        default=lambda self: self. _get_id_modalidad_seleccion(),
    )
    presupuesto = fields.Monetary(
        string='Presupuesto',
        required=False,
        compute='_compute_presupuesto',
    )
    recurso_ids = fields.One2many(
        string='Recursos de Proyectos Asociados',
        required=False,
        comodel_name='project.recurso',
        inverse_name='cupo_id',
        ondelete='restrict',
    )
    grupo_funcional_id = fields.Many2one(
        string='Grupo Funcional',
        required=True,
        track_visibility='onchange',
        comodel_name='hr.department.grupo_funcional',
        ondelete='restrict',
    )
    tema_id = fields.Many2one(
        string='Tema',
        required=True,
        track_visibility='onchange',
        comodel_name='hr.department.tema',
        ondelete='restrict',
        domain="[('grupo_funcional_id','=',grupo_funcional_id)]"
    )
    desempeno_id = fields.Many2one(
        string='Desempeño',
        required=True,
        track_visibility='onchange',
        comodel_name='hr.department.desempeno',
        ondelete='restrict',
        domain="[('tema_id','=',tema_id)]",
    )
    area_conocimiento_ids = fields.One2many(
        string='Area de Conocimiento',
        required=False,
        track_visibility='onchange',
        comodel_name='hr.department.area_conocimiento',
        inverse_name='id',
        ondelete='restrict',
    )
    categoria_id = fields.Many2one(
        string='Categoria',
        required=False,
        track_visibility='onchange',
        comodel_name='hr.categoria',
        ondelete='restrict',
    )
    localizacion = fields.Selection(
        string='Localización',
        required=False,
        readonly=True,
        selection=[
            ('66', '66 - Entidad'),
            ('77', '77 - Metropolitana'),
            ('localidad', 'localidad'),
        ],
        default='66',
    )
    objeto_contractual = fields.Text(
        string='Objeto Contractual',
        required=False,
    )
    plazo_ejecucion_dias = fields.Integer(
        string='Plazo Ejecución en Días',
        required=False,
        track_visibility='onchange',
    )
    honorarios_mes = fields.Monetary(
        string='Honorarios Mensuales',
        required=False,
        track_visibility='onchange',
    )
    financiacion_ids = fields.One2many(
        string='Financiación',
        required=False,
        comodel_name='plan_anual_adquisiciones.cupo_psp.financiacion',
        inverse_name='plan_linea_id',
        ondelete='restrict',
    )
    localidad_ids = fields.Many2many(
        string='Localidades',
        required=False,
        comodel_name='res.country.state.city.district',
        relation='plan_anual_adquisiciones_cupo_psp_district_rel',
        ondelete='restrict',
    )
    total_financiado = fields.Float(
        'Total Financiado',
         compute = "_get_compute_total_financiado",
         store = True
    )
    fecha_radicacion = fields.Date(
        string='Fecha radicación en DTGC',
        required=True,
        default=fields.Date.today,
    )
    fecha_crp = fields.Date(
        string='Fecha CRP',
        required=True,
        default=fields.Date.today,
    )
    fecha_acta_inicio = fields.Date(
        string='Fecha aprobación acta de inicio',
        required=True,
        default=fields.Date.today,
    )
    pago_programado_ids = fields.One2many(
        string='Programación de pagos',
        required=False,
        comodel_name='plan_anual_adquisiciones.cupo_psp.pago_programado',
        inverse_name='plan_linea_id',
        ondelete='restrict',
    )
    total_pago_programado = fields.Monetary(
        string='Total programado',
        required=False,
        track_visibility='onchange',
        size=255,
        compute='_compute_pago_programado',
        store=True
    )
    total_rezago = fields.Monetary(
        string='Rezago',
        track_visibility='onchange',
        compute = "_get_compute_total_rezago",
        store = True
    )

    _sql_constraints = [
        ('unique_plan_linea_id', 'unique(plan_linea_id)', 'Este plan_linea_id ya está registrado'),
    ]

    # -------------------
    # methods
    # -------------------

    def generar_linea_paa(self):
        data = self.copy_data(default=None)
        data[0]['state'] = 'inicial'
        linea_paa_obj = self.env['plan_anual_adquisiciones.plan.linea']
        new_id = linea_paa_obj.create(data[0])
        self.generar_financiacion_ids(new_id)
        self.generar_pago_programado_ids(new_id)
        return new_id

    def generar_financiacion_ids(self, new_id):
        financiacion_linea_paa_obj = self.env['plan_anual_adquisiciones.plan.linea.financiacion']
        for item in self.financiacion_ids:
            data = item.copy_data(default=None)
            data[0]['plan_linea_id'] = new_id.id
            financiacion_linea_paa_obj.create(data[0])
        return True

    def generar_pago_programado_ids(self, new_id):
        pago_programado_linea_paa_obj = self.env['plan_anual_adquisiciones.plan.linea.pago_programado']
        for item in self.pago_programado_ids:
            data = item.copy_data(default=None)
            data[0]['plan_linea_id'] = new_id.id
            pago_programado_linea_paa_obj.create(data[0])
        return True

    @api.model
    def _get_id_modalidad_seleccion(self):
        id_modalidad_seleccion = None
        id_modalidad_seleccion = self.env['plan_anual_adquisiciones.modalidad_seleccion'].search([('name', '=', 'Contratación Directa')])
        return id_modalidad_seleccion.id

    @api.one
    @api.depends('pago_programado_ids')
    def _compute_pago_programado(self):
        total=0
        if self.pago_programado_ids:
            for pago in self.pago_programado_ids:
                total+=pago.valor
        self.total_pago_programado=total

    @api.one
    @api.depends('dependencia_id', 'codigo')
    def _compute_name(self):
        self.name = '{}_CUPO_{}'.format(self.dependencia_id.abreviatura,self.codigo)

    @api.one
    @api.depends('plazo_ejecucion_dias', 'honorarios_mes')
    def _compute_presupuesto(self):
        valor_dia = self.honorarios_mes / 30
        meses = int (self.plazo_ejecucion_dias / 30)
        dias = self.plazo_ejecucion_dias - (meses * 30)
        presupuesto = self.honorarios_mes * meses + valor_dia * dias
        self.presupuesto = presupuesto

    @api.depends('total_programado', 'total_ejecutado')
    def _get_compute_ejecutado(self):
        total = 0
        if self.total_programado:
            total = self.total_ejecutado/self.total_programado*100
        self.avance = total

    @api.depends('financiacion_ids')
    def _get_compute_total_financiado(self):
        total = 0
        if self.financiacion_ids:
            for record in self.financiacion_ids:
                total = total + record['presupuesto']
        self.total_financiado = total

    @api.model
    def create(self, vals):
        vals['codigo'] = self.env['ir.sequence'].next_by_code('codigo_cupo.secuencia')
        return super(plan_anual_adquisiciones_cupo_psp,self).create(vals)

    @api.multi
    def aprobar_cupo_psp(self, ids):
        for item_id in ids:
            item = self.browse(item_id)
            if item.state == 'pre_aprobado':
                item.signal_workflow('wkf_pre_aprobado__aprobado')

    @api.multi
    def crear_linea_paa(self, ids):
        for item_id in ids:
            item = self.browse(item_id)
            if item.state == 'aprobado':
                item.signal_workflow('wkf_aprobado__linea_paa')

    def wkf_check_campos(self):
        if (self.codigo_unspsc and self.proyecto_institucional_id and
                self.categoria_id and self.objeto_contractual and self.pago_programado_ids):
            return True
        else:
            return False

    def wkf_check_valor(self):
        if (self.plazo_ejecucion_dias > 0 and self.honorarios_mes > 0):
            return True
        else:
            raise Warning('''Verificar que el plazo ejecucion dias y los honorarios del mes
                            sean valores mayores a 0'''
            )
            return False

    def wkf_check_pre_aprobado(self):
        if self.financiacion_ids:
            return True
        else:
            return False

    # ===================================================================================
    # Workflow Methods
    # ===================================================================================

    def wkf_validado(self):
        if self.wkf_check_valor():
            if self.wkf_check_campos():
                self.state = 'validado'
            else:
                raise Warning('''Verificar que esté suministrada la información de codigo
                                unspsc, proyecto institucional, categoria, objeto contractual
                                y programación de pagos. Esto para continuar con el proceso de validación.'''
                )

    def wkf_linea_paa(self):
        linea_id = self.generar_linea_paa()
        if linea_id:
            self.plan_linea_id = linea_id
            self.state = 'linea_paa'
        #linea_id.signal_workflow('plan_anual_adquisiciones_workflow.wkf_inicial__por_revisar')
        #linea_id.signal_workflow('plan_anual_adquisiciones_workflow.wkf_por_revisar__pre_aprobado')

    def wkf_aprobado(self):
        self.state = 'aprobado'

    def wkf_pre_aprobado(self):
        if self.wkf_check_pre_aprobado():
            self.state = 'pre_aprobado'
        else:
            raise Warning('''Ingrese la información de financiación del cupo''')

    def wkf_rechazado(self):
        self.state = 'rechazado'

    def wkf_nuevo(self):
        self.state = 'nuevo'

    def wkf_por_validar(self):
        if self.wkf_check_campos():
            self.state = 'por_validar'
        else:
            raise Warning('''Verificar que esté suministrada la información de codigo
                            unspsc, proyecto institucional, categoria, objeto contractual
                            y programación de pagos. Esto para continuar con el proceso.'''
            )

    def wkf_anulado(self):
        self.state = 'anulado'


class plan_anual_adquisiciones_cupo_psp_financiacion(models.Model):
    _name = 'plan_anual_adquisiciones.cupo_psp.financiacion'
    _description = 'Financiacion Linea – Cupo PSP'
    _inherit = ['plan_anual_adquisiciones.plan.linea.financiacion']

    # -------------------
    # Fields
    # -------------------
    plan_linea_id = fields.Many2one(
        string='Cupo PSP',
        track_visibility='onchange',
        comodel_name='plan_anual_adquisiciones.cupo_psp',
        ondelete='restrict',
        default=lambda self: self._context.get('plan_linea_id', None),
    )
    plan_linea_id_presupuesto = fields.Monetary(
        string='Presupuesto línea plan',
        required=False,
        readonly=True,
        related='plan_linea_id.presupuesto',
        comodel_name='plan_anual_adquisiciones.plan.linea',
        ondelete='restrict',
    )
    plan_linea_id_total_financiado = fields.Float(
        string='Total financiado línea plan',
        required=False,
        readonly=True,
        related='plan_linea_id.total_financiado',
        comodel_name='plan_anual_adquisiciones.plan.linea',
        ondelete='restrict',
    )

    @api.constrains('presupuesto')
    def check_presupuesto(self):
        if self.plan_linea_id_total_financiado == 0:
            if self.presupuesto > self.plan_linea_id_presupuesto:
                return True
            else:
                raise Warning('''La financiación supera el valor del presupuesto requerido''')
                return False
        else:
            if self.plan_linea_id_total_financiado > self.plan_linea_id_presupuesto:
                return True
            else:
                raise Warning('''La financiación supera el valor del presupuesto requerido''')
                return False

class plan_anual_adquisiciones_plan_linea_pago_programado(models.Model):
    _name = 'plan_anual_adquisiciones.cupo_psp.pago_programado'
    _description = 'Pago Programado – Cupo PSP'
    _inherit = ['plan_anual_adquisiciones.plan.linea.pago_programado']

    # -------------------
    # Fields
    # -------------------
    plan_linea_id = fields.Many2one(
        string='Cupo PSP',
        track_visibility='onchange',
        comodel_name='plan_anual_adquisiciones.cupo_psp',
        ondelete='restrict',
        default=lambda self: self._context.get('plan_linea_id', None),
    )