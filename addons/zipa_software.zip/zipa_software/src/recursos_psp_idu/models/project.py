# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api
from openerp.exceptions import ValidationError


class project_recurso(models.Model):
    _name = 'project.recurso'
    _description = 'Recurso Humano Proyecto'
    _inherit = ['mail.thread']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        size=255,
        compute='_compute_name',
    )
    project_id = fields.Many2one(
        string='Proyecto',
        required=True,
        track_visibility='onchange',
        comodel_name='project.project',
        ondelete='restrict',
    )
    porcentaje_dedicacion = fields.Integer(
        string='Porcentaje de Dedicación',
        required=True,
        track_visibility='onchange',
        help='Valor entre 1 y 100',
        default=100,
    )
    grupo_funcional_id = fields.Many2one(
        string='Grupo Funcional',
        required=True,
        track_visibility='onchange',
        comodel_name='hr.department.grupo_funcional',
        ondelete='restrict',
    )
    tema_id = fields.Many2one(
        string='Tema',
        required=True,
        track_visibility='onchange',
        comodel_name='hr.department.tema',
        ondelete='restrict',
        domain="[('grupo_funcional_id','=',grupo_funcional_id)]",
    )
    desempeno_id = fields.Many2one(
        string='Desempeño',
        required=True,
        track_visibility='onchange',
        comodel_name='hr.department.desempeno',
        ondelete='restrict',
        domain="[('tema_id','=',tema_id)]",
    )
    dependencia_id = fields.Many2one(
        string='Dependencia',
        #required=True,
        readonly=True,
        track_visibility='onchange',
        related='project_id.dependencia_id',
        comodel_name='hr.department',
        store= True,
        ondelete='restrict',
    )
    cupo_id = fields.Many2one(
        string='Cupo PSP',
        required=False,
        readonly=True,
        track_visibility='onchange',
        comodel_name='plan_anual_adquisiciones.cupo_psp',
        ondelete='restrict',
    )

    # -------------------
    # methods
    # -------------------

    @api.one
    @api.depends('grupo_funcional_id', 'tema_id', 'desempeno_id')
    def _compute_name(self):
        self.name = "[{0}-{2}] {1}".format(self.dependencia_id.abreviatura,
                 self.id,
                 self.grupo_funcional_id.name,
        )

    @api.one
    @api.constrains('porcentaje_dedicacion')
    def _check_porcentaje_dedicacion(self):
        if self.porcentaje_dedicacion > 100:
            raise ValidationError("El porcentaje de dedicación asignado debe ser inferior o igual 100")
