# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api
from openerp.exceptions import ValidationError


class hr_categoria(models.Model):
    _name = 'hr.categoria'
    _description = 'Categoria – HR'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        #readonly=True,
        size=255,
    )
    codigo_siac = fields.Integer(
        string='Código SIAC',
        required=True,
        #readonly=True,
    )

    # -------------------
    # methods
    # -------------------

class hr_department_grupo_funcional(models.Model):
    _name = 'hr.department.grupo_funcional'
    _description = 'Grupo funcional dependencia – HR'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        #readonly=True,
        size=255,
    )
    codigo_siac = fields.Integer(
        string='Código SIAC',
        required=True,
        #readonly=True,
    )
    dependencia_id = fields.Many2one(
        string='Dependencia',
        required=True,
        #readonly=True,
        comodel_name='hr.department',
        ondelete='restrict',
    )
    tema_ids = fields.One2many(
        string='Temas',
        required=False,
        #readonly=True,
        comodel_name='hr.department.tema',
        inverse_name='grupo_funcional_id',
        ondelete='restrict',
    )

    # -------------------
    # methods
    # -------------------

class hr_department_tema(models.Model):
    _name = 'hr.department.tema'
    _description = 'Tema Dependencia – HR'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        #readonly=True,
        size=255,
    )
    codigo_siac = fields.Integer(
        string='Código SIAC',
        required=True,
        #readonly=True,
    )
    dependencia_id = fields.Many2one(
        string='Dependencia',
        required=True,
        #readonly=True,
        comodel_name='hr.department',
        ondelete='restrict',
    )
    grupo_funcional_id = fields.Many2one(
        string='Grupo Funcional',
        required=True,
        #readonly=True,
        comodel_name='hr.department.grupo_funcional',
        ondelete='restrict',
    )
    desempeno_ids = fields.One2many(
        string='Desempeños',
        required=False,
        #readonly=True,
        comodel_name='hr.department.desempeno',
        inverse_name='tema_id',
        ondelete='restrict',
    )

    # -------------------
    # methods
    # -------------------

class hr_department_desempeno(models.Model):
    _name = 'hr.department.desempeno'
    _description = 'Desempeño Dependencia – HR'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        #readonly=True,
        size=255,
    )
    codigo_siac = fields.Integer(
        string='Código SIAC',
        required=True,
        #readonly=True,
    )
    tema_id = fields.Many2one(
        string='Tema',
        required=True,
        #readonly=True,
        comodel_name='hr.department.tema',
        ondelete='restrict',
    )
    dependencia_id = fields.Many2one(
        string='Dependencia',
        required=True,
        #readonly=True,
        related='tema_id.dependencia_id',
        comodel_name='hr.department',
        ondelete='restrict',
        #store =True,
    )
    grupo_funcional_id = fields.Many2one(
        string='Grupo Funcional',
        required=True,
        #readonly=True,
        related='tema_id.grupo_funcional_id',
        comodel_name='hr.department.grupo_funcional',
        ondelete='restrict',
        #store =True,
    )

    # -------------------
    # methods
    # -------------------

class hr_department_area_conocimiento(models.Model):
    _name = 'hr.department.area_conocimiento'
    _description = 'Area de Conocimiento Dependencia – HR'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        #readonly=False,
        size=255,
    )
    codigo_siac = fields.Integer(
        string='Código SIAC',
        required=True,
        #readonly=False,
    )

    # -------------------
    # methods
    # -------------------
