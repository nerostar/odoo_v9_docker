# -*- encoding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2014 Instituto de Desarrollo Urbano (<http://www.idu.gov.co>).
#     All Rights Reserved
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from openerp import models, fields, api
import math



#class plan_anual_adquisiciones_idu_wizard_generar_cupo(osv.osv_memory):

class plan_anual_adquisiciones_idu_wizard_generar_cupo(models.Model):
    """
    Wizard para generar los cupos desde project_idu al plan anual de adquisiciones
    """
    _name = "plan_anual_adquisiciones_idu.wizard.generar_cupo"
    _description = "Permite generar los cupos psp desde porject_idu"

    # -------------------
    # Fields
    # -------------------

    plan_id = fields.Many2one(
        string='Plan',
        required=True,
        track_visibility='onchange',
        comodel_name='plan_anual_adquisiciones.plan',
        ondelete='restrict',
        default=lambda self: self._context.get('plan_id', None),
    )

    @api.multi
    def _compute_total_dedicacion_dependencia(self):
        query = """
            SELECT
                dependencia_id, grupo_funcional_id, desempeno_id, tema_id, sum(porcentaje_dedicacion) as dedicacion
            FROM
                project_recurso
            GROUP BY
                dependencia_id, grupo_funcional_id, desempeno_id, tema_id
        """
        self.env.cr.execute(query)
        lineas_recurso = self.env.cr.fetchall()
        return lineas_recurso

    @api.multi
    def _compute_recurso_id(self,  dependencia_id, grupo_funcional_id, desempeno_id, tema_id):
        query = """
            SELECT
                id
            FROM
                project_recurso
            WHERE
                dependencia_id = {} AND grupo_funcional_id = {} AND desempeno_id = {} AND tema_id = {}
        """.format(dependencia_id, grupo_funcional_id, desempeno_id, tema_id)
        self.env.cr.execute(query)
        recurso_id = self.env.cr.fetchall()
        return  recurso_id[0][0]

    def generar_financiacion_ids(self, new_id):
        financiacion_linea_paa_obj = self.env['plan_anual_adquisiciones.plan.linea.financiacion']
        for item in self.financiacion_ids:
            data = item.copy_data(default=None)
            data[0]['plan_linea_id'] = new_id.id
            financiacion_linea_paa_obj.create(data[0])
        return True

    def generar_pago_programado_ids(self, new_id):
        pago_programado_linea_paa_obj = self.env['plan_anual_adquisiciones.plan.linea.pago_programado']
        for item in self.pago_programado_ids:
            data = item.copy_data(default=None)
            data[0]['plan_linea_id'] = new_id.id
            pago_programado_linea_paa_obj.create(data[0])
        return True

    """Crear los registros en cupo psp del plan anual de aquisiciones """
    @api.one
    #def action_generar(self, cr, uid, ids, context=None):
    def action_generar(self):
        recurso_calculado = self._compute_total_dedicacion_dependencia()
        if recurso_calculado:
            for recurso in recurso_calculado:
                total_recurso = int(math.ceil(recurso[4]/100.0))
                for cupo in range(total_recurso):
                    vals = {
                         'dependencia_id': recurso[0],
                         'grupo_funcional_id': recurso[1],
                         'desempeno_id': recurso[2],
                         'tema_id': recurso[3],
                         'plan_id': self.plan_id.id,
                    }
                    id_cupo = self.env['plan_anual_adquisiciones.cupo_psp'].create(vals)
                    ids_recurso =  self._compute_recurso_id( recurso[0], recurso[1], recurso[2], recurso[3])
                    record_recurso = self.env['project.recurso'].browse([ids_recurso])
                    for record in record_recurso:
                        record.write({'cupo_id': id_cupo.id})
        return self.redirect_to_generar_cupo_view()

    def redirect_to_generar_cupo_view(self):
        return {
            'name': 'Cupos',
            'view_type': 'tree',
            'view_mode': 'tree',
            'res_model': 'plan_anual_adquisiciones.cupo_psp',
            'view_id': False,
            'type': 'ir.actions.act_window',
        }
