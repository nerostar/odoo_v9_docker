{
    'name': 'Proyectos Transmilenio',
    'version': '1.0',
    'depends': [
        'base',
        'base_idu',
        'stone_erp_idu',
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
#         'security/security.xml',
#         'security/ir.model.access.csv',
        'wizards/importar_pagos_transmilenio_xls_view.xml',
    ],
    'test': [],
    'demo': [],
    'installable': True,
    'description': """
Modulo para cargar información de pagos de Transmilenio
""",
}

