{
    'name': 'Procesos Sancionatorios IDU',
    'version': '1.0',
    'depends': [
        'base',
        'base_idu',
        'contrato_idu',
        'hr',
    ],
    'author': "IDU STRT I+D+i",
    'category': 'IDU',
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/sancionatorio_view.xml',
    ],
    'test': [],
    'demo': [
    ],
    'installable': True,
    'description': """
## Dependencias módulos Python
## Configuración adicional
    """,
}
