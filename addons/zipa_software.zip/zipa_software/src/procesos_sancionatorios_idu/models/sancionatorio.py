# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api
from openerp.exceptions import ValidationError




def obtener_proyecto_etapa_contrato(objeto, id_contrato=0, numero_contrato=''):
    '''
    Funcion que obtiene el proyecto y la etapa al cual esta asociado un contrato.
    Retorna un diccionario con los valores: etapa_id y proyecto_id si lo encuentra, si no, un diccionario vacio.
    '''
    consulta = ''
    info_contrato = {}
    if id_contrato:
        consulta = '''
        SELECT e.id as etapa_id, e.proyecto_id
            FROM contrato_contrato c
            LEFT JOIN contrato_contrato_project_project_rel cp ON cp.contrato_contrato_id = c.id
            LEFT JOIN project_obra_proyecto_etapa e ON e.project_id = cp.project_project_id
            LEFT JOIN project_project p ON p.id = e.project_id
            LEFT JOIN account_analytic_account a ON a.id = p.analytic_account_id
            WHERE c.id = {} AND p.state IN ('open', 'draft', 'pending') and e.active = 't' AND e.parent_id IS NULL
            GROUP BY e.id, e.proyecto_id;'''.format(id_contrato)
    elif numero_contrato:
        consulta = '''
        SELECT e.id as etapa_id, e.proyecto_id
            FROM contrato_contrato c
            LEFT JOIN contrato_contrato_project_project_rel cp ON cp.contrato_contrato_id = c.id
            LEFT JOIN project_obra_proyecto_etapa e ON e.project_id = cp.project_project_id
            LEFT JOIN project_project p ON p.id = e.project_id
            LEFT JOIN account_analytic_account a ON a.id = p.analytic_account_id
            WHERE c.numero = '{}' AND p.state IN ('open', 'draft', 'pending') and e.active = 't' AND e.parent_id IS NULL
            GROUP BY e.id, e.proyecto_id;'''.format(numero_contrato)
    if consulta:
        objeto.env.cr.execute(consulta)
        respuesta = objeto.env.cr.fetchall()
        info_contrato['etapa_id'] = respuesta[0][0] if respuesta and respuesta[0] else 0
        info_contrato['proyecto_id'] = respuesta[0][1] if respuesta and respuesta[0] else 0
    return info_contrato


class SancionatorioProceso(models.Model):
    _name = 'sancionatorio.proceso'
    _description = 'Procesos Sancionatorios'
    _inherit = ['mail.thread']


    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        track_visibility='onchange',
        size=250,
        help='''Nombre de la mascota''',
    )
    state = fields.Selection(
        string='Estado',
        required=True,
        track_visibility='onchange',
        help='''Estado del proceso''',
        selection=[
            ('etapa_previa', 'Etapa Previa'),
            ('audiencia', 'Audiencia'),
            ('fallo', 'Fallo'),
            ('cobro', 'Cobro'),
            ('anulado', 'Anulado'),
            ('unificado', 'Unificado'),
            ('sancionado_pagado', 'Sancionado pagado'),
            ('terminado', 'Terminado'),
        ],
        default='etapa_previa',
    )
    user_id = fields.Many2one(
        string='Usuario',
        required=False,
        readonly=True,
        track_visibility='onchange',
        comodel_name='res.users',
        ondelete='restrict',
        help='''Usuario asignado''',
        default=lambda self: self._context.get('uid', self.env['res.users'].browse()),
    )
    tipo_sancion = fields.Selection(
        string='Tipo Sanción',
        required=True,
        selection=[('multa', 'Multa'), ('clausula_penal', 'Clausula Penal'), ('caducidad','Caducidad')],
        track_visibility='onchange',
        default='multa',
    )
    contrato_id = fields.Many2one(
        string='Contrato',
        required=True,
        track_visibility='onchange',
        comodel_name='contrato.contrato',
        ondelete='restrict',
        help='''Contrato''',
    )
    contrato_interventoria_id = fields.Many2one(
        string='Contrato Interventoria',
        required=True,
        track_visibility='onchange',
        comodel_name='contrato.contrato',
        ondelete='restrict',
        help='''Contrato Interventoria''',
    )
    proyecto_id = fields.Many2one(
        string='Proyecto Relacionado',
        track_visibility='onchange',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
    )
    etapa_id = fields.Many2one(
        string='Etapa',
        required=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.etapa.tipo',
        ondelete='restrict',
    )
    etapa_actual_id = fields.Many2one(
        string='Etapa Actual del Proyecto',
        required=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.etapa',
        ondelete='restrict',
        help='''Etapa Actual del proyecto''',
    )
    proyecto_plan_id = fields.Many2one(
        string='Proyecto Plan Relacionado',
        required=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto_plan',
        ondelete='restrict',
        help='''Proyecto Plan Relacionado''',
    )
    unificado_en_id = fields.Many2one(
        string='Unificado en',
        required=False,
        track_visibility='onchange',
        comodel_name='sancionatorio.proceso',
        ondelete='restrict',
        help='''Proceso al que se unificó este proceso''',
    )
    observaciones = fields.Text(
        string='Observaciones',
        required=False,
        track_visibility='onchange',
        help='''Observaciones''',
    )
    observaciones_unificado = fields.Text(
        string='Observaciones Unificado',
        required=False,
        track_visibility='onchange',
        help='''Observaciones de la unificación.''',
    )
    apremio_ids = fields.Many2many(
        string='Apremios',
        required=False,
        track_visibility='onchange',
        comodel_name='sancionatorio.apremio',
        ondelete='restrict',
        help='''Apremios''',
        #domain="[('active','=',True)]",
    )
    informe_incumplimiento_ids = fields.Many2many(
        string='Informes de Incumplimiento',
        required=False,
        track_visibility='onchange',
        comodel_name='sancionatorio.informe_incumplimiento',
        ondelete='restrict',
        help='''Informes de Incumplimiento''',
    )
    mesas_trabajo_ids = fields.Many2many(
        string='Mesas de trabajo',
        required=False,
        track_visibility='onchange',
        comodel_name='sancionatorio.mesas_trabajo',
        ondelete='restrict',
        help='''Mesas de trabajo''',
    )
    audiencia_ids = fields.Many2many(
        string='Audiencias',
        required=False,
        track_visibility='onchange',
        comodel_name='sancionatorio.audiencias',
        ondelete='restrict',
        help='''Audiencias''',
    )
    fallo_ids = fields.Many2many(
        string='Fallos',
        required=False,
        track_visibility='onchange',
        comodel_name='sancionatorio.fallos',
        ondelete='restrict',
        help='''Fallos''',
    )
    reportes_ids = fields.Many2many(
        string='Reportes',
        required=False,
        track_visibility='onchange',
        comodel_name='sancionatorio.reportes',
        ondelete='restrict',
        help='''Reportes''',
    )
    citaciones_ids = fields.Many2many(
        string='Citaciones',
        required=False,
        track_visibility='onchange',
        comodel_name='sancionatorio.citaciones',
        ondelete='restrict',
        help='''Citaciones''',
    )


    # -------------------
    # methods
    # -------------------

    @api.model
    def create(self, vals):
        proceso = super(SancionatorioProceso, self).create(vals)
        return proceso

    @api.one
    def write(self, vals):
        res = super(SancionatorioProceso, self).write(vals)
        return res


    @api.depends('informe_incumplimiento_ids')
    def _compute_abogado_esta(self):
        for record in self:
            for informe in record.informe_incumplimiento_ids:
                if informe.abogado_sustanciador_id.id == self.env.uid:
                    record.abogado_esta = True
                    break


    @api.onchange('contrato_id')
    def _onchange_contrato_id(self):
        result = {}
        if self.contrato_id:
            contrato_interventoria_id = self.contrato_id.interventoria_ids[0].id if self.contrato_id.interventoria_ids else None
            self.contrato_interventoria_id = contrato_interventoria_id
            proyecto_etapa = obtener_proyecto_etapa_contrato(self, id_contrato=self.contrato_id.id)
            if proyecto_etapa:
                if 'proyecto_id' in proyecto_etapa and proyecto_etapa['proyecto_id']:
                    self.proyecto_id = proyecto_etapa['proyecto_id']
                    if len(self.proyecto_id.proyecto_plan_ids.ids) >= 1:
                        plan_ids = self.proyecto_id.proyecto_plan_ids.mapped('proyecto_plan_id').ids
                        self.proyecto_plan_id = plan_ids[0]
                        result = {
                            'domain': {
                                'proyecto_plan_id': [('id', 'in', plan_ids)]
                            },
                        }
                if 'etapa_id' in proyecto_etapa and proyecto_etapa['etapa_id']:
                    self.etapa_actual_id = proyecto_etapa['etapa_id']
            else:
                self.proyecto_id = False
                self.etapa_actual_id = False
                self.proyecto_plan_id = False
        return result


    @api.multi
    def lanzar_wizard_unificar(self):
        view_ids = self.env['ir.ui.view'].search([('model','=','proceso.wizard.unificar_proceso'),
                                                  ('name','=','Unificar Proceso')])

        return {
                'name': "Unificar Procesos",
                'view_mode': 'form',
                'view_id': view_ids.id,
                'view_type': 'form',
                'res_model': 'proceso.wizard.unificar_proceso',
                'type': 'ir.actions.act_window',
                'target': 'new',
                # 'domain': '[if you need]',
                'context': {'proceso_id': self.id, 'contrato_id': self.contrato_id.id}
            }


    @api.multi
    def unificar(self):
        procesos_ids = self.search([('contrato_id', '=', self.contrato_id.id)]).ids
        return {
            'name': 'Procesos a Unificar',
            'type': 'ir.actions.act_window',
            'res_model': 'sancionatorio.proceso',
            'view_type': 'form',
            'view_mode': 'tree',
            'view_id': self.env.ref('procesos_sancionatorios_idu.proceso_unificar_tree').id,
            'domain': [('id', 'in', procesos_ids)],
        }


    # -------------------
    # Workflow methods
    # -------------------
    @api.one
    def wkf_etapa_previa(self):
        self.state = 'etapa_previa'

    @api.one
    def wkf_audiencia(self):
        self.state = 'audiencia'

    @api.one
    def wkf_fallo(self):
        self.state = 'fallo'

    @api.one
    def wkf_cobro(self):
        self.state = 'cobro'

    @api.one
    def wkf_anulado(self):
        self.state = 'anulado'

    @api.one
    def wkf_sancionado_pagado(self):
        self.state = 'sancionado_pagado'

    @api.one
    def wkf_cerrado(self):
        self.state = 'cerrado'






class SancionatorioApremio(models.Model):
    _name = 'sancionatorio.apremio'
    _description = 'Apremios'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        track_visibility='onchange',
        size=100,
        help='''Nombre del Apremio''',
    )
    radicado_idu = fields.Char(
        string='Radicado IDU',
        required=False,
        track_visibility='onchange',
        size=100,
        help='''Radicado IDU''',
    )
    fecha_radicado = fields.Date(
        string='Fecha Radicado',
        required=False,
        track_visibility='onchange',
        help='''Fecha Radicado''',
    )
    observaciones = fields.Text(
        string='Observaciones',
        required=False,
        track_visibility='onchange',
        help='''Observaciones''',
    )

    contrato_id = fields.Many2one(
        string='Contrato',
        required=True,
        readonly=False,
        comodel_name='contrato.contrato',
        ondelete='restrict',
        #domain="[('coordinador_ids.tipo','=','ambiental'), ('coordinador_ids.user_id','=',uid), ('state', '=', 'en_ejecucion')]",
        track_visibility='onchange',
        #states={
        #    'liquidado': [('readonly', True)],
        #    'gestion': [('readonly', True)],
        #},
    )

    fecha_vencimiento = fields.Date(
        string='Fecha de Vencimiento',
        required=True,
        readonly=False,
        track_visibility='onchange'
    )

    copio_a_garante = fields.Boolean(
        string='¿Se copio al garante?',
        required=False,
        readonly=False,
        track_visibility='onchange'
    )

    incluye_obligacion_incumplida = fields.Selection(
        [('si','Si'),
        ('no','No')],
        string='¿Se incluyó la obligación incumplida?',
        required=True,
        readonly=False,
        track_visibility='onchange'
    )
        

    _sql_constraints = [
        ('unique_name', 'unique(name)', 'Este name ya está registrado'),
    ]

    @api.constrains('copio_a_garante')
    def check_copia_a_garante(self):
        print("Validador copia a garante")
        if self.copio_a_garante != True:
            raise ValidationError("Se debe notificar el garante antes de crear o actualizar el apremio")



    
        

    # -------------------
    # methods
    # -------------------

class SancionatorioInformeIncumplimiento(models.Model):
    _name = 'sancionatorio.informe_incumplimiento'
    _description = 'Informes de Incumplimento'


    def abogado_domain(self):
        grupo_abogado_sustanciador = self.env.ref('procesos_sancionatorios_idu.abogado')
        abogados_ids = grupo_abogado_sustanciador.users.ids
        return [('id','in',abogados_ids)]

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        track_visibility='onchange',
        size=100,
        help='''Nombre del Informe de Incumplimiento''',
    )
    asunto = fields.Selection(
        string='Asunto',
        required=True,
        track_visibility='onchange',
        help='''Asunto''',
        selection=[
            ('informe_tecnico_primera_vez', 'Informe Técnico Primera Vez'),
            ('devolucion_informe', 'Devolución Informe'),
            ('informe_tecnico', 'Informe Técnico'),
            ('concepto_de_verificacion', 'Concepto de Verificación'),
            ('asignacion_abogado', 'Asignación Abogado'),
            ('revision_informe', 'Revisión Informe'),
        ],
        default='informe_tecnico_primera_vez',
    )
    radicado = fields.Char(
        string='Radicado',
        required=False,
        track_visibility='onchange',
        size=100,
        help='''Radicado''',
    )
    fecha_radicado = fields.Date(
        string='Fecha Radicado',
        required=False,
        track_visibility='onchange',
        help='''Fecha Radicado''',
    )
    observaciones = fields.Text(
        string='Observaciones',
        required=False,
        track_visibility='onchange',
        help='''Observaciones''',
    )
    abogado_sustanciador_id = fields.Many2one(
        string='Abogado Sustanciador',
        required=False,
        track_visibility='onchange',
        comodel_name='res.users',
        ondelete='restrict',
        help='''Abogado Sustanciador''',
        domain=abogado_domain,
    )

    # -------------------
    # methods
    # -------------------

class SancionatorioMesasTrabajo(models.Model):
    _name = 'sancionatorio.mesas_trabajo'
    _description = 'Mesas de Trabajo'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        track_visibility='onchange',
        size=100,
        help='''Nombre de la mesa de trabajo''',
    )
    state = fields.Selection(
        string='Estado',
        required=True,
        track_visibility='onchange',
        help='''Estado''',
        selection=[
            ('programada', 'Programada'),
            ('realizada', 'Realizada'),
            ('aplazada', 'Aplazada'),
        ],
        default='programada',
    )
    asunto = fields.Selection(
        string='Asunto',
        required=True,
        track_visibility='onchange',
        help='''Asunto''',
        selection=[
            ('mesa_de_trabajo', 'Mesa de Trabajo'),
            ('devolucion_de_informe', 'Devolución de Informe'),
        ],
        default='mesa_de_trabajo',
    )
    fecha = fields.Date(
        string='Fecha',
        required=False,
        track_visibility='onchange',
        help='''Fecha''',
        default=fields.Date.today,
    )
    tarea_ids = fields.Many2many(
        string='Tareas',
        required=False,
        track_visibility='onchange',
        comodel_name='sancionatorio.tareas',
        ondelete='restrict',
        help='''Tareas''',
    )

    # -------------------
    # methods
    # -------------------

class SancionatorioTareas(models.Model):
    _name = 'sancionatorio.tareas'
    _description = 'Tareas'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        track_visibility='onchange',
        size=100,
        help='''Nombre de la Tarea''',
    )
    state = fields.Selection(
        string='Estado',
        required=True,
        track_visibility='onchange',
        help='''Estado''',
        selection=[
            ('en_ejecucion', 'En Ejecución'),
            ('terminada', 'Terminada'),
            ('suspendida', 'Suspendida'),
        ],
        default='en_ejecucion',
    )
    responsable_id = fields.Many2one(
        string='Responsable',
        required=True,
        track_visibility='onchange',
        comodel_name='res.users',
        ondelete='restrict',
        help='''Responsable''',
    )
    fecha_fin = fields.Date(
        string='Fecha Fin',
        required=True,
        track_visibility='onchange',
        help='''Fecha Fin''',
    )

    # -------------------
    # methods
    # -------------------



class SancionatorioAudiencias(models.Model):
    _name = 'sancionatorio.audiencias'
    _description = 'Audiencias'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        track_visibility='onchange',
        size=100,
        help='''Nombre de la Audiencia''',
    )
    asunto = fields.Selection(
        string='Asunto',
        required=True,
        track_visibility='onchange',
        help='''Asunto''',
        selection=[
            ('apalazamiento_audiencia', 'Apalazamiento de Audiencia'),
            ('presentacion_descargos', 'Presentación de Descargos'),
            ('practica_pruebas', 'Práctica de pruebas'),
            ('consideraciones_finales', 'Consideraciones finales'),
        ],
    )
    fecha = fields.Date(
        string='Fecha',
        required=False,
        track_visibility='onchange',
        help='''Fecha''',
    )
    radicado = fields.Char(
        string='Radicado',
        required=False,
        track_visibility='onchange',
        size=100,
        help='''Radicado''',
    )
    observaciones = fields.Text(
        string='Observaciones',
        required=False,
        track_visibility='onchange',
        help='''Observaciones''',
    )

    # -------------------
    # methods
    # -------------------

class SancionatorioFallos(models.Model):
    _name = 'sancionatorio.fallos'
    _description = 'Fallos'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        track_visibility='onchange',
        size=100,
        help='''Nombre del Fallo''',
    )
    tipo = fields.Selection(
        string='Tipo',
        required=True,
        track_visibility='onchange',
        help='''Asunto''',
        selection=[
            ('acto_administrativo_inicial', 'Acto administrativo inicial'),
            ('acto_administrativo_final', 'Acto administrativo final'),
            ('constancia_ejecutoria', 'Constancia ejecutoria'),
        ],
        default='acto_administrativo_inicial',
    )
    fecha = fields.Date(
        string='Fecha',
        required=False,
        track_visibility='onchange',
        help='''Fecha''',
    )
    radicado = fields.Char(
        string='Radicado',
        required=False,
        track_visibility='onchange',
        size=100,
        help='''Radicado''',
    )
    acto_administrativo = fields.Text(
        string='Número de Resolución',
        required=False,
        track_visibility='onchange',
        help='''Número de Resolución''',
    )
    fecha_notificacion = fields.Date(
        string='Fecha Notificación',
        required=False,
        track_visibility='onchange',
        help='''Fecha Notificación''',
    )
    valor = fields.Float(
        string='Valor',
        required=False,
        track_visibility='onchange',
        help='''Valor''',
    )
    fecha_ejecutoria = fields.Date(
        string='Fecha de Ejecutoria',
        required=False,
        track_visibility='onchange',
        help='''Fecha de Ejecutoria''',
    )
    observaciones = fields.Text(
        string='Observaciones',
        required=False,
        track_visibility='onchange',
        help='''Observaciones''',
    )

    # -------------------
    # methods
    # -------------------




class SancionatorioReportes(models.Model):
    _name = 'sancionatorio.reportes'
    _description = 'reportes'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        track_visibility='onchange',
        size=100,
        help='''Nombre del Reporte''',
    )
    entidad = fields.Selection(
        string='Entidad',
        required=True,
        track_visibility='onchange',
        help='''Entidad''',
        selection=[
            ('procuraduria', 'Procuraduria'),
            ('ccomercio', 'Camara de Comercio'),
            ('presupuesto_contabilidad', 'Presupuesto y Contabilidad'),
            ('secop', 'SECOP'),
        ],
    )
    fecha = fields.Date(
        string='Fecha',
        required=False,
        track_visibility='onchange',
        help='''Fecha''',
    )
    radicado = fields.Char(
        string='Radicado ORFEO',
        required=False,
        track_visibility='onchange',
        size=100,
        help='''Radicado ORFEO''',
    )
    archivo = fields.Binary(
        string='Archivo',
        attachment=True,
        track_visibility='onchange',
    )
    nombre_archivo = fields.Char(
        string='Nombre Archivo',
        track_visibility='onchange',
    )



    # -------------------
    # methods
    # -------------------




class SancionatorioCitaciones(models.Model):
    _name = 'sancionatorio.citaciones'
    _description = 'citaciones'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        track_visibility='onchange',
        size=100,
        help='''Nombre de la citación''',
    )
    asunto = fields.Selection(
        string='Asunto',
        required=True,
        track_visibility='onchange',
        help='''Asunto''',
        selection=[
            ('citacion', 'Citación'),
            ('devolucion_citacion', 'Devolución de citación'),
            ('nueva_citacion', 'Nueva citación'),
        ],
    )
    fecha = fields.Date(
        string='Fecha',
        required=False,
        track_visibility='onchange',
        help='''Fecha''',
    )
    radicado = fields.Char(
        string='Radicado',
        required=False,
        track_visibility='onchange',
        size=100,
        help='''Radicado ORFEO''',
    )
    observaciones = fields.Text(
        string='Observaciones',
        track_visibility='onchange',
        size=100,
        help='''Observaciones de la citación''',
    )



    # -------------------
    # methods
    # -------------------
