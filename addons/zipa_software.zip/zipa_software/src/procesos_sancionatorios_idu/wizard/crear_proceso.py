# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import logging

from openerp import models, fields, api
from openerp.exceptions import ValidationError

_logger = logging.getLogger(__name__)


def obtener_proyecto_etapa_contrato(objeto, id_contrato=0, numero_contrato=''):
    '''
    Funcion que obtiene el proyecto y la etapa al cual esta asociado un contrato.
    Retorna un diccionario con los valores: etapa_id y proyecto_id si lo encuentra, si no, un diccionario vacio.
    '''
    consulta = ''
    info_contrato = {}
    if id_contrato:
        consulta = '''
        SELECT e.id as etapa_id, e.proyecto_id
            FROM contrato_contrato c
            LEFT JOIN contrato_contrato_project_project_rel cp ON cp.contrato_contrato_id = c.id
            LEFT JOIN project_obra_proyecto_etapa e ON e.project_id = cp.project_project_id
            LEFT JOIN project_project p ON p.id = e.project_id
            LEFT JOIN account_analytic_account a ON a.id = p.analytic_account_id
            WHERE c.id = {} AND p.state IN ('open', 'draft', 'pending') and e.active = 't' AND e.parent_id IS NULL
            GROUP BY e.id, e.proyecto_id;'''.format(id_contrato)
    elif numero_contrato:
        consulta = '''
        SELECT e.id as etapa_id, e.proyecto_id
            FROM contrato_contrato c
            LEFT JOIN contrato_contrato_project_project_rel cp ON cp.contrato_contrato_id = c.id
            LEFT JOIN project_obra_proyecto_etapa e ON e.project_id = cp.project_project_id
            LEFT JOIN project_project p ON p.id = e.project_id
            LEFT JOIN account_analytic_account a ON a.id = p.analytic_account_id
            WHERE c.numero = '{}' AND p.state IN ('open', 'draft', 'pending') and e.active = 't' AND e.parent_id IS NULL
            GROUP BY e.id, e.proyecto_id;'''.format(numero_contrato)
    if consulta:
        objeto.env.cr.execute(consulta)
        respuesta = objeto.env.cr.fetchall()
        info_contrato['etapa_id'] = respuesta[0][0] if respuesta and respuesta[0] else 0
        info_contrato['proyecto_id'] = respuesta[0][1] if respuesta and respuesta[0] else 0
    return info_contrato


class proceso_crear_proceso_wizard(models.TransientModel):
    _name = 'proceso.wizard.crear_proceso'
    _description = 'Wizard para Crear proceso sancionatorio'

    # -------------------
    # Fields
    # -------------------

    user_id = fields.Many2one(
        string='Autor',
        required=True,
        comodel_name='res.users',
        ondelete='restrict',
        readonly=True,
        default=lambda self: self._context.get('uid', self.env['res.users'].browse()),
    )
    etapa_id = fields.Many2one(
        string='Etapa',
        required=False,
        comodel_name='project_obra.proyecto.etapa.tipo',
        ondelete='restrict',
    )
    etapa_actual_id = fields.Many2one(
        string='Etapa Actual del Proyecto',
        required=False,
        comodel_name='project_obra.proyecto.etapa',
        ondelete='restrict',
        help='''Etapa Actual del proyecto''',
    )
    contrato_id = fields.Many2one(
        string='Contrato',
        required=False,
        comodel_name='contrato.contrato',
        ondelete='restrict',
    )
    contrato_interventoria_id = fields.Many2one(
        string='Contrato de Interventoría',
        required=False,
        comodel_name='contrato.contrato',
        ondelete='restrict',
        domain="[('id','!=',contrato_id), ('siac_tipo_contrato_id.es_interventoria','=',True)]",
    )
    proyecto_id = fields.Many2one(
        string='Proyecto Relacionado',
        required=False,
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
        help='''Proyecto Relacionado''',
    )
    proyecto_plan_id = fields.Many2one(
        string='Proyecto Plan Relacionado',
        required=False,
        comodel_name='project_obra.proyecto_plan',
        ondelete='restrict',
        help='''Proyecto Plan Relacionado''',
    )
    tipo_sancion = fields.Selection(
        string='Tipo Sanción',
        required=True,
        selection=[('multa', 'Multa'), ('clausula_penal', 'Clausula Penal'), ('caducidad','Caducidad')],
        track_visibility='onchange',
        default='multa',
    )
    a_base_otro_proceso = fields.Selection(
        string='A base de otro Proceso',
        selection=[('si', 'Si'), ('no', 'No')],
        required=True,
        default='no'
    )
    proceso_id = fields.Many2one(
        string='Proceso Fuente',
        comodel_name='sancionatorio.proceso',
        ondelete='restrict',
    )


    # -------------------
    # methods
    # -------------------
    @api.onchange('user_id')
    def _onchange_user_id(self):
        # if self.env.user.has_group('procesos_sancionatorios_idu.admin'):
        #     contrato_ids = self.env['contrato.contrato'].search([('state', 'in', ['borrador', 'en_ejecucion'])]).ids
        # else:
        #     contrato_ids = self.env['contrato.coordinador_contrato'].search([
        #         ('user_id', '=', self.env.uid),
        #     ]).mapped('contrato_id.id')
        contrato_ids = self.env['contrato.contrato'].search([('state', 'in', ['borrador', 'en_ejecucion'])]).ids
        return {
            'domain': {
                'contrato_id': [('id', 'in', contrato_ids), ],
            }
        }


    @api.onchange('contrato_id')
    def _onchange_contrato_id(self):
        result = {}
        if self.contrato_id:
            contrato_interventoria_id = self.contrato_id.interventoria_ids[0].id if self.contrato_id.interventoria_ids else None
            self.contrato_interventoria_id = contrato_interventoria_id
            proyecto_etapa = obtener_proyecto_etapa_contrato(self, id_contrato=self.contrato_id.id)
            if proyecto_etapa:
                if 'proyecto_id' in proyecto_etapa and proyecto_etapa['proyecto_id']:
                    self.proyecto_id = proyecto_etapa['proyecto_id']
                    if len(self.proyecto_id.proyecto_plan_ids.ids) >= 1:
                        plan_ids = self.proyecto_id.proyecto_plan_ids.mapped('proyecto_plan_id').ids
                        self.proyecto_plan_id = plan_ids[0]
                        result = {
                            'domain': {
                                'proyecto_plan_id': [('id', 'in', plan_ids)]
                            },
                        }
                if 'etapa_id' in proyecto_etapa and proyecto_etapa['etapa_id']:
                    self.etapa_actual_id = proyecto_etapa['etapa_id']
            else:
                self.proyecto_id = False
                self.etapa_actual_id = False
                self.proyecto_plan_id = False
        return result


    @api.onchange('a_base_otro_proceso')
    def _onchange_a_base_otro_proceso(self):
        if self.a_base_otro_proceso == 'si':
            if self.proyecto_id:
                #procesos = self.env['sancionatorio.proceso'].search([('proyecto_id', '=', self.proyecto_id.id)])
                return {
                    'domain': {
                        'proceso_id': [('contrato_id', '=', self.contrato_id.id), ],
                    }
                }


    @api.onchange('proyecto_id')
    def _onchange_proyecto_id(self):
        if self.proyecto_id:
            if self.a_base_otro_proceso == 'si':
                #procesos = self.env['sancionatorio.proceso'].search([('proyecto_id', '=', self.proyecto_id.id)])
                return {
                    'domain': {
                        'proceso_id': [('proyecto_id', '=', self.proyecto_id.id), ],
                    }
                }

    @api.onchange('proceso_id')
    def _onchange_proceso_id(self):
        if self.proceso_id:
            self.etapa_id = self.etapa_id


    @api.multi
    def crear_proceso(self):
        proceso = {
            'name': 'Proceso Sancionatorio {} - {}'.format(self.contrato_id.numero, self.id),
            'contrato_id': self.contrato_id.id,
            'proyecto_id': self.proyecto_id.id,
            'contrato_interventoria_id': self.contrato_interventoria_id.id,
            'etapa_id': self.etapa_id.id,
            'etapa_actual_id': self.etapa_actual_id.id,
            'proyecto_plan_id': self.proyecto_plan_id.id,
            'tipo_sancion': self.tipo_sancion,
        }
        if self.a_base_otro_proceso == 'si':
            proceso_fuente_datos = {
                'contrato_id': self.proceso_id.contrato_id.id,
                'contrato_interventoria_id': self.proceso_id.contrato_interventoria_id.id,
                'proyecto_id': self.proceso_id.proyecto_id.id,
                'etapa_id': self.proceso_id.etapa_id.id,
                'etapa_actual_id': self.proceso_id.etapa_actual_id.id,
                'proyecto_plan_id': self.proceso_id.proyecto_plan_id.id,
                'tipo_sancion': self.proceso_id.tipo_sancion,
                'apremio_ids': [(6, 0, self.proceso_id.apremio_ids.ids)],
                'informe_incumplimiento_ids': [(6, 0, self.proceso_id.informe_incumplimiento_ids.ids)],
                'mesas_trabajo_ids': [(6, 0, self.proceso_id.mesas_trabajo_ids.ids)],
                'audiencia_ids': [(6, 0, self.proceso_id.audiencia_ids.ids)],
                'fallo_ids': [(6, 0, self.proceso_id.audiencia_ids.ids)],
            }
            proceso.update(proceso_fuente_datos)
        proceso = self.env['sancionatorio.proceso'].sudo().create(proceso)

        # return {
        #     'type': 'ir.actions.act_window',
        #     'res_model': 'sancionatorio.proceso',
        #     'view_mode': 'form',
        #     'res_id': proceso.id,
        #     'target': 'current',
        #     'flags': {'form': {'action_buttons': True, 'options': {'mode': 'edit'}}}
        # }
        view_ids = self.env['ir.ui.view'].search([('model','=','sancionatorio.proceso'),
                                                  ('name','=','sancionatorio.proceso.form')])

        return {
                'view_type':'form',
                'view_mode':'form',
                'res_model':'sancionatorio.proceso',
                'target':'current',
                'type':'ir.actions.act_window',
                'view_id':view_ids.id,
                'res_id': proceso.id
        }

