# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp.addons.web import http
from openerp.addons.web.http import request
from openerp.addons.website.models.website import slug
from openerp.addons.website_project_idu.controllers import zipa_controller

class controller(zipa_controller):
    _breadcrumbs = None

    @http.route(['/zipa'], type='http', auth="user", website=True)
    def zipa_index(self, **kwargs):
        return request.redirect("/page/zipa")

    @http.route(['/zipa/project'], type='http', auth="user", website=True)
    def portafolio_index(self, **kwargs):
        datos = {
            'title': 'Mis Proyectos',
        }
        datos['mis_proyectos'] = request.env['project.project'].search(
            [
             ('state','in',['open','pending']),
             '|','|','|','|','|',
                ('user_id','=',request.uid),
                ('programador_id','=',request.uid),
                ('dependencia_id.manager_id.user_id','=',request.uid),
                ('dependencia_id.proyecto_gerente_id','=',request.uid),
                ('dependencia_id.proyecto_programador_id','=',request.uid),
                ('message_is_follower','=',True),
             ])

        datos['indicadores'] = get_datos_indicadores_project(datos['mis_proyectos'])
        return request.website.render(
            "website_project_idu.portafolio_index",
            self.get_datos_website(datos)
        )


class controller_project(zipa_controller):

    def __init__(self, *args, **kw):
        super(controller_project, self).__init__(*args, **kw)
        self._breadcrumbs = [
            {'url': '/zipa/project', 'label': 'Mis Proyectos'},
        ]

    @http.route(['/zipa/project/<model("project.project"):project>'], type='http', auth="user", website=True)
    def portafolio_project_index(self, project=None, **kwargs):
        datos = {
            'title': project.name,
            'project': project,
        }
        if project.project_padre_id:
            datos.update({
                'additional_title': project.name,
                'title': project.project_padre_id.name,
            })

        datos['indicadores'] = get_datos_indicadores_project(project)
        return request.website.render(
            "website_project_idu.portafolio_project_index",
            self.get_datos_website(datos)
        )

    @http.route(['/zipa/project/<model("project.project"):project>/cronograma'], type='http', auth="user", website=True)
    def portafolio_project_cronograma(self, project=None, **kwargs):
        datos = {
            'title': project.name,
            'additional_title': 'Cronograma',
            'project': project,
        }

        datos['breadcrumbs'] = [
            {'label': project.name, 'url': '/zipa/project/{}'.format(slug(project))}
        ]
        return request.website.render(
            "website_project_idu.portafolio_project_cronograma",
            self.get_datos_website(datos)
        )

    @http.route([
      '/zipa/project/<model("project.project"):project>/cronograma/dhtmlxgantt',
    ], type='json', auth="user", website=False)
    def portafolio_project_cronograma_dhtmlxgantt(self, project=None, reporte=None, **kwargs):
        """Retorna un diccionario en json con la configuración de tareas y relaciones para desplegar con dhtmlxgantt"""
        return project.get_dtmlxgantt_data()

    @http.route([
      '/zipa/backend',
    ], type='http', auth="user", website=True)
    def website_2_backend(self, **kwargs):
        """Website to Backend"""
        action_str = kwargs['action']
        actions = {
            'mis_tareas': {
               'url': '/web#page=0&limit=80&view_type=list&model=project.task&action={0}',
               'action': 'project_edt_idu.task_action',
            },
            'mis_pendientes': {
               'url': '/web#page=0&limit=80&view_type=list&model=project.task.pendiente&action={0}',
               'action': 'project_edt_idu.task_pendiente_action',
            },
            'mis_problemas': {
               'url': '/web#page=0&limit=80&view_type=list&model=project.problema&action={0}',
               'action': 'project_problemas_idu.mi_problema_action',
            },
            'mis_proyectos': {
               'url': '/web#page=0&limit=80&view_type=list&model=project.project&action={0}',
               'action': 'project_edt_idu.project_action',
            },
        }
        action = request.env.ref(actions.get(action_str).get('action'))
        return request.redirect(actions.get(action_str).get('url').format(action.id))


def get_datos_indicadores_project(projects):
    """Retorna datos para desplegar los indicadores basicos de la sección de mis proyectos"""
    indicadores = {}
    color_default = 'gray'
    color_info = 'blue'
    color_danger = 'red'
    for project in projects:
        indicadores[project.id] = []
        slug_project = slug(project)
        verify_gerentes = project.usuario_actual_actua_como_gerente()
        #
        # reportes de avance
        #
        cnt_reportes_pendientes = len(project.reporte_avance_tarea_ids.filtered(lambda r: r.state == 'borrador'))
        cnt_reportes_pendientes_mios = len(project.reporte_avance_tarea_ids.filtered(lambda r: r.state == 'borrador' and r.user_id.id == r._context.get('uid', False)))

        enlaces_registro_avance = []
        enlaces_registro_avance.append({
            'uri': '/zipa/project/{}/reporte_avance_tareas/crear'.format(slug_project),
            'etiqueta': 'Registrar avance de tareas',
            'icono': 'fa-plus-circle',
        })
        if verify_gerentes and cnt_reportes_pendientes:
            enlaces_registro_avance.append({
                'uri': '/zipa/project/{}/reporte_avance_tareas?state=borrador'.format(slug_project),
                'etiqueta': 'Registros en borrador para el proyecto ( {} )'.format(cnt_reportes_pendientes),
                'icono': 'fa-arrow-circle-right',
            })
        if cnt_reportes_pendientes_mios:
            enlaces_registro_avance.append({
                'uri': '/zipa/project/{}/reporte_avance_tareas?state=borrador&amp;user=1'.format(slug_project),
                'etiqueta': 'Mis registros en borrador ( {} )'.format(cnt_reportes_pendientes_mios),
                'icono': 'fa-arrow-circle-right',
            })

        indicadores[project.id].append({
            'color': (cnt_reportes_pendientes_mios > 0 and color_info) or color_default,
            'valor': len(project.reporte_avance_tarea_ids),
            'etiqueta': 'Registros de Avance de Tareas',
            'icono': 'ion ion-bag',
            'enlaces': enlaces_registro_avance,
        })
        #
        # Tareas
        #
        tareas_con_retraso = project.get_tareas_atrasadas(1)
        tareas_con_retraso_mias = project.get_tareas_atrasadas(0)
        enlaces_tarea = []
        enlaces_tarea.append({
            'uri': '/zipa/project/{}/cronograma'.format(slug_project),
            'etiqueta': 'Ver Cronograma',
            'icono': 'fa-arrow-circle-right',
        })
        if len(tareas_con_retraso) > 0:
            enlaces_tarea.append({
                'uri': '/zipa/project/{}#tareas_con_retraso'.format(slug_project),
                'etiqueta': 'Tareas con retraso en el proyecto ( {} ) '.format(len(tareas_con_retraso)),
                'icono': 'fa-times',
            })

        if len(tareas_con_retraso_mias) > 0:
            enlaces_tarea.append({
                'uri': '/zipa/project/{}#tareas_con_retraso'.format(slug_project),
                'etiqueta': 'Mis tareas con retraso ( {} )'.format(len(tareas_con_retraso_mias)),
                'icono': 'fa-times',
            })

        indicadores[project.id].append({
            'color': (len(tareas_con_retraso) > 0 and color_danger) or color_default,
            'valor': project.task_count,
            'etiqueta': 'Tareas',
            'icono': 'fa fa-tasks',
            'enlaces': enlaces_tarea,
        })
        #
        # Reportes de Desempeño
        #
        cnt_reportes = len(project.reporte_desempeno_manual_ids)
        cnt_reportes_pendientes = len(project.reporte_desempeno_manual_ids.filtered(lambda r: r.state == 'borrador'))
        enlaces_desempeno = []
        enlaces_desempeno.append({
            'uri': '/zipa/project/{}/analisis_desempeno_manual'.format(slug_project),
            'etiqueta': '{} {} de desempeño en total'.format(cnt_reportes, (cnt_reportes != 1 and 'reportes') or 'reporte'),
            'icono': 'fa-arrow-circle-right',
        })
        if cnt_reportes_pendientes > 0:
            enlaces_desempeno.append({
                'uri': '/zipa/project/{}/analisis_desempeno_manual?state=borrador'.format(slug_project),
                'etiqueta': '{} {} de desempeño en total'.format(cnt_reportes_pendientes, (cnt_reportes_pendientes != 1 and 'reportes') or 'reporte'),
                'icono': 'fa-arrow-circle-right',
            })

        indicadores[project.id].append({
            'color': (cnt_reportes_pendientes > 0 and color_info) or color_default,
            'valor': cnt_reportes_pendientes,
            'etiqueta': 'Reportes de Desempeño',
            'icono': 'fa fa-briefcase',
            'enlaces': enlaces_desempeno,
        })
        #
        # Problemas
        #
        cnt_problemas = len(project.problema_ids.filtered(lambda r: r.state == 'abierto'))
        cnt_problemas_mios = len(project.problema_ids.filtered(lambda r: r.state == 'abierto' and r.user_id.id == request.uid))
        enlaces_problemas = []
        enlaces_problemas.append({
            'uri': '/zipa/project/{}/gestion_problemas'.format(slug_project),
            'etiqueta': '{} {} {} para el proyecto'.format(cnt_problemas, (cnt_problemas != 1 and 'problemas') or 'problema', (cnt_problemas_mios == 1 and 'abierto') or 'abiertos'),
            'icono': 'fa-arrow-circle-right',
        })
        if cnt_problemas_mios > 0:
            enlaces_problemas.append({
                'uri': '/zipa/project/{}/gestion_problemas'.format(slug_project),
                'etiqueta': '{} {} {} a mi cargo'.format(cnt_problemas_mios, (cnt_problemas_mios != 1 and 'problemas') or 'problema', (cnt_problemas_mios == 1 and 'abierto') or 'abiertos'),
                'icono': 'fa-arrow-circle-right',
            })

        indicadores[project.id].append({
            'color': (cnt_problemas > 0 and color_danger) or color_default,
            'valor': cnt_problemas,
            'etiqueta': (cnt_problemas == 1 and 'Problema') or 'Problemas',
            'icono': 'fa fa-bell',
            'enlaces': enlaces_problemas,
        })
    return indicadores
