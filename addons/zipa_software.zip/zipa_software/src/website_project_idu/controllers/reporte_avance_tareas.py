# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp.addons.web import http
from openerp.addons.web.http import request
from openerp.addons.website.models.website import slug
from openerp.addons.website_project_idu.controllers.main import controller_project
from openerp import fields
import datetime

def get_index(headers, key):
    try:
        return headers.index(key)
    except ValueError, e:
        return None

def get_value(row, index, datatype=None):
    if index != None:
        try:
            if datatype:
                if row[index] != None:
                    return datatype(row[index])
            else:
                return row[index]
        except ValueError:
            return None


class controller(controller_project):

    @http.route([
      '/zipa/project/<model("project.project"):project>/reporte_avance_tareas',
      '/zipa/reporte_avance_tareas',
    ], type='http', auth="user", website=True)
    def reporte_avance_tareas_index(self, project=None, **kwargs):
        res = {
            'title': 'Registros de Avance de Tareas',
            'project': project,
        }
        reporte_model = request.env['project.task.reporte_avance']
        user = kwargs.get('user', False)
        dominio = []
        if user:
            dominio.append(('user_id', '=', request.uid))
        if project:
            dominio.append(('project_id', '=', project.id))
        state = kwargs.get('state', False)
        if state:
            dominio.append(('state', '=', state))
        res['reporte_avance_tareas_listado'] = reporte_model.search(dominio)

        return request.website.render(
            "website_project_idu.reporte_avance_tareas_index",
            res
        )

    @http.route([
      '/zipa/project/<model("project.project"):project>/reporte_avance_tareas/crear',
      '/zipa/project/<model("project.project"):project>/reporte_avance_tareas/<model("project.task.reporte_avance"):reporte>',
    ], type='http', auth="user", website=True)
    def reporte_avance_tareas_crear(self, project=None, reporte=None, **kwargs):
        res = {
            'title': project.name,
            'additional_title': 'Registro de Avance de Tareas',
            'project': project,
            'reporte': reporte,
            'fecha_reporte': datetime.date.today().strftime('%d, %b %Y')
        }
        res['breadcrumbs'] = [
            {'label': project.name, 'url': '/zipa/project/{}'.format(slug(project))}
        ]
        reporte_avance_model = request.env['project.task.reporte_avance']
        res['mis_tareas'] = request.env['project.task'].search(reporte_avance_model.dominio_tareas_a_reportar(project.id, request.uid))
        return request.website.render(
            "website_project_idu.reporte_avance_tareas_show",
            self.get_datos_website(res),
        )

    def _construir_cabecera_handsontable(self, project):
        headers = ['ID', 'No', 'Nombre', 'Fecha de Inicio', 'Fecha Final', 'Terminado']
        col_properties = [{'width': '1px'},
                          {'readOnly': True},
                          {'readOnly': True, 'width': '400px'},
                          {'type': 'date', 'width': '100px', 'dateFormat': 'YYYY-MM-DD'},
                          {'type': 'date', 'width': '100px', 'dateFormat': 'YYYY-MM-DD'},
                          {'type': 'checkbox', 'width': '100px'},]
        if project.reportar_costo:
            headers.extend(['Costo Planeado', 'Costo'])
            col_properties.extend([{'readOnly': True}, {'type': 'numeric', 'format': '$ 0,0.00'}])
        headers.extend(['% Avance'])
        col_properties.extend([{'type': 'numeric'}])

        if project.reportar_cantidad:
            headers.extend(['Cantidad', 'Unidad'])
            col_properties.extend([{'type': 'numeric'}, {'readOnly': True}])
        headers.extend(['Descripción del avance', 'Novedad', 'Nivel de Alerta'])
        col_properties.extend([
                        {'type': 'text', 'width': '200px'},
                        {'type': 'text', 'width': '200px'},
                        {'type': 'dropdown', 'strict': True,
                         'source': ['ninguno', 'bajo', 'medio', 'alto']},
                        ])
        return headers, col_properties

    @http.route([
      '/zipa/project/<model("project.project"):project>/reporte_avance_tareas/crear/handsontable',
      '/zipa/project/<model("project.project"):project>/reporte_avance_tareas/<model("project.task.reporte_avance"):reporte>/handsontable',
    ], type='json', auth="user", website=False)
    def reporte_avance_tareas_data(self, project=None, reporte=None, **kwargs):
        """Retorna un diccionario en json con la configuración para desplegar una table con handsontable"""
        reporte_avance_model = request.env['project.task.reporte_avance']
        data = []
        readonly = False
        if reporte or kwargs.get('res_id', False):
            if not reporte and kwargs.get('res_id', False):
                reporte = reporte_avance_model.search([
                    ('project_id', '=', project.id),
                    ('id','=', int(kwargs.get('res_id'))),
                ])
            data = self._get_tabla_desde_progresos(project, reporte)
            if reporte.state != 'borrador':
                readonly = True
        else:
            tasks = request.env['project.task'].search(reporte_avance_model.dominio_tareas_a_reportar(project.id, request.uid),offset=0, order='numero')
            data = self._get_tabla_desde_tareas(project, tasks)

        headers, col_properties = self._construir_cabecera_handsontable(project)
        res = {
            'readOnly': readonly,
            'data': data,
            'minSpareRows': 1,
            'fixedColumnsLeft': 3,
            'contextMenu': False,
            'mergeCells': [],
            'colHeaders': headers,
            'columns': col_properties,
            'allowInsertRow': False,
            'allowInsertColumn': False,
            'allowInvalid': False,
            'ManualColumnFreeze': True,
            'ManualColumnResize': True,
            'nativeScrollbars': True,
            'height': 500,
            'currentRowClassName': 'hs_current_row',
            'currentColClassName': 'hs_current_col',
        }
        return res

    def _get_tabla_desde_tareas(self, project, tasks):
        """Crea las filas de la tabla a partir de tareas del proyecto"""
        data = []
        edt_incluidas = []

        for t in tasks:
            self._adicionar_arbol_edt_en_tabla(t.edt_id, data, edt_incluidas, t.project_id)
            #['ID', 'No', 'Nombre']
            row = [t.id, t.numero, t.name, t.fecha_inicio, t.fecha_fin, not not t.date_end]
            if project.reportar_costo:
                #['Costo Planeado', 'Costo']
                row.extend([t.costo_planeado, 0])
            #'% Avance'
            row.extend([t.progreso])

            if project.reportar_cantidad:
                #['Cantidad', 'Unidad']
                row.extend([0, t.product_id.uom_id.name])
            #['Descripción del avance', 'Novedad', 'Nivel de Alerta']
            row.extend(['', '', 'ninguno'])
            data.append(row)
        return data

    def _adicionar_arbol_edt_en_tabla(self, edt, data, edt_incluidas, project):
        """Adiciona en `data` los datos de la EDT y sus padres. Se guarda en edt_incluidas
        el listado de EDT ya incluidas en data
        """
        if not edt:
            return
        try:
            edt_incluidas.index(edt.numero)
        except ValueError:
            if edt.parent_id:
                self._adicionar_arbol_edt_en_tabla(edt.parent_id, data, edt_incluidas, project)
            row = [None, edt.numero, edt.name] # Las filas relacionadas a EDTs no se indica el ID
            data.append(row)
            edt_incluidas.append(edt.numero)



    def _get_tabla_desde_progresos(self, project, reporte):
        """Crea las filas de la tabla a partir los datos de los registros existentes en el reporte"""
        data = []
        edt_incluidas = []

        request.env.cr.execute("""SELECT
                                        r.id FROM project_task_registro_progreso r
                                    LEFT JOIN
                                        project_task t ON t.id = r.task_id
                                    WHERE
                                        r.reporte_avance_id = %s
                                    ORDER BY
                                        t.numero ASC;
                                """, (reporte.id,))
        registro_ids = request.env.cr.fetchall()
        registro_ids = [ i[0] for i in registro_ids]
        for a in request.env['project.task.registro_progreso'].browse(registro_ids):
            t = a.task_id
            self._adicionar_arbol_edt_en_tabla(t.edt_id, data, edt_incluidas, t.project_id)
            #['ID', 'No', 'Nombre']
            row = [t.id, t.numero, t.name, t.fecha_inicio, t.fecha_fin, not not t.date_end]
            if project.reportar_costo:
                #['Costo Planeado', 'Costo']
                row.extend([t.costo_planeado, a.costo])
            #'% Avance'
            row.extend([a.porcentaje])

            if project.reportar_cantidad:
                #['Cantidad', 'Unidad']
                row.extend([a.cantidad, t.product_id.uom_id.name])
            #['Descripción del avance', 'Novedad', 'Nivel de Alerta']
            row.extend([a.name, a.novedad, a.nivel_alerta])
            data.append(row)
        return data

    @http.route([
        '/zipa/project/<model("project.project"):project>/reporte_avance_tareas/crear/handsontable/guardar',
        '/zipa/project/<model("project.project"):project>/reporte_avance_tareas/<model("project.task.reporte_avance"):reporte>/handsontable/guardar',
    ], type='json', auth="user", website=False)
    def reporte_avance_tareas_data_post(self, project=None, reporte=None, **kwargs):
        """Retorna un diccionario en json indicando el estado de la transacción"""

        reporte_avance_model = request.env['project.task.reporte_avance']
        task_model = request.env['project.task']
        progreso_model = request.env['project.task.registro_progreso']
        headers, col_properties = self._construir_cabecera_handsontable(project)
        params = kwargs.get('params', {})
        data = kwargs.get('data', [])
        res = {
            'status': 'ok',
            'message': False,
            'res_id': params.get('res_id', False),
            'res_model': 'project.task.reporte_avance',
        }
        if not reporte and params.get('res_id', False):
            reporte = reporte_avance_model.search([
                ('project_id', '=', project.id),
                ('user_id', '=', request.uid),
                ('id','=', int(params.get('res_id'))),
            ])
        elif not reporte:
            reporte = reporte_avance_model.create({
                'project_id': project.id,
                'user_id': request.uid,
            })
            res['res_id'] = reporte.id

        if not reporte.state in ['borrador', 'devuelto']:
            res['status'] = 'error'
            res['message'] = 'El reporte se encuentra en estado {0} por lo tanto lo avances reportados no pueden ser modificados'.format(reporte.state)
            return res

        index_name = get_index(headers, 'Descripción del avance')
        index_task_id = get_index(headers, 'ID')
        index_porcentaje = get_index(headers, '% Avance')
        index_cantidad = get_index(headers, 'Cantidad')
        index_costo = get_index(headers, 'Costo')
        index_nivel_alerta = get_index(headers, 'Nivel de Alerta')
        index_novedad = get_index(headers, 'Novedad')
        index_fecha_inicio = get_index(headers, 'Fecha de Inicio')
        index_fecha_fin = get_index(headers, 'Fecha Final')
        index_terminado = get_index(headers, 'Terminado')
        default_name = 'Avance sin descripción reportado el {0}'.format(datetime.date.today().strftime('%d, %b %Y'))
        hoy = fields.Date.today()
        for row in data:
            task_id = get_value(row, index_task_id, int)
            if task_id == None:
                continue
            progreso = progreso_model.search([
                ('reporte_avance_id', '=', reporte.id),
                ('task_id', '=', task_id),
            ])
            if progreso:
                try:
                    progreso.write({
                        'name': get_value(row, index_name) or default_name,
                        'porcentaje': get_value(row, index_porcentaje, int),
                        'costo': get_value(row, index_costo, float),
                        'cantidad': get_value(row, index_cantidad, float),
                        'nivel_alerta': get_value(row, index_nivel_alerta),
                        'novedad': get_value(row, index_novedad),
                        'fecha_inicio': get_value(row, index_fecha_inicio),
                        'fecha_fin': get_value(row, index_fecha_fin),
                        'terminado': get_value(row, index_terminado),
                    })
                except Exception as e:
                    res['status'] = 'error'
                    res['message'] = 'Tarea {0} falló con el siguiente error: {1}'.format(progreso.task_id.numero, e)
                    break
            else:
                res['status'] = 'error'
                res['message'] = 'Tarea {0} no pertenece al proyecto {1}'.format(task_id, project.name)
                break
        if res['status'] == 'ok' and params.get('terminar', False):
            reporte.signal_workflow('wkf_borrador__por_revisar')
        return res