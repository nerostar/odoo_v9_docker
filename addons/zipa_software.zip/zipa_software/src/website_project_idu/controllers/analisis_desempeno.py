# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp.addons.web import http
from openerp.addons.web.http import request
from openerp.addons.website.models.website import slug
import datetime


class controller(http.Controller):

    @http.route([
        '/zipa/project/<model("project.project"):project>/analisis_desempeno',
        '/zipa/analisis_desempeno',
    ], type='http', auth="user", website=True)
    def analisis_desempeno_index(self, project=None, **kwargs):
        res = {
            'title': 'Reportes de Análisis de Desempeño',
            'project': project,
        }
        reporte_model = request.env['project.reporte_desempeno']
        dominio = [
            ('create_uid', '=', request.uid),
        ]
        if project:
            dominio = [
                ('project_id', '=', project.id),
            ]
        state = kwargs.get('state', False)
        if state:
            dominio.append(('state', '=', state))
        res['reporte_desempeno_listado'] = reporte_model.search(dominio)

        return request.website.render(
            "website_project_idu.analisis_desempeno_index",
            res
        )

    @http.route([
          '/zipa/project/<model("project.project"):project>/analisis_desempeno/<model("project.reporte_desempeno"):reporte>'
        ],
        type='http', auth="user", website=True, methods=['GET'],
    )
    def analisis_desempeno_show(self, project, reporte, **kwargs):
        res = {
            'title': reporte.name,
            'project': project,
            'reporte': reporte,
            'editable': reporte.state in ['borrador', 'devuelto'],
        }
        return request.website.render(
            "website_project_idu.analisis_desempeno_show",
            res
        )

    @http.route([
          '/zipa/project/<model("project.project"):project>/analisis_desempeno/<model("project.reporte_desempeno"):reporte>'
        ],
        type='http', auth="user", website=True, methods=['POST'],
    )
    def analisis_desempeno_guardar(self, project, reporte, **kwargs):
        res = {
            'title': reporte.name,
            'project': project,
            'reporte': reporte,
            'editable': reporte.state in ['borrador', 'devuelto'],
        }
        vals = {}
        for field in ['analisis', 'causa_raiz', 'plan_contingencia']:
            if field in kwargs and kwargs[field]:
                vals[field] = kwargs[field].strip()

        if not res['editable']:
            msg = 'El reporte se encuentra en estado {0} por lo tanto lo avances reportados no pueden ser modificados'.format(reporte.state)
            raise Exception(msg)
        reporte.write(vals)
        if 'guardar_terminar' in kwargs:
            reporte.signal_workflow('wkf_borrador__por_revisar')
            return request.redirect("/zipa/project")
        return request.website.render(
            "website_project_idu.analisis_desempeno_show",
            res
        )

    @http.route([
          '/zipa/project/<model("project.project"):project>/analisis_desempeno/<model("project.reporte_desempeno"):reporte>/dhtmlxgantt'
        ],
        type='json', auth="user", website=True,
    )
    def analisis_desempeno_show_dhtmlxgantt(self, project, reporte, **kwargs):
        """Retorna un diccionario en json con la configuración de tareas y relaciones para desplegar con dhtmlxgantt"""
        return reporte.get_dtmlxgantt_data()

    @http.route(['/zipa/project/<model("project.project"):project>/analisis_desempeno/crear'], type='http', auth="user", website=True, methods=["GET"])
    def analisis_desempeno_crear(self, project=None, **kwargs):
        res = {
            'title': 'Crear Reporte de Análisis de Desempeño',
            'project': project,
            'fecha_reporte': datetime.date.today().strftime('%d, %b %Y')
        }
        return request.website.render(
            "website_project_idu.analisis_desempeno_crear",
            res
        )

    @http.route(['/zipa/project/<model("project.project"):project>/analisis_desempeno/crear/dhtmlxgantt'], type='json', auth="user", website=True)
    def analisis_desempeno_crear_dhtmlxgantt(self, project=None, **kwargs):
        """Retorna un diccionario en json con la configuración de tareas y relaciones para desplegar con dhtmlxgantt"""
        return project.get_dtmlxgantt_data()

    @http.route([
          '/zipa/project/<model("project.project"):project>/analisis_desempeno/crear',
        ],
        type='http', auth="user", website=True, methods=["POST"]
    )
    def analisis_desempeno_crear_post(self, project=None, **kwargs):
        reporte_model = request.env['project.reporte_desempeno']
        name = 'Reporte Desempeño al {0}'.format(datetime.date.today().strftime('%d, %b %Y'))
        snapshot = project.crear_snapshot(name)
        vals = {
            'name': name,
            'project_id': project.id,
            'linea_base_id': project.linea_base_id.id,
            'linea_base_reporte_id': snapshot.id,
        }
        reporte = reporte_model.create(vals)
        return request.redirect("/zipa/project/{0}/analisis_desempeno/{1}".format(slug(project), slug(reporte)))
