# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp.addons.web import http
from openerp.addons.web.http import request
from openerp.addons.website.models.website import slug
import datetime


class controller(http.Controller):

    @http.route([
        '/zipa/project/<model("project.project"):project>/analisis_desempeno_manual',
        '/zipa/analisis_desempeno_manual',
    ], type='http', auth="user", website=True)
    def analisis_desempeno_index(self, project=None, **kwargs):
        res = {
            'title': 'Reportes de Análisis de Desempeño',
            'project': project,
        }
        reporte_model = request.env['project_obra.reporte_desempeno_manual']
        dominio = [
            ('create_uid', '=', request.uid),
        ]
        if project:
            dominio = [
                ('project_id', '=', project.id),
            ]
        state = kwargs.get('state', False)
        if state:
            dominio.append(('state', '=', state))
        print dominio
        res['reporte_desempeno_listado'] = reporte_model.search(dominio)

        return request.website.render(
            "website_project_idu.analisis_desempeno_manual_index",
            res
        )

    @http.route([
          '/zipa/project/<model("project.project"):project>/analisis_desempeno_manual/<model("project_obra.reporte_desempeno_manual"):reporte>'
        ],
        type='http', auth="user", website=True, methods=['GET'],
    )
    def analisis_desempeno_show(self, project, reporte, **kwargs):
        res = {
            'title': reporte.name,
            'project': project,
            'reporte': reporte,
            'editable': reporte.state in ['borrador', 'devuelto'],
        }
        return request.website.render(
            "website_project_idu.analisis_desempeno_manual_show",
            res
        )
