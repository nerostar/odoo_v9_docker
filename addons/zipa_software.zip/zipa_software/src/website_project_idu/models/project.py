# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, api

class project_dhtmlxgantt_mixin(models.AbstractModel):
    _name = 'project.dhtmlxgantt.mixin'
    _description = 'Mixin para generar dhtmlx'

    _dhtmlxgantt_prefijo = '' # Prefijo a utilizarse en la creación del ID
    _dhtmlxgantt_campos_map = {} # Campos para ser mapeados a dhtmlxgantt
    _dhtmlxgantt_descendientes_map = {} # Campos one2many or many2many a ser mapeados

    @api.model
    def _dhtmlxgantt_get_tipo(self, record):
        """Función para cálcular el tipo: milestone, project, task"""
        return 'task'

    @api.multi
    def get_dtmlxgantt_data(self, nivel_profundidad=None):
        """Nivel de profundidad es el nível máximo a incluir"""
        data = {
            'data': [],
            'links': [],
        }
        for record in self:
            record._get_dtmlxgantt_data(data, nivel_profundidad, 0)
        return data

    @api.multi
    def _get_dtmlxgantt_data(self, res, nivel_maximo, nivel_actual, parent_id=None):
        data = self.sudo().read(self._dhtmlxgantt_campos_map.values() + self._dhtmlxgantt_descendientes_map.values())
        nivel_actual += 1
        for record in data:
            record_id = '{0}_{1}'.format(self._dhtmlxgantt_prefijo, record['id'])
            vals = {
                'id': record_id,
                'type': self._dhtmlxgantt_get_tipo(record),
                'open': True,
            }
            if parent_id:
                vals['parent'] = parent_id
            for field, obj_field in self._dhtmlxgantt_campos_map.items():
                if isinstance(record[obj_field], tuple):
                    vals[field] = record[obj_field][0] #set ID
                    if obj_field == "user_id":
                        vals[field] = record[obj_field][1] #set Name
                else:
                    vals[field] = record[obj_field]
            if vals.get('progress',False):
                vals['progress'] = round(float(vals['progress'])/100,2)
            if vals.get('tardiness',False):
                vals['tardiness'] = round(float(vals['tardiness'])/100,2)
            res['data'].append(vals)
            if nivel_maximo and nivel_maximo <= nivel_actual:
                continue
            for child_model, child_field in self._dhtmlxgantt_descendientes_map.items():
                child_model = self.env[child_model]
                if child_field in record:
                    child_ids = record[child_field]
                    child_model.browse(child_ids)._get_dtmlxgantt_data(res, nivel_maximo, nivel_actual, record_id)


class project_project(models.Model):
    _name = 'project.project'
    _inherit = ['project.project']

    @api.multi
    def get_dtmlxgantt_data(self, nivel_profundidad=None):
        """Retorna la estructura para desplegar la EDT y tareas en el formato requerido por dhmtlxgantt
        nivel_profundidad=Indica el nivel de profundidad a incluir
        """
        res = self.edt_raiz_id.get_dtmlxgantt_data(nivel_profundidad)
        return res


class project_edt(models.Model):
    _name = 'project.edt'
    _inherit = ['project.edt', 'project.dhtmlxgantt.mixin']

    _dhtmlxgantt_prefijo = 'E' # Prefijo a utilizarse en la creación del ID
    _dhtmlxgantt_campos_map = {
        'text': 'name',
        'progress': 'progreso',
        'start_date': 'fecha_inicio',
        'end_date': 'fecha_fin',
        'planned_start': 'fecha_planeada_inicio',
        'planned_end': 'fecha_planeada_fin',
        'tardiness': 'retraso',
        'responsible': 'user_id',
    }
    _dhtmlxgantt_descendientes_map = {
        'project.edt': 'child_ids',
        'project.task': 'task_ids',
    }

    @api.model
    def _dhtmlxgantt_get_tipo(self, record):
        """Función para cálcular el tipo: milestone, project, task"""
        return 'project'


class project_task(models.Model):
    _name = 'project.task'
    _inherit = ['project.task', 'project.dhtmlxgantt.mixin']

    _dhtmlxgantt_prefijo = 'T' # Prefijo a utilizarse en la creación del ID
    _dhtmlxgantt_campos_map = {
        'text': 'name',
        'progress': 'progreso',
        'duracion_planeada_dias': 'duracion_planeada_dias',# El que busca dhtmlxgantt es duration, este campo lo tomamos solo para saber si es un milestone o no
        'start_date': 'fecha_inicio',
        'end_date': 'fecha_fin',
        'planned_start': 'fecha_planeada_inicio',
        'planned_end': 'fecha_planeada_fin',
        'tardiness': 'retraso',
        'responsible': 'user_id',
    }
    _dhtmlxgantt_descendientes_map = {
    }

    @api.model
    def _dhtmlxgantt_get_tipo(self, record):
        """Función para cálcular el tipo: milestone, project, task"""
        if record['duracion_planeada_dias'] == 0:
            return 'milestone'
        return 'task'


class project_reporte_desempeno(models.Model):
    _name = 'project.reporte_desempeno'
    _inherit = 'project.reporte_desempeno'

    @api.multi
    def get_dtmlxgantt_data(self, nivel_profundidad=None):
        res = self.linea_base_reporte_id.linea_raiz_id.get_dtmlxgantt_data(nivel_profundidad)
        return res


class project_linea_base_linea(models.Model):
    _name = 'project.linea_base.linea'
    _inherit = ['project.linea_base.linea','project.dhtmlxgantt.mixin']

    _dhtmlxgantt_prefijo = 'L' # Prefijo a utilizarse en la creación del ID
    _dhtmlxgantt_campos_map = {
        'text': 'name',
        'progress': 'progreso',
        'start_date': 'fecha_inicio',
        'end_date': 'fecha_fin',
        'costo': 'costo',
    }
    _dhtmlxgantt_descendientes_map = {
        'project.linea_base.linea': 'child_ids',
    }
