{
    'name': 'Website Proyectos IDU',
    'version': '1.0',
    'depends': [
        'base',
        'website',
        'website_base_idu',
        'website_handsontable',
        'website_dhtmlxgantt',
        'project_edt_idu',
        'project_portafolio_idu',
        'project_obra_portafolio_idu',
        'project_problemas_idu',
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
        'views/main_templates.xml',
        'views/project_view.xml',
        'views/reporte_avance_tareas_templates.xml',
        'views/analisis_desempeno_templates.xml',
        'views/analisis_desempeno_manual_templates.xml',
        'views/gestion_problemas_templates.xml',
        'views/landing_page_templates.xml',
    ],
    'installable': True,
    'description': """
Sitio Web para la gestión de proyectos del IDU
    """,
}

