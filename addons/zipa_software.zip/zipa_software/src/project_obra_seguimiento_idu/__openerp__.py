{
    'name': 'ZIPA: Seguimiento a Obra',
    'version': '1.0',
    'depends': [
        'base',
        'model_security',
        'project_obra_portafolio_idu',
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
        'wizards/asignar_coordinador_contratos_wizard_view.xml',
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/project_obra_view.xml',
        'views/photo_gallery_view.xml',
        'wizards/crear_informe_view.xml',
        'data/project_obra_seguimiento_idu_data.xml',
        'data/tareas_programadas_data.xml',
        'views/contrato_view.xml',
    ],
    'test': [
    ],
    'demo': [
    ],
    'installable': True,
    'description': """
## Dependencias módulos Python
## Configuración adicional
    """,
}
