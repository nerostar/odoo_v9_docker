# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api
from openerp.exceptions import ValidationError, Warning
import datetime as DT
import logging
_logger = logging.getLogger(__name__)


class project_obra_seguimiento_wizard_informe(models.TransientModel):
    _name = 'project_obra.seguimiento.wizard.crear_informe'
    _description = 'Wizard para Crear Informe'

    def ultima_semana(self):
        hoy = DT.date.today()
        ultima_semana = hoy - DT.timedelta(days=6)
        return ultima_semana.strftime('%Y-%m-%d')

    # -------------------
    # Fields
    # -------------------
    user_id = fields.Many2one(
        string='Autor',
        required=True,
        track_visibility='onchange',
        comodel_name='res.users',
        ondelete='restrict',
        readonly=True,
        default=lambda self: self._context.get('uid', self.env['res.users'].browse()),
    )
    periodo_fecha_inicio = fields.Date(
        string='Desde',
        required=True,
        track_visibility='onchange',
        help='''Fecha de Inicio del periodo a reportarse''',
        default=ultima_semana,
    )
    periodo_fecha_fin = fields.Date(
        string='Hasta',
        required=True,
        track_visibility='onchange',
        help='''Fecha de finalización del periodo a reportarse''',
        default=fields.Date.today,
    )
    semana = fields.Integer(
        string='Semana No',
        required=True,
        track_visibility='onchange',
    )
    show_etapa_tipo_id = fields.Boolean(
        compute='_compute_show_etapa_tipo_id',
        default=False,
    )
    etapa_tipo_id = fields.Many2one(
        string='Etapa a Reportar',
        required=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.etapa.tipo',
        ondelete='restrict',
        domain="[('es_visible_website','=',True)]",
    )
    contrato_id = fields.Many2one(
        string='Contrato',
        required=True,
        track_visibility='onchange',
        comodel_name='contrato.contrato',
        ondelete='restrict',
        domain="[('contrato_id','=',False)]",
    )
    contrato_interventoria_id = fields.Many2one(
        string='Contrato de Interventoría',
        required=True,
        track_visibility='onchange',
        comodel_name='contrato.contrato',
        ondelete='restrict',
        domain="[('id','!=',contrato_id), ('siac_tipo_contrato_id.es_interventoria','=',True)]",
    )

    # -------------------
    # methods
    # -------------------

    @api.onchange('contrato_id')
    def _onchange_contrato_id(self):
        if len(self.contrato_id.interventoria_ids):
            return {
                'domain': {
                'contrato_interventoria_id': [('id', '=', self.contrato_id.interventoria_ids[0].id)],
                }
            }
        else:
            contrato_no_aplica_id = self.env['contrato.contrato'].search([
                ('numero', 'like', '%NO APLICA%')
            ])        
            return {
                'domain': {
                'contrato_interventoria_id': [('id', '=', contrato_no_aplica_id.id)],
                }
            }        

    @api.one
    def _check_fechas(self):
        if(self.periodo_fecha_inicio and self.periodo_fecha_fin and
           self.periodo_fecha_inicio > self.periodo_fecha_fin
            ):
            raise ValidationError("Fecha de inicio {} no puede ser posterior a la de finalización {}".format(
                self.periodo_fecha_inicio, self.periodo_fecha_fin)
            )

    @api.one
    @api.constrains('periodo_fecha_inicio')
    def _check_periodo_fecha_inicio(self):
        self._check_fechas()

    @api.one
    @api.constrains('periodo_fecha_fin')
    def _check_periodo_fecha_fin(self):
        self._check_fechas()

    @api.onchange('periodo_fecha_inicio')
    def _onchange_periodo_fecha_inicio(self):
        try:
            self._check_periodo_fecha_inicio()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.onchange('periodo_fecha_fin')
    def _onchange_periodo_fecha_fin(self):
        try:
            self._check_periodo_fecha_fin()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.onchange('user_id')
    def _onchange_user_id(self):
        contrato_ids = self.env['contrato.coordinador_contrato'].search([
            ('user_id', '=', self.env.uid),
            ('tipo', 'in', ['tecnico', 'apoyo']),
        ]).mapped('contrato_id.id')
        return {
            'domain': {
                'contrato_id': [('id', 'in', contrato_ids), ('contrato_id', '=', False)],
                # 'contrato_interventoria_id': [('id', 'in', contrato_ids)],
            }
        }

    @api.one
    @api.depends('contrato_id')
    def _compute_show_etapa_tipo_id(self):
        # HACK para permitir que estos contratos puedan crear informe para dos etapas diferentes
        # Esta es la excepción, si se vuelve regla hay que modificar este código para que sea basado
        # en configuración y no quemado en el código.
        contratos_con_doble_etapa = [
            'IDU-135-2007',
            'IDU-136-2007',
            'IDU-138-2007',
            'IDU-1371-2017',
        ]
        if self.contrato_id.numero in contratos_con_doble_etapa:
            self.show_etapa_tipo_id = True
        else:
            self.show_etapa_tipo_id = False

    @api.multi
    def crear_informe(self):
        self.ensure_one()
        dependencia_name = self.contrato_id.dependencia_id.abreviatura
        metodo_name = "informe_para_{}".format(dependencia_name)
        metodo = getattr(self, metodo_name)
        return metodo()

    def crear_cabecera_e_informe_por_contrato(self):
        # etapa_id = # Lo obtiene a partir del numero de contrato
        self.env.cr.execute("""
            SELECT e.id, e.proyecto_id, p.state, e.tipo_id
            FROM contrato_contrato c
            LEFT JOIN contrato_contrato_project_project_rel cp ON cp.contrato_contrato_id = c.id
            LEFT JOIN project_obra_proyecto_etapa e ON e.project_id = cp.project_project_id
            LEFT JOIN project_project p ON p.id = e.project_id
            LEFT JOIN account_analytic_account a ON a.id = p.analytic_account_id
            WHERE c.id = {0} AND e.state = 'open' and e.active = 't' AND e.parent_id IS NULL
            GROUP BY e.id, e.proyecto_id, p.state
            ORDER BY p.state DESC
            """.format(self.contrato_id.id) # el order by pone primero los pending
        )
        etapa_por_contrato = self.env.cr.fetchall()
        if not len(etapa_por_contrato):
            raise Warning('El contrato {} no esta asociado a ninguna etapa de proyecto'.format(self.contrato_id.numero))
        etapa = etapa_por_contrato[0]
        if len(etapa_por_contrato) > 1:
            _logger.warning('El contrato {} tiene más de una etapa asociada: {}'.format(self.contrato_id.numero, etapa_por_contrato))
            for e in etapa_por_contrato:  # HACK relacionado con _compute_show_etapa_tipo_id
                if e[3] == self.etapa_tipo_id.id:    #e[3] tipo_id
                    etapa = e
                    break

        data_cabecera = {
            'user_id': self.user_id.id,
            'fecha': self.periodo_fecha_fin,
            'periodo_fecha_inicio': self.periodo_fecha_inicio,
            'periodo_fecha_fin': self.periodo_fecha_fin,
            'semana': self.semana,
            'proyecto_id': etapa[1],
            'etapa_actual_id': etapa[0],
        }
        cabecera = self.env['project_obra.informe_cabecera'].create(data_cabecera)
        data_contrato = {
            'cabecera_id': cabecera.id,
            'contrato_id': self.contrato_id.id,
            'contrato_estado': self.contrato_id.estado_siac_id.name,
            'contrato_nombre': '{} ({}) - {}'.format(self.contrato_id.numero,self.contrato_id.siac_tipo_contrato_id.name,self.contrato_id.estado_siac_id.name),
            'contrato_interventoria_id': self.contrato_interventoria_id.id,
            'contrato_interventoria_nombre': '{} ({}) - {}'.format(self.contrato_interventoria_id.numero,self.contrato_interventoria_id.siac_tipo_contrato_id.name,self.contrato_interventoria_id.estado_siac_id.name),
            'contrato_interventoria_estado': self.contrato_interventoria_id.estado_siac_id.name,
        }
        por_contrato = self.env['project_obra.informe_por_contrato'].create(data_contrato)
        return (cabecera, por_contrato)

