# -*- coding: utf-8 -*-
from openerp import models, fields, api


class contrato(models.Model):
    '''
    Se sobre escribe el modelo contrato.coordinador_contrato para agregarle el revisor al tipo de coordinador.
    '''
    _name = 'contrato.coordinador_contrato'
    _inherit = 'contrato.coordinador_contrato'

    tipo = fields.Selection(
        selection_add=[
            ('revisor', 'Revisor'),
        ],
    )




class contrato_contrato(models.Model):
    '''
    Se sobre escribe el modelo contrato.contrato para agregarle el campo de tiempo_notificacion.
    '''
    _name = 'contrato.contrato'
    _inherit = 'contrato.contrato'


    tiempo_notificacion = fields.Integer(
        string='Tiempo Notificación',
        default=9,
    )
    url_imagen = fields.Char(
        string='url_imagen',
    )



    ##############################
    # Metodos
    ##############################

    @api.one
    def actualizar_url_imagen_informe_construccion(self):
        informe_construc_model = self.env['project_obra.construccion.informe_avance']
        informes_construccion = informe_construc_model.search([('contrato_id','=',self.id)])    # ,('photo_ids','!=','')
        cabeceras_ids = informes_construccion.mapped('cabecera_id').ids
        fotos = self.env['photo_gallery.photo'].search([('proyecto_obra_informe_cabecera_id','in',cabeceras_ids),('photo','!=','')])
        if fotos:
            f_id = fotos[-1].id
            url_imagen = '/web/image/photo_gallery.photo/{}/photo/323x242'.format(f_id)
            self.url_imagen = url_imagen
            return url_imagen
        # informe_con_foto = ''
        # f_id = ''
        # if informes_construccion:
        #     informe_con_foto = informes_construccion[0]
        #     for f in informe_con_foto.photo_ids:
        #         if f.photo:
        #             f_id = f.id
        #             url_imagen = '/web/image/photo_gallery.photo/{}/photo/323x242'.format(f_id)
        #             self.url_imagen = url_imagen
        #             return url_imagen
        return False


    @api.one
    def actualizar_url_imagen_informe_conservacion(self):
        informe_conserva_model = self.env['project_obra.conservacion.informe_avance']
        informes_conservacion = informe_conserva_model.search([('contrato_id','=',self.id),('avance_por_frente_ids','!=','')])
        f_id = ''
        # informes_con_foto = informes_conservacion.filtered(lambda informe: informe.id in [av.informe_id.id for av in informe.avance_por_frente_ids if av.photo_ids != ''])

        for informe in informes_conservacion:
            for avance in informe.avance_por_frente_ids:
                for foto in avance.photo_ids:
                    if foto.photo:
                        f_id = foto.id
                        url_imagen = '/web/image/photo_gallery.photo/{}/photo/323x242'.format(f_id)
                        self.url_imagen = url_imagen
                        return url_imagen
        return False
