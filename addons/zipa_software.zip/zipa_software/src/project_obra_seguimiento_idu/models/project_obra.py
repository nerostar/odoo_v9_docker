# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from base64 import b64encode
from datetime import datetime, timedelta, date
from openerp import models, fields, api
from openerp.addons.project_problemas_idu.models.project import PROBLEMA_ESTADOS, PROBLEMA_ESTADOS_LABELS
from openerp.exceptions import ValidationError, Warning
import logging
import xlsxwriter
from lxml import etree



APROBACION_INTERVENTORIA_OPCIONES = [
    ('aprobado', 'Aprobado'),
    ('no_aprobado', 'No Aprobado'),
    ('no_aplica','No Aplica')]
APROBACION_INTERVENTORIA_LABELS = dict(APROBACION_INTERVENTORIA_OPCIONES)
NO_OBJECION_IDU_OPCIONES = [
    ('objetado', 'Objetado'),
    ('no_objetado', 'No Objetado'),
    ('no_aplica','No Aplica')]
NO_OBJECION_IDU_LABELS = dict(NO_OBJECION_IDU_OPCIONES)

_logger = logging.getLogger(__name__)

# Se necesita: import xlsxwriter, por lo cual: sudo pip install XlsxWriter
def crear_archivo_excel(titulo='', ruta_archivo='/tmp', nombre_archivo='archivo.xlsx', datos=[[]]):
    # Creo el archivo
    try:
        archivo = xlsxwriter.Workbook('{}/{}'.format(ruta_archivo, nombre_archivo))
        hoja_calculo = archivo.add_worksheet()
        # Formatos que se pueden aplicar: http://xlsxwriter.readthedocs.io/format.html
        formato_titulo = archivo.add_format({ 'bold':True, 'font_size':14, 'font_color':'black', 'align': 'center', 'valign': 'vcenter', 'text_justlast':True, 'text_wrap':True })
        formato_cuerpo = archivo.add_format({ 'align': 'center', 'valign': 'vcenter', 'text_wrap':True })
        formato_largo = archivo.add_format({ 'align': 'center', 'text_wrap':True, 'align': 'center', 'valign': 'vcenter', 'text_justlast':True, })

        cabecera = '&LPágina &P de &N' + '&C IDU'
        pie_pagina = '&LFecha Actual: &D' + '&RHora Actual: &T'
        hoja_calculo.set_margins(top=1.3)
        hoja_calculo.set_header(cabecera)
        hoja_calculo.set_footer(pie_pagina)
        hoja_calculo.set_column('A:C', 15, formato_cuerpo)
        hoja_calculo.set_column('B:B', 12, formato_cuerpo)
        hoja_calculo.set_column('D:E', 80, formato_largo)
        hoja_calculo.set_row(0, 50, formato_titulo)  # Aplicando el formato al titulo superior
        hoja_calculo.set_row(1, 50, formato_titulo)  # Aplicando el formato al titulo de las columnas

        if datos:
            hoja_calculo.merge_range('A1:E1', titulo)
            filas = len(datos)
            columnas = len(datos[0]) if datos[0] else 0
            for fila in range(filas):
                for col in range(columnas):
                    hoja_calculo.set_row(fila + 2, 30, formato_cuerpo)
                    hoja_calculo.write(fila + 1, col, datos[fila][col])

    except Exception as e:
        _logger.error('No se pudo crear el archivo, por favor verifique la ruta: {}, el nombre: {} y el contenido: {}'.format(ruta_archivo, nombre_archivo, datos))
        _logger.exception(e)
    finally:
        archivo.close()
    return True

def enviar_mensaje_con_plantilla(objeto, contexto, plantilla, nombre_adj="", contenido_adj=""):
    try:
        if nombre_adj and contenido_adj:
            objeto.with_context(contexto).message_post_with_template(plantilla.id,
                notify=False,
                composition_mode='mass_mail',
                attachment_ids=[(0, 0, {'name':nombre_adj, 'datas_fname': nombre_adj, 'datas': b64encode(contenido_adj)})]
                )
        else:
            objeto.with_context(contexto).message_post_with_template(plantilla.id,
            notify=False,
            composition_mode='mass_mail'
            )
    except Exception, e:
        _logger.error('No se pudo enviar el mensaje a los destinatarios, por favor verifique que estos si tengan dirección valida, el nombre del adjunto y el contenido.')
        _logger.exception(e)

def es_fin_de_semana():
        hoy = date.today()
        dia_semana = hoy.weekday()
        if (dia_semana == 5 or dia_semana == 6):  # Si es Sabado o Domingo
            return True
        return False

class project_obra_informe_cabecera(models.Model):
    _name = 'project_obra.informe_cabecera'
    _description = 'Informe Avance de Obra - Cabecera'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']
    _order = 'fecha DESC, id DESC'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        size=50,
        compute='_compute_name',
    )
    state = fields.Selection(
        string='Estado',
        required=True,
        track_visibility='onchange',
        selection=[
            ('nuevo', 'Nuevo'),
            ('por_revisar', 'Por Revisar'),
            ('pre_aprobado', 'Aprobado por Subdirección Técnica'),
            ('aprobado', 'Aprobado'),
            ('publicado', 'Publicado'),
            ('devuelto', 'Devuelto'),
        ],
        default='nuevo',
    )
    company_id = fields.Many2one(
        string='Compañía',
        required=False,
        comodel_name='res.company',
        ondelete='restrict',
        default=lambda self: self.env.user.company_id,
    )
    currency_id = fields.Many2one(
        string='Moneda',
        required=False,
        readonly=True,
        related='company_id.currency_id',
        comodel_name='res.currency',
        ondelete='restrict',
    )
    user_id = fields.Many2one(
        string='Autor',
        required=True,
        readonly=False,
        track_visibility='onchange',
        comodel_name='res.users',
        ondelete='restrict',
        default=lambda self: self._context.get('uid', self.env['res.users'].browse()),
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    fecha = fields.Date(
        string='Fecha del Reporte',
        required=True,
        readonly=False,
        track_visibility='onchange',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    periodo_fecha_inicio = fields.Date(
        string='Desde',
        required=True,
        readonly=False,
        track_visibility='onchange',
        help='''Fecha de Inicio del periodo a reportarse''',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    periodo_fecha_fin = fields.Date(
        string='Hasta',
        required=True,
        readonly=False,
        track_visibility='onchange',
        help='''Fecha de finalización del periodo a reportarse''',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    semana = fields.Integer(
        string='Semana No',
        required=True,
        readonly=False,
        track_visibility='onchange',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    dias_ejecucion = fields.Integer(
        string='Días Transcurridos del Contrato',
        required=False,
        track_visibility='onchange',
        compute='_compute_dias_ejecucion',
        store=True,
    )
    proyecto_id = fields.Many2one(
        string='Proyecto',
        required=True,
        readonly=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    etapa_actual_id = fields.Many2one(
        string='Etapa del Proyecto',
        required=True,
        readonly=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.etapa',
        ondelete='restrict',
        help='''Si la etapa no se encuentra consultar con OAP para su inclusión''',
        domain="[('proyecto_id','=',proyecto_id),('state','=', 'open')]",
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    etapa_actual_tipo_id = fields.Many2one(
        string='Etapa Actual (tipo)',
        required=False,
        readonly=False,
        track_visibility='onchange',
        related='etapa_actual_id.tipo_id',
        comodel_name='project_obra.proyecto.etapa.tipo',
        ondelete='restrict',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    photo_ids = fields.One2many(
        string='Registro Fotográfico',
        required=False,
        readonly=False,
        comodel_name='photo_gallery.photo',
        inverse_name='proyecto_obra_informe_cabecera_id',
        ondelete='restrict',
        default=lambda self: self._context.get('photo_ids', None),
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    informe_por_contrato_ids = fields.One2many(
        string='Informes de Avances de Contratos',
        required=False,
        readonly=False,
        comodel_name='project_obra.informe_por_contrato',
        inverse_name='cabecera_id',
        ondelete='restrict',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    informe_al_ciudadano_ids = fields.One2many(
        string='Informes Al Ciudadano (Visor)',
        required=False,
        readonly=False,
        comodel_name='project_obra.informe_al_ciudadano',
        inverse_name='cabecera_id',
        ondelete='restrict',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    informe_social_ids = fields.One2many(
        string='Informes de Gestión Social',
        required=False,
        readonly=False,
        comodel_name='project_obra.informe_social',
        inverse_name='cabecera_id',
        ondelete='restrict',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    informe_predios_ids = fields.One2many(
        string='Informes de Predios',
        required=False,
        readonly=False,
        comodel_name='project_obra.informe_predios',
        inverse_name='cabecera_id',
        ondelete='restrict',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    informe_novedad_ids = fields.One2many(
        string='Informes de Novedades',
        required=False,
        readonly=False,
        comodel_name='project_obra.informe_novedades',
        inverse_name='cabecera_id',
        ondelete='restrict',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    informe_meta_fisica_ids = fields.One2many(
        string='Informes de Metas Físicas',
        required=False,
        readonly=False,
        comodel_name='project_obra.informe_meta_fisica',
        inverse_name='cabecera_id',
        ondelete='restrict',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    informe_mpp_ids = fields.One2many(
        string='Informes MPPs',
        required=False,
        readonly=False,
        comodel_name='project_obra.informe_mpp',
        inverse_name='cabecera_id',
        ondelete='restrict',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    informe_etapa_ids = fields.One2many(
        string='Informes Etapas en Contratos Mixtos',
        required=False,
        readonly=False,
        comodel_name='project_obra.informe_etapa',
        inverse_name='cabecera_id',
        ondelete='restrict',
        states={
            'aprobado': [('readonly', True)],
            'publicado': [('readonly', True)],
        },
    )
    fecha_cambio_estado = fields.Date(
        string='Fecha del cambio del estado',
        readonly=True,
    )
    # -------------------
    # methods
    # -------------------
    @api.model
    def create(self, vals):
        if 'periodo_fecha_fin' in vals:  # Siempre fecha y periodo_fecha_fin son iguales, entonces no preguntar las dos,
                                        # por compatibilidad con reportes y otras vistas no se quita, solo se deja el valor igual
            vals['fecha'] = vals['periodo_fecha_fin']
        cabecera = super(project_obra_informe_cabecera, self).create(vals)
        return cabecera

    @api.one
    def write(self, vals):
        if 'periodo_fecha_fin' in vals:  # Siempre fecha y periodo_fecha_fin son iguales, entonces no preguntar las dos,
                                        # por compatibilidad con reportes y otras vistas no se quita, solo se deja el valor igual
            vals['fecha'] = vals['periodo_fecha_fin']
        res = super(project_obra_informe_cabecera, self).write(vals)
        return res

    @api.one
    def _compute_name(self):
        self.name = "Informe {} Semana {} ({})".format(self.fecha, self.semana, self.state)

    @api.one
    @api.depends('periodo_fecha_fin', 'informe_por_contrato_ids')
    def _compute_dias_ejecucion(self):
        dias = 0
        if self.periodo_fecha_fin and len(self.informe_por_contrato_ids):
            fecha_inicio = self.informe_por_contrato_ids[0].contrato_id.fecha_inicio
            if fecha_inicio and self.periodo_fecha_fin:
                dias = int((fields.Date.from_string(self.periodo_fecha_fin) - fields.Date.from_string(fecha_inicio)).days)
        if self.periodo_fecha_fin and not len(self.informe_por_contrato_ids) and self.etapa_actual_id:
            fecha_inicio = self.etapa_actual_id.fecha_planeada_inicio
            if fecha_inicio and self.periodo_fecha_fin:
                dias = int((fields.Date.from_string(self.periodo_fecha_fin) - fields.Date.from_string(fecha_inicio)).days)

        self.dias_ejecucion = dias


    @api.one
    @api.constrains('periodo_fecha_inicio')
    def _check_periodo_fecha_inicio(self):
        if self.periodo_fecha_inicio == 'Condición de Validation':
            raise ValidationError("MENSAJE DE ERROR DE VALIDACIÓN")

    @api.one
    @api.constrains('periodo_fecha_fin')
    def _check_periodo_fecha_fin(self):
        if self.periodo_fecha_fin == 'Condición de Validation':
            raise ValidationError("MENSAJE DE ERROR DE VALIDACIÓN")

    @api.onchange('periodo_fecha_inicio')
    def _onchange_periodo_fecha_inicio(self):
        try:
            self._check_periodo_fecha_inicio()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.onchange('periodo_fecha_fin')
    def _onchange_periodo_fecha_fin(self):
        try:
            self._check_periodo_fecha_fin()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.multi
    def toggle_active(self):
        """ Inverse the value of the field ``active`` on the records in ``self``. """
        for record in self:
            record = record.with_context(active_test=False)
            record.active = not record.active
            record.informe_por_contrato_ids.toggle_active()
            record.informe_al_ciudadano_ids.toggle_active()
            record.informe_social_ids.toggle_active()
            record.informe_predios_ids.toggle_active()
            record.informe_novedad_ids.toggle_active()
            record.informe_meta_fisica_ids.toggle_active()
            record.informe_mpp_ids.toggle_active()

    @api.multi
    def unlink(self):
        res = super(project_obra_informe_cabecera, self).unlink()
        self.informe_por_contrato_ids.unlink()
        self.informe_al_ciudadano_ids.unlink()
        self.informe_social_ids.unlink()
        self.informe_predios_ids.unlink()
        self.informe_novedad_ids.unlink()
        self.informe_meta_fisica_ids.unlink()
        self.informe_mpp_ids.unlink()
        return res

    @api.model
    def notificar_estado_proyecto_contrato_activo_cron(self, dias_iniciado):
        if not es_fin_de_semana():
            limite_tiempo = timedelta(days=dias_iniciado)
            fecha_actual = date.today()
            modelo_proyecto = self.env['project_obra.proyecto']
            proyectos = modelo_proyecto.search([('state', '=', 'open')]).ids
            proyectos_cabecera = [c.proyecto_id.id for c in self.search([('proyecto_id', '!=', False)])]
            proyectos_sin_cabecera = set(proyectos) - set(proyectos_cabecera)
            proyectos_sin_cabecera = modelo_proyecto.browse(list(proyectos_sin_cabecera))
            lista_contratos_sin_actualizar = []
            cabecera = self.browse(1)
            for proyecto in proyectos_sin_cabecera:
                etapas = proyecto.etapa_ids
                for etapa in etapas:
                    contratos = etapa.contrato_ids
                    for contrato in contratos:
                        if not contrato.siac_tipo_contrato_id.es_interventoria and contrato.estado_siac_id.id == 1:
                            fecha_inicio = fields.Date.from_string(contrato.fecha_inicio)
                            if (fecha_actual > fecha_inicio) and not (fecha_actual - fecha_inicio) <= limite_tiempo and not contrato in lista_contratos_sin_actualizar:
                                lista_contratos_sin_actualizar.append(contrato)

                                coordinadores = self.env['contrato.coordinador_contrato'].search([('contrato_id', '=', contrato.id), ('tipo', '=', 'tecnico')])
                                correo_coordinador_tecnico = ''
                                for coordinador in coordinadores:
                                    correo_coordinador_tecnico += "{}, ".format(coordinador.user_id.email)
                                if not correo_coordinador_tecnico :
                                    _logger.error('No se pudo enviar el mensaje al coordinador técnico, por favor verifique que estos si tenga dirección válida.')

                                revisores = self.env['contrato.coordinador_contrato'].search([('contrato_id', '=', contrato.id), ('tipo', '=', 'revisor')])
                                correo_revisor_tecnico = ''
                                for revisor in revisores:
                                    correo_revisor_tecnico += "{}, ".format(revisor.user_id.email)
                                if not correo_revisor_tecnico :
                                    _logger.error('No se pudo enviar el mensaje al revisor técnico, por favor verifique que estos si tenga dirección válida.')

                                plantilla = self.env.ref('project_obra_seguimiento_idu.plantilla_solicitud_actualizacion_proyecto_iniciado')
                                ctx = self.env.context.copy()
                                datos = {
                                    'fecha_inicio': contrato.fecha_inicio,
                                    'dias_retrazo': (fecha_actual - fecha_inicio - limite_tiempo).days,
                                    'contrato_id': contrato.numero,
                                    'coordinador_tecnico': correo_coordinador_tecnico,
                                    'revisor_tecnico': correo_revisor_tecnico
                                    }
                                ctx.update({'datos' : datos})
                                enviar_mensaje_con_plantilla(cabecera, ctx, plantilla)

    @api.model
    def notificar_estado_informe_semana_corte_cron(self, dias_iniciado):
        if not es_fin_de_semana():
            limite_tiempo = timedelta(days=dias_iniciado)
            fecha_actual = date.today()

            sentencia_sql = '''SELECT proyecto_id, etapa_id, contrato_id, MAX(cabecera_fecha)
                                    FROM (
                                        SELECT cabecera.proyecto_id AS proyecto_id,
                                            cabecera.etapa_actual_id AS etapa_id,
                                            etapa.state AS etapa_state,
                                            cabecera.id AS cabecera_id,
                                            cabecera.fecha as cabecera_fecha,
                                            contrato.id AS contrato_id,
                                            contrato.numero AS contrato_numero,
                                            contrato.name AS contrato_name,
                                            contrato_tipo.name,
                                            contrato_tipo.es_interventoria
                                        FROM project_obra_informe_cabecera cabecera
                                        LEFT JOIN project_obra_informe_por_contrato AS por_contrato ON cabecera.id = por_contrato.cabecera_id
                                        LEFT JOIN contrato_contrato AS contrato ON por_contrato.contrato_id = contrato.id
                                        LEFT JOIN contrato_siac_tipo_contrato AS contrato_tipo ON contrato_tipo.id = contrato.siac_tipo_contrato_id
                                        LEFT JOIN project_obra_proyecto_etapa AS etapa ON cabecera.etapa_actual_id = etapa.id
                                        LEFT JOIN project_project AS project_etapa ON etapa.project_id = project_etapa.id
                                        LEFT JOIN project_obra_proyecto AS proyecto ON proyecto.id = etapa.proyecto_id
                                        LEFT JOIN project_project AS project_proyecto ON project_proyecto.id = proyecto.project_id
                                        WHERE etapa.state IN ('open', 'pending')
                                            AND cabecera.active = TRUE
                                            AND (contrato_tipo.es_interventoria IS NULL OR contrato_tipo.es_interventoria = FALSE)
                                            AND contrato.estado_siac_id = 1 -- En ejecución
                                        ORDER BY cabecera.proyecto_id ) as informe_avance
                                        GROUP BY proyecto_id, etapa_id, contrato_id
                                        ORDER BY proyecto_id, etapa_id, contrato_id ;
                        '''

            self.env.cr.execute(sentencia_sql)
            datos_completos = self.env.cr.fetchall()
            lista_proyecto_id = [dato[0] for dato in datos_completos]
            lista_etapa_id = [dato[1] for dato in datos_completos]
            lista_contrato_id = [dato[2] for dato in datos_completos]
            lista_fecha_maxima = [dato[3] for dato in datos_completos]

            modelo_proyecto = self.env['project_obra.proyecto']
            modelo_etapa = self.env['project_obra.proyecto.etapa']
            modelo_contrato = self.env['contrato.contrato']
            cabecera = self.browse(1)

            for indice in range(len(lista_proyecto_id)):
                proyecto = modelo_proyecto.browse(lista_proyecto_id[indice])
                etapa = modelo_etapa.browse(lista_etapa_id[indice])
                contrato = modelo_contrato.browse(lista_contrato_id[indice])
                fecha_maxima = fields.Date.from_string(lista_fecha_maxima[indice])
                numero_semana_maxima = fecha_maxima.isocalendar()[1]
                numero_semana_hoy = fecha_actual.isocalendar()[1]

                if numero_semana_hoy > numero_semana_maxima :  # debe presentar informe

                    coordinadores = self.env['contrato.coordinador_contrato'].search([('contrato_id', '=', contrato.id), ('tipo', '=', 'tecnico')])
                    correo_coordinador_tecnico = ''
                    for coordinador in coordinadores:
                        correo_coordinador_tecnico += "{}, ".format(coordinador.user_id.email)
                    if not correo_coordinador_tecnico :
                        _logger.error('No se pudo enviar el mensaje al coordinador técnico, por favor verifique que estos si tenga dirección válida.')

                    revisores = self.env['contrato.coordinador_contrato'].search([('contrato_id', '=', contrato.id), ('tipo', '=', 'revisor')])
                    correo_revisor_tecnico = ''
                    for revisor in revisores:
                        correo_revisor_tecnico += "{}, ".format(revisor.user_id.email)
                    if not correo_revisor_tecnico :
                        _logger.error('No se pudo enviar el mensaje al revisor técnico, por favor verifique que estos si tenga dirección válida.')

                    plantilla = self.env.ref('project_obra_seguimiento_idu.plantilla_solicitud_creacion_informe_semanal')
                    ctx = self.env.context.copy()

                    datos = {
                        'fecha_maxima': fecha_maxima,
                        'contrato_id': contrato.numero,
                        'coordinador_tecnico': correo_coordinador_tecnico,
                        'revisor_tecnico': correo_revisor_tecnico,
                        'proyecto': proyecto.name,
                        }
                    ctx.update({'datos' : datos})
                    enviar_mensaje_con_plantilla(cabecera, ctx, plantilla)

    @api.model
    def notificar_informe_sin_cambio_estado_cron(self, dias):
        if not es_fin_de_semana():
            sentencia_sql_cabeceras_fecha_cambio_estado = '''
            SELECT sub.proyecto_id AS proyecto_id, MAX(sub.fecha) AS fecha, sub.contrato_id  AS contrato_id, sub.tiempo_notificacion AS tiempo_notificacion
                FROM (
                    SELECT
                        cabecera.id AS cabecera_id, cabecera.proyecto_id AS proyecto_id, cabecera.periodo_fecha_fin AS fecha, contrato.id AS contrato_id, contrato.tiempo_notificacion AS tiempo_notificacion
                        FROM
                        project_obra_informe_cabecera cabecera
                        LEFT JOIN
                        project_obra_informe_por_contrato AS por_contrato ON cabecera.id = por_contrato.cabecera_id
                        LEFT JOIN
                        contrato_contrato AS contrato ON por_contrato.contrato_id = contrato.id
                        LEFT JOIN
                        contrato_siac_tipo_contrato AS contrato_tipo ON contrato_tipo.id = contrato.siac_tipo_contrato_id
                        LEFT JOIN
                        project_obra_proyecto_etapa AS etapa ON cabecera.etapa_actual_id = etapa.id
                        LEFT JOIN
                        project_project AS project_etapa ON etapa.project_id = project_etapa.id
                        LEFT JOIN
                        project_obra_proyecto AS proyecto ON proyecto.id = etapa.proyecto_id
                        LEFT JOIN
                        project_project AS project_proyecto ON project_proyecto.id = proyecto.project_id
                        WHERE
                        cabecera.state IN ('publicado')
                        AND
                        cabecera.active = TRUE
                        AND
                        (contrato_tipo.es_interventoria IS NULL OR contrato_tipo.es_interventoria = FALSE)
                        AND
                        contrato.estado_siac_id = 1 -- En ejecución
                        AND
                        proyecto.state = 'open'
                        ORDER BY cabecera.proyecto_id
                    ) AS sub
                    GROUP BY proyecto_id, contrato_id, tiempo_notificacion
                    ORDER BY proyecto_id;
                '''

            self.env.cr.execute(sentencia_sql_cabeceras_fecha_cambio_estado)
            datos_completos = self.env.cr.fetchall()

            lista_proyecto_id = [dato[0] for dato in datos_completos]
            lista_fecha = [dato[1] for dato in datos_completos]
            lista_contrato_id = [dato[2] for dato in datos_completos]
            lista_tiempo_notificacion = [dato[3] for dato in datos_completos]

            modelo_contrato = self.env['contrato.contrato']
            modelo_proyecto = self.env['project_obra.proyecto']

            hoy = date.today()
            # Desde el lunes de la semana anterior, hasta el miercoles de la siguiente (plazo maximo de presentar el informe) hay 9 dias
            # Ahora por defecto de deja 7 días, solo para los contratos con tipo_siac_id  65, 68 o 71 se deja 30
            plazo_max = timedelta(days=int(dias))
            cabecera = self.browse(1)  # Solo se necesita para enviar el mensaje
            for indice in range(len(lista_contrato_id)):
                proyecto = modelo_proyecto.browse(lista_proyecto_id[indice])
                # cabecera = self.browse(lista_cabecera_id[indice])
                contrato = modelo_contrato.browse(lista_contrato_id[indice])
                fecha_ultimo_informe_publicado = fields.Date.from_string(lista_fecha[indice])

                if lista_tiempo_notificacion[indice] and lista_tiempo_notificacion[indice] > 0:
                    plazo_max = timedelta(days=lista_tiempo_notificacion[indice])

                if fecha_ultimo_informe_publicado + plazo_max < hoy:
                    tecnicos = self.env['contrato.coordinador_contrato'].search([('contrato_id', '=', contrato.id), ('tipo', '=', 'tecnico')])
                    direcciones_tecnicos = ''
                    for tecnico in tecnicos:
                        direcciones_tecnicos += "{}, ".format(tecnico.user_id.email)
                    if not direcciones_tecnicos :
                        _logger.error('No se pudo enviar el mensaje al técnico del contrato {}, por favor verifique que estos si tenga dirección válida.'.format(contrato.numero))

                    apoyos = self.env['contrato.coordinador_contrato'].search([('contrato_id', '=', contrato.id), ('tipo', '=', 'apoyo')])
                    direcciones_apoyos = ''
                    for apoyo in apoyos:
                        direcciones_apoyos += "{}, ".format(apoyo.user_id.email)
                    if not direcciones_apoyos :
                        _logger.error('No se pudo enviar el mensaje al apoyo del contrato {}, por favor verifique que estos si tenga dirección válida.'.format(contrato.numero))

                    revisores = self.env['contrato.coordinador_contrato'].search([('contrato_id', '=', contrato.id), ('tipo', '=', 'revisor')])
                    direcciones_revisores = ''
                    for revisor in revisores:
                        direcciones_revisores += "{}, ".format(revisor.user_id.email)
                    if not direcciones_revisores :
                        _logger.error('No se pudo enviar el mensaje al revisor del contrato {}, por favor verifique que estos si tenga dirección válida.'.format(contrato.numero))

                    plantilla = self.env.ref('project_obra_seguimiento_idu.plantilla_solicitud_actualizacion_estado_informe')
                    ctx = self.env.context.copy()
                    datos = {
                        'contrato_id': contrato.numero,
                        'proyecto_nombre':proyecto.name,
                        'fecha_corte':fecha_ultimo_informe_publicado,
                        'direcciones_tecnicos': direcciones_tecnicos,
                        'direcciones_revisores': direcciones_revisores,
                        'direcciones_apoyos': direcciones_apoyos,
                        'dias_transcurridos':(hoy - fecha_ultimo_informe_publicado).days,
                        'dias_retraso':(hoy - fecha_ultimo_informe_publicado - plazo_max).days,
                        }
                    ctx.update({'datos' : datos})
                    enviar_mensaje_con_plantilla(cabecera, ctx, plantilla)

    @api.model
    def notificar_estado_diligenciamiento_contrato_activo_cron(self, dependencias, dir_adicional):
        if not es_fin_de_semana():
            sql = '''
            SELECT sub.proyecto_id AS proyecto_id, MAX(sub.fecha) AS fecha, MAX(sub.contrato_id)  AS contrato_id
                FROM (
                    SELECT
                        cabecera.id AS cabecera_id, cabecera.proyecto_id AS proyecto_id, cabecera.periodo_fecha_fin AS fecha, contrato.id AS contrato_id
                        FROM
                        project_obra_informe_cabecera cabecera
                        LEFT JOIN
                        project_obra_informe_por_contrato AS por_contrato ON cabecera.id = por_contrato.cabecera_id
                        LEFT JOIN
                        contrato_contrato AS contrato ON por_contrato.contrato_id = contrato.id
                        LEFT JOIN
                        contrato_siac_tipo_contrato AS contrato_tipo ON contrato_tipo.id = contrato.siac_tipo_contrato_id
                        LEFT JOIN
                        project_obra_proyecto_etapa AS etapa ON cabecera.etapa_actual_id = etapa.id
                        LEFT JOIN
                        project_project AS project_etapa ON etapa.project_id = project_etapa.id
                        LEFT JOIN
                        project_obra_proyecto AS proyecto ON proyecto.id = etapa.proyecto_id
                        LEFT JOIN
                        project_project AS project_proyecto ON project_proyecto.id = proyecto.project_id
                        WHERE
                        cabecera.state IN ('publicado')
                        AND
                        cabecera.active = TRUE
                        AND
                        (contrato_tipo.es_interventoria IS NULL OR contrato_tipo.es_interventoria = FALSE)
                        AND
                        (   contrato.estado_siac_id = 1 -- En ejecución
                            OR
                            contrato.estado_siac_id = 2 -- Suspendido
                        )
                        ORDER BY cabecera.proyecto_id
                    ) AS sub
                    GROUP BY proyecto_id
                    ORDER BY fecha;
                '''

            self.env.cr.execute(sql)
            datos_completos = self.env.cr.fetchall()

            lista_proyecto_id = [dato[0] for dato in datos_completos]
            lista_fecha = [dato[1] for dato in datos_completos]
            lista_contrato_id = [dato[2] for dato in datos_completos]

            modelo_contrato = self.env['contrato.contrato']
            modelo_proyecto = self.env['project_obra.proyecto']

            cabecera = self.browse(1)
            titulo = "REPORTE ESTADO PUBLICACIÓN INFORMES DE AVANCE DE PROYECTOS"
            datos = [['Fecha Último Reporte', 'Dirección Técnica', 'Número Contrato', 'Nombre Proyecto', 'Coordinador']]

            for indice in range(len(lista_contrato_id)):
                contrato = modelo_contrato.browse(lista_contrato_id[indice])
                proyecto = modelo_proyecto.browse(lista_proyecto_id[indice])
                dependencia = contrato.dependencia_id
                coordinador = 'No Definido'
                coordinadores = self.env['contrato.coordinador_contrato'].search([('contrato_id', '=', contrato.id), ('tipo', '=', 'tecnico')])
                for coordinador in coordinadores:
                    if coordinador and coordinador.user_id and coordinador.user_id.name:
                        coordinador = coordinador.user_id.name

                datos.append([lista_fecha[indice], dependencia.abreviatura, contrato.numero, proyecto.name, coordinador])

            ruta_archivo = '/tmp'
            nombre_archivo = 'informe.xlsx'

            dir_correo = ''
            for dependencia in dependencias:
                dependencia = dependencia.upper()
                if self.env['hr.department'].search([('abreviatura', '=', dependencia)]):
                    dir_correo += "{},".format(self.env['hr.department'].search([('abreviatura', '=', dependencia)]).manager_id.user_id.email)
            # Agrego las direcciones adicionales
            dir_correo += dir_adicional
            if crear_archivo_excel(titulo, ruta_archivo, nombre_archivo, datos):
                plantilla = self.env.ref('project_obra_seguimiento_idu.plantilla_notificacion_diligenciamiento_contrato_activo')
                ctx = self.env.context.copy()
                datos = {
                    'direccion': dir_correo,
                    }
                ctx.update({'datos' : datos})
                try:
                    archivo = open('{}/{}'.format(ruta_archivo, nombre_archivo), 'r')
                    enviar_mensaje_con_plantilla(cabecera, ctx, plantilla, nombre_adj=nombre_archivo, contenido_adj=archivo.read())
                except Exception as e:
                    _logger.error('No se pudo abrir el archivo, por favor verifique la ruta: {} y el nombre: {}'.format(ruta_archivo, nombre_archivo))
                    _logger.exception(e)
                finally:
                    archivo.close()

    @api.model
    def notificar_estado_informe_no_contrato_asociado_semana_corte_cron(self, dias_iniciado):
        if not es_fin_de_semana():

            sentencia_sql = '''
                    SELECT proyecto_id, MAX(cabecera_id) AS cabecera_id, MAX(cabecera_fecha) AS fecha_maxima FROM (
                        SELECT
                            cabecera.proyecto_id AS proyecto_id, cabecera.etapa_actual_id AS etapa_id, etapa.state AS etapa_state, cabecera.id AS cabecera_id,
                            cabecera.fecha as cabecera_fecha, por_contrato.id AS informe_por_contrato
                        FROM
                            project_obra_informe_cabecera cabecera
                        LEFT JOIN
                            project_obra_informe_por_contrato AS por_contrato ON cabecera.id = por_contrato.cabecera_id
                        LEFT JOIN
                            project_obra_proyecto_etapa AS etapa ON cabecera.etapa_actual_id = etapa.id
                        LEFT JOIN
                            project_project AS project_etapa ON etapa.project_id = project_etapa.id
                        LEFT JOIN
                            project_obra_proyecto AS proyecto ON proyecto.id = etapa.proyecto_id
                        LEFT JOIN
                            project_project AS project_proyecto ON project_proyecto.id = proyecto.project_id
                        WHERE
                            etapa.state IN ('open', 'pending')
                        AND
                            cabecera.active = TRUE
                        AND
                            por_contrato IS NULL
                        ORDER BY cabecera.proyecto_id
                    ) as informe_avance
                    GROUP BY proyecto_id
                    ORDER BY proyecto_id
                    ;
            '''
            self.env.cr.execute(sentencia_sql)
            datos_completos = self.env.cr.fetchall()
            lista_proyecto_id = [dato[0] for dato in datos_completos]
            lista_cabecera_id = [dato[1] for dato in datos_completos]
            lista_fecha = [dato[2] for dato in datos_completos]

            modelo_proyecto = self.env['project_obra.proyecto']
            modelo_contrato = self.env['contrato.contrato']

            # Debido a que no hay un contrato asociado, se envia mensaje a todos los usuarios que tengan perfil de revisores.
#             revisores = self.env.ref('project_obra_seguimiento_idu.revisor').users
            revisores = self.env.ref('project_obra_seguimiento_sgdu.aprueba_informes').users
            correo_revisor_tecnico = ''
            for revisor in revisores:
                correo_revisor_tecnico += "{},".format(revisor.email)

            for indice in range(len(lista_proyecto_id)):
                proyecto = modelo_proyecto.browse(lista_proyecto_id[indice])
                cabecera = self.browse(lista_cabecera_id[indice])
                fecha_maxima = lista_fecha[indice]
                plantilla = self.env.ref('project_obra_seguimiento_idu.tmpl_notificacion_creacion_informe_semanal_no_asociado_contrato')
                ctx = self.env.context.copy()
                datos = {
                    'proyecto': proyecto.name,
                    'revisor_tecnico': correo_revisor_tecnico,
                    'responsable':cabecera.user_id.email,
                    'fecha_maxima':fecha_maxima,
                    }
                ctx.update({'datos' : datos})
                enviar_mensaje_con_plantilla(cabecera, ctx, plantilla)

    @api.model
    def historico_informes_por_mes_cron(self, emails):
        if es_fin_de_semana():
            return False
        sentencia_sql = '''
             SELECT i.id, aac.name, rp.name, i.state, i.fecha, to_char(fecha, 'YYYY-MM')
             FROM project_obra_informe_cabecera i
                LEFT JOIN project_obra_proyecto p ON i.proyecto_id = p.id
                LEFT JOIN project_project pp ON pp.id = p.project_id
                LEFT JOIN account_analytic_account aac ON aac.id = pp.analytic_account_id
                LEFT JOIN res_users u ON u.id = i.user_id
                LEFT JOIN res_partner rp ON rp.id = u.partner_id
            WHERE i.active = TRUE
            ;
        '''
        self.env.cr.execute(sentencia_sql)
        cabecera = self.browse(1)
        titulo = "HISTÓRICO DE INFORMES CREADOS"
        datos = [["ID","Proyecto","Autor","Estado Informe", "Fecha del Reporte", "Mes-Año del Reporte"]]
        for dato in self.env.cr.fetchall():
            datos.append(dato)

        ruta_archivo = '/tmp'
        nombre_archivo = 'informe_historico.xlsx'
        dir_correo = emails
        if crear_archivo_excel(titulo, ruta_archivo, nombre_archivo, datos):
            plantilla = self.env.ref('project_obra_seguimiento_idu.plantilla_notificacion_historico_informes')
            ctx = self.env.context.copy()
            datos = {
                'direccion': dir_correo,
                }
            ctx.update({'datos' : datos})
            try:
                archivo = open('{}/{}'.format(ruta_archivo, nombre_archivo), 'r')
                enviar_mensaje_con_plantilla(cabecera, ctx, plantilla, nombre_adj=nombre_archivo, contenido_adj=archivo.read())
            except Exception as e:
                _logger.error('No se pudo abrir el archivo, por favor verifique la ruta: {} y el nombre: {}'.format(ruta_archivo, nombre_archivo))
                _logger.exception(e)
            finally:
                archivo.close()
        return True


class project_obra_informe_por_contrato(models.Model):
    _name = 'project_obra.informe_por_contrato'
    _description = 'Informe Avance de Obra por Contrato'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=100,
        compute='_compute_name',
        store=True,
    )
    contrato_id = fields.Many2one(
        string='Contrato',
        required=True,
        readonly=False,
        track_visibility='onchange',
        comodel_name='contrato.contrato',
        ondelete='restrict',
        default=lambda self: self._context.get('contrato_id', self.env['contrato.contrato'].browse()),
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    contrato_estado = fields.Char(
        string=u'Estado del contrato',
        readonly=True,
        help='Estado del contrato al momento de la creación del informe'
    )
    contrato_nombre = fields.Char(
        string=u'Contrato',
        readonly=True,
        help='Nombre del contrato con el estado al momento de creación del informe'
    )
    contrato_interventoria_id = fields.Many2one(
        string='Contrato de Interventoría',
        required=True,
        readonly=False,
        track_visibility='onchange',
        comodel_name='contrato.contrato',
        ondelete='restrict',
        default=lambda self: self._context.get('contrato_interventoria_id', self.env['contrato.contrato'].browse()),
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    contrato_interventoria_estado = fields.Char(
        string=u'Contrato de Interventoría',
        readonly=True,
        help='Estado del contrato de interventoría al momento de creación del informe'
    )
    contrato_interventoria_nombre = fields.Char(
        string=u'Contrato de Interventoría',
        readonly=True,
        help='Nombre del contrato de interventoría con el estado al momento de creación del informe'
    )
    cabecera_id = fields.Many2one(
        string='Cabecera del Informe',
        required=False,
        readonly=True,
        track_visibility='onchange',
        comodel_name='project_obra.informe_cabecera',
        ondelete='restrict',
        default=lambda self: self._context.get('cabecera_id', self.env['project_obra.informe_cabecera'].browse()),
    )
    state = fields.Selection(
        string='Estado de la Cabecera Informe',
        required=False,
        readonly=True,
        related='cabecera_id.state',
    )
    company_id = fields.Many2one(
        string='Compañía',
        required=False,
        comodel_name='res.company',
        ondelete='restrict',
        default=lambda self: self.env.user.company_id,
    )
    currency_id = fields.Many2one(
        string='Moneda',
        required=False,
        readonly=True,
        related='company_id.currency_id',
        comodel_name='res.currency',
        ondelete='restrict',
    )
    programado_porcentaje_avance_fisico_acumulado = fields.Float(
        string='Porcentaje de avance fisico acumulado (Programado)',
        required=False,
        readonly=False,
        track_visibility='onchange',
        states={
            'nuevo': [('required', True)],
            'publicado': [('readonly', True), ('required', True)],
            'aprobado': [('readonly', True), ('required', True)],
            'por_revisar':[('required', True)],
            'pre_aprobado':[('required', True)],
            'devuelto':[('required', True)],
        },
    )
    programado_avance_financiero_acumulado = fields.Monetary(
        string='Avance financiero Acumulado (Programado)',
        required=False,
        readonly=False,
        track_visibility='onchange',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    ejecutado_porcentaje_avance_fisico_acumulado = fields.Float(
        string='Porcentaje de avance fisico acumulado (Ejecutado)',
        required=False,
        readonly=False,
        track_visibility='onchange',
        states={
            'nuevo': [('required', True)],
            'publicado': [('readonly', True), ('required', True)],
            'aprobado': [('readonly', True), ('required', True)],
            'por_revisar':[('required', True)],
            'pre_aprobado':[('required', True)],
            'devuelto':[('required', True)],
        },
    )
    ejecutado_avance_financiero_acumulado = fields.Monetary(
        string='Avance financiero Acumulado (Ejecutado)',
        required=False,
        readonly=False,
        track_visibility='onchange',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )


    # -------------------
    # methods
    # -------------------

    @api.one
    @api.depends('cabecera_id')
    def _compute_name(self):
        self.name = "Aut impedit laborum praesentium maxime sit quae tenetur."

    @api.one
    @api.constrains('programado_porcentaje_avance_fisico_acumulado')
    def _check_programado_porcentaje_avance_fisico_acumulado(self):
        if self.programado_porcentaje_avance_fisico_acumulado < 0 or self.programado_porcentaje_avance_fisico_acumulado > 100:
            raise ValidationError("El porcentaje ejecutado debe ser un valor entre 0 y 100")

    @api.one
    @api.constrains('programado_avance_financiero_acumulado')
    def _check_programado_avance_financiero_acumulado(self):
        if self.programado_avance_financiero_acumulado == 'Condición de Validation':
            raise ValidationError("MENSAJE DE ERROR DE VALIDACIÓN")

    @api.one
    @api.constrains('ejecutado_porcentaje_avance_fisico_acumulado')
    def _check_ejecutado_porcentaje_avance_fisico_acumulado(self):
        if self.ejecutado_porcentaje_avance_fisico_acumulado < 0 or self.ejecutado_porcentaje_avance_fisico_acumulado > 100:
            raise ValidationError("El porcentaje ejecutado debe ser un valor entre 0 y 100")


    @api.one
    @api.constrains('ejecutado_avance_financiero_acumulado')
    def _check_ejecutado_avance_financiero_acumulado(self):
        if self.ejecutado_avance_financiero_acumulado == 'Condición de Validation':
            raise ValidationError("MENSAJE DE ERROR DE VALIDACIÓN")

    @api.onchange('contrato_id')
    def _onchange_contrato_id(self):
        # https://www.odoo.com/documentation/8.0/howtos/backend.html#onchange
        pass

    @api.onchange('contrato_interventoria_id')
    def _onchange_contrato_interventoria_id(self):
        # https://www.odoo.com/documentation/8.0/howtos/backend.html#onchange
        pass

    @api.onchange('programado_porcentaje_avance_fisico_acumulado')
    def _onchange_programado_porcentaje_avance_fisico_acumulado(self):
        try:
            self._check_programado_porcentaje_avance_fisico_acumulado()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.onchange('programado_avance_financiero_acumulado')
    def _onchange_programado_avance_financiero_acumulado(self):
        try:
            self._check_programado_avance_financiero_acumulado()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.onchange('ejecutado_porcentaje_avance_fisico_acumulado')
    def _onchange_ejecutado_porcentaje_avance_fisico_acumulado(self):
        try:
            self._check_ejecutado_porcentaje_avance_fisico_acumulado()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.onchange('ejecutado_avance_financiero_acumulado')
    def _onchange_ejecutado_avance_financiero_acumulado(self):
        try:
            self._check_ejecutado_avance_financiero_acumulado()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

class project_obra_informe_al_ciudadano(models.Model):
    _name = 'project_obra.informe_al_ciudadano'
    _description = 'Informe Avance de Obra para el Ciudadano'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=100,
        compute='_compute_name',
        store=True,
    )
    cabecera_id = fields.Many2one(
        string='Cabecera del Informe',
        required=False,
        readonly=True,
        track_visibility='onchange',
        comodel_name='project_obra.informe_cabecera',
        ondelete='restrict',
        default=lambda self: self._context.get('cabecera_id', self.env['project_obra.informe_cabecera'].browse()),
    )
    state = fields.Selection(
        string='Estado de la Cabecera Informe',
        required=False,
        readonly=True,
        related='cabecera_id.state',
    )
    ciudadano_anuncios = fields.Char(
        string='Anuncios a la Comunidad',
        required=False,
        readonly=False,
        track_visibility='onchange',
        size=255,
        help='''ej. Cierres Viales, reuniones a realizarse con la comunidad''',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    ciudadano_avances_por_meta_fisica_ids = fields.One2many(
        string='Avances por Meta Física',
        required=False,
        readonly=False,
        track_visibility='onchange',
        comodel_name='project_obra.informe_al_ciudadano.avance_por_meta',
        inverse_name='informe_id',
        ondelete='restrict',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )

    # -------------------
    # methods
    # -------------------

    @api.one
    @api.depends('cabecera_id')
    def _compute_name(self):
        self.name = "In impedit molestiae id."

class project_obra_informe_al_ciudadano_avance_por_meta(models.Model):
    _name = 'project_obra.informe_al_ciudadano.avance_por_meta'
    _description = 'Informe Avance de Obra por Meta Fisica para el Ciudadano'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=100,
        compute='_compute_name',
        store=True,
    )
    informe_id = fields.Many2one(
        string='Informe al Ciudadano',
        required=True,
        readonly=True,
        track_visibility='onchange',
        comodel_name='project_obra.informe_al_ciudadano',
        ondelete='restrict',
        default=lambda self: self._context.get('informe_id', self.env['project_obra.informe_al_ciudadano'].browse()),
    )
    state = fields.Selection(
        string='Estado de la Cabecera Informe',
        required=False,
        readonly=True,
        related='informe_id.cabecera_id.state',
    )
    project_id = fields.Many2one(
        string='Proyecto Odoo',
        required=False,
        readonly=True,
        track_visibility='onchange',
        related='informe_id.cabecera_id.proyecto_id.project_id',
        comodel_name='project.project',
        ondelete='restrict',
    )
    meta_fisica_id = fields.Many2one(
        string='Meta Física',
        required=True,
        readonly=False,
        comodel_name='project.meta',
        ondelete='restrict',
        domain="[('project_id','=',project_id)]",
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    avance = fields.Char(
        string='En Qué se Trabaja',
        required=False,
        readonly=False,
        size=500,
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
            'devuelto':[('required', True)],
        },
    )

    # -------------------
    # methods
    # -------------------

    @api.one
    @api.depends('informe_id')
    def _compute_name(self):
        self.name = "Quia illum excepturi quidem magnam atque deserunt neque."


class project_obra_informe_predios(models.Model):
    _name = 'project_obra.informe_predios'
    _description = 'Informe Avance de Adquisicioon de Predios'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=100,
        compute='_compute_name',
        store=True,
    )
    cabecera_id = fields.Many2one(
        string='Cabecera del Informe',
        required=False,
        readonly=True,
        track_visibility='onchange',
        comodel_name='project_obra.informe_cabecera',
        ondelete='restrict',
        default=lambda self: self._context.get('cabecera_id', self.env['project_obra.informe_cabecera'].browse()),
    )
    state = fields.Selection(
        string='Estado de la Cabecera Informe',
        required=False,
        readonly=True,
        related='cabecera_id.state',
    )
    predios_requeridos = fields.Integer(
        string='Predios Requeridos (Total)',
        required=False,
        readonly=False,
        track_visibility='onchange',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    predios_entregados = fields.Integer(
        string='Predios Entregados (Disponibles)',
        required=False,
        readonly=False,
        track_visibility='onchange',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    predios_pendientes = fields.Integer(
        string='Predios Pendientes',
        required=False,
        readonly=False,
        track_visibility='onchange',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )

    # -------------------
    # methods
    # -------------------

    @api.one
    @api.depends('cabecera_id')
    def _compute_name(self):
        self.name = "Necessitatibus placeat aut maxime ut quo."

class project_obra_informe_novedades(models.Model):
    _name = 'project_obra.informe_novedades'
    _description = 'Informe Avance de Novedades de Obra'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=100,
        compute='_compute_name',
        store=True,
    )
    cabecera_id = fields.Many2one(
        string='Cabecera del Informe',
        required=False,
        readonly=True,
        track_visibility='onchange',
        comodel_name='project_obra.informe_cabecera',
        ondelete='restrict',
        default=lambda self: self._context.get('cabecera_id', self.env['project_obra.informe_cabecera'].browse()),
    )
    state = fields.Selection(
        string='Estado de la Cabecera Informe',
        required=False,
        readonly=True,
        related='cabecera_id.state',
    )
    resumen_novedades = fields.Text(
        string='Resumen de Novedades',
        required=False,
        readonly=False,
        help='''Resumen en Formato JSON de como estaban las novedades para el contrato a la fecha de corte.''',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )

    # -------------------
    # methods
    # -------------------

    @api.one
    @api.depends('cabecera_id')
    def _compute_name(self):
        self.name = "Excepturi aliquam ut tenetur."


class project_obra_informe_meta_fisica(models.Model):
    _name = 'project_obra.informe_meta_fisica'
    _description = 'Informe Avance de Metas Fisicas de Obra'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=100,
        compute='_compute_name',
        store=True,
    )
    cabecera_id = fields.Many2one(
        string='Cabecera del Informe',
        required=False,
        readonly=True,
        track_visibility='onchange',
        comodel_name='project_obra.informe_cabecera',
        ondelete='restrict',
        default=lambda self: self._context.get('cabecera_id', self.env['project_obra.informe_cabecera'].browse()),
    )
    state = fields.Selection(
        string='Estado de la Cabecera Informe',
        required=False,
        readonly=True,
        related='cabecera_id.state',
    )
    proyecto_id = fields.Many2one(
        string='Proyecto',
        required=False,
        readonly=True,
        track_visibility='onchange',
        related='cabecera_id.proyecto_id',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
    )
    meta_fisica_avance_ids = fields.One2many(
        string='Avances por Meta Física',
        required=False,
        readonly=False,
        comodel_name='project_obra.informe_meta_fisica.avance',
        inverse_name='informe_id',
        ondelete='restrict',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )

    # -------------------
    # methods
    # -------------------

    @api.one
    @api.depends('cabecera_id')
    def _compute_name(self):
        self.name = "Maxime qui dolorem rem explicabo."

class project_obra_informe_meta_fisica_avance(models.Model):
    _name = 'project_obra.informe_meta_fisica.avance'
    _description = 'Informe Avance de Metas Fisicas de Obra'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    def _default_inf_meta_fisica_id(self):
        cabecera_id = self._context.get('cabecera_id')
        #proyecto_id = self._context.get('proyecto_id')
        # proyecto = self.env['project_obra.proyecto'].browse(proyecto_id)
        # if proyecto:
        #     project_id = proyecto.project_id
        #     if project_id:
        meta_fisica = self.env['project_obra.informe_meta_fisica'].search([('cabecera_id','=',cabecera_id)])
        if meta_fisica:
            return meta_fisica[0].id


    @api.model
    def _get_meta_fisica_domain(self):
        contrato_id = self._context.get('contrato_id')
        #proyecto_id = self._context.get('proyecto_id')
        if contrato_id:
            etapas = self.env['project_obra.proyecto.etapa'].search([('contrato_ids','=',contrato_id)])
            projects_ids = [e.proyecto_id.project_id.id for e in etapas]
            #proyecto = self.env['project_obra.proyecto'].browse(proyecto_id)
            if projects_ids:
                #project = proyecto.project_id
                meta_ids = self.env['project.meta'].search([('project_id','in',projects_ids)])
                return [('id','in',meta_ids.ids)]
        return [('id','in',[])]

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=100,
        compute='_compute_name',
        store=True,
    )
    informe_id = fields.Many2one(
        string='Cabecera del Informe',
        required=True,
        readonly=True,
        track_visibility='onchange',
        comodel_name='project_obra.informe_meta_fisica',
        ondelete='restrict',
        default=_default_inf_meta_fisica_id,
    )
    state = fields.Selection(
        string='Estado de la Cabecera Informe',
        required=False,
        readonly=True,
        related='informe_id.cabecera_id.state',
    )
    proyecto_id = fields.Many2one(
        string='Proyecto',
        required=False,
        readonly=True,
        track_visibility='onchange',
        related='informe_id.cabecera_id.proyecto_id',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
    )
    proyecto_meta_id = fields.Many2one(
        string='Proyecto Meta',
        required=False,
        readonly=True,
        track_visibility='onchange',
        related='meta_fisica_id.project_id.obra_proyecto_id',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
    )
    project_id = fields.Many2one(
        string='Proyecto Odoo',
        required=False,
        readonly=True,
        track_visibility='onchange',
        related='informe_id.cabecera_id.proyecto_id.project_id',
        comodel_name='project.project',
        ondelete='restrict',
    )
    frente_id = fields.Many2one(
        string='Frente de Obra',
        required=False,
        readonly=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.frente_obra',
        ondelete='restrict',
        default=lambda self: self._context.get('frente_id', self.env['project_obra.proyecto.frente_obra'].browse()),
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    meta_fisica_id = fields.Many2one(
        string='Meta Física',
        required=True,
        readonly=False,
        track_visibility='onchange',
        comodel_name='project.meta',
        ondelete='restrict',
        domain=_get_meta_fisica_domain,
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    avance_programado = fields.Float(
        string='Avance Programado',
        required=False,
        readonly=False,
        track_visibility='onchange',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    avance_acumulado = fields.Float(
        string='Avance Acumulado',
        required=False,
        readonly=False,
        track_visibility='onchange',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    uom_id = fields.Many2one(
        string='Unidad de Medida',
        required=False,
        readonly=True,
        track_visibility='onchange',
        related='meta_fisica_id.tipo_id.uom_id',
        comodel_name='product.uom',
        ondelete='restrict',
        help='''related:meta_fisica_id.uom_id''',
    )
    plan_desarrollo_id = fields.Many2one(
        string='Plan Desarrollo Distrital',
        comodel_name='plan_desarrollo_distrital.plan',
        related='meta_fisica_id.meta_hacienda_id.plan_desarrollo_id',
        readonly=True,
        store=True,
        ondelete='restrict',
    )

    _sql_constraints = [
        ('unique_linea_por_informe', 'unique(informe_id,frente_id,meta_fisica_id)', 'Esta meta ya ha sido seleccionada en el informe'),
    ]

    # -------------------
    # methods
    # -------------------

    @api.one
    @api.depends('informe_id')
    def _compute_name(self):
        self.name = "Explicabo voluptatibus aliquid eveniet ea eligendi."


class project_obra_informe_mpp(models.Model):
    _name = 'project_obra.informe_mpp'
    _description = 'Informe Avance en Archivo MPP'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=100,
        compute='_compute_name',
        store=True,
    )
    cabecera_id = fields.Many2one(
        string='Cabecera del Informe',
        required=False,
        readonly=True,
        track_visibility='onchange',
        comodel_name='project_obra.informe_cabecera',
        ondelete='restrict',
        default=lambda self: self._context.get('cabecera_id', self.env['project_obra.informe_cabecera'].browse()),
    )
    state = fields.Selection(
        string='Estado de la Cabecera Informe',
        required=False,
        readonly=True,
        related='cabecera_id.state',
    )
    proyecto_id = fields.Many2one(
        string='Proyecto',
        required=False,
        readonly=True,
        track_visibility='onchange',
        related='cabecera_id.proyecto_id',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
    )
    archivo_filename = fields.Char(
        string='Nombre de Archivo',
        required=False,
        readonly=False,
        track_visibility='onchange',
        size=255,
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    archivo = fields.Binary(
        string='Archivo MS-Project',
        required=False,
        readonly=False,
        track_visibility='onchange',
        attachment=True,
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    linea_frente_ids = fields.One2many(
        string='Avances por Componente/Frente',
        required=False,
        readonly=False,
        comodel_name='project_obra.informe_mpp.linea_frente',
        inverse_name='informe_id',
        ondelete='restrict',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    #Campo para agregar pestaña dinamica dependiendo de la etapa(DIseño y Factibilidad), ya que en el elemento tree no es dinamico
    linea_frente_aprobacion_objecion_ids = fields.One2many(
        string='Aprobación y Objeción por Componente/Frente',
        required=False,
        readonly=False,
        comodel_name='project_obra.informe_mpp.linea_frente',
        inverse_name='informe_id',
        ondelete='restrict',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )

    # -------------------
    # methods
    # -------------------

    @api.one
    @api.depends('cabecera_id')
    def _compute_name(self):
        self.name = "Id voluptatum laborum voluptatem ea at voluptatem nemo eligendi."


class project_obra_informe_mpp_linea_frente(models.Model):
    _name = 'project_obra.informe_mpp.linea_frente'
    _description = 'Informe Avance Por Frente en Archivo MPP'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']
    _order = 'sequence ASC'

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=100,
        compute='_compute_name',
        store=True,
    )
    informe_id = fields.Many2one(
        string='Informe MPP',
        required=True,
        readonly=True,
        track_visibility='onchange',
        comodel_name='project_obra.informe_mpp',
        ondelete='restrict',
        default=lambda self: self._context.get('informe_id', self.env['project_obra.informe_mpp'].browse()),
    )
    state = fields.Selection(
        string='Estado de la Cabecera Informe',
        required=False,
        readonly=True,
        related='informe_id.cabecera_id.state',
    )
    proyecto_id = fields.Many2one(
        string='Proyecto',
        required=False,
        readonly=True,
        track_visibility='onchange',
        related='informe_id.cabecera_id.proyecto_id',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
    )
    proyecto_frente_id = fields.Many2one(
        string='Proyecto del Frente',
        readonly=True,
        track_visibility='onchange',
        related='frente_id.proyecto_id',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
    )
    etapa_tipo_name = fields.Char(
        string='Tipo de etapa',
        readonly=True,
        related='informe_id.cabecera_id.etapa_actual_id.tipo_id.name',
    )
    frente_id = fields.Many2one(
        string='Frente de Obra',
        required=True,
        readonly=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.frente_obra',
        ondelete='restrict',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    sequence = fields.Integer(
        string='Secuencia del frente de obra',
        related='frente_id.sequence',
        store=True,
    )
    porcentaje_programado = fields.Float(
        string='Porcentaje Programado',
        required=False,
        readonly=False,
        track_visibility='onchange',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    porcentaje_ejecutado = fields.Float(
        string='Porcentaje Ejecutado',
        required=False,
        readonly=False,
        track_visibility='onchange',
        states={
            'publicado': [('readonly', True)],
            'aprobado': [('readonly', True)],
        },
    )
    porcentaje_variacion = fields.Float(
        string='Variación Porcentual',
        required=False,
        track_visibility='onchange',
        compute='_compute_porcentaje_variacion',
        store=True,
    )
    aprobacion_interventoria = fields.Selection(
        string='Aprobación Interventoría',
        selection=APROBACION_INTERVENTORIA_OPCIONES,
        track_visibility='onchange',
    )
    no_objecion_idu = fields.Selection(
        string='No Objeción IDU',
        selection=NO_OBJECION_IDU_OPCIONES,
        track_visibility='onchange',
    )

    _sql_constraints = [
        ('unique_linea_por_informe', 'unique(informe_id,frente_id)', 'Este frente ya ha sido seleccionado en el informe'),
    ]

    # -------------------
    # methods
    # -------------------

    @api.one
    @api.depends('informe_id')
    def _compute_name(self):
        self.name = "Fuga dicta ut dicta sed laudantium necessitatibus."

    @api.one
    @api.depends('porcentaje_programado', 'porcentaje_ejecutado')
    def _compute_porcentaje_variacion(self):
        self.porcentaje_variacion = self.porcentaje_ejecutado - self.porcentaje_programado

    @api.one
    @api.constrains('porcentaje_programado')
    def _check_porcentaje_programado(self):
        if self.porcentaje_programado < 0 or self.porcentaje_programado > 100:
            raise ValidationError("El porcentaje ejecutado debe ser un valor entre 0 y 100")

    @api.one
    @api.constrains('porcentaje_ejecutado')
    def _check_porcentaje_ejecutado(self):
        if self.porcentaje_ejecutado < 0 or self.porcentaje_ejecutado > 100:
            raise ValidationError("El porcentaje ejecutado debe ser un valor entre 0 y 100")

class project_obra_informe_social(models.Model):
    _name = 'project_obra.informe_social'
    _description = 'Informe Gestion Social Obra'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        track_visibility='onchange',
        size=100,
        compute='_compute_name',
        store=True,
    )
    cabecera_id = fields.Many2one(
        string='Cabecera del Informe',
        required=False,
        readonly=True,
        track_visibility='onchange',
        comodel_name='project_obra.informe_cabecera',
        ondelete='restrict',
        default=lambda self: self._context.get('cabecera_id', self.env['project_obra.informe_cabecera'].browse()),
    )
    state = fields.Selection(
        string='Estado de la Cabecera Informe',
        required=False,
        readonly=True,
        related='cabecera_id.state',
    )
    empleos_generados_contratista = fields.Integer(
        string='Empleos Generados por Contratista',
        required=False,
        readonly=False,
        track_visibility='onchange',
        states={
            'nuevo': [('required', True)],
            'publicado': [('readonly', True), ('required', True)],
            'aprobado': [('readonly', True), ('required', True)],
            'por_revisar':[('required', True)],
            'pre_aprobado':[('required', True)],
            'devuelto':[('required', True)],
        },
    )
    empleos_generados_interventoria = fields.Integer(
        string='Empleos Generados por Interventoría',
        required=False,
        readonly=False,
        track_visibility='onchange',
        states={
            'nuevo': [('required', True)],
            'publicado': [('readonly', True), ('required', True)],
            'aprobado': [('readonly', True), ('required', True)],
            'por_revisar':[('required', True)],
            'pre_aprobado':[('required', True)],
            'devuelto':[('required', True)],
        },
    )

    # -------------------
    # methods
    # -------------------

    @api.one
    @api.depends('cabecera_id')
    def _compute_name(self):
        self.name = "Veritatis tenetur debitis voluptas ut labore eum corrupti."


class project_obra_informe_workflow_mixin(models.Model):
    _name = 'project_obra.informe.workflow_mixin'

    # -------------------
    # Workflow methods
    # -------------------
    @api.one
    def reiniciar_workflow(self):
        if self.env.uid == 1 or self.env.user.has_group('project.group_project_manager'):
            self.create_workflow()
            return

        ultimo_publicado = self.search(
            [
                ('etapa_actual_id','=',self.etapa_actual_id.id),
                ('state','=','publicado'),
            ],
            order='periodo_fecha_fin DESC',
            limit=1,
        )
        if ultimo_publicado.id == self.id:
            self.create_workflow()
        else:
            raise Warning('Solo el último informe públicado puede ser re-abierto')
        return True

    @api.one
    def cambiar_estado_workflow(self, estado, partner_ids=False):
        self.fecha_cambio_estado = date.today()
        self.message_post(
            type='notification',
            partner_ids=partner_ids or [],
            body="""El informe de seguimiento del proyecto {} para el corte {} ha cambiado al estado {}""".format(
                self.proyecto_id.name, self.periodo_fecha_fin, estado
            ),
        )
        self.cabecera_id.state = estado

    def wkf_devuelto(self):
        self.cambiar_estado_workflow('devuelto', [self.user_id.partner_id.id])

    def wkf_por_revisar(self):
        for inf in self.informe_al_ciudadano_ids:
            if hasattr(inf, 'informe_detalle_frente_id') and not inf.informe_detalle_frente_id.active:
                continue
            for avance in inf.ciudadano_avances_por_meta_fisica_ids:
                if not avance.avance or (isinstance(avance.avance, basestring) and not len(avance.avance.strip())):
                    raise Warning('No ha diligenciado un avance en la pestaña "Visor" específicamente el campo "En qué se trabaja" para el frente "{} - {}" y la meta: {}'.format(
                        avance.informe_id.informe_detalle_frente_id.frente_id.name, avance.informe_id.informe_detalle_frente_id.tipo_elemento_id.name, avance.meta_fisica_id.name
                    ))

        self.cambiar_estado_workflow('por_revisar')

    def wkf_aprobado(self):
        self.cambiar_estado_workflow('aprobado')

    def wkf_pre_aprobado(self):
        self.cambiar_estado_workflow('pre_aprobado')

    def wkf_nuevo(self):
        self.cambiar_estado_workflow('nuevo')

    def wkf_publicado(self):
        self.cambiar_estado_workflow('publicado')

    @api.multi
    def novedades_view_button(self):
        return {
            'name': 'Novedades',
            'res_model': 'project.problema',
            'domain': [('project_id', '=', self.proyecto_id.project_id.id)],
            'context': {'project_id': self.proyecto_id.project_id.id, 'proyecto_id': self.proyecto_id.id},
            'type': 'ir.actions.act_window',
            'view_mode': 'tree,form',
            'view_type': 'form',
        }

    @api.multi
    def novedades_actualizar_resumen_button(self):
        self.resumen_novedades = self.generar_resumen_novedades(self.cabecera_id)

    @api.model
    def generar_resumen_novedades(self, cabecera):
        problemas_estados = ['abierto', 'en_progreso']
        consolidado_problemas_por_tipo_vs_estado = cabecera.proyecto_id.project_id.get_consolidado_problemas_por_tipo_vs_estado(estados=problemas_estados)
        resumen_novedades = "A la fecha el proyecto tiene las siguientes novedades pendientes de cerrarse:\n"
        if not consolidado_problemas_por_tipo_vs_estado:
            resumen_novedades = 'No hay ninguna novedad abierta para este proyecto'
        for tipo, resumen in consolidado_problemas_por_tipo_vs_estado.items():
            resumen_novedades += "\n{}: {} {}, {} {}".format(
                tipo,
                resumen['abierto'], PROBLEMA_ESTADOS_LABELS['nuevo'],
                resumen['en_progreso'], PROBLEMA_ESTADOS_LABELS['nuevo'],
            )
        return resumen_novedades

    @api.multi
    def toggle_active(self):
        """ Inverse the value of the field ``active`` on the records in ``self``. """
        for record in self:
            record.active = not record.active
            record.cabecera_id.toggle_active()

    @api.multi
    def unlink(self):
        self.check_access_rights('unlink')
        self.check_access_rule('unlink')
        res = self.write({ 'active': False })
        for i in self:
            i.cabecera_id.unlink()
        return res


class project_obra_informe_etapa(models.Model):
    _name = 'project_obra.informe_etapa'
    _description = 'Informe Avance de Obra – Por Etapa Adicional'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']



    # def etapas_domain(self):
    #     # return [('proyecto_id','=',self.proyecto_id.id),('contrato_ids','!=', False), ('parent_id', '=', False)]
    #     domain = [('proyecto_id','=',self.proyecto_id.id),('contrato_ids','!=', False), ('parent_id', '=', False)]
    #     if self.cabecera_id:
    #         informes = self.env['project_obra.construccion.informe_avance'].search([('cabecera_id','=',self.cabecera_id.id)])
    #         if informes:
    #             contrato = informes[0].contrato_id
    #             # etapas = self.env['project_obra.proyecto.etapa'].search([('','',)])
    #             domain = [('contrato_ids','=',contrato.id)]
    #     return domain


    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=False,
        size=50,
        compute='_compute_name',
    )
    cabecera_id = fields.Many2one(
        string='Cabecera del Informe',
        required=False,
        readonly=True,
        track_visibility='onchange',
        comodel_name='project_obra.informe_cabecera',
        ondelete='restrict',
        default=lambda self: self._context.get('cabecera_id', self.env['project_obra.informe_cabecera'].browse()),
    )
    state = fields.Selection(
        string='Estado de la Cabecera Informe',
        required=False,
        readonly=True,
        related='cabecera_id.state',
    )
    proyecto_id = fields.Many2one(
        string='Proyecto',
        required=True,
        readonly=True,
        track_visibility='onchange',
        related='cabecera_id.proyecto_id',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
    )
    proyecto_manual_id = fields.Many2one(
        string='Proyecto Manual',
        #required=True,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto',
        #domain=lambda self: self.proyecto_manual_domain(),
        ondelete='restrict',
    )
    etapa_actual_id = fields.Many2one(
        string='Etapa del Proyecto',
        required=True,
        readonly=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.etapa',
        ondelete='restrict',
        help='''Si la etapa no se encuentra consultar con OAP para su inclusión''',
        #domain=lambda self: self.etapas_domain(),
        #domain="[('proyecto_id','=',proyecto_id),('contrato_ids','!=', False), ('parent_id', '=', False)]",
        states={
            'aprobado': [('readonly', True)],
            'publicado': [('readonly', True)],
        },
    )
    programado_porcentaje_avance_fisico_acumulado = fields.Float(
        string='Porcentaje de avance fisico acumulado (Programado)',
        required=True,
        readonly=False,
        track_visibility='onchange',
        states={
            'aprobado': [('readonly', True)],
            'publicado': [('readonly', True)],
        },
    )
    programado_avance_financiero_acumulado = fields.Monetary(
        string='Avance financiero Acumulado (Programado)',
        required=False,
        readonly=False,
        track_visibility='onchange',
        states={
            'aprobado': [('readonly', True)],
            'publicado': [('readonly', True)],
        },
    )
    ejecutado_porcentaje_avance_fisico_acumulado = fields.Float(
        string='Porcentaje de avance fisico acumulado (Ejecutado)',
        required=True,
        readonly=False,
        track_visibility='onchange',
        states={
            'aprobado': [('readonly', True)],
            'publicado': [('readonly', True)],
        },
    )
    ejecutado_avance_financiero_acumulado = fields.Monetary(
        string='Avance financiero Acumulado (Ejecutado)',
        required=False,
        readonly=False,
        track_visibility='onchange',
        states={
            'aprobado': [('readonly', True)],
            'publicado': [('readonly', True)],
        },
    )
    company_id = fields.Many2one(
        string='Compañía',
        required=False,
        comodel_name='res.company',
        ondelete='restrict',
        default=lambda self: self.env.user.company_id,
    )
    currency_id = fields.Many2one(
        string='Moneda',
        required=False,
        readonly=True,
        related='company_id.currency_id',
        comodel_name='res.currency',
        ondelete='restrict',
    )

    # -------------------
    # methods
    # -------------------


    @api.model
    def fields_view_get(self, view_id=None, view_type='form', toolbar=False, submenu=False):
        res = super(project_obra_informe_etapa, self).fields_view_get(
            view_id=view_id, view_type=view_type, toolbar=toolbar, submenu=submenu)
        # {'cabecera_id': cabecera_id, 'contrato_id': contrato_id, 'proyecto_id': proyecto_id}
        if self._context.get('contrato_id'):
            contrato_id = self._context.get('contrato_id')
            etapas = self.env['project_obra.proyecto.etapa'].search([('contrato_ids','=',contrato_id)])
            proyectos_ids = [e.proyecto_id.id for e in etapas]
            proyecto_filter = "[('id', 'in', {})]".format(proyectos_ids)
            doc = etree.XML(res['arch'])
            for node in doc.xpath("//field[@name='proyecto_manual_id']"):
                node.set('domain', proyecto_filter)

            res['arch'] = etree.tostring(doc)
        return res



    @api.onchange('proyecto_manual_id')
    def _dominio_dinamico_etapa_actual_id(self):
        if self.proyecto_manual_id:
            domain = {'etapa_actual_id': [('proyecto_id','=',self.proyecto_manual_id.id)]}
            contrato_id = self._context.get('contrato_id')
            if contrato_id:
                domain = {'etapa_actual_id': [('proyecto_id', '=', self.proyecto_manual_id.id), ('contrato_ids', '=', contrato_id)]}
            # domain = {'etapa_actual_id': [('proyecto_id','=',self.proyecto_manual_id.id)]}
        else:
            domain = {'etapa_actual_id': [('proyecto_id', 'in', [])]}

        return {'domain': domain}


    @api.one
    def _compute_name(self):
        self.name = "{} {}".format(self.proyecto_id.name, self.etapa_actual_id.name)

    @api.one
    @api.constrains('programado_porcentaje_avance_fisico_acumulado')
    def _check_programado_porcentaje_avance_fisico_acumulado(self):
        if self.programado_porcentaje_avance_fisico_acumulado == 'Condición de Validation':
            raise ValidationError("MENSAJE DE ERROR DE VALIDACIÓN")

    @api.one
    @api.constrains('programado_avance_financiero_acumulado')
    def _check_programado_avance_financiero_acumulado(self):
        if self.programado_avance_financiero_acumulado == 'Condición de Validation':
            raise ValidationError("MENSAJE DE ERROR DE VALIDACIÓN")

    @api.one
    @api.constrains('ejecutado_porcentaje_avance_fisico_acumulado')
    def _check_ejecutado_porcentaje_avance_fisico_acumulado(self):
        if self.ejecutado_porcentaje_avance_fisico_acumulado == 'Condición de Validation':
            raise ValidationError("MENSAJE DE ERROR DE VALIDACIÓN")

    @api.one
    @api.constrains('ejecutado_avance_financiero_acumulado')
    def _check_ejecutado_avance_financiero_acumulado(self):
        if self.ejecutado_avance_financiero_acumulado == 'Condición de Validation':
            raise ValidationError("MENSAJE DE ERROR DE VALIDACIÓN")

    @api.onchange('programado_porcentaje_avance_fisico_acumulado')
    def _onchange_programado_porcentaje_avance_fisico_acumulado(self):
        try:
            self._check_programado_porcentaje_avance_fisico_acumulado()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.onchange('programado_avance_financiero_acumulado')
    def _onchange_programado_avance_financiero_acumulado(self):
        try:
            self._check_programado_avance_financiero_acumulado()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.onchange('ejecutado_porcentaje_avance_fisico_acumulado')
    def _onchange_ejecutado_porcentaje_avance_fisico_acumulado(self):
        try:
            self._check_ejecutado_porcentaje_avance_fisico_acumulado()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }

    @api.onchange('ejecutado_avance_financiero_acumulado')
    def _onchange_ejecutado_avance_financiero_acumulado(self):
        try:
            self._check_ejecutado_avance_financiero_acumulado()
        except Exception as e:
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name}
            }
