# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import logging

from openerp import models, fields, api
from openerp.exceptions import ValidationError

_logger = logging.getLogger(__name__)


def obtener_proyecto_etapa_contrato(objeto, id_contrato=0, numero_contrato=''):
    '''
    Funcion que obtiene el proyecto y la etapa al cual esta asociado un contrato.
    Retorna un diccionario con los valores: etapa_id y proyecto_id si lo encuentra, si no, un diccionario vacio.
    '''
    consulta = ''
    info_contrato = {}
    if id_contrato:
        consulta = '''
        SELECT e.id as etapa_id, e.proyecto_id
            FROM contrato_contrato c
            LEFT JOIN contrato_contrato_project_project_rel cp ON cp.contrato_contrato_id = c.id
            LEFT JOIN project_obra_proyecto_etapa e ON e.project_id = cp.project_project_id
            LEFT JOIN project_project p ON p.id = e.project_id
            LEFT JOIN account_analytic_account a ON a.id = p.analytic_account_id
            WHERE c.id = {} AND p.state IN ('open', 'draft', 'pending') and e.active = 't' AND e.parent_id IS NULL
            GROUP BY e.id, e.proyecto_id;'''.format(id_contrato)
    elif numero_contrato:
        consulta = '''
        SELECT e.id as etapa_id, e.proyecto_id
            FROM contrato_contrato c
            LEFT JOIN contrato_contrato_project_project_rel cp ON cp.contrato_contrato_id = c.id
            LEFT JOIN project_obra_proyecto_etapa e ON e.project_id = cp.project_project_id
            LEFT JOIN project_project p ON p.id = e.project_id
            LEFT JOIN account_analytic_account a ON a.id = p.analytic_account_id
            WHERE c.numero = '{}' AND p.state IN ('open', 'draft', 'pending') and e.active = 't' AND e.parent_id IS NULL
            GROUP BY e.id, e.proyecto_id;'''.format(numero_contrato)
    if consulta:
        objeto.env.cr.execute(consulta)
        respuesta = objeto.env.cr.fetchall()
        info_contrato['etapa_id'] = respuesta[0][0] if respuesta and respuesta[0] else 0
        info_contrato['proyecto_id'] = respuesta[0][1] if respuesta and respuesta[0] else 0
    return info_contrato


class tramite_crear_tramite_wizard(models.TransientModel):
    _name = 'tramite.wizard.crear_tramite'
    _description = 'Wizard para Crear Tramite'

    # -------------------
    # Fields
    # -------------------

    user_id = fields.Many2one(
        string='Autor',
        required=True,
        track_visibility='onchange',
        comodel_name='res.users',
        ondelete='restrict',
        readonly=True,
        default=lambda self: self._context.get('uid', self.env['res.users'].browse()),
    )
    etapa_id = fields.Many2one(
        string='Etapa',
        required=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.etapa.tipo',
        ondelete='restrict',
    )
    etapa_actual_id = fields.Many2one(
        string='Etapa Actual del Proyecto',
        required=False,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.etapa',
        ondelete='restrict',
        help='''Etapa Actual del proyecto''',
    )
    contrato_id = fields.Many2one(
        string='Contrato',
        required=False,
        track_visibility='onchange',
        comodel_name='contrato.contrato',
        ondelete='restrict',
    )
    contrato_interventoria_id = fields.Many2one(
        string='Contrato de Interventoría',
        required=False,
        track_visibility='onchange',
        comodel_name='contrato.contrato',
        ondelete='restrict',
        domain="[('id','!=',contrato_id), ('siac_tipo_contrato_id.es_interventoria','=',True)]",
    )
    proyecto_id = fields.Many2one(
        string='Proyecto Relacionado',
        required=False,
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
        help='''Proyecto Relacionado''',
    )
    proyecto_plan_id = fields.Many2one(
        string='Proyecto Plan Relacionado',
        required=False,
        comodel_name='project_obra.proyecto_plan',
        ondelete='restrict',
        help='''Proyecto Plan Relacionado''',
    )
    tipo_tramite_id = fields.Many2one(
        string='Tramite / Producto',
        required=False,
        track_visibility='onchange',
        comodel_name='tramite.tipo',
        ondelete='restrict',
        help='''Tramite o Producto Asociado''',
    )
    autoridad_id = fields.Many2one(
        string='Entidad',
        required=False,
        track_visibility='onchange',
        comodel_name='tramite.autoridad',
        ondelete='restrict',
        help='''La Entidad que expide''',
    )
    fecha_estimada_aprobacion = fields.Date(
        string='Fecha Estimada de Aprobación',
        help='''Fecha Estimada para ser Aprobado''',
    )

    # -------------------
    # methods
    # -------------------
    @api.onchange('user_id')
    def _onchange_user_id(self):
        if self.env.user.has_group('tramites_idu.administrador'):
            contrato_ids = self.env['contrato.contrato'].search([('state', 'in', ['borrador', 'en_ejecucion'])]).ids
        else:
            contrato_ids = self.env['contrato.coordinador_contrato'].search([
                ('user_id', '=', self.env.uid),
            ]).mapped('contrato_id.id')
        return {
            'domain': {
                'contrato_id': [('id', 'in', contrato_ids), ],
            }
        }

    @api.onchange('contrato_id')
    def _onchange_contrato_id(self):
        result = {}
        if self.contrato_id:
            proyecto_etapa = obtener_proyecto_etapa_contrato(self, id_contrato=self.contrato_id.id)
            if proyecto_etapa:
                if 'proyecto_id' in proyecto_etapa and proyecto_etapa['proyecto_id']:
                    self.proyecto_id = proyecto_etapa['proyecto_id']
                    if len(self.proyecto_id.proyecto_plan_ids.ids) >= 1:
                        plan_ids = self.proyecto_id.proyecto_plan_ids.mapped('proyecto_plan_id').ids
                        self.proyecto_plan_id = plan_ids[0]
                        result = {
                            'domain': {
                                'proyecto_plan_id': [('id', 'in', plan_ids)]
                            },
                        }
                if 'etapa_id' in proyecto_etapa and proyecto_etapa['etapa_id']:
                    self.etapa_actual_id = proyecto_etapa['etapa_id']
            else:
                self.proyecto_id = False
                self.etapa_actual_id = False
                self.proyecto_plan_id = False
        return result

    @api.one
    def crear_tramite(self):
        tramite = {
            'contrato_id': self.contrato_id.id,
            'proyecto_id': self.proyecto_id.id,
            'interventoria_id': self.contrato_interventoria_id.id,
            'tipo_id': self.tipo_tramite_id.id,
            'etapa_id': self.etapa_id.id,
            'autoridad_id': self.autoridad_id.id,
            'etapa_actual_id': self.etapa_actual_id.id,
            'fecha_estimada':self.fecha_estimada_aprobacion,
            'proyecto_plan_id': self.proyecto_plan_id.id,
        }
        self.env['tramite.tramite'].sudo().create(tramite)
