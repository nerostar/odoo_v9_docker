# -*- coding: utf-8 -*-
from datetime import datetime
from openerp import models, fields, api


class tramite_tramite(models.Model):
    _name = 'tramite.tramite'
    _description = 'Seguimiento del Tramite'
    _inherit = ['tramite.tramite']

    # -------------------
    # methods
    # -------------------
    @api.one
    def _compute_name(self):
        self.name = "{} - {}".format(self.id, self.contrato_id.numero)

# Se deshabilito temporalmente ya que no lo necesitan por el momento
#     def search(self, cr, uid, args, offset=0, limit=None, order=None, context=None, count=False):
#         user = self.pool.get('res.users').browse(cr, uid, uid)
#         if user.has_group('tramites_idu.coordinador') and uid != 1:
#             contrato_ids = self.pool.get('contrato.contrato').search(cr, uid, [('coordinador_ids.user_id', '=', uid)])
#             args += [('contrato_id', 'in', contrato_ids)]
#         else:
#             args += []
#         return super(tramite_tramite, self).search(cr, uid, args, offset, limit, order, context, count)

    @api.one
    def reiniciar_workflow(self):
        return self.create_workflow()

    @api.one
    def unlink(self):
        self.check_access_rights('unlink')
        self.check_access_rule('unlink')
        for novedad in self.novedad_ids:
            novedad.unlink()
        for radicado in self.radicado_ids:
            radicado.unlink()
        res = super(tramite_tramite, self).unlink()
        return res


class tramite_novedad(models.Model):
    _name = 'tramite.novedad'
    _description = 'Novedades del Tramite'
    _inherit = ['tramite.novedad']

    # -------------------
    # methods
    # -------------------
    @api.one
    def _compute_name(self):
        self.name = "Trámite {}".format(self.tramite_id.name)


class tramite_radicado(models.Model):
    _name = 'tramite.radicado'
    _description = 'Radicado del Tramite'
    _inherit = ['tramite.radicado']

    # -------------------
    # methods
    # -------------------

    @api.one
    def _compute_name(self):
        self.name = "Trámite: {}".format(self.tramite_id.name)

