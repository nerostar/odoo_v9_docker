# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api

class project_obra_proyecto_plan(models.Model):
    _inherit = ['project_obra.proyecto_plan']

    tramite_ids = fields.One2many(
        string='Tramites',
        comodel_name='tramite.tramite',
        inverse_name='proyecto_plan_id',
    )

    @api.multi
    def tramite_view_button(self):
        return {
            'name': 'Trámites',
            'res_model': 'tramite.tramite',
            'domain': [('proyecto_plan_id', '=', self.id)],
            'context': {'proyecto_plan_id': self.id},
            'type': 'ir.actions.act_window',
            'view_mode': 'tree,form',
            'view_type': 'form',
        }

