# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api
from openerp.exceptions import ValidationError

TRAMITE_STATES = [
            ('registrado', 'Registrado'),
            ('solicitado', 'Solicitado'),
            ('devuelto_con_observaciones', 'Devuelto con Observaciones'),
            ('aprobado', 'Aprobado'),
            ('anulado', 'Anulado'),
            ]


class tramite_tramite(models.Model):
    _name = 'tramite.tramite'
    _description = 'Seguimiento del Trámite'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Número de trámite',
        required=False,
        size=50,
        compute='_compute_name',
        help='''Identificador Trámite''',
    )
    contrato_id = fields.Many2one(
        string='Contrato',
        required=True,
        readonly=True,
        track_visibility='onchange',
        comodel_name='contrato.contrato',
        ondelete='restrict',
        help='''Contrato Relacionado''',
        domain="[('coordinador_ids.user_id', '=', uid), ]",  # ('tipo_id.name','in',['Obra', 'Diseños', 'Actualización de Diseños', 'Diseños y Construcción']),]",
        states={
            'registrado': [('readonly', False)],
        },
    )
    interventoria_id = fields.Many2one(
        string='Contrato de Interventoría',
        required=True,
        readonly=True,
        comodel_name='contrato.contrato',
        ondelete='restrict',
        help='''Contrato de Interventoría''',
        domain="[('id','!=',contrato_id), ('siac_tipo_contrato_id.es_interventoria','=',True)]",
        states={
            'registrado': [('readonly', False)],
        },
    )
    proyecto_plan_id = fields.Many2one(
        string='Proyecto Plan Relacionado',
        comodel_name='project_obra.proyecto_plan',
        help='''Proyecto Plan Relacionado''',
    )
    proyecto_id = fields.Many2one(
        string='Proyecto Relacionado',
        required=True,
        readonly=True,
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
        help='''Proyecto Relacionado''',
        domain="[('state','=','open')]",
        states={
            'registrado': [('readonly', False)],
        },
    )
    tipo_id = fields.Many2one(
        string='Trámite / Producto',
        required=True,
        readonly=True,
        track_visibility='onchange',
        comodel_name='tramite.tipo',
        ondelete='restrict',
        help='''Trámite o Producto Asociado''',
        states={
            'registrado': [('readonly', False)],
        },
    )
    etapa_id = fields.Many2one(
        string='Etapa del Proyecto',
        required=False,
        readonly=True,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto.etapa.tipo',
        ondelete='restrict',
        help='''Etapa del proyecto en la cual aplica este tipo de trámite''',
        states={
            'registrado': [('readonly', False)],
        },
    )
    etapa_actual_id = fields.Many2one(
        string='Etapa del Proyecto',
        required=False,
        comodel_name='project_obra.proyecto.etapa',
        ondelete='restrict',
        help='''Etapa actual del proyecto''',
    )
    state = fields.Selection(
        string='Estado',
        required=False,
        track_visibility='onchange',
        help='''Estado del Trámite, dependiente del Tipo de Trámite''',
        selection=TRAMITE_STATES,
        default='registrado',
    )
    fecha_estimada = fields.Date(
        string='Fecha Estimada de Aprobación',
        required=True,
        readonly=True,
        track_visibility='onchange',
        help='''Fecha Estimada de Aprobación''',
        states={
            'registrado': [('readonly', False)],
            'solicitado': [('readonly', False)],
            'devuelto_con_observaciones': [('readonly', False)],
        },
    )
    descripcion = fields.Text(
        string='Descripción del Trámite',
        required=False,
        readonly=True,
        help='''Descripción del Trámite''',
        states={
            'registrado': [('readonly', False)],
            'solicitado': [('readonly', False)],
            'devuelto_con_observaciones': [('readonly', False)],
        },
    )
    radicado_ids = fields.One2many(
        string='Radicado',
        required=False,
        readonly=True,
        comodel_name='tramite.radicado',
        inverse_name='tramite_id',
        ondelete='restrict',
        help='''Información del Radicado''',
        states={
            'registrado': [('readonly', False)],
            'solicitado': [('readonly', False)],
            'devuelto_con_observaciones': [('readonly', False)],
        },
    )
    fecha_aprobacion = fields.Date(
        string='Fecha Acto de Aprobación',
        required=False,
        readonly=False,
        help='''Fecha en la cual se concedió''',
        states={
            'aprobado': [('required', True), ('readonly', True)]
        },
    )
    num_aprobacion = fields.Char(
        string='Número Acto de Aprobación',
        required=False,
        readonly=True,
        size=50,
        help='''Número del Acto de  Aprobación''',
        states={
            'registrado': [('readonly', False)],
            'solicitado': [('readonly', False)],
            'devuelto_con_observaciones': [('readonly', False)],
        },
    )
    obligaciones = fields.Text(
        string='Obligaciones derivadas',
        required=False,
        readonly=True,
        track_visibility='onchange',
        help='''Obligaciones derivadas''',
        states={
            'registrado': [('readonly', False)],
            'solicitado': [('readonly', False)],
            'devuelto_con_observaciones': [('readonly', False)],
        },
    )
    observaciones = fields.Text(
        string='Observaciones',
        required=False,
        readonly=True,
        track_visibility='onchange',
        help='''Observaciones realizadas''',
        states={
            'registrado': [('readonly', False)],
            'solicitado': [('readonly', False)],
            'devuelto_con_observaciones': [('readonly', False)],
        },
    )
    autoridad_id = fields.Many2one(
        string='Entidad',
        required=True,
        readonly=True,
        track_visibility='onchange',
        comodel_name='tramite.autoridad',
        ondelete='restrict',
        help='''La Entidad que expide''',
        states={
            'registrado': [('readonly', False)],
        },
    )
    novedad_ids = fields.One2many(
        string='Novedades Presentadas',
        required=False,
        readonly=True,
        track_visibility='onchange',
        comodel_name='tramite.novedad',
        inverse_name='tramite_id',
        ondelete='restrict',
        help='''Novedades que se presentaron''',
        states={
            'registrado': [('readonly', False)],
            'solicitado': [('readonly', False)],
            'devuelto_con_observaciones': [('readonly', False)],
        },
    )
    remision_centro_documentacion = fields.Char(
        string='Remisión al Centro de Documentación',
        required=False,
        readonly=True,
        track_visibility='onchange',
        size=50,
        help='''Remisión al Centro de Documentación''',
        states={
            'registrado': [('readonly', False)],
            'solicitado': [('readonly', False)],
            'devuelto_con_observaciones': [('readonly', False)],
        },
    )

    # -------------------
    # methods
    # -------------------
    @api.one
    @api.constrains('descripcion')
    def _check_descripcion(self):
        if self.descripcion and len(self.descripcion) > 300:
            raise ValidationError("El limite de caracteres es de 300")

    @api.onchange('descripcion')
    def _onchange_descripcion(self):
        self._check_descripcion()

    @api.one
    def _compute_name(self):
        self.name = "Soon meeting look fear."

    # -------------------
    # Workflow methods
    # -------------------
    def wkf_registrado(self):
        self.state = 'registrado'

    def wkf_aprobado(self):
        if self.fecha_aprobacion:
            self.state = 'aprobado'
        else:
            raise ValidationError("Debe diligenciar el campo 'Fecha Aprobación' en el Área de Aprobación")

    def wkf_anulado(self):
        self.state = 'anulado'

    def wkf_solicitado(self):
        self.state = 'solicitado'

    def wkf_devuelto_con_observaciones(self):
        self.state = 'devuelto_con_observaciones'

    def search(self, cr, uid, args, offset=0, limit=None, order=None, context=None, count=False):
        user = self.pool.get('res.users').browse(cr, uid, uid)
        if not user.has_group('project.group_project_manager') and not user.has_group('base.group_configuration') and uid != 1:
            sql = """
                SELECT contrato_id FROM contrato_coordinador_contrato cc
                WHERE cc.user_id = %s AND cc.tipo IS NOT NULL AND cc.active = 't';
            """
            cr.execute(sql, (uid,))
            result = cr.fetchall()
            contrato_ids = [ i[0] for i in result ]
            args += [('contrato_id', 'in', contrato_ids)]
        return super(tramite_tramite, self).search(cr, uid, args, offset, limit, order, context, count)


class tramite_tipo(models.Model):
    _name = 'tramite.tipo'
    _description = 'Tipos de Trámites'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Trámite / Producto',
        required=True,
        track_visibility='onchange',
        help='''Nombre del Trámite Producto''',
    )
    estado_id = fields.Many2one(
        string='Estado Permiso',
        required=False,
        track_visibility='onchange',
        comodel_name='tramite.tipo.estado',
        ondelete='restrict',
        help='''Estado del Trámite, dependiente del Tipo de Trámite''',
    )

    _sql_constraints = [
        ('unique_name', 'unique(name)', 'Este name ya está registrado'),
    ]

    # -------------------
    # methods
    # -------------------


class tramite_tipo_estado(models.Model):
    _name = 'tramite.tipo.estado'
    _description = 'Estado del Trámite'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre del Estado',
        required=True,
        track_visibility='onchange',
        size=50,
        help='''Nombre del estado del Trámite''',
    )

    _sql_constraints = [
        ('unique_name', 'unique(name)', 'Este name ya está registrado'),
    ]

    # -------------------
    # methods
    # -------------------


class tramite_autoridad(models.Model):
    _name = 'tramite.autoridad'
    _description = 'Trámite Autoridad'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre de la Entidad',
        required=True,
        track_visibility='onchange',
        size=50,
        help='''Nombre de la Entidad que expide el trámite''',
    )

    _sql_constraints = [
        ('unique_name', 'unique(name)', 'Este name ya está registrado'),
    ]

    # -------------------
    # methods
    # -------------------


class tramite_novedad(models.Model):
    _name = 'tramite.novedad'
    _description = 'Novedades del Trámite'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Novedades Presentadas',
        required=False,
        size=255,
        compute='_compute_name',
        help='''Novedades que se pueden presentar''',
    )
    tramite_id = fields.Many2one(
        string='Trámite asociado',
        required=False,
        readonly=True,
        comodel_name='tramite.tramite',
        ondelete='restrict',
        help='''Trámite Asociado a la novedad''',
        default=lambda self: self._context.get('tramite_id', self.env['tramite.tramite'].browse()),
    )
    descripcion = fields.Text(
        string='Descripción de la novedad',
        required=True,
        help='''descripción de la novedad''',
    )

    # -------------------
    # methods
    # -------------------


class tramite_radicado(models.Model):
    _name = 'tramite.radicado'
    _description = 'Radicado del Trámite'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Identificador del Radicado',
        required=False,
        size=50,
        compute='_compute_name',
        help='''Identidicador del Radicado''',
    )
    tramite_id = fields.Many2one(
        string='Trámite asociado',
        required=False,
        readonly=True,
        comodel_name='tramite.tramite',
        ondelete='restrict',
        help='''Trámite Asociado al Radicado''',
        default=lambda self: self._context.get('tramite_id', self.env['tramite.tramite'].browse()),
    )
    asunto_id = fields.Many2one(
        string='Asunto del radicado',
        required=True,
        track_visibility='onchange',
        comodel_name='tramite.asunto',
        ondelete='restrict',
        help='''Asunto del radicado''',
    )
    rad_idu = fields.Char(
        string='Radicado IDU',
        required=False,
        track_visibility='onchange',
        size=50,
        help='''Numero de radicado orfeo''',
    )
    fecha_rad_idu = fields.Date(
        string='Fecha Radicado IDU',
        required=False,
        track_visibility='onchange',
        help='''Fecha en la cual se asigno el radicado IDU''',
    )
    rad_externo = fields.Char(
        string='Radicado Externo',
        required=False,
        track_visibility='onchange',
        size=50,
        help='''Numero de radicado externo''',
    )
    fecha_rad_ext = fields.Date(
        string='Fecha Radicado Externo',
        required=False,
        track_visibility='onchange',
        help='''Fecha en la cual se dio el Radicado Externo''',
    )
    observaciones = fields.Text(
        string='Observaciones',
        required=False,
        track_visibility='onchange',
        help='''Observaciones del radicado''',
    )

    # -------------------
    # methods
    # -------------------

    @api.one
    def _compute_name(self):
        self.name = "Final six sing lose collection executive speech."


class tramite_asunto(models.Model):
    _name = 'tramite.asunto'
    _description = 'Asunto del Radicado'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Descripción del Asunto',
        required=True,
        track_visibility='onchange',
        size=50,
        help='''Descripción del Asunto''',
    )

    # -------------------
    # methods
    # -------------------
