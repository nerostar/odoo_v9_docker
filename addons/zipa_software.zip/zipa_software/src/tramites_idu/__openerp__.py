{
    'name': 'Gestión de Tramites',
    'version': '1.0',
    'depends': [
        'base',
        'base_idu',
        'contrato_idu',
        'model_security',
        'project_obra_portafolio_idu',
        'project_obra_seguimiento_idu',
    ],
    'author': "IDU STRT I+D+i",
    'category': 'IDU',
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'wizards/crear_tramite_view.xml',
        'views/tramite_view.xml',
        'views/tramite_view_personalizada.xml',
        'views/project_obra.xml',
        'workflow/tramite_workflow.xml',
    ],
    'test': [],
    'demo': [
    ],
    'installable': True,
    'description': """
## Dependencias módulos Python
## Configuración adicional
    """,
}

