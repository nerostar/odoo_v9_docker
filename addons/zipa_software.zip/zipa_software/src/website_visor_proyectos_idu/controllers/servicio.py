# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp.addons.web import http
from openerp.addons.web.http import request
import json

class controller(http.Controller):

    @http.route(['/zipa/visor_proyectos/datos_estadisticas'], type='http', auth="public", methods=['get'])
    def get_datos_proyectos(self, **kwargs):
        informe_cabecera_model = request.env['project_obra.informe_cabecera']
        request.env.cr.execute("""SELECT
                                        rn, cabecera_id
                                    FROM (
                                        SELECT
                                            cabecera.id as cabecera_id,
                                            proyecto.id as proyecto_id,
                                            row_number() over(PARTITION BY proyecto.id order by cabecera.fecha desc) as rn
                                        FROM
                                            project_obra_informe_cabecera as cabecera
                                        LEFT JOIN
                                            project_obra_informe_por_contrato AS por_contrato ON cabecera.id = por_contrato.cabecera_id
                                        LEFT JOIN
                                            contrato_contrato AS contrato ON por_contrato.contrato_id = contrato.id
                                        LEFT JOIN
                                            hr_department AS dependencia ON dependencia.id = contrato.dependencia_id
                                        LEFT JOIN
                                            contrato_contrato_project_project_rel AS c_p_relacion ON c_p_relacion.contrato_contrato_id = contrato.id
                                        LEFT JOIN
                                            project_project AS project_etapa ON c_p_relacion.project_project_id = project_etapa.id
                                        LEFT JOIN
                                            project_obra_proyecto_etapa AS etapa ON etapa.project_id = project_etapa.id
                                        LEFT JOIN
                                            project_obra_proyecto AS proyecto ON proyecto.id = etapa.proyecto_id
                                        LEFT JOIN
                                            project_project AS project_proyecto ON project_proyecto.id = proyecto.project_id
                                        WHERE
                                            cabecera.state IN ('publicado')
                                        AND
                                            etapa.id = cabecera.etapa_actual_id
                                        AND
                                            project_etapa.state IN ('open')
                                        AND
                                            cabecera.active = TRUE
                                        GROUP BY
                                            proyecto.id, contrato.id, cabecera.id
                                            ) as T
                                    WHERE rn <= 1
                                    ORDER BY proyecto_id DESC, rn""")
        datos_completos = request.env.cr.fetchall()
        orden = [ i[0] for i in datos_completos]
        cabeceras = [ i[1] for i in datos_completos]
        informes_cabecera = informe_cabecera_model.browse(cabeceras).sudo()
        data_graficas = datos_graficas(informes_cabecera, orden)
        datos = json.dumps(data_graficas)
        return datos

    @http.route(['/zipa/visor_proyectos/get_avance_conservacion_consolidado_final_por_elemento'], type='http', auth="public", methods=['get'])
    def get_avance_conservacion_consolidado_final_por_elemento(self, **kwargs):
        results = request.env['project_obra.conservacion.informe_avance'].get_consolidado_final_por_elemento()
        datos = json.dumps(results)
        return datos


def datos_graficas(informes_cabecera, orden):
    cantidad_etapas = []
    valor_total = []
    empleos_generados = []
    valor_contratista = 0
    valor_interventoria = 0
    empleos_generados_contratista = 0
    empleos_generados_interventoria = 0

    for i in [1,2,3]:
        cantidad_etapas.append(0)
        valor_total.append(0)
        empleos_generados.append(0)
    for informe_cabecera in informes_cabecera:
        if (informe_cabecera.etapa_actual_tipo_id.name == 'Estudios y Diseños'):
            numero_etapa = 0
        elif (informe_cabecera.etapa_actual_tipo_id.name == 'Construcción'):
            numero_etapa = 1
        elif (informe_cabecera.etapa_actual_tipo_id.name == 'Conservación'):
            numero_etapa = 2
        cantidad_etapas[numero_etapa] += 1
        proyectos_omitidos = ['109','112','113']
        if(proyectos_omitidos.count(informe_cabecera.proyecto_id.codigo) == 0 ):
            valor_total[numero_etapa] += informe_cabecera.informe_por_contrato_ids[-1].contrato_id.valor_total + informe_cabecera.informe_por_contrato_ids[-1].contrato_interventoria_id.valor_total
            valor_contratista += informe_cabecera.informe_por_contrato_ids[-1].contrato_id.valor_total
            valor_interventoria += informe_cabecera.informe_por_contrato_ids[-1].contrato_interventoria_id.valor_total
        empleos_generados[numero_etapa] += informe_cabecera.informe_social_ids[-1].empleos_generados_contratista + informe_cabecera.informe_social_ids[-1].empleos_generados_interventoria
        empleos_generados_contratista += informe_cabecera.informe_social_ids[-1].empleos_generados_contratista
        empleos_generados_interventoria += informe_cabecera.informe_social_ids[-1].empleos_generados_interventoria
    data_graficas = [
        [
            {
                'name' : 'Diseño',
                'cantidad' : cantidad_etapas[0],
                'valor_total' : valor_total[0],
                'empleos' : empleos_generados[0]
            },
            {
                'name' : 'Construcción',
                'cantidad' : cantidad_etapas[1],
                'valor_total' : valor_total[1],
                'empleos' : empleos_generados[1]
            },
            {
                'name' : 'Conservación',
                'cantidad' : cantidad_etapas[2],
                'valor_total' : valor_total[2],
                'empleos' : empleos_generados[2]
            },
        ],
        [
            {
                'name' : 'Contratista',
                'valor_total' : valor_contratista,
                'empleos' : empleos_generados_contratista
            },
            {
                'name' : 'Interventoria',
                'valor_total' : valor_interventoria,
                'empleos' : empleos_generados_interventoria
            }
         ],
         [
            {
                'total_numero_proyectos_ejecucion_etapa' :  cantidad_etapas[0] +  cantidad_etapas[1] + cantidad_etapas[2],
                'total_valor_inversion_etapa' : valor_total[0] + valor_total[1] + valor_total[2],
                'total_valor_inversion_contratista_interventoria' : valor_contratista + valor_interventoria,
                'total_empleos_generados_etapa' : empleos_generados[0] + empleos_generados[1] + empleos_generados[2],
                'total_empleos_generados_contratista_interventoria' : empleos_generados_contratista + empleos_generados_interventoria
            }
         ]
    ]
    return data_graficas
