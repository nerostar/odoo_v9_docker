# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp.addons.web import http
from openerp.addons.web.http import request
from openerp.addons.website.models.website import slug
import werkzeug.exceptions
import json
import base64
from openerp.addons.web.controllers.main import content_disposition


class controller(http.Controller):
    def _get_informe_cabecera_por_contrato(self, request, numero_contrato_consulta):
        informe_cabecera_model = request.env["project_obra.informe_cabecera"].sudo()
        dominio = [
            (
                "informe_por_contrato_ids.contrato_id.numero",
                "in",
                [numero_contrato_consulta],
            ),
            ("state", "=", "publicado"),
        ]
        # HACK para permitir que estos contratos puedan crear informe para dos etapas diferentes
        # Esta es la excepción, si se vuelve regla hay que modificar este código para que sea basado
        # en configuración y no quemado en el código.
        # En el visor de proyectos se toma el informe de conservación para estos contratos
        contratos_con_doble_etapa = [
            "IDU-135-2007",
            "IDU-136-2007",
            "IDU-138-2007",
        ]
        if numero_contrato_consulta in contratos_con_doble_etapa:
            dominio.append(("etapa_actual_tipo_id", "=", 24))  # Filtrar de conservacion

        informe_cabecera = informe_cabecera_model.search(
            dominio,
            order="fecha DESC, id DESC",
            limit=1,
        )
        return informe_cabecera

    def get_resumen_proyecto(self, proyecto):
        punto_idu_model = request.env["pqrs.punto_atencion_ciudadano"].sudo()
        datos = {
            "informacion_financiera": {},
            "informacion_anticipos": {},
            "informacion_predios": {},  # Se Agrega un nuevo diccionario para la información de predios
        }

        for e in proyecto.etapa_ids:
            for c in e.contrato_ids:
                datos["informacion_financiera"][c.numero] = c.get_pagos()
                datos["informacion_anticipos"][c.numero] = 0.0
                if c.pagos_stone_json:
                    pagos_dic = json.loads(c.pagos_stone_json)
                    resumen = pagos_dic.get("resumen", {})
                    if resumen and "anticipo" in resumen:
                        anticipo = resumen["anticipo"]
                        datos["informacion_anticipos"][c.numero] = (
                            float(anticipo) if anticipo else 0.0
                        )
                # Agregar información de predios
                datos["informacion_predios"][c.numero] = {
                    "requeridos": proyecto.indicador_predios_requeridos,
                    "entregados": proyecto.indicador_predios_entregados,
                    "pendientes": proyecto.indicador_predios_pendientes,
                    "disponibles": proyecto.indicador_predios_disponibles,
                }
        return datos

    @http.route(
        [
            "/zipa/visor_proyectos/contrato/<string:numero_contrato>.pdf",
        ],
        type="http",
        auth="public",
        website=True,
    )
    def visor_proyectos_pdf(self, numero_contrato, codigo_frente=False, **kwargs):
        numero_contrato_consulta = fix_numero_contrato(numero_contrato)
        informe_cabecera = self._get_informe_cabecera_por_contrato(
            request, numero_contrato_consulta
        )

        model_informe_avance_construccion = request.env[
            "project_obra.construccion.informe_avance"
        ].sudo()
        model_informe_avance_conservacion = request.env[
            "project_obra.conservacion.informe_avance"
        ].sudo()
        informe_avance_construccion = model_informe_avance_construccion.search(
            [("cabecera_id", "=", informe_cabecera.id)]
        )
        informe_avance_conservacion = model_informe_avance_conservacion.search(
            [("cabecera_id", "=", informe_cabecera.id)]
        )
        archivo = False

        if len(informe_avance_construccion) > 0:
            reporte_parametros = {
                "mostrar_estado_contrato": False,
                "mostrar_informacion_contractual": True,
                "mostrar_informacion_predial": False,
                "mostrar_informacion_desempeno": True,
                "mostrar_novedades": False,
                "mostrar_metas_fisicas": True,
                "mostrar_informacion_visor": True,
                "mostrar_registro_fotografico": False,
            }
            wm = request.env["zipa.reporte_informe_construccion.wizard"].create(
                reporte_parametros
            )
            archivo = wm.crear_reporte_informe_construccion(informe_avance_construccion)
        elif len(informe_avance_conservacion) > 0:
            reporte_parametros = {
                "mostrar_estado_contrato": False,
                "mostrar_informacion_contractual": True,
                "mostrar_informacion_desempeno": True,
                "mostrar_novedades": False,
                "mostrar_registro_fotografico": False,
            }
            wm = request.env["zipa.reporte_informe_conservacion.wizard"].create(
                reporte_parametros
            )
            archivo = wm.crear_reporte_informe_conservacion(informe_avance_conservacion)
        else:
            return request.not_found()
        filecontent = base64.b64decode(archivo.data or "")
        if not filecontent:
            return request.not_found()
        else:
            return request.make_response(
                filecontent,
                [
                    ("Content-Type", "application/octet-stream"),
                    ("Content-Disposition", content_disposition(archivo.filename)),
                ],
            )

    @http.route(
        [
            "/zipa/visor_proyectos/contrato/<string:numero_contrato>/<string:codigo_frente>",
            "/zipa/visor_proyectos/contrato/<string:numero_contrato>",
        ],
        type="http",
        auth="public",
        website=True,
    )
    def visor_proyectos_index(self, numero_contrato, codigo_frente=False, **kwargs):
        try:
            numero_contrato_consulta = fix_numero_contrato(numero_contrato)
        except:
            return request.website.render(
                "website_visor_proyectos_idu.visor_proyectos_index",
                {
                    "sin_contrato": True,
                },
            )
        informe_cabecera = self._get_informe_cabecera_por_contrato(
            request, numero_contrato_consulta
        )
        punto_crea_model = request.env["pqrs.punto_atencion_ciudadano"].sudo()
        punto_crea = punto_crea_model.search(
            [("contrato_id.numero", "=", numero_contrato_consulta)]
        )
        informe_al_ciudadano = False
        photos = False
        if len(informe_cabecera.informe_al_ciudadano_ids) > 1:
            # Colocando uno por defecto por si no hay match con codigo_frente
            informe_al_ciudadano = informe_cabecera.informe_al_ciudadano_ids[-1]
            photos = informe_al_ciudadano.informe_detalle_frente_id.photo_ids
            for informe_al_ciudadano_id in informe_cabecera.informe_al_ciudadano_ids:
                if (
                    informe_al_ciudadano_id.informe_detalle_frente_id.frente_id.codigo_sigidu
                    == codigo_frente
                ):
                    informe_al_ciudadano = informe_al_ciudadano_id
                    photos = informe_al_ciudadano.informe_detalle_frente_id.photo_ids
        elif len(informe_cabecera.informe_al_ciudadano_ids) == 1:
            informe_al_ciudadano = informe_cabecera.informe_al_ciudadano_ids[-1]
            photos = informe_cabecera.photo_ids
        en_que_se_trabaja = False
        if (
            informe_al_ciudadano
            and informe_al_ciudadano.ciudadano_avances_por_meta_fisica_ids
        ):
            for (
                reporte_meta_fisica
            ) in informe_al_ciudadano.ciudadano_avances_por_meta_fisica_ids:
                if reporte_meta_fisica.avance:
                    en_que_se_trabaja = True
        hay_videos = False
        for photo in informe_cabecera.proyecto_id.photo_ids:
            if photo.url:
                hay_videos = True

        # informe_cabecera.proyecto_id.meta_ids
        metas_fisicas = []
        aux_acumulado_cantidad = {}
        #
        for meta_fisica in informe_cabecera.proyecto_id.meta_ids:
            if meta_fisica.tipo_id in aux_acumulado_cantidad:
                aux_acumulado_cantidad[meta_fisica.tipo_id] += meta_fisica.cantidad
                for meta in metas_fisicas:
                    if meta["name"] == meta_fisica.tipo_id.name:
                        meta["cantidad"] = aux_acumulado_cantidad[meta_fisica.tipo_id]
            else:
                aux_acumulado_cantidad[meta_fisica.tipo_id] = meta_fisica.cantidad
                metas_fisicas.append(
                    {
                        "name": meta_fisica.tipo_id.name,
                        "cantidad": meta_fisica.cantidad,
                        "uom_id": meta_fisica.tipo_id.uom_id.name,
                    }
                )

        # Llamar a la función para obtener el resumen
        resumen_datos = self.get_resumen_proyecto(informe_cabecera.proyecto_id)

        datos = {
            "informe_cabecera": informe_cabecera,
            "punto_crea": punto_crea,
            "numero_contrato": numero_contrato,
            "codigo_frente": codigo_frente,
            "informe_al_ciudadano": informe_al_ciudadano,
            "photos": photos,
            "hay_videos": hay_videos,
            "en_que_se_trabaja": en_que_se_trabaja,
            "mostrar_imprimir": (
                (kwargs.get("mostrar_boton_imprimir", False) and "mostrar")
                or "no_mostrar_imprimir"
            ),
            "metas_fisicas": metas_fisicas,
            "resumen": resumen_datos,  # Agregar el resumen a los datos
        }
        # Imprimir el resumen
        print("Resumen del proyecto:")
        print(datos["resumen"])
        return request.website.render(
            "website_visor_proyectos_idu.visor_proyectos_index",
            datos,
        )


def fix_numero_contrato(numero_contrato):
    prefix, codigo, anio = numero_contrato.split("-")
    numero = int(codigo)
    numero_contrato = "IDU-{}-{}".format(numero, anio)
    return numero_contrato
