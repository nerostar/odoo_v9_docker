{
    'name': 'Website del visor de proyectos',
    'version': '1.0',
    'depends': [
        'base',
        'website',
        'pqrs_website_idu'
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
        'views/main_templates.xml',
    ],
    'installable': True,
    'description': """
Sitio Web del visor de proyectos
    """,
}