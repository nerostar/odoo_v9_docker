# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from datetime import date, timedelta
from openerp import models, fields, api
from openerp.exceptions import ValidationError
import logging

PROBLEMA_ESTADOS = [
    ('nuevo', 'En Curso'),
    ('cerrado', 'Solucionada'),
]
PROBLEMA_ESTADOS_LABELS = dict(PROBLEMA_ESTADOS)

_logger = logging.getLogger(__name__)

def enviar_mensaje_con_plantilla(objeto, contexto, plantilla):
    try:
        objeto.with_context(contexto).message_post_with_template(plantilla.id,
            notify=True,
            composition_mode='mass_mail'
            )
    except Exception, e:
        _logger.error('No se pudo enviar el mensaje a los destinatarios, por favor verifique que estos tengan una dirección válida de email.')
        _logger.exception(e)

def url_vista_boton(objeto):
        """Retorna la info para hacer el link al registro, es utilizado en los mail templates"""
        url = objeto._notification_link_helper('view')
        return url

def es_dia_habil():  # De Lunes = 0 a Viernes = 4, se asumen dias habiles. Sabado = 5 y Domingo = 6, No son habiles
    return date.today().weekday() < 5

class project_problema(models.Model):
    _name = 'project.problema'
    _description = 'Problemas en Proyectos'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Asunto',
        required=False,
        size=255,
        compute='_compute_name',
        store=True,
    )
    state = fields.Selection(
        string='Estado',
        required=True,
        track_visibility='onchange',
        selection=PROBLEMA_ESTADOS,
        default='nuevo',
    )
    project_id = fields.Many2one(
        string='Proyecto o Etapa',
        required=True,
        readonly=True,
        track_visibility='onchange',
        comodel_name='project.project',
        ondelete='restrict',
        default=lambda self: self._context.get('project_id', self.env['project.project'].browse()),
    )
    contrato_id = fields.Many2one(
        string='Contrato',
        required=False,
        track_visibility='onchange',
        comodel_name='contrato.contrato',
        ondelete='restrict',
        readonly=True,
        states={
            'nuevo': [('readonly', False)],
            'abierto': [('readonly', False)],
            'devuelto': [('readonly', False)],
            'en_progreso': [('readonly', False)],
            'por_revisar': [('readonly', False)],
        }
    )
    user_id = fields.Many2one(
        string='Responsable',
        required=True,
        track_visibility='onchange',
        comodel_name='res.users',
        ondelete='restrict',
        default=lambda self: self._context.get('uid', False),
        readonly=True,
        states={
            'abierto': [('readonly', False)],
            'en_progreso': [('readonly', False)],
            'nuevo': [('readonly', False)],
            'devuelto': [('readonly', False)],
            'por_revisar': [('readonly', False)],
        }
    )
    tipo_id = fields.Many2one(
        string='Categoría',
        required=True,
        track_visibility='onchange',
        comodel_name='project.problema.tipo',
        ondelete='restrict',
        domain="[('parent_id','=',False)]",
        readonly=True,
        states={
            'abierto': [('readonly', False)],
            'nuevo': [('readonly', False)],
            'devuelto': [('readonly', False)],
            'por_revisar': [('readonly', False)],
            'en_progreso': [('readonly', False)],
        }
    )
    subtipo_id = fields.Many2one(
        string='Sub Categoría',
        required=True,
        track_visibility='onchange',
        comodel_name='project.problema.tipo',
        ondelete='restrict',
        domain="[('parent_id','=',tipo_id)]",
        readonly=True,
        states={
            'abierto': [('readonly', False)],
            'nuevo': [('readonly', False)],
            'devuelto': [('readonly', False)],
            'por_revisar': [('readonly', False)],
            'en_progreso': [('readonly', False)],
        }
    )
    tarea_ids = fields.One2many(
        string='Compromisos/Tareas',
        required=False,
        comodel_name='project.task',
        inverse_name='problema_id',
        ondelete='restrict',
        readonly=True,
        states={
            'abierto': [('readonly', False)],
            'en_progreso': [('readonly', False)],
            'nuevo': [('readonly', False)],
            'devuelto': [('readonly', False)],
            'por_revisar': [('readonly', False)],
        }
    )
    fecha_maxima_solucion = fields.Date(
        string='Fecha Máxima de Solución',
        required=True,
        track_visibility='onchange',
        help='''Fecha máxima para la resolución del problema sin afectar el proyecto''',
        default=fields.Date.today,
        readonly=True,
        states={
            'nuevo': [('readonly', False)],
            'devuelto': [('readonly', False)],
            'por_revisar': [('readonly', False)],
        }
    )
    afecta_cronograma_proyecto = fields.Boolean(
        string='Afecta Cronograma del Proyecto?',
        required=False,
        track_visibility='onchange',
        default=False,
        readonly=True,
        states={
            'abierto': [('readonly', False)],
            'en_progreso': [('readonly', False)],
            'nuevo': [('readonly', False)],
            'devuelto': [('readonly', False)],
            'por_revisar': [('readonly', False)],
        }
    )
    afecta_costo_proyecto = fields.Boolean(
        string='Afecta Costos del Proyecto?',
        required=False,
        track_visibility='onchange',
        default=False,
        readonly=True,
        states={
            'abierto': [('readonly', False)],
            'en_progreso': [('readonly', False)],
            'nuevo': [('readonly', False)],
            'devuelto': [('readonly', False)],
            'por_revisar': [('readonly', False)],
        }
    )
    descripcion = fields.Text(
        string='Descripción',
        track_visibility='onchange',
        required=False,
        readonly=True,
        states={
            'abierto': [('readonly', False)],
            'en_progreso': [('readonly', False),('required',True)],
            'nuevo': [('readonly', False),('required',True)],
            'devuelto': [('readonly', False)],
            'por_revisar': [('readonly', False)],
        }
    )
    impacto = fields.Text(
        string='Impacto',
        track_visibility='onchange',
        required=False,
        readonly=True,
        states={
            'abierto': [('readonly', False)],
            'en_progreso': [('readonly', False),('required',True)],
            'nuevo': [('readonly', False),('required',True)],
            'devuelto': [('readonly', False)],
            'por_revisar': [('readonly', False)],
        }
    )
    gestion = fields.Text(
        string='Gestión',
        track_visibility='onchange',
        readonly=True,
    )
    justificacion = fields.Text(
        string='Justificación',
        track_visibility='onchange',
        readonly=True,
    )
    # -------------------
    # methods
    # -------------------

    @api.multi
    def validar_autorizacion(self):
        autorizado = False
        if self.env.uid == 1 or self.env.user.has_group('project.group_project_manager'):
            autorizado = True
        else:
            proyecto = self.proyecto_id
            if not proyecto:
                contexto = self.env.context
                proyecto_id = contexto.get('proyecto_id',False)
                proyecto_model = self.env['project_obra.proyecto']
                proyecto = proyecto_model.search([('id','=',proyecto_id)])
            if proyecto:
                etapas = proyecto.etapa_ids
                for etapa in etapas:
                    for contrato in etapa.contrato_ids:
                        for coordinador in contrato.coordinador_ids:
                            if self.env.uid == coordinador.user_id.id:
                                autorizado = True
                                break
        return autorizado

    @api.model
    def create(self, vals):
        if not self.validar_autorizacion():
            raise ValidationError("Usted no esta autorizado para crear este registro")
        novedad = super(project_problema, self).create(vals)
        if novedad.user_id and novedad.project_id:
            plantilla = self.env.ref('project_problemas_idu.plantilla_asignacion_novedades')
            ctx = self.env.context.copy()
            boton = {
                'titulo':'Ir a la Novedad',
                'url': url_vista_boton(novedad),
                }
            ctx.update({'boton' : boton})
            enviar_mensaje_con_plantilla(novedad, ctx, plantilla)
        return novedad

    @api.one
    def write(self, vals):
        if not self.validar_autorizacion():
            raise ValidationError("Usted no esta autorizado para modificar este registro")
        return super(project_problema, self).write(vals)

    @api.one
    @api.depends('tipo_id', 'subtipo_id', 'state')
    def _compute_name(self):
        self.name = '{} / {} ({})'.format(self.tipo_id.name, self.subtipo_id.name, PROBLEMA_ESTADOS_LABELS[self.state])

    @api.one
    @api.constrains('contrato_id')
    def _check_contrato_id(self):
        if self.contrato_id and not self.contrato_id.id in self.project_id.contrato_ids.ids:
            raise ValidationError("El contrato no esta asociado al proyecto '{}'. Por favor intentelo nuevamente.".format(self.project_id.name))

    @api.one
    @api.constrains('subtipo_id')
    def _check_subtipo_id(self):
        if self.subtipo_id and self.subtipo_id.parent_id.id != self.tipo_id.id:
            raise ValidationError("La sub-categoría no esta asociado a la categoría seleccionada.")

    @api.onchange('project_id')
    def _onchange_project_id(self):
        return {
            'domain': {
                'contrato_id': [
                    ('id', 'in', self.project_id.contrato_ids.ids)
                ],
            }
        }

    @api.onchange('contrato_id')
    def _onchange_contrato_id(self):
        try:
            self._check_contrato_id()
            return {
                'domain': {
                    'contrato_id': [
                        ('id', 'in', self.project_id.contrato_ids.ids)
                    ],
                }
            }
        except Exception as e:
            self.contrato_id = False
            return {
                'title': "Error de Validación",
                'warning': {'message': e.name},
                'domain': {
                    'contrato_id': [
                        ('id', 'in', self.project_id.contrato_ids.ids)
                    ],
                }
            }

    @api.onchange('tipo_id')
    def _onchange_tipo_id(self):
        self.subtipo_id = False

    @api.model
    def novedad_a_vencerse_cron(self, dias_vencimiento):
        if es_dia_habil():
            plazo_maximo = timedelta(days=dias_vencimiento)
            hoy = date.today()
            fecha_notificacion = fields.Date.to_string(hoy - plazo_maximo)
            novedades = self.search([
                ('state', 'not in', ['cancelado', 'cerrado']),
                ('fecha_maxima_solucion', '<', fecha_notificacion),
            ])
            for novedad in novedades:
                fecha_maxima = fields.Date.from_string(novedad.fecha_maxima_solucion)
                plantilla = self.env.ref('project_problemas_idu.plantilla_vencimiento_novedades')
                ctx = self.env.context.copy()
                datos = {
                    'dias_restantes': (hoy - fecha_maxima).days,
                }
                boton = {
                    'titulo':'Ir a la Novedad',
                    'url': url_vista_boton(novedad),
                    }

                ctx.update({'boton' : boton, 'datos' : datos})
                enviar_mensaje_con_plantilla(novedad, ctx, plantilla)
            return True

    # -------------------
    # Workflow methods
    # -------------------
    @api.one
    def reiniciar_workflow(self):
        self.create_workflow()
        return True

    def wkf_nuevo(self):
        self.state = 'nuevo'

    def wkf_por_revisar(self):
        self.state = 'por_revisar'

    def wkf_abierto(self):
        self.state = 'nuevo'

    def wkf_devuelto(self):
        self.state = 'devuelto'

    def wkf_en_progreso(self):
        self.state = 'nuevo'

    def wkf_cancelado(self):
        self.state = 'cancelado'

    def wkf_cerrado(self):
        self.state = 'cerrado'

    @api.one
    def estado_a_cerrado(self):
        self.state = 'cerrado'

class project_problema_tipo(models.Model):
    _name = 'project.problema.tipo'
    _description = 'Tipo de Problemas de Proyectos'
    _inherit = ['models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        size=255,
    )
    parent_id = fields.Many2one(
        string='Categoría Padre',
        required=False,
        comodel_name='project.problema.tipo',
        ondelete='restrict',
        default=lambda self: self._context.get('parent_id', self.env['project.problema.tipo'].browse()),
    )
    area_responsable_id = fields.Many2one(
        string='Área Responsable de Solución',
        required=False,
        comodel_name='hr.department',
        ondelete='restrict',
    )
    entidad_externa_id = fields.Many2one(
        string='Entidad Externa Involucrada',
        required=False,
        comodel_name='res.partner',
        ondelete='restrict',
    )
    usuario_apoyo_ids = fields.Many2many(
        string='Equipo de apoyo',
        required=False,
        comodel_name='res.users',
        ondelete='restrict',
        help='''Funcionarios que apoyan a la atención y resolución de este tipo de problema''',
    )

    _sql_constraints = [
        ('unique_name', 'unique(name)', 'Este name ya está registrado'),
    ]

    # -------------------
    # methods
    # -------------------

class project_project(models.Model):
    _name = 'project.project'
    _inherit = ['project.project']

    # -------------------
    # Fields
    # -------------------
    problema_ids = fields.One2many(
        string='Novedades',
        required=False,
        comodel_name='project.problema',
        inverse_name='project_id',
        ondelete='restrict',
    )
    usa_problemas = fields.Boolean(
        string='Usar Novedades',
        required=False,
        default=False,
    )

    # -------------------
    # methods
    # -------------------
    @api.multi
    def problema_view_button(self):
        return {
            'name': 'Problemas',
            'res_model': 'project.problema',
            'domain': [('project_id', '=', self.id)],
            'context': {'project_id': self.id, 'display_parent_name': True},
            'type': 'ir.actions.act_window',
            'view_mode': 'tree,form',
            'view_type': 'form',
        }

    @api.multi
    def get_consolidado_problemas_por_tipo_vs_estado(self, tipos=None, estados=None, liquidacion=False):
        """Retorna diccionario que clasifica los problemas por tipo vs estado.
        Recibe opcionalmente in recordlist de tipos de problemas a desplegar y un listado de tuplas de los estados a desplegar

        TODO: Se puede cambiar en el futuro a hacer un SQL query para obtener el consolidado directamente, posiblemente más rápido.
        """
        if len(self.problema_ids) == 0:
            return {}

        if not tipos:
            dominio = [('parent_id', '=', False)]
            tipos = self.env['project.problema.tipo'].search(dominio)  # Solo Categorías Raíz
        if not estados:
            estados = list(map(lambda x: x[0], PROBLEMA_ESTADOS))
        tipo_nombres = tipos.mapped('name')  # Listado de nombres
        res = { t: dict.fromkeys(estados, 0) for t in tipo_nombres }
        soluciones = self.problema_ids
        if liquidacion:
            soluciones = self.with_context({'filtrar_problema_tipo_liquidacion':True}).problema_ids
        for prob in soluciones:
            if prob.state in estados:
                res[prob.tipo_id.name][prob.state] += 1
        return res

class project_task(models.Model):
    _name = 'project.task'
    _inherit = ['project.task']

    # -------------------
    # Fields
    # -------------------
    problema_id = fields.Many2one(
        string='Atiende la Novedad',
        required=False,
        comodel_name='project.problema',
        ondelete='restrict',
        help='''Indica cual es la novedad relacionada a esta tarea''',
        default=lambda self: self._context.get('problema_id', self.env['project.problema'].browse()),
        domain="[('state','in',['abierto', 'en_progreso'])]",
    )

    # -------------------
    # methods
    # -------------------
    @api.model
    def create(self, vals):
        tarea = super(project_task, self).create(vals)

        if tarea.user_id and tarea.problema_id:
            plantilla = self.env.ref('project_problemas_idu.plantilla_asignacion_tareas')
            ctx = self.env.context.copy()
            boton = {
                'titulo':'Ir a la Tarea',
                'url': url_vista_boton(tarea),
                }
            datos = {
                "proyecto":tarea.problema_id.project_id.name,
                }
            ctx.update({'boton' : boton, 'datos':datos})
            enviar_mensaje_con_plantilla(tarea, ctx, plantilla)
        return tarea

    @api.model
    def acciones_a_vencerse_en_problema_cron(self, dias_vencimiento):
        if es_dia_habil():
            plazo = timedelta(days=dias_vencimiento)
            hoy = date.today()
            plazo_max = fields.Date.to_string(hoy - plazo)
            tareas = self.search([
                ('problema_id.state', 'not in', ['cerrado', 'cancelado']),
                ('fecha_fin', '<', plazo_max),
                ('progreso', '<', 100),
            ])  # Solo devuelve las tareas vencidas

            for tarea in tareas:
                fecha_maxima = fields.Date.from_string(tarea.fecha_fin)
                plantilla = self.env.ref('project_problemas_idu.plantilla_vencimiento_tareas')
                ctx = self.env.context.copy()
                datos = {
                    'dias_atraso': (hoy - fecha_maxima).days,
                }
                boton = {
                    'titulo':'Ir a la Novedad',
                    'url': url_vista_boton(tarea.problema_id),
                    }
                ctx.update({'boton' : boton, 'datos':datos})
                enviar_mensaje_con_plantilla(tarea, ctx, plantilla)