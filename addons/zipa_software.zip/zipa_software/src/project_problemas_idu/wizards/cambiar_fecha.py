# -*- coding: utf-8 -*-

from openerp import models, fields, api

class proyecto_problema_idu_wizard_cambiar_fecha(models.TransientModel):
    _name = 'proyecto_problema.wizard.cambiar_fecha'

    # Fields
    justificacion = fields.Text(
        string='Justificación del Cambio',
        required=True,
        track_visibility='onchange',
    )
    fecha_maxima_solucion = fields.Date(
        string='Nueva Fecha',
        required=True,
    )

    @api.multi
    def cambiar_fecha(self):
        id_problema = self.env.context.get('active_id', False)
        problema_proyecto_model = self.env['project.problema']
        registro = problema_proyecto_model.search([('id', '=', id_problema)])
        fecha_anterior = registro.fecha_maxima_solucion
        registro.write({
            'fecha_maxima_solucion': self.fecha_maxima_solucion,
            'justificacion': self.justificacion,
            })
        self.env['mail.message'].create({
            'res_id': id_problema,
            'model': 'project.problema',
            'subject': "Cambio en la fecha máxima de solución de la novedad",
            'type': 'comment',
            'body': "Se ha cambiado la fecha máxima de solución de la novedad de {} a {}, la justificación para el cambio es:\n\n{}".format(
                fecha_anterior,
                self.fecha_maxima_solucion,
                self.justificacion
            ),
        }).id
        return {'type': 'ir.actions.act_window_close'}
