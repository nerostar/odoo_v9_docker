# -*- coding: utf-8 -*-

from openerp import models, fields, api

class proyecto_problema_idu_wizard_agregar_gestion(models.TransientModel):
    _name = 'proyecto_problema.wizard.agregar_gestion'

    # Fields
    gestion = fields.Text(
        string='Gestión',
        required=True,
        track_visibility='onchange',
    )

    @api.multi
    def agregar_gestion(self):
        id_problema = self.env.context.get('active_id', False)
        problema_proyecto_model = self.env['project.problema']
        registro = problema_proyecto_model.search([('id', '=', id_problema)])
        registro.write({
            'gestion': self.gestion,
        })
        return {'type': 'ir.actions.act_window_close'}
