# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_project_problema(common.TransactionCase):
    def test_crud_validaciones(self):
        problema_model = self.env['project.problema']
        vals = {
            'name': "Animi molestiae totam quis iste quidem.",
            'state': "cerrado",
            'project_id': self.ref('project_problemas_idu.project_id_01'),
            'contrato_id': self.ref('project_problemas_idu.contrato_id_01'),
            'user_id': self.ref('project_problemas_idu.user_id_01'),
            'tema_id': self.ref('project_problemas_idu.tema_id_01'),
            'tarea_ids': [
                (4, self.ref('project_problemas_idu.tarea_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
            'fecha_maxima_solucion': "1979-08-10",
            'afecta_cronograma_proyecto': False,
            'afecta_costo_proyecto': True,
            'descripcion': "Omnis qui officia quod adipisci repudiandae consequatur nihil.",
        }
        problema = problema_model.create(vals)

        # Campos computados

        # Campos con api.constrain
        vals_update = {
            'contrato_id': 'Valor a usarse para romper la validación',
        }
        try:
            problema.write(vals_update)
        except ValidationError, e:
            pass
        else:
            self.fail('No se generó exception de validación para "contrato_id"')


if __name__ == '__main__':
    unittest2.main()