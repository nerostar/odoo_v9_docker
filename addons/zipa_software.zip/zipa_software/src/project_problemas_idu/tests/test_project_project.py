# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_project_project(common.TransactionCase):
    def test_crud_validaciones(self):
        project_model = self.env['project.project']
        vals = {
            'problema_ids': [
                (4, self.ref('project_problemas_idu.problema_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        project = project_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()