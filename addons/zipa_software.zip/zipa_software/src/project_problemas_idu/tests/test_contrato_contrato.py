# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_contrato_contrato(common.TransactionCase):
    def test_crud_validaciones(self):
        contrato_model = self.env['contrato.contrato']
        vals = {
            'problema_ids': [
                (4, self.ref('project_problemas_idu.problema_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        contrato = contrato_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()