# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_project_problema_tipo(common.TransactionCase):
    def test_crud_validaciones(self):
        problema_tipo_model = self.env['project.problema.tipo']
        vals = {
            'name': "Eos enim corporis numquam fugit minus harum unde.",
            'area_responsable_id': self.ref('project_problemas_idu.area_responsable_id_01'),
            'entidad_externa_id': self.ref('project_problemas_idu.entidad_externa_id_01'),
            'usuario_apoyo_ids': [
                (4, self.ref('project_problemas_idu.usuario_apoyo_ids_01')),
                (0, 0, {
                    'field_name': valor,
                }),
            ],
        }
        problema_tipo = problema_tipo_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()