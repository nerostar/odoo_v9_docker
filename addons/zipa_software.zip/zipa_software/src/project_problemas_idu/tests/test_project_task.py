# -*- encoding: utf-8 -*-
import unittest2
import logging
from openerp.tests import common
from openerp.exceptions import ValidationError

logging.basicConfig()
_logger = logging.getLogger('TEST')

class Test_project_task(common.TransactionCase):
    def test_crud_validaciones(self):
        task_model = self.env['project.task']
        vals = {
            'problema_id': self.ref('project_problemas_idu.problema_id_01'),
        }
        task = task_model.create(vals)

        # Campos computados

        # Campos con api.constrain


if __name__ == '__main__':
    unittest2.main()