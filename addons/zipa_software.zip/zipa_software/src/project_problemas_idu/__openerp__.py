{
    'name': 'Gestión de Problemas y Compromisos en Proyectos IDU',
    'version': '1.0',
    'depends': [
        'base',
        'base_idu',
        'model_security',
        'project_portafolio_idu',
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'wizards/cambiar_fecha_view.xml',
        'wizards/agregar_gestion_view.xml',
        'views/project_view.xml',
        'views/contrato_view.xml',
        'workflow/problema_workflow.xml',
        'data/tareas_programadas_data.xml',
        'data/project_problemas_idu_data.xml',
    ],
    'test': [
        'tests/001_users.yml',
    ],
    'demo': [
#        'tests/001_users.yml',
    ],
    'installable': True,
    'description': """
## Dependencias módulos Python
## Configuración adicional
    """,
}
