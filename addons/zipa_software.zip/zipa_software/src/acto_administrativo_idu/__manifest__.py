{
    'name': 'ZIPA: Control Acto Administrativo Ambiental',
    'version': '1.0',
    'depends': [
        'base',
        'base_idu',
        'model_security',
    ],
    'author': "IDU STRT I+D+i",
    'category': 'IDU',
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'wizard/acto_administrativo_view.xml',
    ],
    'test': [],
    'demo': [
    ],
    'installable': True,
    'description': """
## Dependencias módulos Python
## Configuración adicional
    """,
}
