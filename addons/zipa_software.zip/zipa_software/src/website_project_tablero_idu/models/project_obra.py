# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, api, fields

class project_obra_proyecto(models.Model):
    _name = 'project_obra.proyecto'
    _inherit = ['project_obra.proyecto', 'project.dhtmlxgantt.mixin']

    _dhtmlxgantt_prefijo = 'PO' # Prefijo a utilizarse en la creación del ID
    _dhtmlxgantt_campos_map = {
        'text': 'name',
        'progress': 'progreso',
        'start_date': 'fecha_planeada_inicio',
        'end_date': 'fecha_planeada_fin',
    }
    _dhtmlxgantt_descendientes_map = {
        'project_obra.proyecto.etapa': 'etapa_ids',
    }

    @api.model
    def _dhtmlxgantt_get_tipo(self, record):
        """Función para cálcular el tipo: milestone, project, task"""
        return 'project'

    etapa_ids = fields.One2many(
        domain=[('parent_id','=',False)], # Evita que las sub etapas se listen en el proyecto como etapas
    )


class project_obra_proyecto_etapa(models.Model):
    _name = 'project_obra.proyecto.etapa'
    _inherit = ['project_obra.proyecto.etapa', 'project.dhtmlxgantt.mixin']

    _dhtmlxgantt_prefijo = 'ET' # Prefijo a utilizarse en la creación del ID
    _dhtmlxgantt_campos_map = {
        'text': 'name',
        'progress': 'progreso',
        'start_date': 'fecha_planeada_inicio',
        'end_date': 'fecha_planeada_fin',
    }
    _dhtmlxgantt_descendientes_map = {
        'project_obra.proyecto.etapa': 'child_ids',
        'project_obra.proyecto.etapa.novedad_cronograma': 'novedad_cronograma_ids',
    }

    @api.model
    def _dhtmlxgantt_get_tipo(self, record):
        """Función para cálcular el tipo: milestone, project, task"""
        return 'task'

class project_obra_proyecto_etapa_novedad_cronograma(models.Model):
    _name = 'project_obra.proyecto.etapa.novedad_cronograma'
    _inherit = ['project_obra.proyecto.etapa.novedad_cronograma', 'project.dhtmlxgantt.mixin']

    _dhtmlxgantt_prefijo = 'NC' # Prefijo a utilizarse en la creación del ID
    _dhtmlxgantt_campos_map = {
        'text': 'name',
        #'progress': 'progreso',
        'start_date': 'fecha_inicio',
        'end_date': 'fecha_fin',
    }
    _dhtmlxgantt_descendientes_map = {
    }

    @api.model
    def _dhtmlxgantt_get_tipo(self, record):
        """Función para cálcular el tipo: milestone, project, task"""
        return 'task'

class project_obra_reporte_desempeno_manual(models.Model):
    _name = 'project_obra.reporte_desempeno_manual'
    _inherit = ['project_obra.reporte_desempeno_manual']

    @api.multi
    def get_dtmlxgantt_data(self, nivel_profundidad=None):
        """Retorna la estructura para desplegar la EDT y tareas en el formato requerido por dhmtlxgantt
        nivel_profundidad=Indica el nivel de profundidad a incluir
        """
        res = self.edt_id.get_dtmlxgantt_data(nivel_profundidad)
        return res
