# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from openerp import models, fields, api


class config_settings(models.TransientModel):
    _name = 'project.tablero.config'

    def get_default_fecha_corte_ini(self):
        key = 'project.tablero.fecha_corte_ini'
        fieldname = 'fecha_corte_ini'
        return self._get(key)

    def get_default_fecha_corte_fin(self):
        key = 'project.tablero.fecha_corte_fin'
        fieldname = 'fecha_corte_fin'
        return self._get(key)

    fecha_corte_ini = fields.Date(
        string="Fecha de Corte Inicial",
        help="Fecha de corte a mostrar en el tablero de proyectos - Inicial",
        default=get_default_fecha_corte_ini,
    )
    fecha_corte_fin = fields.Date(
        string="Fecha de Corte Final",
        help="Fecha de corte a mostrar en el tablero de proyectos - Fin",
        default=get_default_fecha_corte_fin,
    )

    def execute(self, cr, uid, ids, context=None):
        if context is None:
            context = {}

        context = dict(context, active_test=False)
        # other fields: execute all methods that start with 'set_'
        for method in dir(self):
            if method.startswith('set_'):
                getattr(self, method)(cr, uid, ids, context)

    def _set(self, key, fieldname, cr, uid, ids, context):
        param_ids = self.pool.get('ir.config_parameter').search(cr, uid,
            [('key','=',key)],
            context=context,
        )
        for form in self.browse(cr, uid, ids, context=context):
            value = getattr(form, fieldname)
            if not value:
                continue

            if len(param_ids):
                self.pool.get('ir.config_parameter').write(cr, 1, param_ids, {
                    'value': value,
                })
            else:
                self.pool.get('ir.config_parameter').create(cr, 1, {
                    'key': key,
                    'value': value,
                })

    def _get(self, key):
        value = self.env['ir.config_parameter'].get_param(key)
        return value

    def set_fecha_corte_ini(self, cr, uid, ids, context):
        key = 'project.tablero.fecha_corte_ini'
        fieldname = 'fecha_corte_ini'
        return self._set(key, fieldname, cr, uid, ids, context)

    def set_fecha_corte_fin(self, cr, uid, ids, context):
        key = 'project.tablero.fecha_corte_fin'
        fieldname = 'fecha_corte_fin'
        return self._set(key, fieldname, cr, uid, ids, context)
