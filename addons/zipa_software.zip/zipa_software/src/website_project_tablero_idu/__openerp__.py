{
    'name': 'Tablero Seguimiento a Proyectos',
    'version': '1.0',
    'depends': [
        'base',
        'website',
        'website_base_idu',
        'website_dhtmlxgantt',
        'project_edt_idu',
        'project_portafolio_idu',
        'project_obra_portafolio_idu',
        'website_project_idu',
        'project_obra_seguimiento_dtc',
        'project_obra_seguimiento_idu',
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
        'views/main_templates.xml',
        'views/demo_templates.xml',
        'views/datos_financieros_template.xml',
        'views/datos_predios_template.xml',
        'views/project_templates.xml',
        'views/project_obra_templates.xml',
        'views/project_view.xml',
        'views/config_view.xml',
        'views/contrato_info.xml',
    ],
    'installable': True,
    'description': """
Sitio Web para el tablero de proyectos del IDU
    """,
}

