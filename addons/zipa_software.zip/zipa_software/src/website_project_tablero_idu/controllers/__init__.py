from openerp.addons.website_base_idu.controllers import Controller

class zipa_controller(Controller):
    _sistema_nombre = 'ZIPA'
    _sistema_uri_base = '/zipa'
    _sistema_uri_logo = '/website_project_idu/static/src/images/logo.png'
    _breadcrumbs = None

import main
import project
import project_obra
import demo
