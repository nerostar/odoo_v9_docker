# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp.addons.web import http
from openerp.addons.web.http import request
from openerp.addons.website_project_tablero_idu.controllers import zipa_controller

class controller(zipa_controller):
    @http.route(['/zipa/tablero'], type='http', auth="user", website=True)
    def tablero_index(self, **kwargs):
        fecha_ini = request.env['ir.config_parameter'].get_param('project.tablero.fecha_corte_ini')
        fecha_fin = request.env['ir.config_parameter'].get_param('project.tablero.fecha_corte_fin')
        datos = {
            'title': 'Seguimiento a Proyectos de Infraestructura',
            'additional_title': 'Desempeño por Etapas al '+ fecha_fin,
        }
        etapa_model = request.env['project_obra.proyecto.etapa']
        etapas = etapa_model.search([
            ('state','in',['open', 'pending']),
            ('parent_id','=',False),
        ])
        datos['variaciones'] = etapas.get_datos_desempeno_al_corte(fecha_ini, fecha_fin)
        datos['tipo_etapas'] = datos['variaciones'].keys()

        return request.website.render(
            "website_project_tablero_idu.tablero_index",
            self.get_datos_website(datos),
        )

    @http.route(['/zipa/tablero/legacy'], type='http', auth="user", website=True)
    def tablero_legacy_index(self, **kwargs):
        url = kwargs['redirect']
        datos = {
            'title': 'Tablero ZIPA',
            'url': url,
        }
        return request.website.render(
            "website_project_tablero_idu.tablero_legacy_index",
            datos
        )
