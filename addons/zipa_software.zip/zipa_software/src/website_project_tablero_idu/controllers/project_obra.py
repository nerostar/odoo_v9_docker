# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import fields
from openerp.addons.web import http
from openerp.addons.web.http import request
from openerp.addons.website.models.website import slug
from openerp.addons.website_project_tablero_idu.controllers import zipa_controller
from openerp.addons.website_project_idu.controllers.main import get_datos_indicadores_project
from openerp.addons.project_problemas_idu.models.project import PROBLEMA_ESTADOS, PROBLEMA_ESTADOS_LABELS

from openerp.addons.web.controllers.main import serialize_exception,content_disposition
import base64

class controller(zipa_controller):
    def __init__(self, *args, **kw):
        super(controller, self).__init__(*args, **kw)
        self._breadcrumbs = [
            {'url': '/zipa/tablero', 'label': 'Tablero de Proyectos'},
        ]

    @http.route(['/zipa/tablero/obra/<model("project_obra.proyecto"):proyecto>'], type='http', auth="user", website=True)
    def project_obra_proyecto_index(self, proyecto=None, **kwargs):
        problemas_estados = ['nuevo','cerrado']
        datos = {
            'title': proyecto.name,
            'proyecto': proyecto,
            'project': proyecto.project_id,
            'content_css_class': 'invoice',
            'problemas_estados': problemas_estados,
            'problemas_estados_labels': PROBLEMA_ESTADOS_LABELS,
        }
        fecha_ini = request.env['ir.config_parameter'].get_param('project.tablero.fecha_corte_ini')
        fecha_fin = request.env['ir.config_parameter'].get_param('project.tablero.fecha_corte_fin')
        datos['fecha_corte_fin'] = fields.Date.from_string(fecha_fin).strftime('%d/%m/%Y');
        datos['etapas_abiertas'] = proyecto.etapa_ids.filtered(lambda r: r.parent_id.id == False and r.state == 'open')
        datos['variaciones'] = datos['etapas_abiertas'].get_datos_desempeno_al_corte(fecha_ini, fecha_fin)
        datos['consolidado_problemas_por_tipo_vs_estado'] = proyecto.project_id.get_consolidado_problemas_por_tipo_vs_estado(estados=problemas_estados)
        return request.website.render(
            "website_project_tablero_idu.project_obra_proyecto_index",
            self.get_datos_website(datos)
        )

    @http.route([
      '/zipa/tablero/obra/<model("project_obra.proyecto"):proyecto>/dhtmlxgantt',
    ], type='json', auth="user", website=False)
    def project_obra_proyecto_index_dhtmlxgantt(self, proyecto=None, **kwargs):
        """Retorna un diccionario en json con la configuración de tareas y relaciones para desplegar con dhtmlxgantt"""
        return proyecto.get_dtmlxgantt_data()

    @http.route(['/zipa/tablero/obra/reporte_variacion/<model("project_obra.reporte_desempeno_manual"):reporte>'], type='http', auth="user", website=True)
    def project_obra_reporte_desempeno_index(self, reporte=None, **kwargs):
        datos = {
            'title': reporte.project_id.name,
            'reporte_desempeno': reporte,
            'content_css_class': 'invoice',
        }
        return request.website.render(
            "website_project_tablero_idu.project_reporte_desempeno_index",
            self.get_datos_website(datos)
        )

    @http.route([
      '/zipa/tablero/obra/reporte_variacion/<model("project_obra.reporte_desempeno_manual"):reporte>'
    ], type='json', auth="user", website=False)
    def project_obra_reporte_desempeno_index_dhtmlxgantt(self, reporte=None, **kwargs):
        """Retorna un diccionario en json con la configuración de tareas y relaciones para desplegar con dhtmlxgantt"""
        return reporte.get_dtmlxgantt_data()

    @http.route(['/zipa/tablero/obra/<model("project_obra.proyecto"):proyecto>/linea_base/<model("project.linea_base"):linea_base>'], type='http', auth="user", website=True)
    def project_obra_linea_base_index(self, proyecto, linea_base=None, **kwargs):

        if not linea_base and len(proyecto.linea_base_ids):
            linea_base = proyecto.linea_base_ids[-1]

        datos = {
            'title': 'Cronograma Detallado',
            'proyecto': proyecto,
            'linea_base': linea_base,
            'content_css_class': 'invoice',
        }
        if linea_base.project_id.id != proyecto.project_id.id:
            raise Exception('La línea base no se relaciona con el Proyecto')

        datos['breadcrumbs'] = [
            {'label': 'Visor de Proyecto', 'url': '/zipa/tablero/obra/{}'.format(slug(datos['proyecto']))}
        ]

        return request.website.render(
            "website_project_tablero_idu.linea_base_index",
            self.get_datos_website(datos)
        )

    @http.route([
      '/zipa/tablero/obra/<model("project_obra.proyecto"):proyecto>/linea_base/<model("project.linea_base"):linea_base>/dhtmlxgantt'
    ], type='json', auth="user", website=False)
    def project_obra_linea_base_index_dhtmlxgantt(self, proyecto, linea_base, **kwargs):
        """Retorna un diccionario en json con la configuración de tareas y relaciones para desplegar con dhtmlxgantt"""
        if linea_base.project_id.id != proyecto.project_id.id:
            raise Exception('La línea base no se relaciona con el Proyecto')
        return linea_base.linea_raiz_id.get_dtmlxgantt_data()





    @http.route(['/zipa/tablero/obra/<model("project_obra.proyecto"):proyecto>/frente_obra/<model("project_obra.proyecto.frente_obra"):frente_obra>'], type='http', auth="user", website=True)
    def project_obra_frente_obra_index(self, proyecto, frente_obra, **kwargs):
        datos = {
            'title': 'Frente de Obra',
            'proyecto': proyecto,
            'frente_obra': frente_obra,
            'content_css_class': 'invoice',
        }
        if frente_obra.proyecto_id.id != proyecto.id:
            raise Exception('El frente de obra no se relaciona con el Proyecto')

        datos['breadcrumbs'] = [
            {'label': 'Visor de Proyecto', 'url': '/zipa/tablero/obra/{}'.format(slug(datos['proyecto']))}
        ]

        return request.website.render(
            "website_project_tablero_idu.frente_obra_index",
            self.get_datos_website(datos)
        )

    @http.route([
      '/zipa/tablero/obra/<model("project_obra.proyecto"):proyecto>/frente_obra/<model("project_obra.proyecto.frente_obra"):frente_obra>/dhtmlxgantt'
    ], type='json', auth="user", website=False)
    def project_obra_frente_obra_index_dhtmlxgantt(self, proyecto, frente_obra, **kwargs):
        """Retorna un diccionario en json con la configuración de tareas y relaciones para desplegar con dhtmlxgantt"""
        if frente_obra.proyecto_id.id != proyecto.id:
            raise Exception('El frente de obra no se relaciona con el Proyecto')
        return frente_obra.linea_base_linea_id.get_dtmlxgantt_data()

    @http.route(['/zipa/tablero/obra/servicio/<int:cabecera>'], type='http', auth="public", methods=['get'])
    def crear_reporte_informe_avance(self, cabecera, **kwargs):
        model_informe_avance_construccion = request.env['project_obra.construccion.informe_avance'].sudo()
        model_informe_avance_conservacion = request.env['project_obra.conservacion.informe_avance'].sudo()
        informe_avance_construccion = model_informe_avance_construccion.search([('cabecera_id','=',cabecera)])
        informe_avance_conservacion = model_informe_avance_conservacion.search([('cabecera_id','=',cabecera)])
        archivo = False
        if len(informe_avance_construccion)>0:
            wm = request.env['zipa.reporte_informe_construccion.wizard'].create({
                'mostrar_informacion_contractual': True,
                'mostrar_informacion_predial': True,
                'mostrar_informacion_desempeno': True,
                'mostrar_informacion_visor': True,
                'mostrar_metas_fisicas': True,
                'mostrar_novedades': True,
            })
            archivo = wm.crear_reporte_informe_construccion(informe_avance_construccion)
        elif len(informe_avance_conservacion)>0:
            wm = request.env['zipa.reporte_informe_conservacion.wizard'].create({
                'mostrar_informacion_contractual': True,
                'mostrar_informacion_desempeno': True,
                'mostrar_novedades': True,
            })
            archivo = wm.crear_reporte_informe_conservacion(informe_avance_conservacion)
        else:
            return request.not_found()
        filecontent = base64.b64decode(archivo.data or '')
        if not filecontent:
            return request.not_found()
        else:
            return request.make_response(filecontent,
                [
                    ('Content-Type', 'application/octet-stream'),
                    ('Content-Disposition', content_disposition(archivo.filename))
                ]
            )
