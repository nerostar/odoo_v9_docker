# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from collections import defaultdict

from openerp.addons.web import http
from openerp.addons.web.http import request
from openerp.addons.website_project_tablero_idu.controllers import zipa_controller
from openerp.addons.website.models.website import slug
from openerp.addons.project_problemas_idu.models.project import PROBLEMA_ESTADOS, PROBLEMA_ESTADOS_LABELS

class controller(zipa_controller):
    @http.route(['/zipa/tablero/<model("project.project"):project>'], type='http', auth="user", website=True)
    def tablero_project_index(self, project=None, **kwargs):
        datos = {
            'title': project.name,
            'project': project,
        }
        if project.project_padre_id:
            datos.update({
                'additional_title': project.name,
                'title': project.project_padre_id.name,
            })

        return request.website.render(
            "website_project_tablero_idu.tablero_project_index",
            self.get_datos_website(datos)
        )

    @http.route(['/zipa/tablero/<model("project.project"):project>/gestion_problemas'], type='http', auth="user", website=True)
    def tablero_project_problemas(self, project=None, **kwargs):
        datos = {
            'title': project.name,
            'additional_title': 'Gestión de Novedades',
            'project': project,
            'proyecto': request.env['project_obra.proyecto'].search([('project_id','=',project.id)], limit=1),
        }
        dominio = [('project_id','=',project.id)]
        state = kwargs.get('state', False)
        if state:
            state_list = state.split(',')
            dominio.append(('state', 'in', state_list))
            datos['additional_title'] += ' en Estado {}'.format(', '.join(PROBLEMA_ESTADOS_LABELS[x] for x in state_list))
        tipo = kwargs.get('tipo', False)
        if tipo:
            dominio.append(('tipo_id.name', '=', tipo))
            datos['additional_title'] += ' de Tipo {}'.format(tipo)
        frente_obra = kwargs.get('frente_obra', False)
        if frente_obra:
            dominio.append(('frente_obra_ids.id', '=', frente_obra))
            frente_obra_name = request.env['project.problema'].search([('id','=',frente_obra)]).name
            datos['additional_title'] += ' para el Frente {}'.format(frente_obra_name)
        filtro_estado = kwargs.get('filtro_estado', False)
        ultimo_informe = kwargs.get('ultimo_informe', False)
        if filtro_estado == 'terminado' and not ultimo_informe:
            datos['problemas'] = request.env['project.problema'].with_context({'filtrar_problema_tipo_liquidacion':True}).search(dominio)
        else:
            datos['problemas'] = request.env['project.problema'].search(dominio)
        datos['breadcrumbs'] = [
            {'label': 'Visor de Proyecto', 'url': '/zipa/tablero/obra/{}'.format(slug(datos['proyecto']))}
        ]
        model_mail = request.env['mail.tracking.value']
        gestiones = model_mail.search([
            ('field','=','gestion'),
            ('mail_message_id.model','=','project.problema'),
            ('mail_message_id.res_id','in',datos['problemas'].ids),
        ],order='mail_message_id DESC')
        fechas_maximas__justificaciones = model_mail.search([
            ('field','in',['justificacion','fecha_maxima_solucion']),
            ('mail_message_id.model','=','project.problema'),
            ('mail_message_id.res_id','in',datos['problemas'].ids),
        ],order='mail_message_id DESC')
        fechas_maximas__justificaciones_list = defaultdict(list)
        contador = 0
        omitir_siguiente = False
        for fecha_maxima__justificacion in fechas_maximas__justificaciones:
            if not omitir_siguiente:
                if (len(fechas_maximas__justificaciones) != contador+1) and (fecha_maxima__justificacion.mail_message_id == fechas_maximas__justificaciones[contador+1].mail_message_id):
                    fecha = {
                        'id': fecha_maxima__justificacion.mail_message_id.res_id,
                        'justificacion': fechas_maximas__justificaciones[contador+1].new_value_text,
                        'fecha_maxima_anterior': fecha_maxima__justificacion.new_value_datetime,
                    }
                    omitir_siguiente = True
                else:
                    fecha = {
                        'id': fecha_maxima__justificacion.mail_message_id.res_id,
                        'justificacion': False,
                        'fecha_maxima_anterior': False,
                    }
                if not fecha['id'] in fechas_maximas__justificaciones_list:
                    fechas_maximas__justificaciones_list[fecha['id']] = []
                if fecha['justificacion']:
                    fechas_maximas__justificaciones_list[fecha['id']].append(fecha)
            else:
                omitir_siguiente = False
            contador += 1
        datos['gestiones'] = gestiones
        datos['fechas'] = fechas_maximas__justificaciones_list
        return request.website.render(
            "website_project_tablero_idu.tablero_project_gestion_problemas_index",
            self.get_datos_website(datos)
        )
