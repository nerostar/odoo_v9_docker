{
    "name": "Project Obra Portafolio Servicio IDU",
    "version": "1.0",
    "summary": "Módulo para exponer API para consumir valores de tipos de etapas de proyectos.",
    "description": """
        Este módulo expone una API para consumir los valores del modelo 'project_obra.proyecto.etapa.tipo'.
    """,
    "author": "Johannes Moreno",
    "category": "Tools",
    "depends": ["base", "project_obra_portafolio_idu"],
    "data": [
        "views/project_obra_portafolio_servicio_idu.xml",
    ],
    "demo": [],
    "installable": True,
    "icon": "./static/description/icon.png",
}
