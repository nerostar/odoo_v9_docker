{
    'name': 'Materiales, RCD y MAGCR',
    'version': '1.0',
    'depends': [
        'base',
        'base_idu',
        'contrato_idu',
        'model_security',
    ],
    'author': "IDU STRT I+D+i",
    'category': 'IDU',
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'wizards/importar_informe_view.xml',
        'wizards/cargar_plantilla_view.xml',
        'views/aprovechamiento_material_view.xml',
        'views/aprovechamiento_material_view_personalizada.xml',
        'workflow/control_workflow.xml',
        'workflow/informe_workflow.xml',
        'workflow/proveedor_workflow.xml',
        'workflow/categoria_workflow.xml',
        'workflow/sitio_aprovechamiento_workflow.xml',
        'workflow/actividad_constructiva_workflow.xml',
        'workflow/sitio_origen_workflow.xml',
    ],
    'test': [],
    'demo': [
    ],
    'installable': True,
    'description': """
## Dependencias módulos Python
## Configuración adicional
    """,
}

