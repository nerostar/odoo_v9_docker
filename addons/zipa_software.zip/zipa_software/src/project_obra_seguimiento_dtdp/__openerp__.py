{
    'name': 'Proyectos Obra Predios',
    'version': '1.0',
    'depends': [
        'base',
        'base_idu',
        'model_security',
        'project_obra_portafolio_idu',
        'project_obra_seguimiento_idu',
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/project_obra_view.xml',
        'wizards/importar_datos_predios_xls_view.xml',
    ],
    'test': [],
    'demo': [],
    'installable': True,
    'description': """
Modulo para cargar información de Proyectos de Predios.
""",
}

