# -*- coding: utf-8 -*-
##############################################################################
#
#    Grupo de Investigación, Desarrollo e Innovación I+D+I
#    Subdirección de Recursos Tecnológicos - STRT
#    INSTITUTO DE DESARROLLO URBANO - BOGOTA (COLOMBIA)
#    Copyright (C) 2015 IDU STRT I+D+I (http://www.idu.gov.co/)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api
from openerp.exceptions import ValidationError


class project_obra_predios_informe_avance(models.Model):
    _name = 'project_obra.predios.informe_avance'
    _description = 'Informe Avance Proyecto de Predios'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        track_visibility='onchange',
        size=50,
        compute='_compute_name',
    )
    fecha_inicio = fields.Date(
        string='Fecha Inicio',
        required=True,
        help='Periodo de reporte Fecha Inicio'
    )
    fecha_fin = fields.Date(
        string='Fecha Fin',
        required=True,
        help='Periodo de reporte Fecha Fin'
    )
    user_id = fields.Many2one(
        string='Autor',
        required=True,
        track_visibility='onchange',
        comodel_name='res.users',
        ondelete='restrict',
        default=lambda self: self._context.get('uid', False),
    )
    archivo = fields.Binary(
        string='Archivo con Reporte',
        track_visibility='onchange',
        attachment=True,
    )
    archivo_filename = fields.Char(
        string='Archivo',
    )
    detalle_ids = fields.One2many(
        string='Detalle de Predios',
        comodel_name='project_obra.predios.informe_avance.detalle_predio',
        inverse_name='project_obra_predios_informe_avance_id',
        ondelete='restrict',
    )


    # -------------------
    # methods
    # -------------------
    @api.one
    def _compute_name(self):
        self.name = 'Avance_{}_{}'.format(self.user_id.name, self.id)

class project_obra_predios_informe_avance_detalle_predio(models.Model):
    _name = 'project_obra.predios.informe_avance.detalle_predio'
    _description = 'Detalle Informe Avance Proyecto de Predios'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        track_visibility='onchange',
        size=50,
        compute='_compute_name',
    )
    project_obra_predios_informe_avance_id = fields.Many2one(
        string='Avance Informe Proyecto Predios',
        track_visibility='onchange',
        comodel_name='project_obra.predios.informe_avance',
    )
    proyecto_id = fields.Many2one(
        string='Proyecto',
        required=True,
        track_visibility='onchange',
        comodel_name='project_obra.proyecto',
        ondelete='restrict',
    )
    rt = fields.Char(
        string='RT',
        size=10,
    )
    categoria_id = fields.Many2one(
        string='Categoría',
        track_visibility='onchange',
        comodel_name='project_obra.predios.categoria',
    )
    estado_id = fields.Many2one(
        string='Estado',
        track_visibility='onchange',
        comodel_name='project_obra.predios.estado',
    )
    fecha_estimada_entrega = fields.Date(
        string='Fecha Estimada de Entrega',
    )
    cantidad_unidades_sociales = fields.Integer(
        string='Cantidad de Unidades Sociales'
    )
    observaciones = fields.Text(
        string='Observaciones',
    )
    valor_estimado_predios = fields.Float(
        string='Valor Estimado Predios',
    )
    valor_ejecutado_predios = fields.Float(
        string = 'Valor Ejecutado Predios',
    )
    valor_girado_predios = fields.Float(
        string = 'Valor Girado Predios',
    )



    # -------------------
    # methods
    # -------------------
    @api.one
    def _compute_name(self):
        proyecto_name = self.proyecto_id.name[:10] if len(self.proyecto_id.name) >= 10 else self.proyecto_id.name
        self.name = 'Detalle_informe_predio_{}_{}'.format(proyecto_name, self.id)


class project_obra_predios_categoria(models.Model):
    _name = 'project_obra.predios.categoria'
    _description = 'Categoria Predios - Proyecto Obra'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        track_visibility='onchange',
        size=50,
    )


class project_obra_predios_estado(models.Model):
    _name = 'project_obra.predios.estado'
    _description = 'Estados Predios - Proyecto Obra'
    _inherit = ['mail.thread', 'models.soft_delete.mixin']

    # -------------------
    # Fields
    # -------------------
    name = fields.Char(
        string='Nombre',
        required=True,
        track_visibility='onchange',
        size=50,
    )

