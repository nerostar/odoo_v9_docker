# -*- coding: utf-8 -*-
# -*- encoding: utf-8 -*-

from openerp import models, fields, api
from openerp.exceptions import Warning
import xlrd    #sudo pip install xlrd
import base64
import logging
from unicodedata import normalize, category
from datetime import datetime
import json
import os


logging.basicConfig()
_logger = logging.getLogger('INFO')


def normaliza(cadena):
    u = u'{}'.format(cadena.lower())
    vocmap = {ord(c): ord(t) for c, t in zip(u"áéíóúñ", u"aeioun")}
    res = u.translate(vocmap)
    return " ".join(res.split())

class project_obra_transmi_idu_importar_pagos_wizard(models.TransientModel):
    _name = 'project_obra_seguimiento_dtdp.wizard.importar_datos_xls'

    archivo = fields.Binary(
        string = 'Archivo',
        required = True,
        help = 'Archivo xls a importar.',
    )
    archivo_filename = fields.Char(
        string = 'Archivo nombre',
    )
    fecha_inicio = fields.Date(
        string='Fecha Inicio',
        required=True,
        help='Periodo de reporte Fecha Inicio',
    )
    fecha_fin = fields.Date(
        string='Fecha Fin',
        required=True,
        help='Periodo de reporte Fecha Fin',
    )


    @api.multi
    def action_create(self):

        proyecto_model = self.env['project_obra.proyecto']
        informe_model = self.env['project_obra.predios.informe_avance']
        detalle_predio_model = self.env['project_obra.predios.informe_avance.detalle_predio']
        estado_model = self.env['project_obra.predios.estado']
        categoria_model = self.env['project_obra.predios.categoria']

        #Documento borrar al final
        fuente = '/tmp/archivo_datos_predios_{}.xlsx'.format(self.id)
        archivo = base64.decodestring(self.archivo)
        archivo_ = open(fuente,'wb')
        archivo_.write(archivo)
        archivo_.close()
        doc = xlrd.open_workbook(fuente)

        #hoja 1
        hoja1 = doc.sheet_by_name('ZIPA')
        columnas = hoja1.ncols
        filas = hoja1.nrows

        fila_inicial = 0
        for fila in range(filas):
            if hoja1.cell_value(fila, 0) == 'PROYECTO':
                fila_inicial = fila
                break

        headers = []
        for col in range(columnas):
            headers.append(hoja1.cell_value(fila_inicial,col))

        fila_inicial += 1

        datos_dicc = {}

        informe_dicc = {
            'archivo': self.archivo,
            'archivo_filename': self.archivo_filename,
            'fecha_inicio': self.fecha_inicio,
            'fecha_fin': self.fecha_fin
        }
        informe = informe_model.create(informe_dicc)
        
        predios_valor = {}

        for fila in range(fila_inicial,filas):
            try:
                proyecto_nombre = hoja1.cell_value(fila, headers.index("PROYECTO")) if 'PROYECTO' in headers else ''                                    # ======== PROYECTO
                proyecto_id = int(hoja1.cell_value(fila, headers.index("COD ZIPA"))) if 'COD ZIPA' in headers else ''                                   # ======== COD ZIPA
                rt = hoja1.cell_value(fila, headers.index("RT")) if 'RT' in headers else ''                                                             # ======== RT
                categoria_nombre = hoja1.cell_value(fila, headers.index("CATEGORIA")) if 'CATEGORIA' in headers else ''                                 # ======== CATEGORIA
                estado_nombre = hoja1.cell_value(fila, headers.index("ESTADO")) if 'ESTADO' in headers else ''                                          # ======== ESTADO
                fecha_estimada = hoja1.cell_value(fila, headers.index("FECHA ESTIMADA DE ENTREGA")) if 'FECHA ESTIMADA DE ENTREGA' in headers else ''   # ======== FECHA ESTIMADA DE ENTREGA
                unidades_sociales = hoja1.cell_value(fila, headers.index("UNIDADES SOCIALES")) if 'UNIDADES SOCIALES' in headers else 0.0               # ======== UNIDADES SOCIALES
                observaciones = hoja1.cell_value(fila, headers.index("OBSERVACIONES")) if 'OBSERVACIONES' in headers else 0.0                           # ======== OBSERVACIONES
                valor_estimado_predios = hoja1.cell_value(fila, headers.index("Valor Estimado de Predios")) if 'Valor Estimado de Predios' in headers else 0.0
                valor_ejecutado_predios = hoja1.cell_value(fila, headers.index("Valor Ejecutado de Predios")) if 'Valor Ejecutado de Predios' in headers else 0.0
                valor_girado_predios = hoja1.cell_value(fila, headers.index("Valor Girado de Predios")) if 'Valor Girado de Predios' in headers else 0.0

#                 if proyecto_id in predios_valor and type(predios_valor[proyecto_id]) == list:
#                     if valor_estimado_predios and valor_estimado_predios > 0:
#                         predios_valor[proyecto_id][0] = valor_estimado_predios
#                     if valor_ejecutado_predios and valor_ejecutado_predios > 0:
#                         predios_valor[proyecto_id][1] = valor_ejecutado_predios
#                     if valor_girado_predios and valor_girado_predios > 0:
#                         predios_valor[proyecto_id][2] = valor_girado_predios
#                 else:
#                     if ((valor_estimado_predios and valor_estimado_predios > 0) and (valor_ejecutado_predios and valor_ejecutado_predios > 0) and (valor_girado_predios and valor_girado_predios > 0)):
#                         predios_valor[proyecto_id] = [valor_estimado_predios, valor_ejecutado_predios, valor_girado_predios]

                categoria = ''
                estado = ''

                if fecha_estimada:
                    fecha_estimada = datetime(*xlrd.xldate_as_tuple(fecha_estimada, doc.datemode)).strftime('%Y-%m-%d')

                if categoria_nombre:
                    categoria = categoria_model.search([('name','=',categoria_nombre)])
                    if categoria:
                        categoria = categoria[0]
                    else:
                        categoria = categoria_model.create({'name': categoria_nombre})

                if estado_nombre:
                    estado = estado_model.search([('name','=',estado_nombre)])
                    if estado:
                        estado = estado[0]
                    else:
                        estado = estado_model.create({'name': estado_nombre})

                proyecto = proyecto_model.browse([proyecto_id])
                if proyecto:
                    proyecto = proyecto[0]
                    rt_int = ''
                    if rt:
                        try:
                            rt_int = int(rt)
                        except:
                            rt_int = rt
                    datos_dicc = {
                        'project_obra_predios_informe_avance_id': informe.id,
                        'proyecto_id': int(proyecto.id),
                        'rt': rt_int,
                        'categoria_id': categoria.id,
                        'estado_id': estado.id,
                        'fecha_estimada_entrega': fecha_estimada or False,
                        'cantidad_unidades_sociales': int(unidades_sociales) if unidades_sociales else 0,
                        'observaciones': observaciones,
                        'valor_estimado_predios': valor_estimado_predios,
                        'valor_ejecutado_predios': valor_ejecutado_predios,
                        'valor_girado_predios': valor_girado_predios,
                    }
                    ctx = {'mail_notrack': True, 'mail_create_nosubscribe': True, 'tracking_disable': True}
                    try:
                        detalle_predio_model.with_context(ctx).create(datos_dicc)    #Sin mensajes para que importe más rápido
                        #detalle_predio_model.create(datos_dicc)
                    except:
                        msg = "Error creando registro de project_obra.predios.informe_avance.detalle_predio, por favor contácte el administrador del sistema."
                        _logger.error(msg, exc_info=True)
                        raise Warning(msg)
            except:
                msg = "Error leyendo el archivo Excel, por favor verifique los datos y los formatos de los datos."
                _logger.error(msg, exc_info=True)
                raise Warning(msg)


        proyectos_ids_lista = []
        for fila in range(fila_inicial,filas):
            proyectos_ids_lista.append(int(hoja1.cell_value(fila, headers.index("COD ZIPA"))))
        proyectos_ids_lista = list(set(proyectos_ids_lista))

        #Se actualizan los datos de predios en los proyectos:
        for proyecto_id in proyectos_ids_lista:
            predios_entregados = detalle_predio_model.search_count([('proyecto_id','=',proyecto_id),('categoria_id.name','=','ENTREGADO AL CONTRATISTA'),('project_obra_predios_informe_avance_id','=',informe.id)])
            predios_pendientes = detalle_predio_model.search_count([('proyecto_id','=',proyecto_id),('categoria_id.name','=','PENDIENTE'),('project_obra_predios_informe_avance_id','=',informe.id)])
            predios_disponibles = detalle_predio_model.search_count([('proyecto_id','=',proyecto_id),('categoria_id.name','=','DISPONIBLE'),('project_obra_predios_informe_avance_id','=',informe.id)])
            predios_requeridos = predios_entregados + predios_pendientes + predios_disponibles
            proyecto = proyecto_model.sudo().browse([proyecto_id])
            if proyecto:
                proyecto[0].indicador_predios_requeridos = predios_requeridos
                proyecto[0].indicador_predios_entregados = predios_entregados
                proyecto[0].indicador_predios_disponibles = predios_disponibles
                proyecto[0].indicador_predios_pendientes = predios_pendientes
                detalles_avance_predio_proyecto = detalle_predio_model.search([('proyecto_id','=',proyecto_id),('project_obra_predios_informe_avance_id','=',informe.id)])
                indicador_predios_valor_estimado = sum(detalle.valor_estimado_predios for detalle in detalles_avance_predio_proyecto)
                indicador_predios_valor_ejecutado = sum(detalle.valor_ejecutado_predios for detalle in detalles_avance_predio_proyecto)
                indicador_predios_valor_girado = sum(detalle.valor_girado_predios for detalle in detalles_avance_predio_proyecto)

                proyecto[0].indicador_predios_valor_estimado = indicador_predios_valor_estimado
                proyecto[0].indicador_predios_valor_ejecutado = indicador_predios_valor_ejecutado
                proyecto[0].indicador_predios_valor_girado = indicador_predios_valor_girado


        #Se elimina el temporal creado
        if os.path.exists(fuente):
            os.remove(fuente)

        return {
            'type': 'ir.actions.act_window',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'project_obra.predios.informe_avance',
            'res_id': informe.id,
        }
