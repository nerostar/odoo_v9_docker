{
    'name': 'Website Sala Transparente',
    'version': '1.0',
    'depends': [
        'base',
        'website',
        'project_obra_portafolio_idu',
    ],
    'author': "Grupo de Investigación, Desarrollo e Innovación - STRT - IDU",
    'category': 'IDU',
    'data': [
        'views/main_templates.xml',
        'views/config_view.xml',
    ],
    'installable': True,
    'description': """
Sitio Web para IDU Transparente
    """,
}

